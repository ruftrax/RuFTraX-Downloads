#!/bin/zsh
set -euo pipefail

PACKAGE_DIR="${0:A:h}"
SOURCE_DIR="$PACKAGE_DIR/Source"
BUILD_DIR="$SOURCE_DIR/build-v0.5.2"
LOG_FILE="$HOME/Desktop/RuFTraX_CD_Imager_v0.5.2_Install.log"
INSTALL_DIR="$HOME/Applications"
INSTALL_APP="$INSTALL_DIR/RuFTraX CD Imager.app"
SUPPORT_DIR="$HOME/Library/Application Support/RuFTraX/CD Imager"
BACKUP_ROOT="$HOME/Library/Application Support/RuFTraX/Backups/CD Imager"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"

exec > >(tee "$LOG_FILE") 2>&1

fail()
{
    print
    print "INSTALL FAILED"
    print "$1"
    print
    print "Log: $LOG_FILE"
    exit 1
}

print "RuFTraX CD Imager v0.5.2 FINAL"
print "Build and Install"
print

JUCE_PATH="${JUCE_DIR:-}"
if [[ -z "$JUCE_PATH" || ! -f "$JUCE_PATH/CMakeLists.txt" ]]; then
    for candidate in "$HOME/JUCE" "$HOME/Downloads/JUCE"; do
        if [[ -f "$candidate/CMakeLists.txt" ]]; then
            JUCE_PATH="$candidate"
            break
        fi
    done
fi

[[ -n "$JUCE_PATH" && -f "$JUCE_PATH/CMakeLists.txt" ]] \
    || fail "JUCE was not found. Install JUCE in $HOME/JUCE, then run this installer again."

if ! command -v cmake >/dev/null 2>&1; then
    if command -v brew >/dev/null 2>&1; then
        brew install cmake
    else
        fail "CMake was not found. Install Homebrew and run: brew install cmake"
    fi
fi

if ! command -v ddrescue >/dev/null 2>&1; then
    if command -v brew >/dev/null 2>&1; then
        brew install ddrescue
    else
        fail "GNU ddrescue was not found. Install Homebrew and run: brew install ddrescue"
    fi
fi

chmod +x "$SOURCE_DIR/Scripts/"*.sh
"$SOURCE_DIR/Scripts/validate_release_source.sh"

export JUCE_DIR="$JUCE_PATH"

print "JUCE: $JUCE_DIR"
print "Build: $BUILD_DIR"

cmake -S "$SOURCE_DIR" -B "$BUILD_DIR" \
    -DCMAKE_BUILD_TYPE=Release \
    -DJUCE_DIR="$JUCE_DIR"
cmake --build "$BUILD_DIR" --config Release -j 4

BUILT_APP="$BUILD_DIR/RuFTraXCDImager_artefacts/Release/RuFTraX CD Imager.app"
[[ -d "$BUILT_APP" ]] || fail "The built application was not found: $BUILT_APP"

BINARY="$BUILT_APP/Contents/MacOS/RuFTraX CD Imager"
[[ -x "$BINARY" ]] || fail "The application binary was not found."

xattr -cr "$BUILT_APP"
codesign --force --deep --sign - "$BUILT_APP"
codesign --verify --deep --strict --verbose=2 "$BUILT_APP"

mkdir -p "$INSTALL_DIR" "$SUPPORT_DIR" "$BACKUP_ROOT"

if [[ -d "$INSTALL_APP" ]]; then
    BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"
    mkdir -p "$BACKUP_DIR"
    ditto "$INSTALL_APP" "$BACKUP_DIR/RuFTraX CD Imager.app"
    print "Existing CD Imager backed up to:"
    print "  $BACKUP_DIR"
fi

ditto "$BUILT_APP" "$INSTALL_APP"
mkdir -p "$SUPPORT_DIR/Scripts" "$SUPPORT_DIR/Logs" \
    "$SUPPORT_DIR/Checksums" "$SUPPORT_DIR/Reports"
ditto "$SOURCE_DIR/Scripts" "$SUPPORT_DIR/Scripts"
chmod +x "$SUPPORT_DIR/Scripts/"*.sh

xattr -cr "$INSTALL_APP"
codesign --verify --deep --strict --verbose=2 "$INSTALL_APP"

print
print "INSTALL COMPLETE"
print "Installed: $INSTALL_APP"
print "Support files: $SUPPORT_DIR"
print "Log: $LOG_FILE"
print

open "$INSTALL_APP"
