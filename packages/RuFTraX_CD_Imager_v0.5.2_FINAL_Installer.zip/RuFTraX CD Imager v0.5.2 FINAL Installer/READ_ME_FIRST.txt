RuFTraX CD Imager v0.5.2 FINAL
================================

This is the fully rebranded RuFTraX optical-disc imaging application.
Third-party manufacturer branding and trademark symbols have been removed
from the application name, interface, bundle identifier, scripts, reports,
folders, and release package.

INSTALL

1. Double-click INSTALL_RUFTRAX_CD_IMAGER.command.
2. If macOS asks, allow Terminal to run it.
3. The installer builds the application, installs its imaging scripts,
   places the app in your user Applications folder, and opens it.

INSTALL LOCATION

~/Applications/RuFTraX CD Imager.app

SUPPORT LOCATION

~/Library/Application Support/RuFTraX/CD Imager

DEFAULT IMAGE LOCATION

~/Documents/RuFTraX CD Imager/Images

INSTALL LOG

~/Desktop/RuFTraX_CD_Imager_v0.5.2_Install.log

REQUIREMENTS

- macOS
- JUCE in ~/JUCE or ~/Downloads/JUCE
- CMake
- GNU ddrescue

The installer can use Homebrew to install CMake or ddrescue when Homebrew is
already available.
