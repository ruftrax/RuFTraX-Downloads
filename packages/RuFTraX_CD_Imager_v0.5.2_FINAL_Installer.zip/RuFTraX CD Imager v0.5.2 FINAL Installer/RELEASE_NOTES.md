# RuFTraX CD Imager v0.5.2 FINAL

## Current JUCE bounds correction

- Uses floating-point constants for the `userBounds` fit-screen calculation.
- Resolves the `jmax` template type mismatch reported by AppleClang.
- Replaces the v0.5.1 package that stopped while compiling `Main.cpp`.

## Build correction

- Uses an explicit empty `juce::File` assignment compatible with current JUCE.
- Uses the current JUCE display `userBounds` API.
- Replaces the v0.5.0 package that stopped during C++ compilation.

This release establishes the manufacturer-neutral RuFTraX CD Imager identity.

## Rebrand

- Product renamed to RuFTraX CD Imager.
- Interface artwork now uses only RuFTraX branding.
- Bundle identifier changed to `com.ruftrax.cdimager`.
- Application, source target, scripts, folders, reports, logs, and package names updated.
- Third-party manufacturer branding and trademark symbols removed.

## Preserved imaging workflow

- Automatic Mode 1 optical-disc detection.
- GNU ddrescue two-pass imaging.
- Selected output-folder handling.
- Recoverable partial-image and map workflow.
- Exact byte-count verification.
- SHA-256 checksum generation.
- Imaging report generation.
- Scalable vintage RuFTraX interface with remembered view size.

## Installation

Double-click `INSTALL_RUFTRAX_CD_IMAGER.command`.

The installer builds and ad-hoc signs the application locally. Developer ID
signing and notarization are still required for unrestricted public distribution.
