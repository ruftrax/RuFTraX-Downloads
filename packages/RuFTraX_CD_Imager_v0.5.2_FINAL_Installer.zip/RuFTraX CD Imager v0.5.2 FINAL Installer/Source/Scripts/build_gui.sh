#!/bin/zsh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ -z "${JUCE_DIR:-}" ]]; then
    if [[ -f "$HOME/JUCE/CMakeLists.txt" ]]; then
        export JUCE_DIR="$HOME/JUCE"
    else
        echo "ERROR: Set JUCE_DIR first. Example:"
        echo 'export JUCE_DIR="$HOME/JUCE"'
        exit 1
    fi
fi

command -v cmake >/dev/null || {
    echo "ERROR: cmake was not found. Install it with: brew install cmake"
    exit 1
}

command -v ddrescue >/dev/null || {
    echo "ERROR: ddrescue was not found. Install it with: brew install ddrescue"
    exit 1
}

BUILD_DIR="$ROOT/build-v0.5.2"
cmake -S . -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release -DJUCE_DIR="$JUCE_DIR"
cmake --build "$BUILD_DIR" --config Release -j 4

APP="$BUILD_DIR/RuFTraXCDImager_artefacts/Release/RuFTraX CD Imager.app"
if [[ ! -d "$APP" ]]; then
    echo "ERROR: Build completed, but the app was not found at:"
    echo "$APP"
    exit 1
fi

echo
echo "Build complete:"
echo "$APP"
open "$APP"
