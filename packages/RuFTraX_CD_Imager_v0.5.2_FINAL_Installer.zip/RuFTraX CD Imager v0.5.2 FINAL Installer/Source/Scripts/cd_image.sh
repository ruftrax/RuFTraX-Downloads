#!/bin/zsh

set -euo pipefail

SCRIPT_DIR="${0:A:h}"
if [[ $# -lt 1 || $# -gt 2 ]]; then
    echo "Usage: zsh Scripts/cd_image.sh \"Disc Name\" [output-folder]"
    exit 1
fi

DISC_NAME="$1"
OUTPUT_FOLDER="${2:-$HOME/Documents/RuFTraX CD Imager/Images}"

safe_name="$(
    printf '%s' "$DISC_NAME" |
    tr '[:space:]' '_' |
    tr -cd '[:alnum:]_.-'
)"

if [[ -z "$safe_name" ]]; then
    echo "ERROR: Disc name contains no usable characters."
    exit 1
fi

detection="$("$SCRIPT_DIR/find_mode1_cd.sh")"
source_device="${detection%%|*}"
disc_size="${detection#*|}"

echo
echo "Detected Mode 1 CD:"
echo "Device: $source_device"
echo "Size:   $disc_size"
echo "Name:   $safe_name"
echo

zsh "$SCRIPT_DIR/create_cd_image.sh" \
    "$source_device" \
    "$safe_name" \
    "$OUTPUT_FOLDER"
