#!/bin/zsh

set -euo pipefail

SCRIPT_DIR="${0:A:h}"
PROJECT_ROOT="${SCRIPT_DIR:h}"
LOG_DIR="$PROJECT_ROOT/Logs"
CHECKSUM_DIR="$PROJECT_ROOT/Checksums"
REPORT_DIR="$PROJECT_ROOT/Reports"

mkdir -p "$LOG_DIR" "$CHECKSUM_DIR" "$REPORT_DIR"

if [[ $# -ne 3 ]]; then
    echo "Usage: $0 <source-device> <disc-name> <output-folder>"
    echo "Example:"
    echo "$0 /dev/rdisk5s0 CD_Image_001 \"$HOME/Desktop\""
    exit 1
fi

SOURCE_DEVICE="$1"
DISC_NAME="$2"
OUTPUT_FOLDER="$3"

if [[ "$SOURCE_DEVICE" != /dev/rdisk* ]]; then
    echo "ERROR: Source must be a raw macOS device such as /dev/rdisk5s0."
    exit 1
fi

if [[ -z "$DISC_NAME" ]]; then
    echo "ERROR: Disc name is empty."
    exit 1
fi

DISK_ID="${SOURCE_DEVICE#/dev/r}"
WHOLE_DISK="${DISK_ID%s[0-9]*}"

if [[ "$WHOLE_DISK" == "disk0" ]]; then
    echo "ERROR: Refusing to use the startup disk."
    exit 1
fi

if ! /usr/sbin/diskutil info "$SOURCE_DEVICE" >/dev/null 2>&1; then
    echo "ERROR: Device does not exist: $SOURCE_DEVICE"
    exit 1
fi

mkdir -p "$OUTPUT_FOLDER"

ISO_PATH="$OUTPUT_FOLDER/$DISC_NAME.iso"
TEMP_PATH="$OUTPUT_FOLDER/$DISC_NAME.partial.iso"
MAP_PATH="$LOG_DIR/$DISC_NAME.map"
SHA_PATH="$CHECKSUM_DIR/$DISC_NAME.sha256"
REPORT_PATH="$REPORT_DIR/$DISC_NAME-report.txt"
DEBUG_PATH="$LOG_DIR/$DISC_NAME-debug.log"

exec > >(tee "$DEBUG_PATH") 2>&1

echo
echo "RuFTraX CD Imager 0.5.2"
echo "Source: $SOURCE_DEVICE"
echo "Temporary image: $TEMP_PATH"
echo "Final image: $ISO_PATH"
echo

if [[ -e "$ISO_PATH" ]]; then
    echo "ERROR: The final image already exists:"
    echo "$ISO_PATH"
    echo "Choose a different disc name or move the existing image."
    exit 2
fi

if [[ -e "$TEMP_PATH" && ! -e "$MAP_PATH" ]]; then
    echo "ERROR: A partial image exists without its ddrescue map:"
    echo "$TEMP_PATH"
    echo "Move that partial file before starting again."
    exit 3
fi

if [[ ! -e "$TEMP_PATH" && -e "$MAP_PATH" ]]; then
    echo "Removing stale map because no partial image exists:"
    echo "$MAP_PATH"
    rm -f "$MAP_PATH"
fi

EXPECTED_BYTES="$(
    /usr/sbin/diskutil info "$SOURCE_DEVICE" |
    awk -F'[()]' '
        /Disk Size:/ {
            value=$2
            gsub(/[^0-9]/, "", value)
            print value
            exit
        }
    '
)"

if [[ -z "$EXPECTED_BYTES" || "$EXPECTED_BYTES" -le 0 ]]; then
    echo "ERROR: Could not determine the exact source size."
    exit 4
fi

echo "Expected bytes: $EXPECTED_BYTES"

read "REPLY?Type IMAGE to continue: "

if [[ "$REPLY" != "IMAGE" ]]; then
    echo "Cancelled."
    exit 5
fi

/usr/sbin/diskutil unmountDisk "/dev/$WHOLE_DISK" || true

echo
echo "Administrator authorization is required to read the optical device."
sudo -v

DDRESCUE="$(command -v ddrescue || true)"
DDRESCUELOG="$(command -v ddrescuelog || true)"

if [[ -z "$DDRESCUE" ]]; then
    echo "ERROR: GNU ddrescue is not installed."
    echo "Install it with: brew install ddrescue"
    exit 6
fi

echo
echo "Pass 1: fast recovery"
sudo "$DDRESCUE" \
    --sector-size=2048 \
    --no-scrape \
    "$SOURCE_DEVICE" \
    "$TEMP_PATH" \
    "$MAP_PATH"

echo
echo "Pass 2: retry unread sectors"
sudo "$DDRESCUE" \
    --sector-size=2048 \
    --retry-passes=3 \
    "$SOURCE_DEVICE" \
    "$TEMP_PATH" \
    "$MAP_PATH"

sudo chown "$(id -u):$(id -g)" "$TEMP_PATH" "$MAP_PATH" 2>/dev/null || true

ACTUAL_BYTES="$(stat -f "%z" "$TEMP_PATH" 2>/dev/null || echo 0)"

echo
echo "Expected bytes: $EXPECTED_BYTES"
echo "Actual bytes:   $ACTUAL_BYTES"

if [[ "$ACTUAL_BYTES" != "$EXPECTED_BYTES" ]]; then
    echo "ERROR: The image size does not match the source."
    echo "The partial image and map were preserved so imaging can resume."
    exit 7
fi

mv "$TEMP_PATH" "$ISO_PATH"

shasum -a 256 "$ISO_PATH" | tee "$SHA_PATH"

{
    echo "RuFTraX CD Image Report"
    echo "Created: $(date)"
    echo "Source: $SOURCE_DEVICE"
    echo "Image: $ISO_PATH"
    echo
    echo "Image size:"
    stat -f "%z bytes" "$ISO_PATH"
    echo
    echo "Expected size:"
    echo "$EXPECTED_BYTES bytes"
    echo
    echo "SHA-256:"
    cat "$SHA_PATH"
    echo
    echo "ddrescue status:"

    if [[ -n "$DDRESCUELOG" ]]; then
        "$DDRESCUELOG" --show-status "$MAP_PATH"
    else
        echo "ddrescuelog was not found."
    fi
} | tee "$REPORT_PATH"

echo
echo "IMAGE COMPLETE"
echo "$ISO_PATH"
