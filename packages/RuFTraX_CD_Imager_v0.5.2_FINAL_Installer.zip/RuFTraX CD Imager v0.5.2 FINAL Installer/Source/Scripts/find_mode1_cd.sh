#!/bin/zsh

set -euo pipefail

device="$(
    diskutil list |
    awk '/CD_ROM_Mode_1/ {
        print "/dev/r" $NF
        exit
    }'
)"

if [[ -z "$device" ]]; then
    echo "ERROR: No Mode 1 CD-ROM was detected." >&2
    exit 1
fi

normal_device="/dev/${device#/dev/r}"

if ! diskutil info "$normal_device" >/dev/null 2>&1; then
    echo "ERROR: Detected device is not accessible: $normal_device" >&2
    exit 1
fi

size="$(
    diskutil info "$normal_device" |
    awk -F: '/Disk Size/ {
        sub(/^[ \t]+/, "", $2)
        print $2
        exit
    }'
)"

echo "${device}|${size:-Unknown size}"
