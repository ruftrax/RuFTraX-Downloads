#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
SOURCE_ROOT="${SCRIPT_DIR:h}"

fail()
{
    print "VALIDATION FAILED: $1"
    exit 1
}

required_files=(
    "$SOURCE_ROOT/CMakeLists.txt"
    "$SOURCE_ROOT/Source/Main.cpp"
    "$SOURCE_ROOT/Source/MainComponent.cpp"
    "$SOURCE_ROOT/Source/MainComponent.h"
    "$SOURCE_ROOT/Source/ImagingEngine.cpp"
    "$SOURCE_ROOT/Source/ImagingEngine.h"
    "$SOURCE_ROOT/Source/VintageLookAndFeel.cpp"
    "$SOURCE_ROOT/Source/VintageLookAndFeel.h"
    "$SOURCE_ROOT/Assets/AppIcon.png"
    "$SOURCE_ROOT/Scripts/build_gui.sh"
    "$SOURCE_ROOT/Scripts/create_cd_image.sh"
    "$SOURCE_ROOT/Scripts/find_mode1_cd.sh"
    "$SOURCE_ROOT/Scripts/cd_image.sh"
)

for file in "${required_files[@]}"; do
    [[ -s "$file" ]] || fail "Missing or empty file: $file"
done

grep -q 'project(RuFTraXCDImager VERSION 0.5.2' "$SOURCE_ROOT/CMakeLists.txt" \
    || fail "CMake product or version is incorrect"
grep -q 'PRODUCT_NAME "RuFTraX CD Imager"' "$SOURCE_ROOT/CMakeLists.txt" \
    || fail "Product name is incorrect"
grep -q 'BUNDLE_ID "com.ruftrax.cdimager"' "$SOURCE_ROOT/CMakeLists.txt" \
    || fail "Bundle identifier is incorrect"
grep -Fq 'ICON_BIG "${CMAKE_CURRENT_SOURCE_DIR}/Assets/AppIcon.png"' "$SOURCE_ROOT/CMakeLists.txt" \
    || fail "Finder application icon is not connected to the build"
grep -q 'getApplicationName() override.*RuFTraX CD Imager' "$SOURCE_ROOT/Source/Main.cpp" \
    || fail "Application name is incorrect"
grep -q 'getApplicationVersion() override.*0.5.2' "$SOURCE_ROOT/Source/Main.cpp" \
    || fail "Application version is incorrect"
grep -q 'create_cd_image.sh' "$SOURCE_ROOT/Source/ImagingEngine.cpp" \
    || fail "The generic imaging engine script is not connected"
grep -q 'getChildFile("Application Support")' "$SOURCE_ROOT/Source/ImagingEngine.cpp" \
    || fail "The installed support-script location is not connected"
grep -q 'RuFTraX CD Image Report' "$SOURCE_ROOT/Source/ImagingEngine.cpp" \
    || fail "The report branding is incorrect"

legacy_brand="$(printf '\101\113\101\111')"
if LC_ALL=C grep -RIni "$legacy_brand" "$SOURCE_ROOT" >/dev/null 2>&1; then
    fail "Legacy manufacturer branding remains in the source"
fi

if LC_ALL=C grep -RIn $'\302\256\|\342\204\242' "$SOURCE_ROOT" >/dev/null 2>&1; then
    fail "Trademark symbols remain in the source"
fi

grep -q 'projectRoot = juce::File();' "$SOURCE_ROOT/Source/ImagingEngine.cpp" \
    || fail "JUCE File reset is not explicit"
grep -q 'display->userBounds' "$SOURCE_ROOT/Source/Main.cpp" \
    || fail "Current JUCE display bounds API is not used"
grep -q 'jmax(1.0f, area.getWidth() - 40.0f)' "$SOURCE_ROOT/Source/Main.cpp" \
    || fail "Display width calculation does not use matching float types"
grep -q 'jmax(1.0f, area.getHeight() - 80.0f)' "$SOURCE_ROOT/Source/Main.cpp" \
    || fail "Display height calculation does not use matching float types"

print "RuFTraX CD Imager v0.5.2 source validation passed."
