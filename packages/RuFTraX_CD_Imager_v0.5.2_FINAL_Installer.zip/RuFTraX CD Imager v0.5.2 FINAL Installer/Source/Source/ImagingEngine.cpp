#include "ImagingEngine.h"

ImagingEngine::ImagingEngine() = default;

ImagingEngine::~ImagingEngine()
{
    stopTimer();

    if (process && process->isRunning())
        process->kill();
}

void ImagingEngine::addListener(Listener* listener)
{
    listeners.add(listener);
}

void ImagingEngine::removeListener(Listener* listener)
{
    listeners.remove(listener);
}

bool ImagingEngine::isBusy() const noexcept
{
    return state == State::imaging || state == State::verifying;
}

ImagingEngine::State ImagingEngine::getState() const noexcept
{
    return state;
}

juce::File ImagingEngine::getLastReport() const
{
    return reportFile;
}

juce::String ImagingEngine::shellQuote(const juce::String& text)
{
    return "'" + text.replace("'", "'\\''") + "'";
}

juce::String ImagingEngine::appleScriptQuote(const juce::String& text)
{
    return text.replace("\\", "\\\\").replace("\"", "\\\"");
}

int64_t ImagingEngine::parseBytes(const juce::String& text)
{
    const auto open = text.indexOfChar('(');
    const auto bytesPosition = text.indexOfIgnoreCase(" Bytes");

    if (open >= 0 && bytesPosition > open)
        return text.substring(open + 1, bytesPosition)
                   .retainCharacters("0123456789")
                   .getLargeIntValue();

    return 0;
}

ImagingEngine::DiscInfo ImagingEngine::detectDisc() const
{
    DiscInfo result;
    juce::ChildProcess list;

    if (!list.start({ "/usr/sbin/diskutil", "list" }))
        return result;

    list.waitForProcessToFinish(5000);

    juce::StringArray lines;
    lines.addLines(list.readAllProcessOutput());

    juce::String identifier;

    for (auto& line : lines)
    {
        if (!line.contains("CD_ROM_Mode_1"))
            continue;

        juce::StringArray tokens;
        tokens.addTokens(line, " \t", "");

        if (!tokens.isEmpty())
            identifier = tokens[tokens.size() - 1];

        break;
    }

    if (identifier.isEmpty())
        return result;

    result.normalDevice = "/dev/" + identifier;
    result.rawDevice = "/dev/r" + identifier;

    juce::ChildProcess info;

    if (!info.start({ "/usr/sbin/diskutil", "info", result.normalDevice }))
        return result;

    info.waitForProcessToFinish(5000);

    juce::StringArray infoLines;
    infoLines.addLines(info.readAllProcessOutput());

    for (auto& line : infoLines)
    {
        if (!line.trimStart().startsWith("Disk Size:"))
            continue;

        result.sizeDescription =
            line.fromFirstOccurrenceOf(":", false, false).trim();
        result.sizeBytes = parseBytes(result.sizeDescription);
        break;
    }

    result.valid = result.sizeBytes > 0;
    return result;
}

bool ImagingEngine::startImaging(const DiscInfo& disc,
                                 const juce::String& discName,
                                 const juce::File& requestedOutputFolder)
{
    if (isBusy() || !disc.valid || discName.trim().isEmpty())
        return false;

    auto safeName =
        discName.trim()
                .replaceCharacters(" ", "_")
                .retainCharacters(
                    "abcdefghijklmnopqrstuvwxyz"
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    "0123456789_.-");

    if (safeName.isEmpty())
        return false;

    auto outputFolder = requestedOutputFolder;

    if (!outputFolder.isDirectory())
    {
        const auto createResult = outputFolder.createDirectory();

        if (createResult.failed())
        {
            finish(false,
                   "Could not create the selected output folder:\n"
                   + outputFolder.getFullPathName()
                   + "\n\n"
                   + createResult.getErrorMessage());
            return false;
        }
    }

    activeDisc = disc;
    activeName = safeName;

    imageFile = outputFolder.getChildFile(safeName + ".iso");
    temporaryImageFile =
        outputFolder.getChildFile(safeName + ".partial.iso");

    if (imageFile.existsAsFile())
    {
        finish(false,
               "An image with this name already exists:\n"
               + imageFile.getFullPathName()
               + "\n\nChoose another disc name or move the existing image.");
        return false;
    }

    auto projectRoot =
        juce::File::getSpecialLocation(
            juce::File::currentExecutableFile)
            .getParentDirectory();

    while (projectRoot != juce::File{}
           && !projectRoot.getChildFile("Scripts")
                          .getChildFile("create_cd_image.sh")
                          .existsAsFile())
    {
        const auto parent = projectRoot.getParentDirectory();
        if (parent == projectRoot)
        {
            projectRoot = juce::File();
            break;
        }
        projectRoot = parent;
    }

    if (projectRoot == juce::File{}
        || !projectRoot.getChildFile("Scripts")
                       .getChildFile("create_cd_image.sh")
                       .existsAsFile())
    {
        projectRoot =
            juce::File::getSpecialLocation(
                juce::File::userApplicationDataDirectory)
                .getChildFile("Application Support")
                .getChildFile("RuFTraX")
                .getChildFile("CD Imager");
    }

    const auto cliScript =
        projectRoot.getChildFile("Scripts")
                   .getChildFile("create_cd_image.sh");

    if (!cliScript.existsAsFile())
    {
        finish(false,
               "Validated imaging script was not found:\n"
               + cliScript.getFullPathName());
        return false;
    }

    const auto jobFolder = projectRoot.getChildFile("Logs");
    jobFolder.createDirectory();

    terminalScriptFile =
        jobFolder.getChildFile(safeName + "-gui-job.sh");
    completionFile =
        jobFolder.getChildFile(safeName + "-gui-result.txt");
    mapFile =
        jobFolder.getChildFile(safeName + ".map");
    debugFile =
        jobFolder.getChildFile(safeName + "-debug.log");
    checksumFile =
        projectRoot.getChildFile("Checksums")
                   .getChildFile(safeName + ".sha256");
    reportFile =
        projectRoot.getChildFile("Reports")
                   .getChildFile(safeName + "-report.txt");

    completionFile.deleteFile();
    terminalScriptFile.deleteFile();

    juce::String job;

    job << "#!/bin/zsh\n"
        << "cd "
        << shellQuote(projectRoot.getFullPathName())
        << " || exit 98\n"
        << "printf 'IMAGE\\n' | /bin/zsh "
        << shellQuote(cliScript.getFullPathName())
        << " "
        << shellQuote(disc.rawDevice)
        << " "
        << shellQuote(safeName)
        << " "
        << shellQuote(outputFolder.getFullPathName())
        << "\n"
        << "RESULT=$?\n"
        << "echo $RESULT > "
        << shellQuote(completionFile.getFullPathName())
        << "\n"
        << "echo\n"
        << "echo 'Return to RuFTraX CD Imager.'\n";

    job = job.replace("\r\n", "\n").replace("\r", "\n");

    auto outputStream = terminalScriptFile.createOutputStream();

    if (outputStream == nullptr)
    {
        finish(false, "Could not create the Terminal imaging job.");
        return false;
    }

    const auto utf8 = job.toUTF8();
    const auto byteCount =
        static_cast<size_t>(utf8.sizeInBytes() - 1);

    if (!outputStream->write(utf8.getAddress(), byteCount))
    {
        finish(false, "Could not write the Terminal imaging job.");
        return false;
    }

    outputStream->flush();
    outputStream.reset();
    terminalScriptFile.setExecutePermission(true);

    const auto terminalCommand =
        "/bin/zsh "
        + shellQuote(terminalScriptFile.getFullPathName());

    const auto appleScript =
        "tell application \"Terminal\"\n"
        "activate\n"
        "do script \"" + appleScriptQuote(terminalCommand) + "\"\n"
        "end tell";

    process = std::make_unique<juce::ChildProcess>();

    if (!process->start({
            "/usr/bin/osascript",
            "-e",
            appleScript
        }))
    {
        finish(false, "Could not launch the imaging job in Terminal.");
        return false;
    }

    process->waitForProcessToFinish(5000);

    const auto launchOutput =
        process->readAllProcessOutput().trim();
    const auto launchExitCode = process->getExitCode();

    if (launchExitCode != 0)
    {
        process.reset();
        finish(false,
               "Terminal launch failed. Exit code: "
               + juce::String(launchExitCode)
               + "\n\n"
               + launchOutput);
        return false;
    }

    process.reset();

    state = State::imaging;
    progress = 0.0;
    lastMessage = "Imaging in Terminal...";

    listeners.call([&](Listener& listener)
    {
        listener.engineStatusChanged(state, lastMessage);
    });

    startTimer(500);
    return true;
}

void ImagingEngine::timerCallback()
{
    if (state != State::imaging)
        return;

    int64_t actualSize = 0;

    if (temporaryImageFile.existsAsFile())
        actualSize = temporaryImageFile.getSize();
    else if (imageFile.existsAsFile())
        actualSize = imageFile.getSize();

    progress =
        activeDisc.sizeBytes > 0
            ? juce::jlimit(
                0.0,
                1.0,
                static_cast<double>(actualSize)
                    / static_cast<double>(activeDisc.sizeBytes))
            : 0.0;

    listeners.call([&](Listener& listener)
    {
        listener.engineProgressChanged(progress);
    });

    if (!completionFile.existsAsFile())
        return;

    const auto exitCode =
        completionFile.loadFileAsString().trim().getIntValue();

    completionFile.deleteFile();
    process.reset();

    const auto finalSize =
        imageFile.existsAsFile() ? imageFile.getSize() : 0;

    if (exitCode == 0
        && imageFile.existsAsFile()
        && finalSize == activeDisc.sizeBytes)
    {
        beginVerification();
        return;
    }

    juce::String debugDetails;

    if (debugFile.existsAsFile())
    {
        const auto debugText =
            debugFile.loadFileAsString().trim();

        if (debugText.isNotEmpty())
            debugDetails =
                "\n\nLast imaging messages:\n"
                + debugText.getLastCharacters(2400);
    }

    juce::String reason;
    reason << "Terminal imaging job failed.\n"
           << "Exit code: " << juce::String(exitCode) << "\n"
           << "Expected bytes: "
           << juce::String(activeDisc.sizeBytes) << "\n"
           << "Actual bytes: "
           << juce::String(finalSize > 0 ? finalSize : actualSize)
           << "\n"
           << "Output: " << imageFile.getFullPathName()
           << debugDetails;

    finish(false, reason);
}

void ImagingEngine::beginVerification()
{
    state = State::verifying;
    lastMessage = "Calculating SHA-256...";

    listeners.call([&](Listener& listener)
    {
        listener.engineStatusChanged(state, lastMessage);
    });

    stopTimer();

    const auto hash =
        juce::SHA256(imageFile).toHexString();

    checksumFile.replaceWithText(
        hash + "  "
        + imageFile.getFullPathName()
        + "\n");

    juce::String report;
    report << "RuFTraX CD Image Report\n"
           << "Created: "
           << juce::Time::getCurrentTime().toString(true, true)
           << "\n"
           << "Source: " << activeDisc.rawDevice << "\n"
           << "Image: " << imageFile.getFullPathName() << "\n"
           << "Image size: " << juce::String(imageFile.getSize())
           << " bytes\n"
           << "Expected size: "
           << juce::String(activeDisc.sizeBytes)
           << " bytes\n"
           << "SHA-256: " << hash << "\n"
           << "Verification: PASS\n";

    reportFile.replaceWithText(report);

    progress = 1.0;

    listeners.call([&](Listener& listener)
    {
        listener.engineProgressChanged(progress);
    });

    finish(true,
           "Image complete and SHA-256 verified.\n\n"
           + imageFile.getFullPathName());
}

void ImagingEngine::finish(bool ok, const juce::String& message)
{
    stopTimer();
    state = ok ? State::finished : State::failed;
    lastMessage = message;

    listeners.call([&](Listener& listener)
    {
        listener.engineStatusChanged(state, lastMessage);
    });

    listeners.call([&](Listener& listener)
    {
        listener.engineFinished(ok, reportFile, message);
    });
}
