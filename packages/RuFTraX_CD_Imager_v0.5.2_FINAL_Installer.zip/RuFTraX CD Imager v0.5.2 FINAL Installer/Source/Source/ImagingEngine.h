#pragma once
#include <JuceHeader.h>

class ImagingEngine final : private juce::Timer
{
public:
    struct DiscInfo
    {
        bool valid = false;
        juce::String rawDevice;
        juce::String normalDevice;
        juce::String sizeDescription;
        int64_t sizeBytes = 0;
    };

    enum class State { idle, imaging, verifying, finished, failed };

    class Listener
    {
    public:
        virtual ~Listener() = default;
        virtual void engineStatusChanged(State, const juce::String&) = 0;
        virtual void engineProgressChanged(double) = 0;
        virtual void engineFinished(bool, const juce::File&, const juce::String&) = 0;
    };

    ImagingEngine();
    ~ImagingEngine() override;

    DiscInfo detectDisc() const;
    bool startImaging(const DiscInfo&, const juce::String& discName,
                      const juce::File& outputFolder);
    bool isBusy() const noexcept;
    State getState() const noexcept;
    juce::File getLastReport() const;

    void addListener(Listener*);
    void removeListener(Listener*);

private:
    void timerCallback() override;
    void beginVerification();
    void finish(bool ok, const juce::String& message);
    static juce::String shellQuote(const juce::String&);
    static juce::String appleScriptQuote(const juce::String&);
    static int64_t parseBytes(const juce::String&);

    DiscInfo activeDisc;
    juce::String activeName;
    juce::File imageFile, temporaryImageFile, mapFile;
    juce::File checksumFile, reportFile, debugFile;
    juce::File terminalScriptFile, completionFile;
    std::unique_ptr<juce::ChildProcess> process;
    juce::ListenerList<Listener> listeners;
    State state = State::idle;
    double progress = 0.0;
    juce::String lastMessage;
};
