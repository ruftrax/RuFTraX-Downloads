#include <JuceHeader.h>
#include "MainComponent.h"

namespace
{
    constexpr int designWidth  = 1450;
    constexpr int designHeight = 930;

    class ScaledContent final : public juce::Component
    {
    public:
        ScaledContent(MainComponent::ScaleChoiceChanged scaleChoiceChanged,
                      int initialScaleChoice)
            : mainComponent(std::move(scaleChoiceChanged), initialScaleChoice)
        {
            addAndMakeVisible(mainComponent);
            setScaleFactor(1.0f);
        }

        void setScaleFactor(float newScale)
        {
            scaleFactor = juce::jlimit(0.35f, 1.0f, newScale);
            setSize(juce::roundToInt(static_cast<float>(designWidth) * scaleFactor),
                    juce::roundToInt(static_cast<float>(designHeight) * scaleFactor));
            resized();
        }

        void resized() override
        {
            mainComponent.setBounds(0, 0, designWidth, designHeight);
            mainComponent.setTransform(juce::AffineTransform::scale(scaleFactor));
        }

    private:
        MainComponent mainComponent;
        float scaleFactor = 1.0f;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ScaledContent)
    };
}

class RuFTraXCDImagerApplication final : public juce::JUCEApplication
{
public:
    const juce::String getApplicationName() override       { return "RuFTraX CD Imager"; }
    const juce::String getApplicationVersion() override    { return "0.5.2"; }
    bool moreThanOneInstanceAllowed() override             { return false; }

    void initialise(const juce::String&) override
    {
        juce::PropertiesFile::Options options;
        options.applicationName = getApplicationName();
        options.filenameSuffix = "settings";
        options.folderName = "RuFTraX";
        options.osxLibrarySubFolder = "Application Support";
        options.storageFormat = juce::PropertiesFile::storeAsXML;
        applicationProperties.setStorageParameters(options);

        mainWindow = std::make_unique<MainWindow>(getApplicationName(),
                                                  applicationProperties);
    }

    void shutdown() override
    {
        mainWindow.reset();
        applicationProperties.saveIfNeeded();
    }

    void systemRequestedQuit() override
    {
        quit();
    }

    void anotherInstanceStarted(const juce::String&) override {}

private:
    class MainWindow final : public juce::DocumentWindow
    {
    public:
        MainWindow(juce::String name, juce::ApplicationProperties& propertiesToUse)
            : DocumentWindow(std::move(name),
                             juce::Colour::fromRGB(32, 32, 32),
                             DocumentWindow::allButtons),
              properties(propertiesToUse)
        {
            setUsingNativeTitleBar(true);
            setResizable(false, false);

            auto* settings = properties.getUserSettings();
            const int initialChoice = juce::jlimit(
                1, 5, settings != nullptr
                          ? settings->getIntValue("uiScaleChoice", 1)
                          : 1);

            scaledContent = new ScaledContent(
                [this](int choice) { applyScaleChoice(choice, true); },
                initialChoice);

            setContentOwned(scaledContent, true);
            applyScaleChoice(initialChoice, false);
            centreWithSize(getWidth(), getHeight());
            setVisible(true);
        }

        void closeButtonPressed() override
        {
            juce::JUCEApplication::getInstance()->systemRequestedQuit();
        }

    private:
        float getFitScreenScale() const
        {
            const auto& displays = juce::Desktop::getInstance().getDisplays();
            auto* display = displays.getPrimaryDisplay();

            if (display == nullptr)
                return 0.75f;

            const auto area = display->userBounds;
            const auto widthScale =
                juce::jmax(1.0f, area.getWidth() - 40.0f) /
                static_cast<float>(designWidth);
            const auto heightScale =
                juce::jmax(1.0f, area.getHeight() - 80.0f) /
                static_cast<float>(designHeight);

            return juce::jlimit(0.35f, 1.0f,
                                juce::jmin(widthScale, heightScale));
        }

        float scaleForChoice(int choice) const
        {
            switch (choice)
            {
                case 2:  return 0.50f;
                case 3:  return 0.67f;
                case 4:  return 0.75f;
                case 5:  return 1.00f;
                case 1:
                default: return getFitScreenScale();
            }
        }

        void applyScaleChoice(int choice, bool centreWindow)
        {
            choice = juce::jlimit(1, 5, choice);

            if (auto* settings = properties.getUserSettings())
            {
                settings->setValue("uiScaleChoice", choice);
                settings->saveIfNeeded();
            }

            const auto scale = scaleForChoice(choice);
            scaledContent->setScaleFactor(scale);
            setContentComponentSize(scaledContent->getWidth(),
                                    scaledContent->getHeight());

            if (centreWindow)
                centreWithSize(getWidth(), getHeight());
        }

        juce::ApplicationProperties& properties;
        ScaledContent* scaledContent = nullptr;
    };

    juce::ApplicationProperties applicationProperties;
    std::unique_ptr<MainWindow> mainWindow;
};

START_JUCE_APPLICATION(RuFTraXCDImagerApplication)
