#include "MainComponent.h"

namespace
{
    juce::Font bold(float size) { return juce::Font(juce::FontOptions(size, juce::Font::bold)); }
    juce::Font regular(float size) { return juce::Font(juce::FontOptions(size)); }
}

MainComponent::MainComponent(ScaleChoiceChanged scaleChoiceChangedCallback,
                             int initialScaleChoice)
    : onScaleChoiceChanged(std::move(scaleChoiceChangedCallback))
{
    setLookAndFeel(&lookAndFeel);
    setSize(1450, 930);

    for (auto* b : { &refreshButton, &chooseButton, &imageButton, &openReportButton })
    {
        addAndMakeVisible(*b);
        b->addListener(this);
    }

    imageButton.setColour(juce::TextButton::textColourOffId, VintageLookAndFeel::deepRed());
    imageButton.setTooltip("Create a verified CD image");

    for (auto* e : { &discNameEditor, &outputFolderEditor })
    {
        addAndMakeVisible(*e);
        e->setFont(regular(18.0f));
    }

    discNameEditor.setText("CD_Image_001");
    outputFolderEditor.setReadOnly(true);
    outputFolderEditor.setText(
        juce::File::getSpecialLocation(juce::File::userDocumentsDirectory)
            .getChildFile("RuFTraX CD Imager")
            .getChildFile("Images").getFullPathName());

    addAndMakeVisible(scaleLabel);
    scaleLabel.setText("VIEW SIZE", juce::dontSendNotification);
    scaleLabel.setFont(bold(13.0f));
    scaleLabel.setJustificationType(juce::Justification::centred);
    scaleLabel.setColour(juce::Label::textColourId, juce::Colours::black);

    addAndMakeVisible(scaleBox);
    scaleBox.addItem("Fit Screen", 1);
    scaleBox.addItem("50%", 2);
    scaleBox.addItem("67%", 3);
    scaleBox.addItem("75%", 4);
    scaleBox.addItem("100%", 5);
    scaleBox.setSelectedId(juce::jlimit(1, 5, initialScaleChoice),
                           juce::dontSendNotification);
    scaleBox.setTooltip("Scale the entire RuFTraX CD Imager interface");
    scaleBox.setColour(juce::ComboBox::backgroundColourId,
                       juce::Colour::fromRGB(238, 236, 230));
    scaleBox.setColour(juce::ComboBox::textColourId, juce::Colours::black);
    scaleBox.setColour(juce::ComboBox::outlineColourId,
                       juce::Colour::fromRGB(55, 55, 55));
    scaleBox.setColour(juce::ComboBox::arrowColourId,
                       VintageLookAndFeel::deepRed());
    scaleBox.onChange = [this] { scaleChoiceChanged(); };

    for (auto* l : { &deviceValue, &typeValue, &sizeValue, &statusValue,
                     &shaValue, &verifyValue, &reportStatusValue, &reportPathValue,
                     &progressText })
    {
        addAndMakeVisible(*l);
        l->setFont(regular(16.0f));
        l->setColour(juce::Label::textColourId, juce::Colours::black);
    }

    typeValue.setText("CD-ROM (Mode 1)", juce::dontSendNotification);
    progressText.setText("Ready to image", juce::dontSendNotification);

    addAndMakeVisible(progressBar);
    engine.addListener(this);

    refreshDisc();
}

MainComponent::~MainComponent()
{
    engine.removeListener(this);
    setLookAndFeel(nullptr);
}

void MainComponent::paint(juce::Graphics& g)
{
    auto bounds = getLocalBounds().toFloat();
    g.fillAll(juce::Colour::fromRGB(25, 24, 22));

    const float wood = 52.0f;
    juce::ColourGradient woodGrad(juce::Colour::fromRGB(62, 28, 10), 0, 0,
                                  juce::Colour::fromRGB(130, 72, 30), wood, 0, false);
    g.setGradientFill(woodGrad);
    g.fillRect(bounds.removeFromLeft(wood));
    g.fillRect(bounds.removeFromRight(wood));

    juce::ColourGradient metal(VintageLookAndFeel::silverLight(), 0, 0,
                               VintageLookAndFeel::silverMid(), 0, getHeight(), false);
    g.setGradientFill(metal);
    g.fillRoundedRectangle(bounds.reduced(5), 8.0f);

    auto header = juce::Rectangle<float>(70, 45, getWidth() - 140.0f, 245.0f);
    drawPanel(g, header, {});
    drawHeaderArtwork(g, header);

    drawPanel(g, juce::Rectangle<float>(85, 315, 470, 290), "1. SOURCE DISC");
    drawPanel(g, juce::Rectangle<float>(580, 315, 565, 135), "2. DISC NAME");
    drawPanel(g, juce::Rectangle<float>(580, 465, 565, 140), "3. OUTPUT FOLDER");
    drawPanel(g, juce::Rectangle<float>(85, 625, 1060, 125), "4. IMAGE PROGRESS");
    drawPanel(g, juce::Rectangle<float>(85, 765, 1060, 125), "5. VERIFICATION");
    drawPanel(g, juce::Rectangle<float>(1165, 315, 200, 210), "6. REPORT");
    drawPanel(g, juce::Rectangle<float>(1165, 545, 200, 345), {});

    drawLed(g, { 520.0f, 350.0f }, discInfo.valid, juce::Colours::limegreen);
    drawLed(g, { 1265.0f, 780.0f }, engine.isBusy(), VintageLookAndFeel::deepRed());

    g.setColour(juce::Colours::black);
    g.setFont(bold(16.0f));
    g.drawText("DEVICE:", 110, 390, 100, 26, juce::Justification::centredLeft);
    g.drawText("TYPE:",   110, 430, 100, 26, juce::Justification::centredLeft);
    g.drawText("SIZE:",   110, 470, 100, 26, juce::Justification::centredLeft);
    g.drawText("STATUS:", 110, 525, 100, 26, juce::Justification::centredLeft);

    g.drawText("SHA-256:", 110, 810, 110, 24, juce::Justification::centredLeft);
    g.drawText("VERIFY:",  110, 850, 110, 24, juce::Justification::centredLeft);

    g.setFont(bold(18.0f));
    g.drawText("RuFTraX CD Imager", 1185, 825, 170, 26, juce::Justification::centred);
    g.setFont(regular(14.0f));
    g.drawText("Version 0.5.2", 1185, 850, 170, 22, juce::Justification::centred);

    g.setFont(bold(17.0f));
    g.drawText("R U F T R A X   -   P R E S E R V E   T H E   S O U N D",
               250, getHeight() - 34, getWidth() - 500, 24, juce::Justification::centred);
}

void MainComponent::drawPanel(juce::Graphics& g, juce::Rectangle<float> r,
                              const juce::String& title) const
{
    juce::ColourGradient p(VintageLookAndFeel::silverLight(), r.getX(), r.getY(),
                           VintageLookAndFeel::silverMid(), r.getX(), r.getBottom(), false);
    g.setGradientFill(p);
    g.fillRoundedRectangle(r, 16.0f);
    g.setColour(juce::Colours::black.withAlpha(0.85f));
    g.drawRoundedRectangle(r, 16.0f, 2.0f);

    if (title.isNotEmpty())
    {
        g.setFont(bold(18.0f));
        g.setColour(juce::Colours::black);
        g.drawText(title, r.getX() + 20, r.getY() + 10, r.getWidth() - 40, 28,
                   juce::Justification::centredLeft);
    }
}

void MainComponent::drawHeaderArtwork(juce::Graphics& g, juce::Rectangle<float> r) const
{
    g.setColour(juce::Colours::black);
    g.setFont(juce::Font(juce::FontOptions(62.0f, juce::Font::bold)));
    g.drawText("RuFTraX", r.getX() + 40, r.getY() + 40, 340, 90, juce::Justification::centredLeft);
    g.setFont(bold(25.0f));
    g.drawText("SOUND LABS", r.getX() + 42, r.getY() + 128, 340, 35,
               juce::Justification::centredLeft);

    g.setFont(bold(24.0f));
    g.drawText("DIGITAL PRESERVATION SYSTEM", r.getX() + 410, r.getY() + 55, 390, 40,
               juce::Justification::centredLeft);
    g.setColour(VintageLookAndFeel::deepRed());
    g.setFont(bold(38.0f));
    g.drawText("CD IMAGER", r.getX() + 410, r.getY() + 98, 350, 55,
               juce::Justification::centredLeft);
    g.setColour(juce::Colours::black);
    g.setFont(bold(21.0f));
    g.drawText("DISC TO VERIFIED IMAGE", r.getX() + 412, r.getY() + 150, 350, 30,
               juce::Justification::centredLeft);

    auto cd = juce::Rectangle<float>(r.getRight() - 520, r.getY() + 34, 180, 180);
    juce::ColourGradient disc(juce::Colours::white, cd.getCentreX(), cd.getCentreY(),
                              juce::Colour::fromRGB(120, 125, 130), cd.getRight(), cd.getBottom(), true);
    g.setGradientFill(disc);
    g.fillEllipse(cd);
    g.setColour(juce::Colours::black.withAlpha(0.7f));
    g.drawEllipse(cd, 2.0f);
    g.fillEllipse(cd.withSizeKeepingCentre(45, 45));
    g.setColour(VintageLookAndFeel::silverLight());
    g.fillEllipse(cd.withSizeKeepingCentre(20, 20));

    juce::Path arrow;
    auto ax = cd.getRight() + 15;
    auto ay = cd.getCentreY();
    arrow.startNewSubPath(ax, ay - 13);
    arrow.lineTo(ax + 60, ay - 13);
    arrow.lineTo(ax + 60, ay - 35);
    arrow.lineTo(ax + 100, ay);
    arrow.lineTo(ax + 60, ay + 35);
    arrow.lineTo(ax + 60, ay + 13);
    arrow.lineTo(ax, ay + 13);
    arrow.closeSubPath();
    g.setColour(juce::Colours::black);
    g.fillPath(arrow);

    auto folder = juce::Rectangle<float>(r.getRight() - 210, r.getY() + 65, 160, 120);
    g.setColour(juce::Colour::fromRGB(212, 190, 145));
    g.fillRoundedRectangle(folder, 8.0f);
    g.setColour(juce::Colour::fromRGB(170, 130, 70));
    g.drawRoundedRectangle(folder, 8.0f, 2.0f);
    g.setColour(VintageLookAndFeel::deepRed());
    g.setFont(bold(24.0f));
    g.drawText("RUFTRAX", folder.toNearestInt().reduced(10), juce::Justification::centredTop);
    g.setColour(juce::Colours::black);
    g.setFont(bold(16.0f));
    g.drawText("DISC IMAGE", folder.toNearestInt().reduced(10), juce::Justification::centredBottom);
}

void MainComponent::drawLed(juce::Graphics& g, juce::Point<float> c, bool on,
                            juce::Colour colour) const
{
    auto led = juce::Rectangle<float>(c.x - 9, c.y - 9, 18, 18);
    g.setColour(juce::Colours::black);
    g.fillEllipse(led.expanded(2));
    g.setColour(on ? colour.brighter(0.35f) : colour.darker(0.8f));
    g.fillEllipse(led);
    if (on)
    {
        g.setColour(juce::Colours::white.withAlpha(0.65f));
        g.fillEllipse(led.withSizeKeepingCentre(6, 6).translated(-3, -3));
    }
}

void MainComponent::resized()
{
    deviceValue.setBounds(220, 390, 285, 28);
    typeValue.setBounds(220, 430, 285, 28);
    sizeValue.setBounds(220, 470, 285, 50);
    statusValue.setBounds(220, 525, 285, 28);
    refreshButton.setBounds(110, 558, 130, 36);

    discNameEditor.setBounds(610, 365, 505, 38);
    outputFolderEditor.setBounds(610, 515, 395, 38);
    chooseButton.setBounds(1015, 515, 100, 38);

    progressBar.setBounds(115, 680, 1000, 36);
    progressText.setBounds(430, 718, 380, 24);

    shaValue.setBounds(220, 808, 860, 28);
    verifyValue.setBounds(220, 848, 860, 28);

    reportStatusValue.setBounds(1185, 365, 160, 28);
    reportPathValue.setBounds(1185, 402, 160, 55);
    openReportButton.setBounds(1185, 470, 160, 38);

    imageButton.setBounds(1190, 580, 150, 120);
    scaleLabel.setBounds(1190, 706, 150, 20);
    scaleBox.setBounds(1190, 730, 150, 32);
}

void MainComponent::scaleChoiceChanged()
{
    if (onScaleChoiceChanged)
        onScaleChoiceChanged(scaleBox.getSelectedId());
}

void MainComponent::buttonClicked(juce::Button* b)
{
    if (b == &refreshButton) refreshDisc();
    else if (b == &chooseButton) chooseOutputFolder();
    else if (b == &imageButton) startImaging();
    else if (b == &openReportButton) openReport();
}

void MainComponent::refreshDisc()
{
    discInfo = engine.detectDisc();
    if (discInfo.valid)
    {
        deviceValue.setText(discInfo.rawDevice, juce::dontSendNotification);
        typeValue.setText("CD-ROM (Mode 1)", juce::dontSendNotification);
        sizeValue.setText(discInfo.sizeDescription, juce::dontSendNotification);
        statusValue.setText("Disc Ready", juce::dontSendNotification);
    }
    else
    {
        deviceValue.setText("-", juce::dontSendNotification);
        sizeValue.setText("-", juce::dontSendNotification);
        statusValue.setText("No Mode 1 disc detected", juce::dontSendNotification);
    }
    repaint();
}

void MainComponent::chooseOutputFolder()
{
    chooser.launchAsync(juce::FileBrowserComponent::openMode |
                        juce::FileBrowserComponent::canSelectDirectories,
        [this](const juce::FileChooser& fc)
        {
            auto f = fc.getResult();
            if (f != juce::File{})
                outputFolderEditor.setText(f.getFullPathName());
        });
}

void MainComponent::startImaging()
{
    if (!discInfo.valid)
    {
        juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,
                                               "No disc detected",
                                               "Insert a Mode 1 CD and press Refresh.");
        return;
    }

    auto output = juce::File(outputFolderEditor.getText());
    if (!engine.startImaging(discInfo, discNameEditor.getText(), output))
    {
        juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,
                                               "Unable to start",
                                               "Check the disc name, output folder, and ddrescue installation.");
    }
}

void MainComponent::openReport()
{
    if (lastReport.existsAsFile())
        lastReport.startAsProcess();
}

void MainComponent::engineStatusChanged(ImagingEngine::State state, const juce::String& text)
{
    juce::MessageManager::callAsync([this, state, text]
    {
        progressText.setText(text, juce::dontSendNotification);
        statusValue.setText(text, juce::dontSendNotification);
        imageButton.setEnabled(state != ImagingEngine::State::imaging &&
                               state != ImagingEngine::State::verifying);
        repaint();
    });
}

void MainComponent::engineProgressChanged(double value)
{
    juce::MessageManager::callAsync([this, value]
    {
        progressValue = value;
        progressText.setText(juce::String(juce::roundToInt(value * 100.0)) + "% complete",
                             juce::dontSendNotification);
        repaint();
    });
}

void MainComponent::engineFinished(bool ok, const juce::File& report,
                                   const juce::String& message)
{
    juce::MessageManager::callAsync([this, ok, report, message]
    {
        lastReport = report;
        reportStatusValue.setText(ok ? "PASS" : "FAILED", juce::dontSendNotification);
        reportPathValue.setText(report.existsAsFile() ? report.getFileName() : "-",
                                juce::dontSendNotification);
        verifyValue.setText(ok ? "PASS - image size and SHA-256 recorded" : "FAILED",
                            juce::dontSendNotification);

        if (ok)
        {
            auto checksum = report.getSiblingFile(report.getFileNameWithoutExtension()
                                .upToLastOccurrenceOf("-report", false, false) + ".sha256");
            juce::ignoreUnused(checksum);
        }

        juce::AlertWindow::showMessageBoxAsync(
            ok ? juce::MessageBoxIconType::InfoIcon : juce::MessageBoxIconType::WarningIcon,
            ok ? "Imaging complete" : "Imaging failed", message);
        repaint();
    });
}
