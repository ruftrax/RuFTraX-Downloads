#pragma once
#include <JuceHeader.h>
#include "VintageLookAndFeel.h"
#include "ImagingEngine.h"

class MainComponent final : public juce::Component,
                            private juce::Button::Listener,
                            private ImagingEngine::Listener
{
public:
    using ScaleChoiceChanged = std::function<void(int)>;

    MainComponent(ScaleChoiceChanged scaleChoiceChanged, int initialScaleChoice);
    ~MainComponent() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void buttonClicked(juce::Button*) override;
    void refreshDisc();
    void chooseOutputFolder();
    void startImaging();
    void openReport();
    void scaleChoiceChanged();

    void engineStatusChanged(ImagingEngine::State, const juce::String&) override;
    void engineProgressChanged(double) override;
    void engineFinished(bool, const juce::File&, const juce::String&) override;

    void drawPanel(juce::Graphics&, juce::Rectangle<float>, const juce::String&) const;
    void drawHeaderArtwork(juce::Graphics&, juce::Rectangle<float>) const;
    void drawLed(juce::Graphics&, juce::Point<float>, bool, juce::Colour) const;

    VintageLookAndFeel lookAndFeel;
    ImagingEngine engine;
    ImagingEngine::DiscInfo discInfo;

    juce::TextButton refreshButton { "REFRESH" };
    juce::TextButton chooseButton { "CHOOSE..." };
    juce::TextButton imageButton { "IMAGE\nSTART" };
    juce::TextButton openReportButton { "OPEN REPORT" };

    juce::TextEditor discNameEditor;
    juce::TextEditor outputFolderEditor;

    juce::Label scaleLabel;
    juce::ComboBox scaleBox;
    ScaleChoiceChanged onScaleChoiceChanged;

    juce::Label deviceValue, typeValue, sizeValue, statusValue;
    juce::Label shaValue, verifyValue, reportStatusValue, reportPathValue;
    juce::Label progressText;

    double progressValue = 0.0;
    juce::ProgressBar progressBar { progressValue };
    juce::FileChooser chooser { "Choose Output Folder" };
    juce::File lastReport;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MainComponent)
};
