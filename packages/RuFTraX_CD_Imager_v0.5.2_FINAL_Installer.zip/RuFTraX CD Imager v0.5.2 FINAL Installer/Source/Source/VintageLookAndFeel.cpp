#include "VintageLookAndFeel.h"

VintageLookAndFeel::VintageLookAndFeel()
{
    setColour(juce::TextButton::textColourOffId, juce::Colours::black);
    setColour(juce::TextEditor::textColourId, juce::Colours::black);
    setColour(juce::TextEditor::backgroundColourId, juce::Colour::fromRGB(238, 236, 230));
    setColour(juce::TextEditor::outlineColourId, juce::Colour::fromRGB(55, 55, 55));
}

juce::Colour VintageLookAndFeel::silverLight() { return juce::Colour::fromRGB(236, 235, 230); }
juce::Colour VintageLookAndFeel::silverMid()   { return juce::Colour::fromRGB(174, 176, 174); }
juce::Colour VintageLookAndFeel::silverDark()  { return juce::Colour::fromRGB(82, 84, 83); }
juce::Colour VintageLookAndFeel::deepRed()     { return juce::Colour::fromRGB(135, 25, 19); }

void VintageLookAndFeel::drawButtonBackground(juce::Graphics& g, juce::Button& b,
                                               const juce::Colour&, bool hover, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced(1.0f);
    juce::ColourGradient grad(
        down ? silverDark() : silverLight(), r.getCentreX(), r.getY(),
        down ? silverMid() : silverDark(), r.getCentreX(), r.getBottom(), false);

    if (hover && !down)
        grad.addColour(0.5, juce::Colours::white.withAlpha(0.25f));

    g.setGradientFill(grad);
    g.fillRoundedRectangle(r, 4.0f);
    g.setColour(juce::Colours::black.withAlpha(0.8f));
    g.drawRoundedRectangle(r, 4.0f, 2.0f);
    g.setColour(juce::Colours::white.withAlpha(0.5f));
    g.drawLine(r.getX() + 4, r.getY() + 3, r.getRight() - 4, r.getY() + 3, 1.0f);
}

void VintageLookAndFeel::drawButtonText(juce::Graphics& g, juce::TextButton& b, bool, bool)
{
    g.setColour(b.findColour(juce::TextButton::textColourOffId));
    g.setFont(juce::FontOptions(17.0f, juce::Font::bold));
    g.drawFittedText(b.getButtonText(), b.getLocalBounds().reduced(5),
                     juce::Justification::centred, 2);
}

void VintageLookAndFeel::drawProgressBar(juce::Graphics& g, juce::ProgressBar&,
                                          int w, int h, double progress,
                                          const juce::String& text)
{
    auto r = juce::Rectangle<float>(0, 0, (float) w, (float) h).reduced(2.0f);
    g.setColour(juce::Colours::black);
    g.fillRoundedRectangle(r, 4.0f);

    auto fill = r.reduced(4.0f);
    fill.setWidth((float) juce::jlimit(0.0, 1.0, progress) * fill.getWidth());
    juce::ColourGradient grad(deepRed().brighter(0.25f), fill.getX(), 0,
                              deepRed().darker(0.35f), fill.getRight(), 0, false);
    g.setGradientFill(grad);
    g.fillRoundedRectangle(fill, 2.0f);

    g.setColour(juce::Colours::white);
    g.setFont(juce::FontOptions(15.0f, juce::Font::bold));
    g.drawFittedText(text, juce::Rectangle<int>(0, 0, w, h),
                     juce::Justification::centred, 1);
}

void VintageLookAndFeel::fillTextEditorBackground(juce::Graphics& g, int w, int h,
                                                   juce::TextEditor&)
{
    g.setColour(juce::Colour::fromRGB(238, 236, 230));
    g.fillRoundedRectangle(juce::Rectangle<float>(0, 0, (float) w, (float) h), 3.0f);
}

void VintageLookAndFeel::drawTextEditorOutline(juce::Graphics& g, int w, int h,
                                                juce::TextEditor& e)
{
    g.setColour(e.hasKeyboardFocus(true) ? deepRed() : juce::Colour::fromRGB(55, 55, 55));
    g.drawRoundedRectangle(juce::Rectangle<float>(0, 0, (float) w, (float) h).reduced(0.5f),
                           3.0f, e.hasKeyboardFocus(true) ? 2.0f : 1.0f);
}
