#pragma once
#include <JuceHeader.h>

class VintageLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    VintageLookAndFeel();

    void drawButtonBackground(juce::Graphics&, juce::Button&,
                              const juce::Colour&, bool, bool) override;
    void drawButtonText(juce::Graphics&, juce::TextButton&,
                        bool, bool) override;
    void drawProgressBar(juce::Graphics&, juce::ProgressBar&,
                         int, int, double, const juce::String&) override;
    void fillTextEditorBackground(juce::Graphics&, int, int,
                                  juce::TextEditor&) override;
    void drawTextEditorOutline(juce::Graphics&, int, int,
                               juce::TextEditor&) override;

    static juce::Colour silverLight();
    static juce::Colour silverMid();
    static juce::Colour silverDark();
    static juce::Colour deepRed();
};
