#!/bin/zsh
set -euo pipefail

PACKAGE_DIR="${0:A:h}"
SOURCE_DIR="$PACKAGE_DIR/Source"
LOG_FILE="$HOME/Desktop/RuFTraX_Digital_Vault_v0.2.2_Install.log"
INSTALL_DIR="$HOME/Applications"
INSTALL_APP="$INSTALL_DIR/RuFTraX Digital Vault.app"
BACKUP_ROOT="$HOME/Library/Application Support/RuFTraX/Backups/Digital Vault"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"

exec > >(tee "$LOG_FILE") 2>&1

print "RuFTraX Digital Vault v0.2.2 FINAL"
print "Build and Install"
print

chmod +x "$SOURCE_DIR/build_mac.sh" "$SOURCE_DIR/Scripts/validate_release_source.sh"
"$SOURCE_DIR/build_mac.sh"

BUILT_APP="$SOURCE_DIR/build-v0.2.2/RuFTraXDigitalVault_artefacts/Release/RuFTraX Digital Vault.app"
[[ -d "$BUILT_APP" ]] || { print "The built app was not found."; exit 1; }

BINARY="$BUILT_APP/Contents/MacOS/RuFTraX Digital Vault"
[[ -x "$BINARY" ]] || { print "The app binary was not found."; exit 1; }

ARCHITECTURE="$(lipo -archs "$BINARY")"
[[ "$ARCHITECTURE" == *arm64* ]] || { print "The app is not an arm64 build: $ARCHITECTURE"; exit 1; }

xattr -cr "$BUILT_APP"
codesign --force --deep --sign - "$BUILT_APP"
codesign --verify --deep --strict --verbose=2 "$BUILT_APP"

mkdir -p "$INSTALL_DIR"
if [[ -d "$INSTALL_APP" ]]; then
    BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"
    mkdir -p "$BACKUP_DIR"
    ditto "$INSTALL_APP" "$BACKUP_DIR/RuFTraX Digital Vault.app"
    print "Existing app backed up to:"
    print "  $BACKUP_DIR"
fi

ditto "$BUILT_APP" "$INSTALL_APP"
xattr -cr "$INSTALL_APP"
codesign --verify --deep --strict --verbose=2 "$INSTALL_APP"

print
print "INSTALL COMPLETE"
print "Installed: $INSTALL_APP"
print "Log: $LOG_FILE"
print
open "$INSTALL_APP"
