#include "MainComponent.h"

#include <algorithm>

namespace
{
    void styleButton(juce::TextButton& button, juce::Colour colour = juce::Colour(VaultColours::panelRaised))
    {
        button.setColour(juce::TextButton::buttonColourId, colour);
        button.setColour(juce::TextButton::textColourOffId, juce::Colour(VaultColours::ivory));
        button.setColour(juce::TextButton::textColourOnId, juce::Colour(VaultColours::ivory));
    }

    void styleHeading(juce::Label& label)
    {
        label.setColour(juce::Label::textColourId, juce::Colour(VaultColours::amber));
        label.setFont(juce::FontOptions(13.0f, juce::Font::bold));
        label.setJustificationType(juce::Justification::centredLeft);
    }

    void paintPanel(juce::Graphics& graphics, juce::Rectangle<int> bounds)
    {
        graphics.setColour(juce::Colour(VaultColours::panel));
        graphics.fillRoundedRectangle(bounds.toFloat(), 7.0f);
        graphics.setColour(juce::Colour(VaultColours::grid));
        graphics.drawRoundedRectangle(bounds.toFloat(), 7.0f, 1.0f);
    }

    juce::String readBundleVersion(const juce::File& appBundle)
    {
        const auto infoPlist = appBundle.getChildFile("Contents").getChildFile("Info.plist");
        if (!infoPlist.existsAsFile())
            return {};

        if (auto xml = juce::XmlDocument::parse(infoPlist))
        {
            auto* dictionary = xml->getChildByName("dict");
            if (dictionary != nullptr)
            {
                for (auto* element = dictionary->getFirstChildElement();
                     element != nullptr;
                     element = element->getNextElement())
                {
                    if (element->hasTagName("key")
                        && element->getAllSubText().trim() == "CFBundleShortVersionString")
                    {
                        if (auto* value = element->getNextElement())
                            return value->getAllSubText().trim();
                    }
                }
            }
        }

#if JUCE_MAC
        juce::ChildProcess defaults;
        juce::StringArray command
        {
            "/usr/bin/defaults",
            "read",
            infoPlist.getFullPathName(),
            "CFBundleShortVersionString"
        };
        if (defaults.start(command))
        {
            defaults.waitForProcessToFinish(3000);
            return defaults.readAllProcessOutput().trim();
        }
#endif
        return {};
    }

    bool isFinalSFPlayerPro(const juce::File& appBundle)
    {
        return appBundle.isDirectory()
            && appBundle.getFileName() == "RuFTraX SF Player Pro.app"
            && readBundleVersion(appBundle) == "4.3.2";
    }
}

MainComponent::MainComponent()
{
    setLookAndFeel(&vaultLookAndFeel);
    audioFormatManager.registerBasicFormats();
    configureControls();

    database.load();
    allItems = database.getItems();
    applyFilters();
    updateFolderDisplay();
    updateHistoryDisplay();

    setSize(1440, 850);
    setAudioChannels(0, 2);
    startTimerHz(30);
}

MainComponent::~MainComponent()
{
    stopTimer();
    if (scanner != nullptr)
    {
        scanner->signalThreadShouldExit();
        scanner->stopThread(3000);
    }
    stopPreview();
    transport.setSource(nullptr);
    readerSource.reset();
    shutdownAudio();
    database.save();
    setLookAndFeel(nullptr);
}

void MainComponent::configureControls()
{
    addAndMakeVisible(brandLabel);
    brandLabel.setText("RuFTraX", juce::dontSendNotification);
    brandLabel.setFont(juce::FontOptions(36.0f, juce::Font::bold));
    brandLabel.setColour(juce::Label::textColourId, juce::Colour(VaultColours::ivory));

    addAndMakeVisible(productLabel);
    productLabel.setText("DIGITAL VAULT", juce::dontSendNotification);
    productLabel.setFont(juce::FontOptions(23.0f, juce::Font::bold));
    productLabel.setColour(juce::Label::textColourId, juce::Colour(VaultColours::amber));

    addAndMakeVisible(taglineLabel);
    taglineLabel.setText("PRESERVE  |  SEARCH  |  PREVIEW  |  CREATE", juce::dontSendNotification);
    taglineLabel.setFont(juce::FontOptions(12.0f, juce::Font::bold));
    taglineLabel.setColour(juce::Label::textColourId, juce::Colour(VaultColours::muted));
    taglineLabel.setJustificationType(juce::Justification::centredRight);

    addAndMakeVisible(searchEditor);
    searchEditor.setTextToShowWhenEmpty("Search instruments, formats, tags, or folders...",
                                        juce::Colour(VaultColours::muted));
    searchEditor.onTextChange = [this] { applyFilters(); };

    addAndMakeVisible(categoryFilter);
    categoryFilter.addItem("ALL CATEGORIES", 1);
    const juce::StringArray categories
    {
        "Keys", "Brass", "Strings", "Guitar", "Bass", "Drums",
        "Percussion", "Synth", "Vocal", "FX", "Disc Images", "Other"
    };
    for (int i = 0; i < categories.size(); ++i)
        categoryFilter.addItem(categories[i], i + 2);
    categoryFilter.setSelectedId(1);
    categoryFilter.onChange = [this] { applyFilters(); };

    for (auto* button : { &addFolderButton, &rescanButton, &optionsButton,
                          &removeFolderButton, &openVaultButton, &openCDImagerButton,
                          &openConverterButton, &openSFPlayerButton,
                          &openSuperInstrumentButton, &openTimeforgeButton,
                          &openRM10Button,
                          &openMuDButton,
                          &openChainerButton,
                          &previewButton, &stopButton, &revealButton, &openButton,
                          &importHistoryButton })
    {
        addAndMakeVisible(*button);
        styleButton(*button);
    }

    styleButton(addFolderButton, juce::Colour(VaultColours::red));
    styleButton(previewButton, juce::Colour(VaultColours::bronze));
    styleButton(openVaultButton, juce::Colour(VaultColours::bronze));

    addFolderButton.onClick = [this] { addLibraryFolder(); };
    rescanButton.onClick = [this] { startScan(); };
    optionsButton.onClick = [this] { showOptionsMenu(); };
    removeFolderButton.onClick = [this] { removeSelectedFolder(); };
    openVaultButton.onClick = [this] { focusDigitalVault(); };
    openCDImagerButton.onClick = [this] { launchRuFTraXApp("RuFTraX CD Imager"); };
    openConverterButton.onClick = [this] { launchRuFTraXApp("RuFTraX Sample Converter"); };
    openSFPlayerButton.onClick = [this] { launchFinalSFPlayerPro(); };
    openSuperInstrumentButton.onClick = [this]
    {
        launchRuFTraXApp("RuFTraX SF2 Super Instrument");
    };
    openTimeforgeButton.onClick = [this] { launchRuFTraXApp("RuFTraX TIMEFORGE"); };
    openRM10Button.onClick = [this] { launchRuFTraXApp("RuFTraX RM-10"); };
    openMuDButton.onClick = [this] { launchRuFTraXApp("RuFTraX MuD"); };
    openChainerButton.onClick = [this] { launchRuFTraXApp("RuFTraX Plug-In Chainer"); };
    previewButton.onClick = [this] { togglePreview(); };
    stopButton.onClick = [this] { stopPreview(); };
    revealButton.onClick = [this] { revealSelectedItem(); };
    openButton.onClick = [this] { openSelectedItem(); };
    importHistoryButton.onClick = [this] { importConverterHistory(); };

    addAndMakeVisible(statusLabel);
    statusLabel.setFont(juce::FontOptions(12.0f));
    statusLabel.setColour(juce::Label::textColourId, juce::Colour(VaultColours::teal));
    statusLabel.setText("READY", juce::dontSendNotification);

    addAndMakeVisible(librariesHeading);
    librariesHeading.setText("LIBRARY LOCATIONS", juce::dontSendNotification);
    styleHeading(librariesHeading);

    addAndMakeVisible(appsHeading);
    appsHeading.setText("RUFTRAX APPS", juce::dontSendNotification);
    styleHeading(appsHeading);

    addAndMakeVisible(libraryFoldersView);
    libraryFoldersView.setMultiLine(true);
    libraryFoldersView.setReadOnly(true);
    libraryFoldersView.setScrollbarsShown(true);
    libraryFoldersView.setColour(juce::TextEditor::backgroundColourId, juce::Colour(VaultColours::background));
    libraryFoldersView.setFont(juce::FontOptions(12.0f));

    addAndMakeVisible(itemTable);
    itemTable.setRowHeight(34);
    itemTable.setOutlineThickness(1);
    itemTable.setMultipleSelectionEnabled(false);
    auto& header = itemTable.getHeader();
    header.addColumn("NAME", 1, 260, 120, 600, juce::TableHeaderComponent::defaultFlags);
    header.addColumn("CATEGORY", 2, 100, 80, 180, juce::TableHeaderComponent::defaultFlags);
    header.addColumn("FORMAT", 3, 75, 60, 100, juce::TableHeaderComponent::defaultFlags);
    header.addColumn("ROOT", 4, 60, 50, 80, juce::TableHeaderComponent::defaultFlags);
    header.addColumn("TAGS", 5, 220, 120, 500, juce::TableHeaderComponent::defaultFlags);

    addAndMakeVisible(detailName);
    detailName.setFont(juce::FontOptions(20.0f, juce::Font::bold));
    detailName.setColour(juce::Label::textColourId, juce::Colour(VaultColours::ivory));
    detailName.setJustificationType(juce::Justification::centredLeft);
    detailName.setText("SELECT AN ASSET", juce::dontSendNotification);

    for (auto* label : { &detailType, &detailMetadata, &detailTags })
    {
        addAndMakeVisible(*label);
        label->setFont(juce::FontOptions(12.0f));
        label->setColour(juce::Label::textColourId, juce::Colour(VaultColours::muted));
        label->setJustificationType(juce::Justification::topLeft);
    }

    addAndMakeVisible(historyHeading);
    historyHeading.setText("CONVERSION & LIBRARY HISTORY", juce::dontSendNotification);
    styleHeading(historyHeading);

    addAndMakeVisible(historyView);
    historyView.setMultiLine(true);
    historyView.setReadOnly(true);
    historyView.setScrollbarsShown(true);
    historyView.setFont(juce::FontOptions(11.0f));
    historyView.setColour(juce::TextEditor::backgroundColourId, juce::Colour(VaultColours::background));

    setWantsKeyboardFocus(true);
}

void MainComponent::paint(juce::Graphics& graphics)
{
    graphics.fillAll(juce::Colour(VaultColours::background));

    juce::ColourGradient headerGradient(juce::Colour(0xff351b13), 0.0f, 0.0f,
                                        juce::Colour(0xff121414), static_cast<float>(getWidth()), 0.0f, false);
    graphics.setGradientFill(headerGradient);
    graphics.fillRect(0, 0, getWidth(), 82);
    graphics.setColour(juce::Colour(VaultColours::bronze));
    graphics.fillRect(0, 80, getWidth(), 2);

    paintPanel(graphics, leftPanel);
    paintPanel(graphics, centrePanel);
    paintPanel(graphics, rightPanel);
    paintPanel(graphics, historyPanel);

    auto artworkBounds = getArtworkBounds();
    graphics.setColour(juce::Colour(VaultColours::background));
    graphics.fillRoundedRectangle(artworkBounds.toFloat(), 5.0f);
    graphics.setColour(juce::Colour(VaultColours::bronze).withAlpha(0.65f));
    graphics.drawRoundedRectangle(artworkBounds.toFloat(), 5.0f, 1.0f);

    if (selectedArtwork.isValid())
    {
        graphics.drawImageWithin(selectedArtwork,
                                 artworkBounds.getX() + 4,
                                 artworkBounds.getY() + 4,
                                 artworkBounds.getWidth() - 8,
                                 artworkBounds.getHeight() - 8,
                                 juce::RectanglePlacement::centred);
    }
    else
    {
        const auto centre = artworkBounds.getCentre().toFloat();
        const float radius = static_cast<float>(juce::jmin(artworkBounds.getWidth(),
                                                           artworkBounds.getHeight())) * 0.28f;
        graphics.setColour(juce::Colour(VaultColours::panelRaised));
        graphics.fillEllipse(centre.x - radius, centre.y - radius, radius * 2.0f, radius * 2.0f);
        graphics.setColour(juce::Colour(VaultColours::bronze));
        graphics.drawEllipse(centre.x - radius, centre.y - radius, radius * 2.0f, radius * 2.0f, 3.0f);
        graphics.drawEllipse(centre.x - radius * 0.62f, centre.y - radius * 0.62f,
                             radius * 1.24f, radius * 1.24f, 1.5f);
        graphics.drawLine(centre.x, centre.y, centre.x + radius * 0.55f, centre.y - radius * 0.30f, 3.0f);
        graphics.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        graphics.drawText("RUFTRAX ARCHIVE",
                          artworkBounds.removeFromBottom(24),
                          juce::Justification::centred);
    }

    const auto waveformBounds = getWaveformBounds();
    graphics.setColour(juce::Colour(VaultColours::background));
    graphics.fillRoundedRectangle(waveformBounds.toFloat(), 4.0f);
    graphics.setColour(juce::Colour(VaultColours::grid));
    graphics.drawRoundedRectangle(waveformBounds.toFloat(), 4.0f, 1.0f);

    if (thumbnail.getTotalLength() > 0.0)
    {
        graphics.setColour(juce::Colour(VaultColours::teal));
        thumbnail.drawChannels(graphics, waveformBounds.reduced(4), 0.0,
                               thumbnail.getTotalLength(), 1.0f);

        const auto positionRatio = transport.getLengthInSeconds() > 0.0
            ? transport.getCurrentPosition() / transport.getLengthInSeconds()
            : 0.0;
        const auto cursorX = waveformBounds.getX()
            + static_cast<int>(positionRatio * static_cast<double>(waveformBounds.getWidth()));
        graphics.setColour(juce::Colour(VaultColours::amber));
        graphics.drawVerticalLine(cursorX,
                                  static_cast<float>(waveformBounds.getY() + 2),
                                  static_cast<float>(waveformBounds.getBottom() - 2));
    }
    else
    {
        graphics.setColour(juce::Colour(VaultColours::muted));
        graphics.setFont(juce::FontOptions(11.0f));
        graphics.drawText("AUDIO PREVIEW", waveformBounds, juce::Justification::centred);
    }

    graphics.setColour(juce::Colour(VaultColours::muted));
    graphics.setFont(juce::FontOptions(10.0f));
    graphics.drawText("RuFTraX DIGITAL VAULT v0.2.2  |  9-APP HUB  |  LOCAL CATALOG  |  DRAG FOLDERS HERE",
                      18, getHeight() - 24, getWidth() - 36, 16,
                      juce::Justification::centred);
}

void MainComponent::resized()
{
    auto bounds = getLocalBounds().reduced(16);
    auto header = bounds.removeFromTop(66);
    brandLabel.setBounds(header.removeFromLeft(190));
    productLabel.setBounds(header.removeFromLeft(240));
    taglineLabel.setBounds(header);

    bounds.removeFromTop(12);
    auto toolbar = bounds.removeFromTop(40);
    addFolderButton.setBounds(toolbar.removeFromLeft(130));
    toolbar.removeFromLeft(8);
    rescanButton.setBounds(toolbar.removeFromLeft(90));
    toolbar.removeFromLeft(8);
    searchEditor.setBounds(toolbar.removeFromLeft(juce::jmax(220, getWidth() / 4)));
    toolbar.removeFromLeft(8);
    categoryFilter.setBounds(toolbar.removeFromLeft(170));
    toolbar.removeFromLeft(8);
    optionsButton.setBounds(toolbar.removeFromLeft(90));
    statusLabel.setBounds(toolbar.reduced(10, 0));

    bounds.removeFromTop(10);
    bounds.removeFromBottom(26);
    historyPanel = bounds.removeFromBottom(132);
    bounds.removeFromBottom(10);

    leftPanel = bounds.removeFromLeft(240);
    bounds.removeFromLeft(10);
    rightPanel = bounds.removeFromRight(330);
    bounds.removeFromRight(10);
    centrePanel = bounds;

    auto left = leftPanel.reduced(12);
    librariesHeading.setBounds(left.removeFromTop(22));
    left.removeFromTop(4);
    libraryFoldersView.setBounds(
        left.removeFromTop(juce::jlimit(88, 150, left.getHeight() - 380)));
    left.removeFromTop(6);
    removeFolderButton.setBounds(left.removeFromTop(28));
    left.removeFromTop(12);
    appsHeading.setBounds(left.removeFromTop(22));
    left.removeFromTop(4);

    auto placeAppButton = [&left](juce::TextButton& button)
    {
        button.setBounds(left.removeFromTop(27));
        left.removeFromTop(3);
    };

    placeAppButton(openVaultButton);
    placeAppButton(openCDImagerButton);
    placeAppButton(openConverterButton);
    placeAppButton(openSFPlayerButton);
    placeAppButton(openSuperInstrumentButton);
    placeAppButton(openTimeforgeButton);
    placeAppButton(openRM10Button);
    placeAppButton(openMuDButton);
    openChainerButton.setBounds(left.removeFromTop(27));

    itemTable.setBounds(centrePanel.reduced(10));

    auto right = rightPanel.reduced(12);
    detailName.setBounds(right.removeFromTop(30));
    detailType.setBounds(right.removeFromTop(20));
    right.removeFromTop(6);
    const int artworkHeight = juce::jlimit(130, 230, right.getHeight() / 3);
    right.removeFromTop(artworkHeight);
    right.removeFromTop(8);
    detailMetadata.setBounds(right.removeFromTop(52));
    detailTags.setBounds(right.removeFromTop(34));
    right.removeFromTop(8);
    right.removeFromTop(70);
    right.removeFromTop(8);
    auto previewRow = right.removeFromTop(34);
    previewButton.setBounds(previewRow.removeFromLeft(150));
    previewRow.removeFromLeft(8);
    stopButton.setBounds(previewRow);
    right.removeFromTop(8);
    auto openRow = right.removeFromTop(34);
    revealButton.setBounds(openRow.removeFromLeft(150));
    openRow.removeFromLeft(8);
    openButton.setBounds(openRow);

    auto history = historyPanel.reduced(12);
    auto historyHeader = history.removeFromTop(28);
    historyHeading.setBounds(historyHeader.removeFromLeft(280));
    importHistoryButton.setBounds(historyHeader.removeFromRight(220));
    history.removeFromTop(4);
    historyView.setBounds(history);
}

int MainComponent::getNumRows()
{
    return static_cast<int>(filteredIndices.size());
}

void MainComponent::paintRowBackground(juce::Graphics& graphics,
                                       int rowNumber,
                                       int width,
                                       int height,
                                       bool rowIsSelected)
{
    const auto colour = rowIsSelected
        ? juce::Colour(VaultColours::red)
        : ((rowNumber % 2) == 0 ? juce::Colour(VaultColours::panel)
                                : juce::Colour(VaultColours::panelRaised).withAlpha(0.48f));
    graphics.fillAll(colour);
    graphics.setColour(juce::Colour(VaultColours::grid).withAlpha(0.5f));
    graphics.drawHorizontalLine(height - 1, 0.0f, static_cast<float>(width));
}

void MainComponent::paintCell(juce::Graphics& graphics,
                              int rowNumber,
                              int columnId,
                              int width,
                              int height,
                              bool)
{
    const auto* item = getItemForVisibleRow(rowNumber);
    if (item == nullptr)
        return;

    juce::String text;
    switch (columnId)
    {
        case 1: text = item->name; break;
        case 2: text = item->category; break;
        case 3: text = item->format; break;
        case 4: text = item->rootNote.isEmpty() ? "--" : item->rootNote; break;
        case 5: text = item->tags; break;
        default: break;
    }

    graphics.setColour(columnId == 3 ? juce::Colour(VaultColours::teal)
                                      : juce::Colour(VaultColours::ivory));
    graphics.setFont(juce::FontOptions(columnId == 1 ? 13.0f : 12.0f,
                                        columnId == 1 ? juce::Font::bold : juce::Font::plain));
    graphics.drawFittedText(text, 7, 0, width - 14, height,
                            juce::Justification::centredLeft, 1);
}

void MainComponent::selectedRowsChanged(int lastRowSelected)
{
    if (lastRowSelected < 0 || lastRowSelected >= static_cast<int>(filteredIndices.size()))
        selectedItemIndex = -1;
    else
        selectedItemIndex = filteredIndices[static_cast<size_t>(lastRowSelected)];

    updateSelectedItem();
}

void MainComponent::cellDoubleClicked(int rowNumber, int, const juce::MouseEvent&)
{
    if (rowNumber >= 0)
        openSelectedItem();
}

bool MainComponent::isInterestedInFileDrag(const juce::StringArray& files)
{
    for (const auto& path : files)
    {
        const juce::File file(path);
        if (file.isDirectory() || VaultScanner::isSupportedAsset(file))
            return true;
    }
    return false;
}

void MainComponent::filesDropped(const juce::StringArray& files, int, int)
{
    bool changed = false;
    for (const auto& path : files)
    {
        const juce::File file(path);
        const auto folder = file.isDirectory() ? file : file.getParentDirectory();
        if (database.addLibraryFolder(folder))
        {
            database.addHistory("Library added", folder.getFullPathName());
            changed = true;
        }
    }

    if (changed)
    {
        database.save();
        updateFolderDisplay();
        startScan();
    }
}

void MainComponent::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    transport.prepareToPlay(samplesPerBlockExpected, sampleRate);
}

void MainComponent::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    if (readerSource == nullptr)
        bufferToFill.clearActiveBufferRegion();
    else
        transport.getNextAudioBlock(bufferToFill);
}

void MainComponent::releaseResources()
{
    transport.releaseResources();
}

void MainComponent::timerCallback()
{
    if (transport.isPlaying() && transport.getCurrentPosition() >= transport.getLengthInSeconds())
        stopPreview();
    repaint(getWaveformBounds().expanded(2));
}

void MainComponent::addLibraryFolder()
{
    folderChooser = std::make_unique<juce::FileChooser>(
        "Choose a sample, SoundFont, or disc-image library folder",
        juce::File::getSpecialLocation(juce::File::userMusicDirectory));

    folderChooser->launchAsync(juce::FileBrowserComponent::openMode
                                   | juce::FileBrowserComponent::canSelectDirectories,
                               [safeThis = juce::Component::SafePointer<MainComponent>(this)]
                               (const juce::FileChooser& chooser)
    {
        if (safeThis == nullptr)
            return;

        const auto folder = chooser.getResult();
        if (folder.isDirectory() && safeThis->database.addLibraryFolder(folder))
        {
            safeThis->database.addHistory("Library added", folder.getFullPathName());
            safeThis->database.save();
            safeThis->updateFolderDisplay();
            safeThis->startScan();
        }
        safeThis->folderChooser.reset();
    });
}

void MainComponent::removeSelectedFolder()
{
    const auto folders = database.getLibraryFolders();
    if (folders.isEmpty())
        return;

    juce::PopupMenu menu;
    for (int i = 0; i < folders.size(); ++i)
        menu.addItem(i + 1, folders[i]);

    menu.showMenuAsync({}, [safeThis = juce::Component::SafePointer<MainComponent>(this), folders](int result)
    {
        if (safeThis == nullptr || result <= 0 || result > folders.size())
            return;

        const juce::File folder(folders[result - 1]);
        if (safeThis->database.removeLibraryFolder(folder))
        {
            safeThis->database.addHistory("Library removed", folder.getFullPathName());
            safeThis->database.save();
            safeThis->updateFolderDisplay();
            safeThis->startScan();
        }
    });
}

void MainComponent::startScan()
{
    if (scanner != nullptr && scanner->isThreadRunning())
        return;

    const auto folders = database.getLibraryFolders();
    if (folders.isEmpty())
    {
        statusLabel.setText("ADD A LIBRARY FOLDER TO BEGIN", juce::dontSendNotification);
        return;
    }

    statusLabel.setText("SCANNING...", juce::dontSendNotification);
    rescanButton.setEnabled(false);

    auto safeThis = juce::Component::SafePointer<MainComponent>(this);
    scanner = std::make_unique<VaultScanner>(
        folders,
        [safeThis](int filesSeen, const juce::String& folder)
        {
            juce::MessageManager::callAsync([safeThis, filesSeen, folder]
            {
                if (safeThis != nullptr)
                    safeThis->statusLabel.setText(
                        "SCANNING " + folder.toUpperCase() + "  |  "
                            + juce::String(filesSeen) + " FILES",
                        juce::dontSendNotification);
            });
        },
        [safeThis](std::vector<VaultItem> items) mutable
        {
            juce::MessageManager::callAsync([safeThis, items = std::move(items)]() mutable
            {
                if (safeThis != nullptr)
                    safeThis->scanCompleted(std::move(items));
            });
        });
    scanner->startThread();
}

void MainComponent::scanCompleted(std::vector<VaultItem> scannedItems)
{
    const int previousCount = static_cast<int>(allItems.size());
    allItems = std::move(scannedItems);
    database.replaceItems(allItems);
    database.addHistory("Library scan",
                        juce::String(static_cast<int>(allItems.size())) + " assets indexed"
                            + (previousCount == static_cast<int>(allItems.size())
                                   ? ""
                                   : " (" + juce::String(static_cast<int>(allItems.size()) - previousCount)
                                       + " change)"));
    database.save();

    applyFilters();
    updateHistoryDisplay();
    rescanButton.setEnabled(true);
    statusLabel.setText(juce::String(static_cast<int>(allItems.size())) + " ASSETS READY",
                        juce::dontSendNotification);
}

void MainComponent::applyFilters()
{
    filteredIndices.clear();
    const auto search = searchEditor.getText().trim().toLowerCase();
    const auto selectedCategory = categoryFilter.getSelectedId() <= 1
        ? juce::String()
        : categoryFilter.getText();

    for (int index = 0; index < static_cast<int>(allItems.size()); ++index)
    {
        const auto& item = allItems[static_cast<size_t>(index)];
        const bool categoryMatches = selectedCategory.isEmpty() || item.category == selectedCategory;
        const auto searchable = (item.name + " " + item.path + " " + item.tags
                                 + " " + item.format + " " + item.rootNote).toLowerCase();
        const bool searchMatches = search.isEmpty() || searchable.contains(search);
        if (categoryMatches && searchMatches)
            filteredIndices.push_back(index);
    }

    selectedItemIndex = -1;
    itemTable.deselectAllRows();
    itemTable.updateContent();
    itemTable.repaint();
    updateSelectedItem();

    statusLabel.setText(juce::String(static_cast<int>(filteredIndices.size())) + " OF "
                            + juce::String(static_cast<int>(allItems.size())) + " ASSETS",
                        juce::dontSendNotification);
}

void MainComponent::updateFolderDisplay()
{
    const auto folders = database.getLibraryFolders();
    if (folders.isEmpty())
        libraryFoldersView.setText("No folders added.\n\nDrag a library folder onto the window or click ADD LIBRARY.");
    else
    {
        juce::String text;
        for (int i = 0; i < folders.size(); ++i)
            text << juce::String(i + 1) << ". " << folders[i] << "\n\n";
        libraryFoldersView.setText(text.trimEnd());
    }
}

void MainComponent::updateHistoryDisplay()
{
    const auto entries = database.getHistory();
    juce::String text;
    const int count = juce::jmin(8, static_cast<int>(entries.size()));
    for (int i = 0; i < count; ++i)
    {
        const auto time = juce::Time(entries[static_cast<size_t>(i)].timestampMilliseconds);
        text << time.formatted("%Y-%m-%d  %H:%M") << "   "
             << entries[static_cast<size_t>(i)].action.toUpperCase() << "   "
             << entries[static_cast<size_t>(i)].detail << "\n";
    }
    if (text.isEmpty())
        text = "No history yet. Add a library folder and scan.";
    historyView.setText(text.trimEnd());
}

void MainComponent::updateSelectedItem()
{
    stopPreview();
    selectedArtwork = {};
    thumbnail.clear();

    if (selectedItemIndex < 0 || selectedItemIndex >= static_cast<int>(allItems.size()))
    {
        detailName.setText("SELECT AN ASSET", juce::dontSendNotification);
        detailType.setText("Artwork and technical details appear here.", juce::dontSendNotification);
        detailMetadata.setText({}, juce::dontSendNotification);
        detailTags.setText({}, juce::dontSendNotification);
        previewButton.setEnabled(false);
        revealButton.setEnabled(false);
        openButton.setEnabled(false);
        repaint(rightPanel);
        return;
    }

    const auto& item = allItems[static_cast<size_t>(selectedItemIndex)];
    detailName.setText(item.name, juce::dontSendNotification);
    detailType.setText(item.category.toUpperCase() + "  |  " + item.format
                           + (item.rootNote.isNotEmpty() ? "  |  ROOT " + item.rootNote : ""),
                       juce::dontSendNotification);

    juce::String metadata = formatBytes(item.fileSize);
    if (item.durationSeconds > 0.0)
        metadata << "  |  " << formatDuration(item.durationSeconds);
    if (item.sampleRate > 0.0)
        metadata << "  |  " << juce::String(item.sampleRate / 1000.0, 1) << " kHz"
                 << "  |  " << item.channels << " ch";
    detailMetadata.setText(metadata, juce::dontSendNotification);
    detailTags.setText("TAGS  " + item.tags, juce::dontSendNotification);

    if (item.artworkPath.isNotEmpty())
        selectedArtwork = juce::ImageFileFormat::loadFrom(juce::File(item.artworkPath));

    previewButton.setEnabled(item.previewable);
    revealButton.setEnabled(true);
    openButton.setEnabled(true);
    if (item.previewable)
        loadPreview(juce::File(item.path));
    repaint(rightPanel);
}

void MainComponent::loadPreview(const juce::File& file)
{
    stopPreview();
    transport.setSource(nullptr);
    readerSource.reset();

    if (auto* reader = audioFormatManager.createReaderFor(file))
    {
        const auto sourceSampleRate = reader->sampleRate;
        readerSource = std::make_unique<juce::AudioFormatReaderSource>(reader, true);
        transport.setSource(readerSource.get(), 0, nullptr, sourceSampleRate);
        thumbnail.setSource(new juce::FileInputSource(file));
        previewButton.setButtonText("PLAY PREVIEW");
    }
}

void MainComponent::togglePreview()
{
    if (readerSource == nullptr)
        return;

    if (transport.isPlaying())
    {
        transport.stop();
        previewButton.setButtonText("PLAY PREVIEW");
    }
    else
    {
        if (transport.getCurrentPosition() >= transport.getLengthInSeconds())
            transport.setPosition(0.0);
        transport.start();
        previewButton.setButtonText("PAUSE");
    }
}

void MainComponent::stopPreview()
{
    transport.stop();
    transport.setPosition(0.0);
    previewButton.setButtonText("PLAY PREVIEW");
}

void MainComponent::revealSelectedItem()
{
    if (selectedItemIndex < 0 || selectedItemIndex >= static_cast<int>(allItems.size()))
        return;
    juce::File(allItems[static_cast<size_t>(selectedItemIndex)].path).revealToUser();
}

void MainComponent::openSelectedItem()
{
    if (selectedItemIndex < 0 || selectedItemIndex >= static_cast<int>(allItems.size()))
        return;

    const auto file = juce::File(allItems[static_cast<size_t>(selectedItemIndex)].path);
    if (!file.startAsProcess())
        file.revealToUser();
}

void MainComponent::launchRuFTraXApp(const juce::String& appName)
{
#if JUCE_MAC
    const auto appBundleName = appName + ".app";
    juce::Array<juce::File> candidates
    {
        juce::File::getSpecialLocation(juce::File::userHomeDirectory)
            .getChildFile("Applications")
            .getChildFile(appBundleName),
        juce::File("/Applications").getChildFile(appBundleName)
    };

    juce::ChildProcess spotlight;
    juce::StringArray searchCommand
    {
        "/usr/bin/mdfind",
        "kMDItemFSName == '" + appBundleName.replace("'", "\\'") + "'cd"
    };

    if (spotlight.start(searchCommand))
    {
        spotlight.waitForProcessToFinish(5000);
        juce::StringArray discovered;
        discovered.addLines(spotlight.readAllProcessOutput());
        for (const auto& path : discovered)
        {
            const juce::File candidate(path.trim());
            if (candidate.hasFileExtension("app"))
                candidates.addIfNotAlreadyThere(candidate);
        }
    }

    for (const auto& candidate : candidates)
    {
        if (!candidate.isDirectory())
            continue;

        if (candidate.startAsProcess())
        {
            database.addHistory("App launched",
                                appName + "  |  " + candidate.getFullPathName());
            database.save();
            updateHistoryDisplay();
            statusLabel.setText(appName.toUpperCase() + " OPENED",
                                juce::dontSendNotification);
            return;
        }
    }

    statusLabel.setText(appName.toUpperCase() + " NOT FOUND",
                        juce::dontSendNotification);
    juce::AlertWindow::showMessageBoxAsync(
        juce::MessageBoxIconType::WarningIcon,
        "RuFTraX app not found",
        appName + " is not installed in your user or system Applications folder.");
#else
    juce::ignoreUnused(appName);
    statusLabel.setText("RUFTRAX APP LINKS REQUIRE macOS", juce::dontSendNotification);
#endif
    database.save();
    updateHistoryDisplay();
}

void MainComponent::focusDigitalVault()
{
    toFront(true);
    grabKeyboardFocus();
    statusLabel.setText("DIGITAL VAULT IS OPEN", juce::dontSendNotification);
}

void MainComponent::launchFinalSFPlayerPro()
{
#if JUCE_MAC
    juce::Array<juce::File> candidates
    {
        juce::File::getSpecialLocation(juce::File::userHomeDirectory)
            .getChildFile("Applications")
            .getChildFile("RuFTraX SF Player Pro.app"),
        juce::File("/Applications/RuFTraX SF Player Pro.app")
    };

    juce::ChildProcess spotlight;
    juce::StringArray searchCommand
    {
        "/usr/bin/mdfind",
        "kMDItemCFBundleIdentifier == 'com.ruftrax.sf2player'"
    };
    if (spotlight.start(searchCommand))
    {
        spotlight.waitForProcessToFinish(5000);
        juce::StringArray discovered;
        discovered.addLines(spotlight.readAllProcessOutput());
        for (const auto& path : discovered)
        {
            const juce::File candidate(path.trim());
            if (candidate.hasFileExtension("app"))
                candidates.addIfNotAlreadyThere(candidate);
        }
    }

    for (const auto& candidate : candidates)
    {
        if (!isFinalSFPlayerPro(candidate))
            continue;

        if (candidate.startAsProcess())
        {
            database.addHistory("App launched",
                                "RuFTraX SF Player Pro v4.3.2 FINAL  |  "
                                    + candidate.getFullPathName());
            database.save();
            updateHistoryDisplay();
            statusLabel.setText("SF PLAYER PRO v4.3.2 FINAL OPENED",
                                juce::dontSendNotification);
            return;
        }
    }

    statusLabel.setText("FINAL SF PLAYER PRO v4.3.2 NOT FOUND",
                        juce::dontSendNotification);
    juce::AlertWindow::showMessageBoxAsync(
        juce::MessageBoxIconType::WarningIcon,
        "Final SF Player Pro not found",
        "Digital Vault found no RuFTraX SF Player Pro v4.3.2 app. "
        "Install the final red MIDI / Tone / Chord Analyzer build with SF2 and SFZ support first.");
#else
    statusLabel.setText("SF PLAYER PRO LINK REQUIRES macOS",
                        juce::dontSendNotification);
#endif
}

void MainComponent::importConverterHistory()
{
    const auto applicationSupport =
        juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory);
    const juce::Array<juce::File> candidates
    {
        applicationSupport.getChildFile("RuFTraX Sample Converter"),
        applicationSupport.getChildFile("RuFTraX").getChildFile("Sample Converter")
    };

    int imported = 0;
    for (const auto& candidate : candidates)
    {
        if (!candidate.isDirectory())
            continue;

        for (const auto& entry : juce::RangedDirectoryIterator(candidate, true, "*.log", juce::File::findFiles))
        {
            const auto file = entry.getFile();
            database.addHistory("Converter log",
                                file.getFileName() + "  |  "
                                    + file.getLastModificationTime().formatted("%Y-%m-%d %H:%M"));
            ++imported;
        }
    }

    database.addHistory("History import",
                        imported > 0 ? juce::String(imported) + " converter logs found"
                                     : "No converter logs found");
    database.save();
    updateHistoryDisplay();
    statusLabel.setText(imported > 0 ? "CONVERTER HISTORY IMPORTED"
                                     : "NO CONVERTER HISTORY FOUND",
                        juce::dontSendNotification);
}

void MainComponent::showOptionsMenu()
{
    juce::PopupMenu menu;
    menu.addItem(1, "Open Digital Vault data folder");
    menu.addItem(2, "Launch FINAL SF Player Pro v4.3.2");
    menu.addItem(3, "Launch RuFTraX SF2 Super Instrument v1.8.2");
    menu.addItem(4, "Launch RuFTraX CD Imager");
    menu.addItem(5, "Launch RuFTraX Sample Converter");
    menu.addItem(6, "Launch RuFTraX TIMEFORGE");
    menu.addItem(7, "Launch RuFTraX Plug-In Chainer");
    menu.addItem(8, "Launch RuFTraX RM-10");
    menu.addItem(9, "Launch RuFTraX MuD");
    menu.addSeparator();
    menu.addItem(10, "Rescan all libraries");

    menu.showMenuAsync({}, [safeThis = juce::Component::SafePointer<MainComponent>(this)](int result)
    {
        if (safeThis == nullptr)
            return;
        if (result == 1) safeThis->database.getDataDirectory().revealToUser();
        if (result == 2) safeThis->launchFinalSFPlayerPro();
        if (result == 3) safeThis->launchRuFTraXApp("RuFTraX SF2 Super Instrument");
        if (result == 4) safeThis->launchRuFTraXApp("RuFTraX CD Imager");
        if (result == 5) safeThis->launchRuFTraXApp("RuFTraX Sample Converter");
        if (result == 6) safeThis->launchRuFTraXApp("RuFTraX TIMEFORGE");
        if (result == 7) safeThis->launchRuFTraXApp("RuFTraX Plug-In Chainer");
        if (result == 8) safeThis->launchRuFTraXApp("RuFTraX RM-10");
        if (result == 9) safeThis->launchRuFTraXApp("RuFTraX MuD");
        if (result == 10) safeThis->startScan();
    });
}

const VaultItem* MainComponent::getItemForVisibleRow(int row) const
{
    if (row < 0 || row >= static_cast<int>(filteredIndices.size()))
        return nullptr;
    const auto index = filteredIndices[static_cast<size_t>(row)];
    if (index < 0 || index >= static_cast<int>(allItems.size()))
        return nullptr;
    return &allItems[static_cast<size_t>(index)];
}

juce::Rectangle<int> MainComponent::getArtworkBounds() const
{
    auto bounds = rightPanel.reduced(12);
    bounds.removeFromTop(56);
    bounds.removeFromTop(6);
    const int artworkHeight = juce::jlimit(130, 230, bounds.getHeight() / 3);
    return bounds.removeFromTop(artworkHeight);
}

juce::Rectangle<int> MainComponent::getWaveformBounds() const
{
    auto bounds = rightPanel.reduced(12);
    bounds.removeFromTop(56);
    bounds.removeFromTop(6);
    const int artworkHeight = juce::jlimit(130, 230, bounds.getHeight() / 3);
    bounds.removeFromTop(artworkHeight);
    bounds.removeFromTop(8 + 52 + 34 + 8);
    return bounds.removeFromTop(70);
}

juce::String MainComponent::formatBytes(int64_t bytes)
{
    const double value = static_cast<double>(bytes);
    if (bytes >= 1024LL * 1024LL * 1024LL)
        return juce::String(value / (1024.0 * 1024.0 * 1024.0), 2) + " GB";
    if (bytes >= 1024LL * 1024LL)
        return juce::String(value / (1024.0 * 1024.0), 1) + " MB";
    if (bytes >= 1024LL)
        return juce::String(value / 1024.0, 1) + " KB";
    return juce::String(bytes) + " bytes";
}

juce::String MainComponent::formatDuration(double seconds)
{
    const auto total = static_cast<int>(seconds);
    return juce::String(total / 60).paddedLeft('0', 2)
        + ":" + juce::String(total % 60).paddedLeft('0', 2);
}
