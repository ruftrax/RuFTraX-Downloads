#include "VaultDatabase.h"

#include <algorithm>
#include <regex>
#include <set>

namespace
{
    juce::String readString(const juce::var& value, const juce::Identifier& property)
    {
        if (auto* object = value.getDynamicObject())
            return object->getProperty(property).toString();
        return {};
    }

    int64_t readInt64(const juce::var& value, const juce::Identifier& property)
    {
        if (auto* object = value.getDynamicObject())
            return static_cast<int64_t>(object->getProperty(property));
        return 0;
    }

    double readDouble(const juce::var& value, const juce::Identifier& property)
    {
        if (auto* object = value.getDynamicObject())
            return static_cast<double>(object->getProperty(property));
        return 0.0;
    }

    bool readBool(const juce::var& value, const juce::Identifier& property)
    {
        if (auto* object = value.getDynamicObject())
            return static_cast<bool>(object->getProperty(property));
        return false;
    }

    bool nameContainsAny(juce::String text, std::initializer_list<const char*> words)
    {
        text = text.toLowerCase();
        for (const auto* word : words)
            if (text.contains(word))
                return true;
        return false;
    }
}

VaultDatabase::VaultDatabase()
{
    getDataDirectory().createDirectory();
}

juce::File VaultDatabase::getDataDirectory() const
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("RuFTraX")
        .getChildFile("Digital Vault");
}

juce::File VaultDatabase::getDatabaseFile() const
{
    return getDataDirectory().getChildFile("vault-catalog.json");
}

bool VaultDatabase::load()
{
    const juce::ScopedLock scopedLock(lock);
    const auto file = getDatabaseFile();

    items.clear();
    history.clear();
    libraryFolders.clear();

    if (!file.existsAsFile())
        return true;

    const auto parsed = juce::JSON::parse(file);
    auto* object = parsed.getDynamicObject();
    if (object == nullptr)
        return false;

    if (auto* foldersArray = object->getProperty("libraryFolders").getArray())
        for (const auto& folder : *foldersArray)
            libraryFolders.addIfNotAlreadyThere(folder.toString());

    if (auto* itemArray = object->getProperty("items").getArray())
        for (const auto& item : *itemArray)
            items.push_back(itemFromVar(item));

    if (auto* historyArray = object->getProperty("history").getArray())
        for (const auto& entry : *historyArray)
            history.push_back(historyFromVar(entry));

    return true;
}

bool VaultDatabase::save() const
{
    const juce::ScopedLock scopedLock(lock);
    getDataDirectory().createDirectory();

    juce::Array<juce::var> folderValues;
    for (const auto& folder : libraryFolders)
        folderValues.add(folder);

    juce::Array<juce::var> itemValues;
    for (const auto& item : items)
        itemValues.add(itemToVar(item));

    juce::Array<juce::var> historyValues;
    for (const auto& entry : history)
        historyValues.add(historyToVar(entry));

    auto root = juce::var(new juce::DynamicObject());
    auto* object = root.getDynamicObject();
    object->setProperty("schemaVersion", 1);
    object->setProperty("productVersion", "0.2.2");
    object->setProperty("libraryFolders", juce::var(folderValues));
    object->setProperty("items", juce::var(itemValues));
    object->setProperty("history", juce::var(historyValues));

    const juce::TemporaryFile temporary(getDatabaseFile());
    if (!temporary.getFile().replaceWithText(juce::JSON::toString(root, true)))
        return false;
    return temporary.overwriteTargetFileWithTemporary();
}

std::vector<VaultItem> VaultDatabase::getItems() const
{
    const juce::ScopedLock scopedLock(lock);
    return items;
}

void VaultDatabase::replaceItems(std::vector<VaultItem> newItems)
{
    const juce::ScopedLock scopedLock(lock);
    items = std::move(newItems);
}

juce::StringArray VaultDatabase::getLibraryFolders() const
{
    const juce::ScopedLock scopedLock(lock);
    return libraryFolders;
}

bool VaultDatabase::addLibraryFolder(const juce::File& folder)
{
    if (!folder.isDirectory())
        return false;

    const juce::ScopedLock scopedLock(lock);
    const auto path = folder.getFullPathName();
    if (libraryFolders.contains(path))
        return false;

    libraryFolders.add(path);
    return true;
}

bool VaultDatabase::removeLibraryFolder(const juce::File& folder)
{
    const juce::ScopedLock scopedLock(lock);
    const auto index = libraryFolders.indexOf(folder.getFullPathName());
    if (index < 0)
        return false;
    libraryFolders.remove(index);
    return true;
}

std::vector<VaultHistoryEntry> VaultDatabase::getHistory() const
{
    const juce::ScopedLock scopedLock(lock);
    return history;
}

void VaultDatabase::addHistory(juce::String action, juce::String detail)
{
    const juce::ScopedLock scopedLock(lock);
    history.insert(history.begin(),
                   { std::move(action),
                     std::move(detail),
                     juce::Time::getCurrentTime().toMilliseconds() });
    if (history.size() > 250)
        history.resize(250);
}

juce::var VaultDatabase::itemToVar(const VaultItem& item)
{
    auto value = juce::var(new juce::DynamicObject());
    auto* object = value.getDynamicObject();
    object->setProperty("id", item.id);
    object->setProperty("name", item.name);
    object->setProperty("path", item.path);
    object->setProperty("format", item.format);
    object->setProperty("category", item.category);
    object->setProperty("tags", item.tags);
    object->setProperty("artworkPath", item.artworkPath);
    object->setProperty("rootNote", item.rootNote);
    object->setProperty("fileSize", item.fileSize);
    object->setProperty("modifiedMilliseconds", item.modifiedMilliseconds);
    object->setProperty("durationSeconds", item.durationSeconds);
    object->setProperty("sampleRate", item.sampleRate);
    object->setProperty("channels", item.channels);
    object->setProperty("previewable", item.previewable);
    return value;
}

VaultItem VaultDatabase::itemFromVar(const juce::var& value)
{
    VaultItem item;
    item.id = readString(value, "id");
    item.name = readString(value, "name");
    item.path = readString(value, "path");
    item.format = readString(value, "format");
    item.category = readString(value, "category");
    item.tags = readString(value, "tags");
    item.artworkPath = readString(value, "artworkPath");
    item.rootNote = readString(value, "rootNote");
    item.fileSize = readInt64(value, "fileSize");
    item.modifiedMilliseconds = readInt64(value, "modifiedMilliseconds");
    item.durationSeconds = readDouble(value, "durationSeconds");
    item.sampleRate = readDouble(value, "sampleRate");
    item.channels = static_cast<int>(readInt64(value, "channels"));
    item.previewable = readBool(value, "previewable");
    return item;
}

juce::var VaultDatabase::historyToVar(const VaultHistoryEntry& entry)
{
    auto value = juce::var(new juce::DynamicObject());
    auto* object = value.getDynamicObject();
    object->setProperty("action", entry.action);
    object->setProperty("detail", entry.detail);
    object->setProperty("timestampMilliseconds", entry.timestampMilliseconds);
    return value;
}

VaultHistoryEntry VaultDatabase::historyFromVar(const juce::var& value)
{
    VaultHistoryEntry entry;
    entry.action = readString(value, "action");
    entry.detail = readString(value, "detail");
    entry.timestampMilliseconds = readInt64(value, "timestampMilliseconds");
    return entry;
}

VaultScanner::VaultScanner(juce::StringArray foldersToScan,
                           ProgressCallback onProgress,
                           CompletionCallback onComplete)
    : juce::Thread("RuFTraX Digital Vault Scanner"),
      folders(std::move(foldersToScan)),
      progress(std::move(onProgress)),
      complete(std::move(onComplete))
{
}

VaultScanner::~VaultScanner()
{
    signalThreadShouldExit();
    stopThread(3000);
}

void VaultScanner::run()
{
    std::vector<VaultItem> results;
    std::set<std::string> seenPaths;
    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();
    int filesSeen = 0;

    for (const auto& folderPath : folders)
    {
        if (threadShouldExit())
            return;

        const juce::File root(folderPath);
        if (!root.isDirectory())
            continue;

        if (progress)
            progress(filesSeen, root.getFileName());

        for (const auto& entry : juce::RangedDirectoryIterator(root, true, "*", juce::File::findFiles))
        {
            if (threadShouldExit())
                return;

            const auto file = entry.getFile();
            ++filesSeen;

            if ((filesSeen % 50) == 0 && progress)
                progress(filesSeen, root.getFileName());

            if (!isSupportedAsset(file))
                continue;

            const auto canonicalPath = file.getFullPathName().toStdString();
            if (!seenPaths.insert(canonicalPath).second)
                continue;

            VaultItem item;
            item.id = makeStableId(file);
            item.name = file.getFileNameWithoutExtension();
            item.path = file.getFullPathName();
            item.format = file.getFileExtension().trimCharactersAtStart(".").toUpperCase();
            item.category = inferCategory(file);
            item.tags = makeTags(file, item.category);
            item.artworkPath = findArtwork(file);
            item.rootNote = inferRootNote(file);
            item.fileSize = file.getSize();
            item.modifiedMilliseconds = file.getLastModificationTime().toMilliseconds();

            if (auto reader = std::unique_ptr<juce::AudioFormatReader>(formatManager.createReaderFor(file)))
            {
                item.previewable = true;
                item.sampleRate = reader->sampleRate;
                item.channels = static_cast<int>(reader->numChannels);
                if (reader->sampleRate > 0.0)
                    item.durationSeconds = static_cast<double>(reader->lengthInSamples) / reader->sampleRate;
            }

            results.push_back(std::move(item));
        }
    }

    std::sort(results.begin(), results.end(), [](const auto& first, const auto& second)
    {
        const auto categoryOrder = first.category.compareNatural(second.category);
        if (categoryOrder != 0)
            return categoryOrder < 0;
        return first.name.compareNatural(second.name) < 0;
    });

    if (complete && !threadShouldExit())
        complete(std::move(results));
}

bool VaultScanner::isSupportedAsset(const juce::File& file)
{
    static const juce::StringArray extensions
    {
        ".wav", ".aif", ".aiff", ".flac", ".mp3", ".ogg", ".m4a",
        ".sf2", ".sfz", ".exs", ".exs24", ".nki", ".nkm",
        ".akp", ".akm", ".s3p", ".pgm", ".xpm", ".xpj",
        ".iso", ".img", ".bin", ".cue", ".mdf", ".nrg",
        ".ruftrax", ".rtxpreset"
    };
    return extensions.contains(file.getFileExtension().toLowerCase());
}

juce::String VaultScanner::makeStableId(const juce::File& file)
{
    return juce::String::toHexString(file.getFullPathName().hashCode64());
}

juce::String VaultScanner::inferCategory(const juce::File& file)
{
    const auto text = file.getFullPathName();
    if (nameContainsAny(text, { "piano", "keys", "wurly", "rhodes", "organ", "clav" })) return "Keys";
    if (nameContainsAny(text, { "brass", "trumpet", "trombone", "horn", "tuba" })) return "Brass";
    if (nameContainsAny(text, { "string", "violin", "viola", "cello", "orchestra" })) return "Strings";
    if (nameContainsAny(text, { "guitar", "strat", "tele", "acoustic" })) return "Guitar";
    if (nameContainsAny(text, { "bass", "sub" })) return "Bass";
    if (nameContainsAny(text, { "drum", "kick", "snare", "hat", "tom", "cymbal", "rim" })) return "Drums";
    if (nameContainsAny(text, { "perc", "conga", "bongo", "shaker", "timpani" })) return "Percussion";
    if (nameContainsAny(text, { "synth", "pad", "lead", "arp", "analog", "digital" })) return "Synth";
    if (nameContainsAny(text, { "vocal", "voice", "choir", "vox" })) return "Vocal";
    if (nameContainsAny(text, { "fx", "effect", "impact", "riser", "noise" })) return "FX";
    if (nameContainsAny(text, { "iso", "image", "disc" })) return "Disc Images";
    return "Other";
}

juce::String VaultScanner::inferRootNote(const juce::File& file)
{
    const std::regex expression(R"((?:^|[_\-\s])([A-Ga-g])([#b]?)([0-8])(?:$|[_\-\s.]))");
    std::smatch match;
    const auto name = file.getFileName().toStdString();
    if (!std::regex_search(name, match, expression) || match.size() < 4)
        return {};

    auto note = juce::String(match[1].str()).toUpperCase();
    note += juce::String(match[2].str());
    note += juce::String(match[3].str());
    return note;
}

juce::String VaultScanner::findArtwork(const juce::File& file)
{
    const auto parent = file.getParentDirectory();
    const auto base = file.getFileNameWithoutExtension();
    const juce::StringArray names
    {
        base + ".png", base + ".jpg", base + ".jpeg",
        "cover.png", "cover.jpg", "artwork.png", "artwork.jpg", "folder.jpg"
    };

    for (const auto& name : names)
    {
        const auto candidate = parent.getChildFile(name);
        if (candidate.existsAsFile())
            return candidate.getFullPathName();
    }
    return {};
}

juce::String VaultScanner::makeTags(const juce::File& file, const juce::String& category)
{
    juce::StringArray values;
    values.add(category);
    values.add(file.getFileExtension().trimCharactersAtStart(".").toUpperCase());
    values.add(file.getParentDirectory().getFileName());
    values.removeEmptyStrings();
    values.removeDuplicates(false);
    return values.joinIntoString(", ");
}
