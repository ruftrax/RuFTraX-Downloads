#pragma once

#include <JuceHeader.h>
#include <functional>
#include <vector>

struct VaultItem
{
    juce::String id;
    juce::String name;
    juce::String path;
    juce::String format;
    juce::String category;
    juce::String tags;
    juce::String artworkPath;
    juce::String rootNote;
    int64_t fileSize = 0;
    int64_t modifiedMilliseconds = 0;
    double durationSeconds = 0.0;
    double sampleRate = 0.0;
    int channels = 0;
    bool previewable = false;
};

struct VaultHistoryEntry
{
    juce::String action;
    juce::String detail;
    int64_t timestampMilliseconds = 0;
};

class VaultDatabase final
{
public:
    VaultDatabase();

    bool load();
    bool save() const;

    std::vector<VaultItem> getItems() const;
    void replaceItems(std::vector<VaultItem> newItems);

    juce::StringArray getLibraryFolders() const;
    bool addLibraryFolder(const juce::File& folder);
    bool removeLibraryFolder(const juce::File& folder);

    std::vector<VaultHistoryEntry> getHistory() const;
    void addHistory(juce::String action, juce::String detail);

    juce::File getDatabaseFile() const;
    juce::File getDataDirectory() const;

private:
    static juce::var itemToVar(const VaultItem& item);
    static VaultItem itemFromVar(const juce::var& value);
    static juce::var historyToVar(const VaultHistoryEntry& entry);
    static VaultHistoryEntry historyFromVar(const juce::var& value);

    mutable juce::CriticalSection lock;
    std::vector<VaultItem> items;
    std::vector<VaultHistoryEntry> history;
    juce::StringArray libraryFolders;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VaultDatabase)
};

class VaultScanner final : public juce::Thread
{
public:
    using ProgressCallback = std::function<void(int filesSeen, const juce::String& currentFolder)>;
    using CompletionCallback = std::function<void(std::vector<VaultItem>)>;

    VaultScanner(juce::StringArray foldersToScan,
                 ProgressCallback onProgress,
                 CompletionCallback onComplete);
    ~VaultScanner() override;

    void run() override;

    static juce::String inferCategory(const juce::File& file);
    static juce::String inferRootNote(const juce::File& file);
    static bool isSupportedAsset(const juce::File& file);

private:
    static juce::String makeStableId(const juce::File& file);
    static juce::String findArtwork(const juce::File& file);
    static juce::String makeTags(const juce::File& file, const juce::String& category);

    juce::StringArray folders;
    ProgressCallback progress;
    CompletionCallback complete;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VaultScanner)
};
