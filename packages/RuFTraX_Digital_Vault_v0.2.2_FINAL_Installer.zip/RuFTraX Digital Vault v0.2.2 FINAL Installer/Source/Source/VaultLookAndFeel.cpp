#include "VaultLookAndFeel.h"

VaultLookAndFeel::VaultLookAndFeel()
{
    setColour(juce::ResizableWindow::backgroundColourId, juce::Colour(VaultColours::background));
    setColour(juce::Label::textColourId, juce::Colour(VaultColours::ivory));
    setColour(juce::TextEditor::backgroundColourId, juce::Colour(VaultColours::background));
    setColour(juce::TextEditor::textColourId, juce::Colour(VaultColours::ivory));
    setColour(juce::TextEditor::outlineColourId, juce::Colour(VaultColours::grid));
    setColour(juce::TextEditor::focusedOutlineColourId, juce::Colour(VaultColours::amber));
    setColour(juce::ComboBox::backgroundColourId, juce::Colour(VaultColours::background));
    setColour(juce::ComboBox::textColourId, juce::Colour(VaultColours::ivory));
    setColour(juce::ComboBox::outlineColourId, juce::Colour(VaultColours::grid));
    setColour(juce::ComboBox::arrowColourId, juce::Colour(VaultColours::amber));
    setColour(juce::PopupMenu::backgroundColourId, juce::Colour(VaultColours::panel));
    setColour(juce::PopupMenu::textColourId, juce::Colour(VaultColours::ivory));
    setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(VaultColours::red));
    setColour(juce::PopupMenu::highlightedTextColourId, juce::Colour(VaultColours::ivory));
    setColour(juce::TableHeaderComponent::backgroundColourId, juce::Colour(VaultColours::panelRaised));
    setColour(juce::TableHeaderComponent::textColourId, juce::Colour(VaultColours::ivory));
    setColour(juce::ListBox::backgroundColourId, juce::Colour(VaultColours::panel));
    setColour(juce::ListBox::outlineColourId, juce::Colour(VaultColours::grid));
    setColour(juce::ScrollBar::thumbColourId, juce::Colour(VaultColours::bronze));
}

void VaultLookAndFeel::drawButtonBackground(juce::Graphics& graphics,
                                            juce::Button& button,
                                            const juce::Colour& backgroundColour,
                                            bool isMouseOverButton,
                                            bool isButtonDown)
{
    auto bounds = button.getLocalBounds().toFloat().reduced(0.5f);
    auto colour = backgroundColour;
    if (isButtonDown)
        colour = juce::Colour(VaultColours::red);
    else if (isMouseOverButton)
        colour = colour.brighter(0.16f);

    graphics.setColour(colour);
    graphics.fillRoundedRectangle(bounds, 4.0f);
    graphics.setColour(juce::Colour(VaultColours::bronze));
    graphics.drawRoundedRectangle(bounds, 4.0f, 1.0f);
}

void VaultLookAndFeel::drawButtonText(juce::Graphics& graphics,
                                      juce::TextButton& button,
                                      bool,
                                      bool)
{
    graphics.setColour(button.findColour(juce::TextButton::textColourOffId));
    graphics.setFont(juce::FontOptions(13.0f, juce::Font::bold));
    graphics.drawFittedText(button.getButtonText(),
                            button.getLocalBounds().reduced(7, 2),
                            juce::Justification::centred,
                            1);
}

void VaultLookAndFeel::drawComboBox(juce::Graphics& graphics,
                                    int width,
                                    int height,
                                    bool,
                                    int,
                                    int,
                                    int,
                                    int,
                                    juce::ComboBox& box)
{
    auto bounds = juce::Rectangle<float>(0.0f, 0.0f,
                                         static_cast<float>(width),
                                         static_cast<float>(height)).reduced(0.5f);
    graphics.setColour(box.findColour(juce::ComboBox::backgroundColourId));
    graphics.fillRoundedRectangle(bounds, 4.0f);
    graphics.setColour(box.findColour(juce::ComboBox::outlineColourId));
    graphics.drawRoundedRectangle(bounds, 4.0f, 1.0f);

    juce::Path arrow;
    const float centreX = static_cast<float>(width - 16);
    const float centreY = static_cast<float>(height) * 0.5f;
    arrow.addTriangle(centreX - 5.0f, centreY - 2.0f,
                      centreX + 5.0f, centreY - 2.0f,
                      centreX, centreY + 4.0f);
    graphics.setColour(box.findColour(juce::ComboBox::arrowColourId));
    graphics.fillPath(arrow);
}

void VaultLookAndFeel::drawPopupMenuBackground(juce::Graphics& graphics, int width, int height)
{
    graphics.fillAll(juce::Colour(VaultColours::panel));
    graphics.setColour(juce::Colour(VaultColours::bronze));
    graphics.drawRect(0, 0, width, height);
}
