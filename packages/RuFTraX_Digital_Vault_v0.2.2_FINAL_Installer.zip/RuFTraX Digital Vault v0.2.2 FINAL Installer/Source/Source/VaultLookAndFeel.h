#pragma once

#include <JuceHeader.h>

namespace VaultColours
{
    static constexpr juce::uint32 background = 0xff121414;
    static constexpr juce::uint32 panel = 0xff1d211f;
    static constexpr juce::uint32 panelRaised = 0xff272c29;
    static constexpr juce::uint32 bronze = 0xffb47a2a;
    static constexpr juce::uint32 amber = 0xfff0a323;
    static constexpr juce::uint32 ivory = 0xffe9d8b4;
    static constexpr juce::uint32 teal = 0xff31d1cc;
    static constexpr juce::uint32 red = 0xff9f251c;
    static constexpr juce::uint32 muted = 0xff838b86;
    static constexpr juce::uint32 grid = 0xff3b433f;
}

class VaultLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    VaultLookAndFeel();

    void drawButtonBackground(juce::Graphics&,
                              juce::Button&,
                              const juce::Colour& backgroundColour,
                              bool isMouseOverButton,
                              bool isButtonDown) override;
    void drawButtonText(juce::Graphics&,
                        juce::TextButton&,
                        bool isMouseOverButton,
                        bool isButtonDown) override;
    void drawComboBox(juce::Graphics&,
                      int width,
                      int height,
                      bool isButtonDown,
                      int buttonX,
                      int buttonY,
                      int buttonW,
                      int buttonH,
                      juce::ComboBox&) override;
    void drawPopupMenuBackground(juce::Graphics&, int width, int height) override;

private:
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VaultLookAndFeel)
};
