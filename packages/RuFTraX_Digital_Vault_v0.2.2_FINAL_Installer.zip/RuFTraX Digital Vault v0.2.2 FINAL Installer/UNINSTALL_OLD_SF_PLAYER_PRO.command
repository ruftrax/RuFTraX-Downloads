#!/bin/zsh
set -euo pipefail

FINAL_VERSION="4.3.2"
FINAL_BUNDLE_ID="com.ruftrax.sf2player"
TRASH_DIR="$HOME/.Trash"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
REMOVED=0
UNREGISTERED=0

bundle_value() {
    local bundle="$1"
    local key="$2"
    /usr/bin/defaults read "$bundle/Contents/Info" "$key" 2>/dev/null \
        || /usr/bin/defaults read "$bundle/Contents/Info.plist" "$key" 2>/dev/null \
        || true
}

is_ruftrax_player() {
    local bundle="$1"
    local identifier
    identifier="$(bundle_value "$bundle" CFBundleIdentifier)"
    [[ "$identifier" == "$FINAL_BUNDLE_ID" || "$identifier" == "$FINAL_BUNDLE_ID".* ]]
}

move_old_installed_bundle_to_trash() {
    local bundle="$1"
    [[ -d "$bundle" ]] || return 0

    if ! is_ruftrax_player "$bundle"; then
        print "Skipped unrelated bundle: $bundle"
        return 0
    fi

    local version
    version="$(bundle_value "$bundle" CFBundleShortVersionString)"

    if [[ "$version" == "$FINAL_VERSION" ]]; then
        print "KEPT FINAL v$FINAL_VERSION: $bundle"
        return 0
    fi

    if [[ -z "$version" ]]; then
        print "Skipped because its version could not be verified: $bundle"
        return 0
    fi

    mkdir -p "$TRASH_DIR"
    local extension="${bundle:e}"
    local base_name="${bundle:t:r}"
    local destination="$TRASH_DIR/${base_name} OLD v${version} ${TIMESTAMP}.${extension}"

    print "Moving old v$version to Trash:"
    print "  $bundle"

    if [[ -w "${bundle:h}" ]]; then
        mv "$bundle" "$destination"
    else
        sudo mv "$bundle" "$destination"
        sudo chown -R "$USER":staff "$destination"
    fi

    print "  -> $destination"
    REMOVED=$((REMOVED + 1))
}

print "RuFTraX SF Player Pro cleanup"
print "Final protected version: v$FINAL_VERSION"
print

installed_bundles=(
    "$HOME/Applications/RuFTraX SF Player Pro.app"
    "/Applications/RuFTraX SF Player Pro.app"
    "$HOME/Library/Audio/Plug-Ins/Components/RuFTraX SF Player Pro.component"
    "/Library/Audio/Plug-Ins/Components/RuFTraX SF Player Pro.component"
    "$HOME/Library/Audio/Plug-Ins/VST3/RuFTraX SF Player Pro.vst3"
    "/Library/Audio/Plug-Ins/VST3/RuFTraX SF Player Pro.vst3"
)

for bundle in "${installed_bundles[@]}"; do
    move_old_installed_bundle_to_trash "$bundle"
done

LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
if [[ -x "$LSREGISTER" ]]; then
    while IFS= read -r candidate; do
        [[ -d "$candidate" ]] || continue
        [[ "${candidate:e}" == "app" ]] || continue
        is_ruftrax_player "$candidate" || continue

        version="$(bundle_value "$candidate" CFBundleShortVersionString)"
        if [[ -n "$version" && "$version" != "$FINAL_VERSION" ]]; then
            "$LSREGISTER" -u "$candidate" >/dev/null 2>&1 || true
            print "Unregistered duplicate v$version: $candidate"
            UNREGISTERED=$((UNREGISTERED + 1))
        fi
    done < <(/usr/bin/mdfind "kMDItemCFBundleIdentifier == '$FINAL_BUNDLE_ID'" 2>/dev/null)
fi

killall AudioComponentRegistrar >/dev/null 2>&1 || true

print
print "CLEANUP COMPLETE"
print "Old installed bundles moved to Trash: $REMOVED"
print "Old duplicate build registrations removed: $UNREGISTERED"
print "RuFTraX SF Player Pro v$FINAL_VERSION was protected."
print
print "Items in the Trash can be recovered until the Trash is emptied."
