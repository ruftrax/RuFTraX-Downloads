RuFTraX Digital Vault v0.2.3 FINAL
=================================

This release adds a permanent RuFTraX Apps panel on the left side of the
Vault. It provides one-click access to all nine approved applications:

1. Digital Vault
2. CD Imager
3. Sample Converter
4. SF Player Pro v4.3.2
5. SF2 Super Instrument
6. TIMEFORGE
7. RM-10
8. MuD
9. Plug-In Chainer

INSTALL

1. Double-click INSTALL_RUFTRAX_DIGITAL_VAULT_V0.2.3.command.
2. If macOS asks, allow Terminal to run it.
3. The installer finds JUCE and CMake, builds the app, installs it in
   your user Applications folder, and opens it.

FIRST TEST

1. Confirm all nine app buttons appear in the left panel.
2. Confirm the Digital Vault icon appears in Finder and Applications.
3. Click each app button and confirm the installed application opens.
4. Click ADD LIBRARY and choose a small sample or SoundFont folder.
5. Wait for the status to say ASSETS READY.
6. Search, select an audio file, and click PLAY PREVIEW.
7. Close and reopen the app to confirm the catalog is saved.

INSTALL LOCATION

~/Applications/RuFTraX Digital Vault.app

CATALOG LOCATION

~/Library/Application Support/RuFTraX/Digital Vault/vault-catalog.json

INSTALL LOG

~/Desktop/RuFTraX_Digital_Vault_v0.2.3_Install.log

OPTIONAL OLD PLAYER CLEANUP

UNINSTALL_OLD_SF_PLAYER_PRO.command remains available as a separate,
recoverable cleanup tool. It protects the approved v4.3.2 build.

This local installer uses an ad-hoc signature. Apple Developer ID signing
and notarization are still required before unrestricted public distribution.
