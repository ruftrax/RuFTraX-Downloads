# RuFTraX Digital Vault v0.2.3 FINAL

Version 0.2.3 turns Digital Vault into the visible nine-app hub for the
complete RuFTraX suite.

The installer now moves the previous application bundle into its timestamped
backup before copying the new build. This prevents stale resources from older
Vault versions from invalidating the new app signature.

## Nine-app panel

The left panel now contains one-click entries for:

- Digital Vault
- CD Imager
- Sample Converter
- SF Player Pro v4.3.2
- SF2 Super Instrument
- TIMEFORGE
- RM-10
- MuD
- Plug-In Chainer

Each external entry searches the user Applications folder, the system
Applications folder, and Spotlight before reporting that an app is missing.
The SF Player entry now requires the approved v4.3.2 final build.

## Included

- Persistent local catalog backend
- Recursive multi-folder scanning
- Search and category filters
- Audio and sampler format indexing
- General disc-image indexing
- Sidecar artwork discovery
- Audio metadata and waveform preview
- Root-note labels parsed from filenames
- Conversion and library activity history
- Visible launch links for all nine RuFTraX applications
- Approved Digital Vault Finder icon connected to the macOS app bundle
- Drag-and-drop folder import
- Scalable vintage RuFTraX interface
- One-click macOS build and installer command

## Test focus

- Very large folders and external-drive libraries
- MP3/M4A preview behavior
- Reopening the saved catalog
- Missing or disconnected external drives
- Launch links for all nine currently installed RuFTraX app names
- Converter history paths

## Distribution note

This final local package is buildable and ad-hoc signed. Public distribution
requires Apple Developer ID signing and notarization.
