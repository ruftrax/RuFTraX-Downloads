# RuFTraX Digital Vault

RuFTraX Digital Vault is the local library and application hub for the
RuFTraX instrument and conversion workflow. Version 0.2.3 is a standalone
Apple-silicon macOS application built with JUCE.

## Version 0.2.3 scope

- Add or drag in any number of library folders.
- Recursively index audio, sampler, preset, and disc-image assets.
- Search by instrument name, filename, path, format, category, tags, or root-note label.
- Filter the catalog by instrument category.
- Read WAV, AIFF, FLAC, MP3, OGG, and other JUCE-supported audio metadata.
- Preview supported audio through the selected Mac audio output.
- Display sidecar artwork when a matching image, `cover`, `artwork`, or `folder.jpg` exists.
- Infer useful categories from folder and file names.
- Read root-note labels embedded in filenames such as `Bass_C2.wav`.
- Persist the catalog, library locations, and activity history locally.
- Import available RuFTraX Sample Converter log history.
- Show all nine RuFTraX applications in the left workflow panel.
- Launch CD Imager, Sample Converter, SF Player Pro, SF2 Super Instrument,
  TIMEFORGE, RM-10, MuD, and Plug-In Chainer.
- Keep Digital Vault itself visible as the first app entry.
- Display the approved Digital Vault icon in Finder and the macOS Applications folder.
- Require RuFTraX SF Player Pro v4.3.2 FINAL, the centered-preset MIDI / Tone / Chord Analyzer build with saved SoundFont transpose; older and simplified builds are not launched.
- Reveal or open any indexed item in Finder.
- Scale from 1050 x 820 through 2200 x 1400.

## Indexed formats

Audio:

`WAV`, `AIFF`, `FLAC`, `MP3`, `OGG`, `M4A`

Sampler and preset:

`SF2`, `SFZ`, `EXS`, `EXS24`, `NKI`, `NKM`, `AKP`, `AKM`, `S3P`, `PGM`, `XPM`, `XPJ`, `RUFTRAX`, `RTXPRESET`

Disc image:

`ISO`, `IMG`, `BIN`, `CUE`, `MDF`, `NRG`

## Local data

The catalog is stored at:

`~/Library/Application Support/RuFTraX/Digital Vault/vault-catalog.json`

Digital Vault never moves, renames, converts, or deletes indexed assets. It stores paths and metadata only.

The package-level `UNINSTALL_OLD_SF_PLAYER_PRO.command` is a separate, explicit cleanup tool. It moves verified older installed player bundles to the Trash, keeps v4.3.2, and only unregisters duplicate old build copies.

## Build on macOS

Requirements:

- Apple-silicon Mac
- macOS 12 or newer
- Xcode command-line tools
- CMake 3.22 or newer
- JUCE

Run:

```zsh
cd "/path/to/RuFTraX Digital Vault Source"
chmod +x build_mac.sh Scripts/validate_release_source.sh
./build_mac.sh
```

The build script automatically checks the known JUCE locations used by the RuFTraX projects. You can also set:

```zsh
export JUCE_DIR="$HOME/JUCE"
```

## Distribution status

Version 0.2.3 is the local nine-app final. The included one-click installer
builds the app locally and applies an ad-hoc signature. Public distribution
still requires Apple Developer ID signing and notarization.
