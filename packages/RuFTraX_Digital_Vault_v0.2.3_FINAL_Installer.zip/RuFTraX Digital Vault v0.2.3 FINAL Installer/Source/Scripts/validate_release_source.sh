#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
SOURCE_ROOT="${SCRIPT_DIR:h}"
PACKAGE_ROOT="${SOURCE_ROOT:h}"

fail() {
    print "VALIDATION FAILED: $1"
    exit 1
}

required_files=(
    "$SOURCE_ROOT/CMakeLists.txt"
    "$SOURCE_ROOT/Source/Main.cpp"
    "$SOURCE_ROOT/Source/MainComponent.cpp"
    "$SOURCE_ROOT/Source/MainComponent.h"
    "$SOURCE_ROOT/Source/VaultDatabase.cpp"
    "$SOURCE_ROOT/Source/VaultDatabase.h"
    "$SOURCE_ROOT/Source/VaultLookAndFeel.cpp"
    "$SOURCE_ROOT/Source/VaultLookAndFeel.h"
    "$SOURCE_ROOT/Assets/AppIcon.png"
    "$SOURCE_ROOT/build_mac.sh"
    "$PACKAGE_ROOT/INSTALL_RUFTRAX_DIGITAL_VAULT_V0.2.3.command"
    "$PACKAGE_ROOT/UNINSTALL_OLD_SF_PLAYER_PRO.command"
)

for file in "${required_files[@]}"; do
    [[ -s "$file" ]] || fail "Missing or empty file: $file"
done

grep -q 'project(RuFTraXDigitalVault VERSION 0.2.3' "$SOURCE_ROOT/CMakeLists.txt" \
    || fail "CMake version is not 0.2.3"
grep -q 'BUNDLE_ID "com.ruftrax.digitalvault"' "$SOURCE_ROOT/CMakeLists.txt" \
    || fail "Bundle identifier changed"
grep -q 'juce_generate_juce_header(RuFTraXDigitalVault)' "$SOURCE_ROOT/CMakeLists.txt" \
    || fail "Generated JUCE header support is missing"
grep -Fq 'ICON_BIG "${CMAKE_CURRENT_SOURCE_DIR}/Assets/AppIcon.png"' "$SOURCE_ROOT/CMakeLists.txt" \
    || fail "Finder application icon is not connected to the build"
grep -q 'VaultScanner' "$SOURCE_ROOT/Source/VaultDatabase.cpp" \
    || fail "Library scanner is missing"
grep -q 'vault-catalog.json' "$SOURCE_ROOT/Source/VaultDatabase.cpp" \
    || fail "Persistent catalog is missing"
grep -q 'AudioTransportSource' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "Audio preview engine is missing"
grep -q 'FileDragAndDropTarget' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "Folder drag and drop is missing"
grep -q 'IMPORT CONVERTER HISTORY' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "Converter history control is missing"
grep -q 'RuFTraX CD Imager' "$SOURCE_ROOT/Source/MainComponent.cpp" \
    || fail "CD Imager workflow link is missing"
grep -q 'RuFTraX Sample Converter' "$SOURCE_ROOT/Source/MainComponent.cpp" \
    || fail "Sample Converter workflow link is missing"
grep -q 'launchFinalSFPlayerPro' "$SOURCE_ROOT/Source/MainComponent.cpp" \
    || fail "Final SF Player Pro launcher is missing"
grep -q 'readBundleVersion(appBundle) == "4.3.2"' "$SOURCE_ROOT/Source/MainComponent.cpp" \
    || fail "SF Player Pro v4.3.2 lock is missing"
grep -q 'com.ruftrax.sf2player' "$SOURCE_ROOT/Source/MainComponent.cpp" \
    || fail "SF Player Pro bundle identifier is missing"
if grep -q 'launchRuFTraXApp("RuFTraX SF Player Pro")' "$SOURCE_ROOT/Source/MainComponent.cpp"; then
    fail "Ambiguous SF Player Pro name-based launcher is still present"
fi
grep -q 'SF PLAYER PRO v4.3.2' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "Visible SF Player Pro v4.3.2 launcher is missing"
grep -q 'DIGITAL VAULT  -  OPEN' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "Digital Vault app entry is missing"
grep -q 'SF2 SUPER INSTRUMENT' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "SF2 Super Instrument app entry is missing"
grep -q 'TIMEFORGE' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "TIMEFORGE app entry is missing"
grep -q 'RM-10' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "RM-10 app entry is missing"
grep -q 'launchRuFTraXApp("RuFTraX RM-10")' "$SOURCE_ROOT/Source/MainComponent.cpp" \
    || fail "RM-10 launcher is missing"
grep -q 'MUD' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "MuD app entry is missing"
grep -q 'launchRuFTraXApp("RuFTraX MuD")' "$SOURCE_ROOT/Source/MainComponent.cpp" \
    || fail "MuD launcher is missing"
grep -q '9-APP HUB' "$SOURCE_ROOT/Source/MainComponent.cpp" \
    || fail "Nine-app hub label is missing"
grep -q 'PLUG-IN CHAINER' "$SOURCE_ROOT/Source/MainComponent.h" \
    || fail "Plug-In Chainer app entry is missing"
grep -q 'RUFTRAX APPS' "$SOURCE_ROOT/Source/MainComponent.cpp" \
    || fail "RuFTraX app panel heading is missing"
grep -q 'setResizable(true, true)' "$SOURCE_ROOT/Source/Main.cpp" \
    || fail "Scalable window support is missing"
grep -Fq 'mv "$INSTALL_APP" "$BACKUP_DIR/RuFTraX Digital Vault.app"' \
    "$PACKAGE_ROOT/INSTALL_RUFTRAX_DIGITAL_VAULT_V0.2.3.command" \
    || fail "Clean app-bundle replacement is missing"
grep -Fq 'codesign --force --deep --sign - "$INSTALL_APP"' \
    "$PACKAGE_ROOT/INSTALL_RUFTRAX_DIGITAL_VAULT_V0.2.3.command" \
    || fail "Installed app re-sign step is missing"

if LC_ALL=C grep -RIn $'\342\200\246\|\342\200\223\|\342\200\224\|\342\200\231\|\342\200\234\|\342\200\235' \
    "$SOURCE_ROOT/Source" "$SOURCE_ROOT/CMakeLists.txt" >/dev/null 2>&1; then
    fail "Non-ASCII punctuation was found in source"
fi

legacy_brand="$(printf '\101\113\101\111')"
if LC_ALL=C grep -RIni "$legacy_brand" "$SOURCE_ROOT" >/dev/null 2>&1; then
    fail "Legacy manufacturer branding remains in Digital Vault"
fi

print "RuFTraX Digital Vault v0.2.3 source validation passed."
