#include <JuceHeader.h>
#include "MainComponent.h"

class RuFTraXDigitalVaultApplication final : public juce::JUCEApplication
{
public:
    const juce::String getApplicationName() override       { return "RuFTraX Digital Vault"; }
    const juce::String getApplicationVersion() override    { return "0.2.3"; }
    bool moreThanOneInstanceAllowed() override              { return false; }

    void initialise(const juce::String&) override
    {
        mainWindow = std::make_unique<MainWindow>(getApplicationName());
    }

    void shutdown() override
    {
        mainWindow.reset();
    }

    void systemRequestedQuit() override
    {
        quit();
    }

    void anotherInstanceStarted(const juce::String&) override
    {
        if (mainWindow != nullptr)
            mainWindow->toFront(true);
    }

private:
    class MainWindow final : public juce::DocumentWindow
    {
    public:
        explicit MainWindow(juce::String name)
            : juce::DocumentWindow(std::move(name),
                                   juce::Colour(VaultColours::background),
                                   juce::DocumentWindow::allButtons)
        {
            setUsingNativeTitleBar(true);
            setContentOwned(new MainComponent(), true);
            setResizable(true, true);
            setResizeLimits(1050, 820, 2200, 1400);
            centreWithSize(1440, 850);
            setVisible(true);
        }

        void closeButtonPressed() override
        {
            juce::JUCEApplication::getInstance()->systemRequestedQuit();
        }
    };

    std::unique_ptr<MainWindow> mainWindow;
};

START_JUCE_APPLICATION(RuFTraXDigitalVaultApplication)
