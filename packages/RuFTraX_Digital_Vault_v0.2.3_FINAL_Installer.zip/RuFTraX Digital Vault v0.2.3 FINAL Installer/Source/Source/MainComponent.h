#pragma once

#include <JuceHeader.h>
#include "VaultDatabase.h"
#include "VaultLookAndFeel.h"

class MainComponent final : public juce::AudioAppComponent,
                            public juce::TableListBoxModel,
                            public juce::FileDragAndDropTarget,
                            private juce::Timer
{
public:
    MainComponent();
    ~MainComponent() override;

    void paint(juce::Graphics&) override;
    void resized() override;

    int getNumRows() override;
    void paintRowBackground(juce::Graphics&, int rowNumber, int width, int height, bool rowIsSelected) override;
    void paintCell(juce::Graphics&, int rowNumber, int columnId, int width, int height, bool rowIsSelected) override;
    void selectedRowsChanged(int lastRowSelected) override;
    void cellDoubleClicked(int rowNumber, int columnId, const juce::MouseEvent&) override;

    bool isInterestedInFileDrag(const juce::StringArray& files) override;
    void filesDropped(const juce::StringArray& files, int x, int y) override;

    void prepareToPlay(int samplesPerBlockExpected, double sampleRate) override;
    void getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill) override;
    void releaseResources() override;

private:
    void timerCallback() override;

    void configureControls();
    void addLibraryFolder();
    void removeSelectedFolder();
    void startScan();
    void scanCompleted(std::vector<VaultItem> scannedItems);
    void applyFilters();
    void updateFolderDisplay();
    void updateHistoryDisplay();
    void updateSelectedItem();
    void loadPreview(const juce::File& file);
    void togglePreview();
    void stopPreview();
    void revealSelectedItem();
    void openSelectedItem();
    void launchRuFTraXApp(const juce::String& appName);
    void launchFinalSFPlayerPro();
    void focusDigitalVault();
    void importConverterHistory();
    void showOptionsMenu();

    const VaultItem* getItemForVisibleRow(int row) const;
    juce::Rectangle<int> getArtworkBounds() const;
    juce::Rectangle<int> getWaveformBounds() const;
    static juce::String formatBytes(int64_t bytes);
    static juce::String formatDuration(double seconds);

    VaultLookAndFeel vaultLookAndFeel;
    VaultDatabase database;

    juce::Label brandLabel;
    juce::Label productLabel;
    juce::Label taglineLabel;
    juce::Label statusLabel;

    juce::TextEditor searchEditor;
    juce::ComboBox categoryFilter;
    juce::TextButton addFolderButton { "ADD LIBRARY" };
    juce::TextButton rescanButton { "RESCAN" };
    juce::TextButton optionsButton { "OPTIONS" };

    juce::Label librariesHeading;
    juce::TextEditor libraryFoldersView;
    juce::TextButton removeFolderButton { "REMOVE FOLDER" };
    juce::Label appsHeading;
    juce::TextButton openVaultButton { "DIGITAL VAULT  -  OPEN" };
    juce::TextButton openCDImagerButton { "CD IMAGER" };
    juce::TextButton openConverterButton { "SAMPLE CONVERTER" };
    juce::TextButton openSFPlayerButton { "SF PLAYER PRO v4.3.2" };
    juce::TextButton openSuperInstrumentButton { "SF2 SUPER INSTRUMENT" };
    juce::TextButton openTimeforgeButton { "TIMEFORGE" };
    juce::TextButton openRM10Button { "RM-10" };
    juce::TextButton openMuDButton { "MUD" };
    juce::TextButton openChainerButton { "PLUG-IN CHAINER" };

    juce::TableListBox itemTable { "Vault Library", this };

    juce::Label detailName;
    juce::Label detailType;
    juce::Label detailMetadata;
    juce::Label detailTags;
    juce::TextButton previewButton { "PLAY PREVIEW" };
    juce::TextButton stopButton { "STOP" };
    juce::TextButton revealButton { "SHOW IN FINDER" };
    juce::TextButton openButton { "OPEN" };

    juce::Label historyHeading;
    juce::TextEditor historyView;
    juce::TextButton importHistoryButton { "IMPORT CONVERTER HISTORY" };

    std::vector<VaultItem> allItems;
    std::vector<int> filteredIndices;
    int selectedItemIndex = -1;
    juce::Image selectedArtwork;

    std::unique_ptr<juce::FileChooser> folderChooser;
    std::unique_ptr<VaultScanner> scanner;

    juce::AudioFormatManager audioFormatManager;
    juce::AudioTransportSource transport;
    std::unique_ptr<juce::AudioFormatReaderSource> readerSource;
    juce::AudioThumbnailCache thumbnailCache { 8 };
    juce::AudioThumbnail thumbnail { 512, audioFormatManager, thumbnailCache };

    juce::Rectangle<int> leftPanel;
    juce::Rectangle<int> centrePanel;
    juce::Rectangle<int> rightPanel;
    juce::Rectangle<int> historyPanel;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MainComponent)
};
