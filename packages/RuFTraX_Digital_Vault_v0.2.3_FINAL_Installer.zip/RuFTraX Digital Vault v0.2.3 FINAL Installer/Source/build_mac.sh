#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
BUILD_DIR="$SCRIPT_DIR/build-v0.2.3"

find_juce() {
    local candidates=()
    [[ -n "${JUCE_DIR:-}" ]] && candidates+=("$JUCE_DIR")
    candidates+=(
        "$HOME/JUCE"
        "$HOME/Downloads/JUCE"
        "/Volumes/2T BackUP/RuFTraX Projects/Logic Chainer/JUCE"
        "/Volumes/2T BackUP/RuFTraX Projects/JUCE"
    )

    local candidate
    for candidate in "${candidates[@]}"; do
        if [[ -f "$candidate/CMakeLists.txt" && -d "$candidate/modules" ]]; then
            print -r -- "$candidate"
            return 0
        fi
    done
    return 1
}

find_cmake() {
    if command -v cmake >/dev/null 2>&1; then
        command -v cmake
        return 0
    fi
    local candidate
    for candidate in /opt/homebrew/bin/cmake /usr/local/bin/cmake; do
        [[ -x "$candidate" ]] && { print -r -- "$candidate"; return 0; }
    done
    return 1
}

JUCE_PATH="$(find_juce || true)"
CMAKE_BIN="$(find_cmake || true)"

if [[ -z "$JUCE_PATH" ]]; then
    print "JUCE was not found."
    print "Install JUCE or set JUCE_DIR, for example:"
    print '  export JUCE_DIR="$HOME/JUCE"'
    exit 1
fi

if [[ -z "$CMAKE_BIN" ]]; then
    print "CMake was not found. Install it with: brew install cmake"
    exit 1
fi

"$SCRIPT_DIR/Scripts/validate_release_source.sh"

print "Building RuFTraX Digital Vault v0.2.3..."
print "JUCE: $JUCE_PATH"
print "Build: $BUILD_DIR"

"$CMAKE_BIN" -S "$SCRIPT_DIR" -B "$BUILD_DIR" \
    -DJUCE_DIR="$JUCE_PATH" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_OSX_ARCHITECTURES=arm64

"$CMAKE_BIN" --build "$BUILD_DIR" --config Release --parallel "$(sysctl -n hw.logicalcpu)"

APP_PATH="$BUILD_DIR/RuFTraXDigitalVault_artefacts/Release/RuFTraX Digital Vault.app"
if [[ ! -d "$APP_PATH" ]]; then
    print "Build finished, but the app bundle was not found at:"
    print "  $APP_PATH"
    exit 1
fi

print
print "BUILD COMPLETE"
print "$APP_PATH"
