#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build-v0.1.9"
ARTEFACTS="$BUILD_DIR/RuFTraXMuD_artefacts/Release"
LOG_DIR="$HOME/Library/Logs/RuFTraX"
LOG_FILE="$LOG_DIR/RuFTraX_MuD_v0.1.9_Install.log"

mkdir -p "$LOG_DIR"
exec > >(tee "$LOG_FILE") 2>&1

echo "RuFTraX MuD v0.1.9"
echo "Build and Install"
echo

"$PROJECT_DIR/Scripts/build_mac.sh"

APP_SOURCE="$ARTEFACTS/Standalone/RuFTraX MuD.app"
AU_SOURCE="$ARTEFACTS/AU/RuFTraX MuD.component"
VST3_SOURCE="$ARTEFACTS/VST3/RuFTraX MuD.vst3"

for item in "$APP_SOURCE" "$AU_SOURCE" "$VST3_SOURCE"; do
  if [[ ! -e "$item" ]]; then
    echo "Expected build product is missing: $item" >&2
    exit 1
  fi
done

mkdir -p "$HOME/Applications"
mkdir -p "$HOME/Library/Audio/Plug-Ins/Components"
mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3"

ditto "$APP_SOURCE" "$HOME/Applications/RuFTraX MuD.app"
ditto "$AU_SOURCE" "$HOME/Library/Audio/Plug-Ins/Components/RuFTraX MuD.component"
ditto "$VST3_SOURCE" "$HOME/Library/Audio/Plug-Ins/VST3/RuFTraX MuD.vst3"

touch "$HOME/Library/Audio/Plug-Ins/Components/RuFTraX MuD.component"
touch "$HOME/Library/Audio/Plug-Ins/VST3/RuFTraX MuD.vst3"

echo
echo "Installed:"
echo "  $HOME/Applications/RuFTraX MuD.app"
echo "  $HOME/Library/Audio/Plug-Ins/Components/RuFTraX MuD.component"
echo "  $HOME/Library/Audio/Plug-Ins/VST3/RuFTraX MuD.vst3"
echo
echo "Install log: $LOG_FILE"

open "$HOME/Applications/RuFTraX MuD.app"
