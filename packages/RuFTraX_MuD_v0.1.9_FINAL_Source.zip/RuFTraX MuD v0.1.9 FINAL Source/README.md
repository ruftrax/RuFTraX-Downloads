# RuFTraX MuD v0.1.9

RuFTraX MuD is a quad-source mutation instrument for macOS. It combines a
wavetable/virtual-analog engine, an FM/harmonic engine, and two sample engines
inside one polyphonic voice. The four sources meet in the central Morph Core.

## Current working backend

- 16-voice polyphony
- Synth 1: screen-based sine/triangle/saw/square wavetable selector,
  1-7 voice unison, detune, and wavefolding
- Synth 2: screen-based sine/triangle/saw/square carrier selector,
  carrier/modulator ratios, FM index, and feedback
- Two independent WAV, AIFF, or FLAC sample slots
- Automatic root-note detection, fine-tuning correction, and keyboard mapping
  for every imported sample in both sample slots
- Explicit filename-note fallback (`C3`, `F#2`, `Bb4`, and similar); genuinely
  unpitched material receives a predictable C4 keyboard anchor
- Live per-sample note readouts show the received MIDI note/number and the
  actual tone triggered after each layer's Tune, Fine, and pitch-bend offsets
- Reverse, loop, 16-slice mapping, granular playback, grain size, density,
  scatter, and stretch controls
- Individual source ADSR, tuning, fine tuning, level, pan, high-pass,
  low-pass, mute, solo, and LED metering
- Vector, spectral/timbral, grain-switching, and harmonic morph modes
- Motion, jitter, density, scatter, smear, freeze, shatter, stretch,
  resonance, damage, smooth, and grime processing
- Host-tempo-aware 16-step mutation sequencer
- Safe and Wild randomization with locks for Sources, Pitch, Rhythm, Filter,
  Modulation, FX, and Mix, triggered by a pair of rolling dice
- Four pristine, synthesis-based RuFTraX signature factory patches:
  Velvet E-Piano, Crown Brass, Deep Current Bass, and Glasswood Guitar
- One-click signature-patch selection and reset; every factory sound remains
  fully editable and is preserved with project and plug-in state
- Mutation capture/recall plus undo/redo
- Individually separated Chorus, Digital/Ping-Pong/Tape Delay,
  Room/Hall/Plate/Void Reverb, Spectral Freeze, and Chamber sections, each
  with an LED driven by its real wet-audio activity
- Limiter and complete effects bypass
- Dedicated vertical master fader, output polarity reversal, and switchable
  tape-wobble distortion with wow, flutter, saturation, and gentle tape roll-off
- MIDI note/chord and velocity display
- Complete AU/VST3/standalone state saving, including loaded sample paths
- Fully scalable, vector-drawn editor based on the approved MuD render
- 12 dB higher default master output with legacy-state migration
- Effects start fully dry, with guarded resonator decay to prevent background noise
- Zero FX mix is now a hard-off state: Space cannot reopen a zeroed effect,
  spectral freeze cannot be held open by the transform control, and stored
  chorus, delay, freeze, chamber, and reverb tails are cleared when disabled

## Build and install on macOS

1. Keep JUCE at `$HOME/JUCE`, or set `JUCE_DIR` to its location.
2. Double-click `INSTALL_RUFTRAX_MUD.command`.
3. The script builds Release versions and installs them for the current user.

Installed locations:

- Standalone: `$HOME/Applications/RuFTraX MuD.app`
- Audio Unit: `$HOME/Library/Audio/Plug-Ins/Components/RuFTraX MuD.component`
- VST3: `$HOME/Library/Audio/Plug-Ins/VST3/RuFTraX MuD.vst3`

MuD does not build or install AAX.

## Development status

This is the first functional development build, not a locked distribution
release. Version 0.1.9 adds functional waveform selectors to both synthesizers
and live, audio-driven activity LEDs in five separated effects sections.
Version 0.1.8 fixes lingering effects feedback and guarantees true silence from
zeroed effects. Version 0.1.7 added the dedicated master fader, phase reversal, and
tape-wobble distortion stage. Version 0.1.6 added live MIDI-to-actual-tone readouts beneath both
sample waveforms. It also includes automatic root-key mapping, filename-note
fallback, the four signature factory sounds, standalone launch fix, higher
output, dice randomizer, dry effects defaults, and resonator noise protection.
The next validation gate is opening the standalone and confirming both synth
engines, both sample slots, MIDI, morphing, state restoration, and all plug-in
formats.
