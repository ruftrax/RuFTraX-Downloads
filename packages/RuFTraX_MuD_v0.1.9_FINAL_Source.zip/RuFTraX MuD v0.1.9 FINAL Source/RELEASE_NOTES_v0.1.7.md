# RuFTraX MuD v0.1.7

## Master-stage update

- Replaced the rotary master control with a dedicated vertical master fader.
- Added an automatable `PHASE REV` master-output polarity switch.
- Added an automatable `TAPE WOBBLE` switch with wow, flutter, soft tape
  saturation, and gentle high-frequency roll-off.
- Smoothed tape engagement, master gain, and polarity changes to prevent hard
  switching clicks.
- Preserved every existing host parameter index by appending the new switches.
- Advanced saved-state format to version 4. Older MuD sessions migrate with
  both new switches safely off.

## Signal order

1. MuD effects and mutation processing
2. Tape wobble/distortion when enabled
3. Master fader
4. Limiter when enabled
5. Phase reversal when enabled

`BYPASS FX` also bypasses tape wobble. The master fader, limiter, output meters,
and phase-reversal switch remain part of the master output path.
