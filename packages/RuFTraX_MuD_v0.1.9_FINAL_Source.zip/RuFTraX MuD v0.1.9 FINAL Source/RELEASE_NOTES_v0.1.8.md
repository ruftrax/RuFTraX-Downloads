# RuFTraX MuD v0.1.8

## Effects-tail correction

- Made `CH MIX`, `DELAY MIX`, `REV MIX`, `SP FREEZE`, and `CHAMBER` true
  hard-off controls at zero.
- Prevented `MACRO SPACE` from silently reopening chorus, delay, or reverb when
  their own mix control is zero. Space still expands effects that are enabled.
- Prevented the transform `FREEZE` value from holding the spectral-freeze
  feedback loop open when `SP FREEZE` is zero. Transform Freeze now deepens an
  explicitly enabled spectral freeze instead.
- Clears each effect's stored audio exactly once when its mix reaches zero, so
  old delay, freeze, chamber, and reverb tails cannot return on a later note.
- Clears all effect-tail and resonator state when `BYPASS FX` is engaged.
- Skips disabled effect processors, reducing unnecessary work while the rack is
  dry.

No parameters were added or reordered, so v0.1.7 projects and automation remain
compatible. Saved-state format remains version 4.
