# RuFTraX MuD v0.1.9

## Dual waveform selectors

- Added a waveform window to both synth screens with Sine, Triangle, Saw, and
  Square choices.
- Synth 1 now snaps its existing wavetable-shape parameter to those four exact
  waveforms while retaining the same parameter ID and host position.
- Added a new Synth 2 carrier-wave parameter and connected it to the FM audio
  engine, waveform preview, factory reset, mutation system, and saved state.
- Appended the Synth 2 parameter after all existing parameters so older host
  automation indexes remain stable.

## Effects activity display

- Split the effects panel into bordered Chorus, Delay, Reverb, Freeze, and
  Chamber sections.
- Added a dedicated activity LED to every effects section.
- Each LED reads the actual wet signal produced by its DSP stage; it is not a
  static indication of the knob position.
- Added peak hold and smooth visual decay without adding locks or allocations
  to the real-time audio path.

## Compatibility

- Saved-state format is version 5. Sessions from earlier MuD versions receive
  Sine as the safe default for the new Synth 2 carrier waveform.
- The v0.1.8 hard-off effect gates and tail clearing remain in place.
