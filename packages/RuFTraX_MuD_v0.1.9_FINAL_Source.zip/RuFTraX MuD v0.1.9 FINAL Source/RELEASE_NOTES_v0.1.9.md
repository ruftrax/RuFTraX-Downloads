# RuFTraX MuD v0.1.9

## Key, Scale, and IN KEY

- Added a Key selector (12 root notes), a Major/Minor Scale selector, and an
  IN KEY toggle to the header.
- With IN KEY engaged, every incoming note is snapped once, at note-on, to
  the nearest note in the selected key/scale - all four sources (both
  synths, both samples) stay locked together since they all derive their
  pitch from that one quantized note.
- With IN KEY off (the default, on every factory patch), notes pass through
  untouched - sound design can go anywhere regardless of what key is
  selected.

## 20 new factory patches: Glitch / Chop / Reverse

- Added a 20-patch collection themed on 80s/70s glitchy, chopped, and
  reversed sound design, alongside the original 4 signature patches (24
  total in the Factory Patches browser).
- Built from the engine's existing glitch tools - shatter, damage, grime,
  scatter/density granular, spectral freeze, smear, resonate, the
  host-tempo mutation sequencer (several patches carry hand-built 16-step
  chop patterns), tape wobble, phase reverse, and grain-mode morphing.
- The "reverse" patches use a long-attack/short-release envelope (there's
  no bundled audio to literally reverse) and pre-arm both sample slots'
  Reverse flag, so any sample dropped in plays backwards immediately.

## Randomizer fixes

- Fixed a bug where randomizing FX parameters could jump delay feedback or
  reverb size to a hot value while the mix was already open, causing
  whatever was already circulating in the delay/reverb buffers to build up
  into a lingering, self-sustaining trail with no way to clear it short of
  Bypass FX. FX randomization now flushes those buffers first, so every
  pass starts clean.
- Freeze (the Mutation/Transform panel's Freeze knob) and Sp Freeze (the
  Effects panel's spectral freeze) are now excluded from every randomizer
  pass (SAFE, WILD, and the MOD/FX category buttons). Freeze is a hold
  effect - it should only ever turn on when deliberately reached for, never
  as a randomizer side effect. Both stay wherever the player left them
  (zero, unless they've touched it) through any amount of randomizing;
  factory patches built around freeze still set it on load, since loading
  a patch is the player's own choice.

## Dual waveform selectors

- Added a waveform window to both synth screens with Sine, Triangle, Saw, and
  Square choices.
- Synth 1 now snaps its existing wavetable-shape parameter to those four exact
  waveforms while retaining the same parameter ID and host position.
- Added a new Synth 2 carrier-wave parameter and connected it to the FM audio
  engine, waveform preview, factory reset, mutation system, and saved state.
- Appended the Synth 2 parameter after all existing parameters so older host
  automation indexes remain stable.

## Effects activity display

- Split the effects panel into bordered Chorus, Delay, Reverb, Freeze, and
  Chamber sections.
- Added a dedicated activity LED to every effects section.
- Each LED reads the actual wet signal produced by its DSP stage; it is not a
  static indication of the knob position.
- Added peak hold and smooth visual decay without adding locks or allocations
  to the real-time audio path.

## Compatibility

- Saved-state format is version 6. Sessions from versions before the Key/
  Scale feature receive C Major with IN KEY off, so nothing that already
  existed suddenly starts quantizing notes it wasn't designed to. Sessions
  from before v0.1.9's Synth 2 carrier waveform still receive Sine as the
  safe default for that parameter.
- The v0.1.8 hard-off effect gates and tail clearing remain in place.
