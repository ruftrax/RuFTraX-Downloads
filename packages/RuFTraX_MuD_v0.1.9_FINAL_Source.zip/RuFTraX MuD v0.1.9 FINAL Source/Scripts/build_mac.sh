#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$PROJECT_DIR/build-v0.1.9"
JUCE_PATH="${JUCE_DIR:-$HOME/JUCE}"

"$PROJECT_DIR/Scripts/validate_source.sh"

if ! command -v cmake >/dev/null 2>&1; then
  echo "CMake is required. Install it with: brew install cmake" >&2
  exit 1
fi

if [[ ! -f "$JUCE_PATH/CMakeLists.txt" ]]; then
  echo "JUCE was not found at: $JUCE_PATH" >&2
  echo "Set it first, for example: export JUCE_DIR=\"$HOME/JUCE\"" >&2
  exit 1
fi

echo "Building RuFTraX MuD v0.1.9"
echo "JUCE:  $JUCE_PATH"
echo "Build: $BUILD_DIR"

cmake -S "$PROJECT_DIR" -B "$BUILD_DIR" \
  -DJUCE_DIR="$JUCE_PATH" \
  -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD_DIR" --config Release --parallel "$(sysctl -n hw.logicalcpu)"

echo "MuD build completed."
