#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

required=(
  "CMakeLists.txt"
  "Source/PluginProcessor.cpp"
  "Source/PluginProcessor.h"
  "Source/PluginEditor.cpp"
  "Source/PluginEditor.h"
  "Source/DSP/MuDVoice.cpp"
  "Source/DSP/MuDVoice.h"
  "Source/DSP/SampleStore.cpp"
  "Source/DSP/EffectsRack.cpp"
  "Source/UI/MuDLookAndFeel.cpp"
)

for item in "${required[@]}"; do
  if [[ ! -s "$PROJECT_DIR/$item" ]]; then
    echo "Missing required MuD source: $item" >&2
    exit 1
  fi
done

if ! grep -q 'PRODUCT_NAME "RuFTraX MuD"' "$PROJECT_DIR/CMakeLists.txt"; then
  echo "The MuD product identity is missing from CMakeLists.txt." >&2
  exit 1
fi

if grep -R -n --exclude-dir=build --exclude='*.png' 'AKAI\|AAX' \
  "$PROJECT_DIR/Source" "$PROJECT_DIR/CMakeLists.txt" >/dev/null; then
  echo "Unexpected external product or AAX reference found in MuD source." >&2
  exit 1
fi

for feature in \
  'randomize(MutationMode' \
  'renderSampleEngine' \
  'combineSources' \
  'class DiceButton' \
  'applyFactoryPatch' \
  'RuFTraX Velvet E-Piano' \
  'rootNoteFromFileName' \
  'ROOT C4 DEFAULT' \
  'getSampleTriggeredNoteDescription' \
  'TONE UNPITCHED' \
  'updateRuntimeModulation' \
  'stateVersion", 5' \
  'synth2Wave' \
  'FM Carrier Waveform' \
  'waveSelector.addItemList' \
  'effectActivityCount = 5' \
  'consumeActivity' \
  'effectGroupBounds' \
  'phaseReverse' \
  'tapeWobble' \
  'gatedMacroMix' \
  'spectralFreezeMix <= effectOffThreshold' \
  'resetEffectTails' \
  'delayWasActive' \
  'reverbWasActive' \
  'class RuFTraXMuDAudioProcessorEditor::ParameterFader' \
  'getStateInformation' \
  'setStateInformation'; do
  if ! grep -R -q "$feature" "$PROJECT_DIR/Source"; then
    echo "Required MuD backend feature is missing: $feature" >&2
    exit 1
  fi
done

if grep -q 'jmax(read(spectralFreeze), read(transformFreeze))' \
  "$PROJECT_DIR/Source/DSP/EffectsRack.cpp"; then
  echo "Transform Freeze can still reopen a zeroed spectral-freeze loop." >&2
  exit 1
fi

if grep -Eq 'read\((chorusMix|delayMix|reverbMix)\)[[:space:]]*\+[[:space:]]*spaceMacro' \
  "$PROJECT_DIR/Source/DSP/EffectsRack.cpp"; then
  echo "Macro Space can still reopen a zeroed time-based effect." >&2
  exit 1
fi

if grep -q 'addKnob(mud::param::synth1Wave' "$PROJECT_DIR/Source/PluginEditor.cpp"; then
  echo "Synth 1 still uses the old waveform knob instead of its selector." >&2
  exit 1
fi

echo "RuFTraX MuD v0.1.9 source validation passed."
