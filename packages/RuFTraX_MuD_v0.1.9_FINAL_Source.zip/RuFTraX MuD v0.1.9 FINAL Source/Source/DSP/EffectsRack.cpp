#include "EffectsRack.h"
#include "ParameterIDs.h"
#include <cmath>

namespace mud
{
namespace
{
constexpr float effectOffThreshold = 0.0001f;

float gatedMacroMix(float baseMix, float macroAmount, float macroDepth) noexcept
{
    baseMix = juce::jlimit(0.0f, 1.0f, baseMix);
    if (baseMix <= effectOffThreshold)
        return 0.0f;

    return juce::jlimit(0.0f, 1.0f, baseMix + macroAmount * macroDepth);
}
} // namespace

std::atomic<float>* EffectsRack::get(juce::AudioProcessorValueTreeState& state,
                                     const char* id)
{
    auto* value = state.getRawParameterValue(id);
    jassert(value != nullptr);
    return value;
}

float EffectsRack::read(const std::atomic<float>* value) noexcept
{
    return value != nullptr ? value->load(std::memory_order_relaxed) : 0.0f;
}

EffectsRack::EffectsRack(juce::AudioProcessorValueTreeState& state)
    : chorusRate(get(state, param::chorusRate)),
      chorusDepth(get(state, param::chorusDepth)),
      chorusMix(get(state, param::chorusMix)),
      delayType(get(state, param::delayType)),
      delayTime(get(state, param::delayTime)),
      delayFeedback(get(state, param::delayFeedback)),
      delayMix(get(state, param::delayMix)),
      reverbType(get(state, param::reverbType)),
      reverbSize(get(state, param::reverbSize)),
      reverbDamping(get(state, param::reverbDamping)),
      reverbMix(get(state, param::reverbMix)),
      spectralFreeze(get(state, param::spectralFreeze)),
      transformFreeze(get(state, param::freeze)),
      convolutionMix(get(state, param::convolutionMix)),
      resonate(get(state, param::resonate)),
      smear(get(state, param::smear)),
      macroSpace(get(state, param::macroSpace)),
      masterGain(get(state, param::masterGain)),
      limiterEnabled(get(state, param::limiterEnabled)),
      bypassAll(get(state, param::bypassAll)),
      phaseReverse(get(state, param::phaseReverse)),
      tapeWobble(get(state, param::tapeWobble))
{
    for (auto& activity : effectActivity)
        activity.store(0.0f, std::memory_order_relaxed);
}

void EffectsRack::prepare(const juce::dsp::ProcessSpec& spec)
{
    sampleRate = spec.sampleRate;
    chorus.prepare(spec);
    delay.prepare(spec);
    freezeDelay.prepare(spec);
    chamberDelay.prepare(spec);
    reverb.prepare(spec);
    tapeWobbleDelay.prepare(spec);
    outputGain.prepare(spec);
    limiter.prepare(spec);
    tapeWobbleMix.reset(spec.sampleRate, 0.05);
    phasePolarity.reset(spec.sampleRate, 0.01);
    outputGain.setRampDurationSeconds(0.025);
    limiter.setThreshold(-0.3f);
    limiter.setRelease(80.0f);
    wetBuffer.setSize(static_cast<int>(spec.numChannels),
                      static_cast<int>(spec.maximumBlockSize));
    reset();
}

void EffectsRack::reset()
{
    resetEffectTails();
    tapeWobbleDelay.reset();
    outputGain.reset();
    limiter.reset();
    smearState = { 0.0f, 0.0f };
    resonatorLow = { 0.0f, 0.0f };
    resonatorBand = { 0.0f, 0.0f };
    tapeFilterState = { 0.0f, 0.0f };
    tapePhase = 0.0f;
    masterTapeWowPhase = 0.0f;
    masterTapeFlutterPhase = 0.0f;
    tapeWobbleMix.setCurrentAndTargetValue(
        read(tapeWobble) >= 0.5f ? 1.0f : 0.0f);
    phasePolarity.setCurrentAndTargetValue(
        read(phaseReverse) >= 0.5f ? -1.0f : 1.0f);
    wasBypassed = false;
}

void EffectsRack::resetEffectTails()
{
    chorus.reset();
    delay.reset();
    freezeDelay.reset();
    chamberDelay.reset();
    reverb.reset();
    chorusWasActive = false;
    delayWasActive = false;
    freezeWasActive = false;
    chamberWasActive = false;
    reverbWasActive = false;
    for (auto& activity : effectActivity)
        activity.store(0.0f, std::memory_order_relaxed);
}

float EffectsRack::consumeActivity(int effect) const noexcept
{
    if (! juce::isPositiveAndBelow(effect, effectActivityCount))
        return 0.0f;

    return effectActivity[static_cast<std::size_t>(effect)].exchange(
        0.0f, std::memory_order_relaxed);
}

void EffectsRack::pushActivity(int effect, float magnitude) noexcept
{
    if (! juce::isPositiveAndBelow(effect, effectActivityCount))
        return;

    magnitude = juce::jlimit(0.0f, 1.0f, std::abs(magnitude));
    auto& peak = effectActivity[static_cast<std::size_t>(effect)];
    auto previous = peak.load(std::memory_order_relaxed);
    while (previous < magnitude
           && ! peak.compare_exchange_weak(previous, magnitude,
                                           std::memory_order_relaxed,
                                           std::memory_order_relaxed))
    {
    }
}

void EffectsRack::copyInput(const juce::AudioBuffer<float>& source)
{
    for (int channel = 0; channel < source.getNumChannels(); ++channel)
        wetBuffer.copyFrom(channel, 0, source, channel, 0, source.getNumSamples());
}

void EffectsRack::blend(juce::AudioBuffer<float>& dry, float mix)
{
    mix = juce::jlimit(0.0f, 1.0f, mix);
    for (int channel = 0; channel < dry.getNumChannels(); ++channel)
    {
        auto* destination = dry.getWritePointer(channel);
        const auto* wet = wetBuffer.getReadPointer(channel);
        for (int frame = 0; frame < dry.getNumSamples(); ++frame)
            destination[frame] = destination[frame] * (1.0f - mix) + wet[frame] * mix;
    }
}

void EffectsRack::process(juce::AudioBuffer<float>& buffer)
{
    const auto bypassed = read(bypassAll) >= 0.5f;
    if (bypassed)
    {
        if (! wasBypassed)
        {
            resetEffectTails();
            smearState = { 0.0f, 0.0f };
            resonatorLow = { 0.0f, 0.0f };
            resonatorBand = { 0.0f, 0.0f };
        }
        wasBypassed = true;
    }
    else
    {
        wasBypassed = false;
        const auto channels = juce::jmin(2, buffer.getNumChannels());
        const auto spaceMacro = juce::jlimit(0.0f, 1.0f, read(macroSpace));

        const auto smearAmount = juce::jlimit(0.0f, 1.0f, read(smear));
        const auto resonateAmount = juce::jlimit(0.0f, 1.0f, read(resonate));
        const auto smearCutoff = juce::jmap(smearAmount, 19000.0f, 300.0f);
        const auto smearCoefficient = 1.0f - std::exp(
            -juce::MathConstants<float>::twoPi * smearCutoff / static_cast<float>(sampleRate));
        const auto resonatorFrequency = juce::jmap(resonateAmount, 90.0f, 1800.0f);
        const auto resonatorF = 2.0f * std::sin(
            juce::MathConstants<float>::pi * resonatorFrequency
            / static_cast<float>(sampleRate));
        const auto resonatorQ = juce::jmap(resonateAmount, 0.45f, 0.02f);

        for (int channel = 0; channel < channels; ++channel)
        {
            auto* samples = buffer.getWritePointer(channel);
            auto& low = resonatorLow[static_cast<std::size_t>(channel)];
            auto& band = resonatorBand[static_cast<std::size_t>(channel)];
            if (resonateAmount < 0.001f)
            {
                low = 0.0f;
                band = 0.0f;
            }
            for (int frame = 0; frame < buffer.getNumSamples(); ++frame)
            {
                smearState[static_cast<std::size_t>(channel)] += smearCoefficient
                    * (samples[frame] - smearState[static_cast<std::size_t>(channel)]);
                const auto smeared = juce::jmap(smearAmount, samples[frame],
                    smearState[static_cast<std::size_t>(channel)]);
                if (resonateAmount >= 0.001f)
                {
                    low += resonatorF * band;
                    const auto high = smeared - low - resonatorQ * band;
                    band += resonatorF * high;
                    low = juce::jlimit(-4.0f, 4.0f, low * 0.9995f);
                    band = juce::jlimit(-4.0f, 4.0f, band * 0.9995f);
                    if (! std::isfinite(low) || ! std::isfinite(band))
                        low = band = 0.0f;
                }
                samples[frame] = smeared + band * resonateAmount * 0.65f;
            }
        }

        const auto chorusWet = gatedMacroMix(read(chorusMix), spaceMacro, 0.18f);
        if (chorusWet > effectOffThreshold)
        {
            chorusWasActive = true;
            copyInput(buffer);
            juce::dsp::AudioBlock<float> chorusStorage(wetBuffer);
            auto chorusBlock = chorusStorage.getSubBlock(
                0, static_cast<std::size_t>(buffer.getNumSamples()));
            juce::dsp::ProcessContextReplacing<float> chorusContext(chorusBlock);
            chorus.setRate(juce::jlimit(0.01f, 12.0f, read(chorusRate)));
            chorus.setDepth(juce::jlimit(0.0f, 1.0f, read(chorusDepth)));
            chorus.setCentreDelay(7.0f);
            chorus.setFeedback(0.12f);
            chorus.setMix(1.0f);
            chorus.process(chorusContext);
            auto chorusActivity = 0.0f;
            for (int channel = 0; channel < channels; ++channel)
                chorusActivity = juce::jmax(chorusActivity,
                    wetBuffer.getMagnitude(channel, 0, buffer.getNumSamples()));
            pushActivity(0, chorusActivity * chorusWet);
            blend(buffer, chorusWet);
        }
        else if (chorusWasActive)
        {
            chorus.reset();
            chorusWasActive = false;
        }

        const auto selectedDelayType = juce::jlimit(0, 2,
            juce::roundToInt(read(delayType)));
        const auto baseDelaySeconds = juce::jlimit(0.005f, 3.8f, read(delayTime));
        const auto delayWet = gatedMacroMix(read(delayMix), spaceMacro, 0.18f);
        const auto feedback = juce::jlimit(0.0f, 0.96f, read(delayFeedback));

        if (delayWet > effectOffThreshold)
        {
            delayWasActive = true;
            auto delayActivity = 0.0f;
            for (int frame = 0; frame < buffer.getNumSamples(); ++frame)
            {
                tapePhase += 0.23f / static_cast<float>(sampleRate);
                if (tapePhase >= 1.0f)
                    tapePhase -= 1.0f;
                const auto tapeMod = selectedDelayType == 2
                    ? std::sin(juce::MathConstants<float>::twoPi * tapePhase) * 0.004f
                    : 0.0f;
                const auto delaySamples = (baseDelaySeconds + tapeMod)
                                          * static_cast<float>(sampleRate);
                delay.setDelay(juce::jlimit(1.0f,
                    static_cast<float>(delay.getMaximumDelayInSamples() - 2), delaySamples));
                std::array<float, 2> delayed {};
                for (int channel = 0; channel < channels; ++channel)
                    delayed[static_cast<std::size_t>(channel)] = delay.popSample(channel);
                for (int channel = 0; channel < channels; ++channel)
                {
                    auto& sample = buffer.getWritePointer(channel)[frame];
                    const auto feedbackChannel = selectedDelayType == 1 && channels > 1
                        ? 1 - channel : channel;
                    auto send = sample + delayed[static_cast<std::size_t>(feedbackChannel)]
                                         * feedback;
                    if (selectedDelayType == 2)
                        send = std::tanh(send * 1.35f);
                    delay.pushSample(channel, send);
                    delayActivity = juce::jmax(delayActivity,
                        std::abs(delayed[static_cast<std::size_t>(channel)])
                            * delayWet);
                    sample = sample * (1.0f - delayWet)
                             + delayed[static_cast<std::size_t>(channel)] * delayWet;
                }
            }
            pushActivity(1, delayActivity);
        }
        else if (delayWasActive)
        {
            delay.reset();
            delayWasActive = false;
        }

        const auto spectralFreezeMix = juce::jlimit(0.0f, 1.0f,
            read(spectralFreeze));
        const auto freezeAmount = spectralFreezeMix <= effectOffThreshold
            ? 0.0f
            : juce::jlimit(0.0f, 1.0f,
                spectralFreezeMix + read(transformFreeze) * 0.5f);
        if (freezeAmount > effectOffThreshold)
        {
            freezeWasActive = true;
            auto freezeActivity = 0.0f;
            const auto freezeSamples = juce::jlimit(128.0f,
                static_cast<float>(freezeDelay.getMaximumDelayInSamples() - 2),
                static_cast<float>(sampleRate * 0.19));
            freezeDelay.setDelay(freezeSamples);
            for (int channel = 0; channel < channels; ++channel)
            {
                auto* samples = buffer.getWritePointer(channel);
                for (int frame = 0; frame < buffer.getNumSamples(); ++frame)
                {
                    const auto frozen = freezeDelay.popSample(channel);
                    const auto feedbackSample = freezeAmount > 0.02f
                        ? frozen * 0.9985f + samples[frame] * (1.0f - freezeAmount) * 0.35f
                        : samples[frame];
                    freezeDelay.pushSample(channel, feedbackSample);
                    freezeActivity = juce::jmax(freezeActivity,
                        std::abs(frozen) * freezeAmount);
                    samples[frame] = juce::jmap(freezeAmount, samples[frame], frozen);
                }
            }
            pushActivity(3, freezeActivity);
        }
        else if (freezeWasActive)
        {
            freezeDelay.reset();
            freezeWasActive = false;
        }

        const auto chamberMix = juce::jlimit(0.0f, 1.0f, read(convolutionMix));
        if (chamberMix > effectOffThreshold)
        {
            chamberWasActive = true;
            auto chamberActivity = 0.0f;
            for (int frame = 0; frame < buffer.getNumSamples(); ++frame)
            {
                for (int channel = 0; channel < channels; ++channel)
                {
                    auto& sample = buffer.getWritePointer(channel)[frame];
                    const auto tapDelay = channel == 0
                        ? static_cast<float>(sampleRate * 0.031)
                        : static_cast<float>(sampleRate * 0.043);
                    const auto chamber = chamberDelay.popSample(channel, tapDelay);
                    chamberDelay.pushSample(channel, sample + chamber * 0.58f);
                    chamberActivity = juce::jmax(chamberActivity,
                        std::abs(chamber) * chamberMix);
                    sample = sample * (1.0f - chamberMix) + chamber * chamberMix;
                }
            }
            pushActivity(4, chamberActivity);
        }
        else if (chamberWasActive)
        {
            chamberDelay.reset();
            chamberWasActive = false;
        }

        const auto reverbWet = gatedMacroMix(read(reverbMix), spaceMacro, 0.25f);
        if (reverbWet > effectOffThreshold)
        {
            reverbWasActive = true;
            copyInput(buffer);
            juce::dsp::AudioBlock<float> reverbStorage(wetBuffer);
            auto reverbBlock = reverbStorage.getSubBlock(
                0, static_cast<std::size_t>(buffer.getNumSamples()));
            juce::dsp::ProcessContextReplacing<float> reverbContext(reverbBlock);
            const auto selectedReverb = juce::jlimit(0, 3,
                juce::roundToInt(read(reverbType)));
            juce::Reverb::Parameters reverbParameters;
            const std::array<float, 4> typeSize { 0.35f, 0.72f, 0.55f, 0.96f };
            const std::array<float, 4> typeDamping { 0.62f, 0.42f, 0.28f, 0.18f };
            reverbParameters.roomSize = juce::jlimit(0.0f, 1.0f,
                0.5f * read(reverbSize)
                + 0.5f * typeSize[static_cast<std::size_t>(selectedReverb)]);
            reverbParameters.damping = juce::jlimit(0.0f, 1.0f,
                0.5f * read(reverbDamping)
                + 0.5f * typeDamping[static_cast<std::size_t>(selectedReverb)]);
            reverbParameters.width = selectedReverb == 2 ? 0.72f : 1.0f;
            reverbParameters.wetLevel = 1.0f;
            reverbParameters.dryLevel = 0.0f;
            reverb.setParameters(reverbParameters);
            reverb.process(reverbContext);
            auto reverbActivity = 0.0f;
            for (int channel = 0; channel < channels; ++channel)
                reverbActivity = juce::jmax(reverbActivity,
                    wetBuffer.getMagnitude(channel, 0, buffer.getNumSamples()));
            pushActivity(2, reverbActivity * reverbWet);
            blend(buffer, reverbWet);
        }
        else if (reverbWasActive)
        {
            reverb.reset();
            reverbWasActive = false;
        }
    }

    // Keep the tape delay primed even while bypassed so engaging the switch is
    // immediate. A shared wow/flutter delay supplies real pitch movement;
    // soft clipping and a gentle low-pass add tape-style colour.
    const auto channels = juce::jmin(2, buffer.getNumChannels());
    tapeWobbleMix.setTargetValue(! bypassed && read(tapeWobble) >= 0.5f
                                     ? 1.0f : 0.0f);
    const auto tapeCutoff = juce::jmin(14500.0f,
        static_cast<float>(sampleRate * 0.45));
    const auto tapeCoefficient = 1.0f - std::exp(
        -juce::MathConstants<float>::twoPi * tapeCutoff
        / static_cast<float>(sampleRate));
    const auto saturationNormaliser = 1.0f / std::tanh(1.65f);

    for (int frame = 0; frame < buffer.getNumSamples(); ++frame)
    {
        masterTapeWowPhase += 0.42f / static_cast<float>(sampleRate);
        masterTapeFlutterPhase += 4.70f / static_cast<float>(sampleRate);
        if (masterTapeWowPhase >= 1.0f)
            masterTapeWowPhase -= 1.0f;
        if (masterTapeFlutterPhase >= 1.0f)
            masterTapeFlutterPhase -= 1.0f;

        const auto wow = std::sin(juce::MathConstants<float>::twoPi
                                  * masterTapeWowPhase) * 0.0011f;
        const auto flutter = std::sin(juce::MathConstants<float>::twoPi
                                      * masterTapeFlutterPhase) * 0.00018f;
        const auto delaySamples = juce::jlimit(1.0f,
            static_cast<float>(tapeWobbleDelay.getMaximumDelayInSamples() - 2),
            static_cast<float>(sampleRate) * (0.0022f + wow + flutter));
        tapeWobbleDelay.setDelay(delaySamples);
        const auto mix = tapeWobbleMix.getNextValue();

        for (int channel = 0; channel < channels; ++channel)
        {
            auto& sample = buffer.getWritePointer(channel)[frame];
            const auto dry = sample;
            const auto delayed = tapeWobbleDelay.popSample(channel);
            tapeWobbleDelay.pushSample(channel, dry);
            const auto saturated = std::tanh(delayed * 1.65f)
                                   * saturationNormaliser;
            auto& filtered = tapeFilterState[static_cast<std::size_t>(channel)];
            filtered += tapeCoefficient * (saturated - filtered);
            sample = dry + (filtered - dry) * mix;
        }
    }

    juce::dsp::AudioBlock<float> block(buffer);
    juce::dsp::ProcessContextReplacing<float> context(block);
    outputGain.setGainDecibels(read(masterGain));
    outputGain.process(context);
    if (read(limiterEnabled) >= 0.5f)
        limiter.process(context);

    phasePolarity.setTargetValue(read(phaseReverse) >= 0.5f ? -1.0f : 1.0f);
    for (int frame = 0; frame < buffer.getNumSamples(); ++frame)
    {
        const auto polarity = phasePolarity.getNextValue();
        for (int channel = 0; channel < buffer.getNumChannels(); ++channel)
            buffer.getWritePointer(channel)[frame] *= polarity;
    }
}
} // namespace mud
