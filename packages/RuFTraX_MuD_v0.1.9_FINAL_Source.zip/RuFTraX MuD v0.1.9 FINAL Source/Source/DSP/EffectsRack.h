#pragma once

#include <JuceHeader.h>
#include "ParameterIDs.h"
#include <array>
#include <atomic>

namespace mud
{
class EffectsRack
{
public:
    static constexpr int effectActivityCount = 5;

    explicit EffectsRack(juce::AudioProcessorValueTreeState&);
    void prepare(const juce::dsp::ProcessSpec&);
    void reset();
    void process(juce::AudioBuffer<float>&);
    float consumeActivity(int effect) const noexcept;

    /**
     * Flags the feedback-bearing effect tails (chorus/delay/freeze/chamber/reverb) to be
     * cleared at the start of the next process() call. Safe to call from any thread - it only
     * touches an atomic flag; the actual DSP object resets still happen on the audio thread
     * inside process(), same as every other tail-clear in this class.
     *
     * Needed because those effects only clear their own buffers when their mix drops back to
     * zero (see resetEffectTails() call sites below) or when the whole rack is bypassed. A
     * sudden jump in delayFeedback/reverbSize while the mix is already open - exactly what the
     * randomizer can do in one step - would otherwise recirculate whatever was already sitting
     * in the buffer at the new, possibly much higher feedback amount, producing a lingering
     * build-up with no way to clear it short of hitting Bypass.
     */
    void requestFlush() noexcept { flushRequested.store(true, std::memory_order_relaxed); }

private:
    static std::atomic<float>* get(juce::AudioProcessorValueTreeState&, const char* id);
    static float read(const std::atomic<float>*) noexcept;
    void copyInput(const juce::AudioBuffer<float>&);
    void blend(juce::AudioBuffer<float>&, float mix);
    void resetEffectTails();
    void pushActivity(int effect, float magnitude) noexcept;

    std::atomic<float>* chorusRate = nullptr;
    std::atomic<float>* chorusDepth = nullptr;
    std::atomic<float>* chorusMix = nullptr;
    std::atomic<float>* delayType = nullptr;
    std::atomic<float>* delayTime = nullptr;
    std::atomic<float>* delayFeedback = nullptr;
    std::atomic<float>* delayMix = nullptr;
    std::atomic<float>* reverbType = nullptr;
    std::atomic<float>* reverbSize = nullptr;
    std::atomic<float>* reverbDamping = nullptr;
    std::atomic<float>* reverbMix = nullptr;
    std::atomic<float>* spectralFreeze = nullptr;
    std::atomic<float>* transformFreeze = nullptr;
    std::atomic<float>* convolutionMix = nullptr;
    std::atomic<float>* resonate = nullptr;
    std::atomic<float>* smear = nullptr;
    std::atomic<float>* macroSpace = nullptr;
    std::atomic<float>* masterGain = nullptr;
    std::atomic<float>* limiterEnabled = nullptr;
    std::atomic<float>* bypassAll = nullptr;
    std::atomic<float>* phaseReverse = nullptr;
    std::atomic<float>* tapeWobble = nullptr;

    double sampleRate = 44100.0;
    juce::dsp::Chorus<float> chorus;
    // Sized for a 44.1kHz session by default; prepare() resizes this to match
    // param::maxDelayTimeSeconds at the session's actual sample rate, so the delay line's real
    // capacity always matches what the Delay Time knob advertises, at any sample rate.
    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> delay {
        static_cast<int>(param::maxDelayTimeSeconds * 44100.0f) + 1
    };
    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> freezeDelay { 768000 };
    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> chamberDelay { 96000 };
    juce::dsp::Reverb reverb;
    juce::dsp::DelayLine<float,
        juce::dsp::DelayLineInterpolationTypes::Lagrange3rd> tapeWobbleDelay { 16384 };
    juce::dsp::Gain<float> outputGain;
    juce::dsp::Limiter<float> limiter;
    juce::SmoothedValue<float> tapeWobbleMix;
    juce::SmoothedValue<float> phasePolarity;
    juce::AudioBuffer<float> wetBuffer;
    mutable std::array<std::atomic<float>, effectActivityCount> effectActivity;
    std::array<float, 2> smearState {};
    std::array<float, 2> resonatorLow {};
    std::array<float, 2> resonatorBand {};
    std::array<float, 2> tapeFilterState {};
    float tapePhase = 0.0f;
    float masterTapeWowPhase = 0.0f;
    float masterTapeFlutterPhase = 0.0f;
    std::atomic<bool> flushRequested { false };
    bool wasBypassed = false;
    bool chorusWasActive = false;
    bool delayWasActive = false;
    bool freezeWasActive = false;
    bool chamberWasActive = false;
    bool reverbWasActive = false;
    bool limiterWasActive = false;
};
} // namespace mud
