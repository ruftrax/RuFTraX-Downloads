#pragma once

#include <JuceHeader.h>
#include <array>
#include <atomic>

namespace mud
{
class EffectsRack
{
public:
    static constexpr int effectActivityCount = 5;

    explicit EffectsRack(juce::AudioProcessorValueTreeState&);
    void prepare(const juce::dsp::ProcessSpec&);
    void reset();
    void process(juce::AudioBuffer<float>&);
    float consumeActivity(int effect) const noexcept;

private:
    static std::atomic<float>* get(juce::AudioProcessorValueTreeState&, const char* id);
    static float read(const std::atomic<float>*) noexcept;
    void copyInput(const juce::AudioBuffer<float>&);
    void blend(juce::AudioBuffer<float>&, float mix);
    void resetEffectTails();
    void pushActivity(int effect, float magnitude) noexcept;

    std::atomic<float>* chorusRate = nullptr;
    std::atomic<float>* chorusDepth = nullptr;
    std::atomic<float>* chorusMix = nullptr;
    std::atomic<float>* delayType = nullptr;
    std::atomic<float>* delayTime = nullptr;
    std::atomic<float>* delayFeedback = nullptr;
    std::atomic<float>* delayMix = nullptr;
    std::atomic<float>* reverbType = nullptr;
    std::atomic<float>* reverbSize = nullptr;
    std::atomic<float>* reverbDamping = nullptr;
    std::atomic<float>* reverbMix = nullptr;
    std::atomic<float>* spectralFreeze = nullptr;
    std::atomic<float>* transformFreeze = nullptr;
    std::atomic<float>* convolutionMix = nullptr;
    std::atomic<float>* resonate = nullptr;
    std::atomic<float>* smear = nullptr;
    std::atomic<float>* macroSpace = nullptr;
    std::atomic<float>* masterGain = nullptr;
    std::atomic<float>* limiterEnabled = nullptr;
    std::atomic<float>* bypassAll = nullptr;
    std::atomic<float>* phaseReverse = nullptr;
    std::atomic<float>* tapeWobble = nullptr;

    double sampleRate = 44100.0;
    juce::dsp::Chorus<float> chorus;
    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> delay { 768000 };
    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> freezeDelay { 768000 };
    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> chamberDelay { 96000 };
    juce::dsp::Reverb reverb;
    juce::dsp::DelayLine<float,
        juce::dsp::DelayLineInterpolationTypes::Lagrange3rd> tapeWobbleDelay { 16384 };
    juce::dsp::Gain<float> outputGain;
    juce::dsp::Limiter<float> limiter;
    juce::SmoothedValue<float> tapeWobbleMix;
    juce::SmoothedValue<float> phasePolarity;
    juce::AudioBuffer<float> wetBuffer;
    mutable std::array<std::atomic<float>, effectActivityCount> effectActivity;
    std::array<float, 2> smearState {};
    std::array<float, 2> resonatorLow {};
    std::array<float, 2> resonatorBand {};
    std::array<float, 2> tapeFilterState {};
    float tapePhase = 0.0f;
    float masterTapeWowPhase = 0.0f;
    float masterTapeFlutterPhase = 0.0f;
    bool wasBypassed = false;
    bool chorusWasActive = false;
    bool delayWasActive = false;
    bool freezeWasActive = false;
    bool chamberWasActive = false;
    bool reverbWasActive = false;
};
} // namespace mud
