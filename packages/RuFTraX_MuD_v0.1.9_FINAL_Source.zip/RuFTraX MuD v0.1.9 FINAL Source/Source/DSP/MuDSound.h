#pragma once

#include <JuceHeader.h>

namespace mud
{
class MuDSound final : public juce::SynthesiserSound
{
public:
    bool appliesToNote(int) override { return true; }
    bool appliesToChannel(int) override { return true; }
};
} // namespace mud

