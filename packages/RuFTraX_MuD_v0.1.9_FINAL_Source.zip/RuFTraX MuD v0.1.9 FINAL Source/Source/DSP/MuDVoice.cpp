#include "MuDVoice.h"
#include "MuDSound.h"
#include <algorithm>
#include <cmath>

namespace mud
{
namespace
{
constexpr float twoPi = juce::MathConstants<float>::twoPi;

float clamp01(float value) noexcept
{
    return juce::jlimit(0.0f, 1.0f, value);
}

float wrapPhase(float phase) noexcept
{
    while (phase >= 1.0f)
        phase -= 1.0f;
    while (phase < 0.0f)
        phase += 1.0f;
    return phase;
}
} // namespace

SourceMeterBus::SourceMeterBus()
{
    for (auto& peak : peaks)
        peak.store(0.0f);
}

void SourceMeterBus::push(int source, float magnitude) noexcept
{
    if (! juce::isPositiveAndBelow(source, static_cast<int>(peaks.size())))
        return;

    auto& destination = peaks[static_cast<std::size_t>(source)];
    auto current = destination.load(std::memory_order_relaxed);
    while (magnitude > current
           && ! destination.compare_exchange_weak(
               current, magnitude, std::memory_order_relaxed))
    {
    }
}

float SourceMeterBus::consume(int source) noexcept
{
    if (! juce::isPositiveAndBelow(source, static_cast<int>(peaks.size())))
        return 0.0f;
    return peaks[static_cast<std::size_t>(source)].exchange(0.0f,
                                                            std::memory_order_relaxed);
}

void MuDVoice::OnePoleBand::set(double newSampleRate, float highPassHz,
                                float lowPassHz) noexcept
{
    const auto sr = juce::jmax(1.0, newSampleRate);
    const auto hp = juce::jlimit(10.0f, static_cast<float>(sr * 0.45), highPassHz);
    const auto lp = juce::jlimit(hp + 10.0f, static_cast<float>(sr * 0.49), lowPassHz);
    hpCoefficient = 1.0f - std::exp(-twoPi * hp / static_cast<float>(sr));
    lpCoefficient = 1.0f - std::exp(-twoPi * lp / static_cast<float>(sr));
}

float MuDVoice::OnePoleBand::process(float input) noexcept
{
    hpState += hpCoefficient * (input - hpState);
    const auto highPassed = input - hpState;
    lpState += lpCoefficient * (highPassed - lpState);
    return lpState;
}

MuDVoice::MuDVoice(VoiceParameters& sharedParameters, SampleStore& sampleA,
                   SampleStore& sampleB, SourceMeterBus& meters)
    : parameters(sharedParameters), sampleStores { &sampleA, &sampleB }, meterBus(meters)
{
}

bool MuDVoice::canPlaySound(juce::SynthesiserSound* sound)
{
    return dynamic_cast<MuDSound*>(sound) != nullptr;
}

float MuDVoice::read(const std::atomic<float>* value) noexcept
{
    return value != nullptr ? value->load(std::memory_order_relaxed) : 0.0f;
}

void MuDVoice::startNote(int midiNoteNumber, float velocity,
                         juce::SynthesiserSound*, int pitchWheelPosition)
{
    sampleRate = getSampleRate() > 0.0 ? getSampleRate() : 44100.0;
    midiNote = midiNoteNumber;
    noteVelocity = velocity;
    randomState ^= static_cast<uint32_t>(midiNote + 1) * 2654435761u;
    carrierPhase = modulatorPhase = fmFeedbackSample = 0.0f;
    motionPhase = morphGrainPhase = 0.0f;
    smoothState = { 0.0f, 0.0f };

    for (std::size_t index = 0; index < synth1Phases.size(); ++index)
        synth1Phases[index] = static_cast<float>(index) /
                              static_cast<float>(synth1Phases.size());

    updateEnvelopes();
    for (auto& envelope : envelopes)
    {
        envelope.setSampleRate(sampleRate);
        envelope.reset();
        envelope.noteOn();
    }

    for (auto& sourceFilters : filters)
        for (auto& filter : sourceFilters)
            filter.reset();

    initialiseSamplePlayhead(0);
    initialiseSamplePlayhead(1);
    pitchWheelMoved(pitchWheelPosition);
}

void MuDVoice::stopNote(float, bool allowTailOff)
{
    if (allowTailOff)
    {
        for (auto& envelope : envelopes)
            envelope.noteOff();
    }
    else
    {
        for (auto& envelope : envelopes)
            envelope.reset();
        clearCurrentNote();
    }
}

void MuDVoice::pitchWheelMoved(int newPitchWheelValue)
{
    pitchBendSemitones = 2.0f *
        (static_cast<float>(newPitchWheelValue) - 8192.0f) / 8192.0f;
}

void MuDVoice::updateEnvelopes()
{
    for (std::size_t index = 0; index < envelopes.size(); ++index)
    {
        const auto& source = parameters.source[index];
        juce::ADSR::Parameters next;
        next.attack = juce::jmax(0.001f, read(source.attack));
        next.decay = juce::jmax(0.001f, read(source.decay));
        next.sustain = clamp01(read(source.sustain));
        next.release = juce::jmax(0.002f, read(source.release));
        envelopes[index].setParameters(next);

        for (auto& channelFilter : filters[index])
            channelFilter.set(sampleRate, read(source.highPass), read(source.lowPass));
    }
}

void MuDVoice::initialiseSamplePlayhead(int sampleIndex)
{
    auto& playhead = playheads[static_cast<std::size_t>(sampleIndex)];
    playhead = {};
    playhead.asset = sampleStores[static_cast<std::size_t>(sampleIndex)]->get();
    if (playhead.asset == nullptr || playhead.asset->audio.getNumSamples() < 2)
    {
        playhead.finished = true;
        return;
    }

    const auto totalFrames = playhead.asset->audio.getNumSamples();
    playhead.regionStart = 0.0;
    playhead.regionEnd = static_cast<double>(totalFrames - 1);

    if (read(parameters.sample[static_cast<std::size_t>(sampleIndex)].slice) >= 0.5f)
    {
        constexpr int slices = 16;
        const auto slice = midiNote % slices;
        const auto sliceLength = static_cast<double>(totalFrames) / slices;
        playhead.regionStart = slice * sliceLength;
        playhead.regionEnd = juce::jmin(static_cast<double>(totalFrames - 1),
                                       playhead.regionStart + sliceLength - 1.0);
    }

    const auto reverse = read(parameters.sample[
        static_cast<std::size_t>(sampleIndex)].reverse) >= 0.5f;
    playhead.position = reverse ? playhead.regionEnd : playhead.regionStart;
    playhead.grainStart = playhead.position;
    playhead.grainAge = 0;
}

float MuDVoice::oscillator(float phase, float shape) noexcept
{
    phase = wrapPhase(phase);
    const auto sine = std::sin(twoPi * phase);
    const auto triangle = 1.0f - 4.0f * std::abs(phase - 0.5f);
    const auto saw = 2.0f * phase - 1.0f;
    const auto square = phase < 0.5f ? 1.0f : -1.0f;
    shape = juce::jlimit(0.0f, 3.0f, shape);
    const auto segment = juce::jmin(2, static_cast<int>(shape));
    const auto fraction = shape - static_cast<float>(segment);
    const std::array<float, 4> values { sine, triangle, saw, square };
    return juce::jmap(fraction, values[static_cast<std::size_t>(segment)],
                     values[static_cast<std::size_t>(segment + 1)]);
}

float MuDVoice::fold(float value, float amount) noexcept
{
    auto driven = value * (1.0f + juce::jmax(0.0f, amount) * 7.0f);
    while (driven > 1.0f || driven < -1.0f)
    {
        if (driven > 1.0f)
            driven = 2.0f - driven;
        else if (driven < -1.0f)
            driven = -2.0f - driven;
    }
    return driven;
}

float MuDVoice::interpolate(const juce::AudioBuffer<float>& buffer, int channel,
                            double position) noexcept
{
    if (buffer.getNumSamples() < 2)
        return 0.0f;
    const auto selectedChannel = juce::jlimit(0, buffer.getNumChannels() - 1, channel);
    const auto frame = juce::jlimit(0, buffer.getNumSamples() - 2,
                                    static_cast<int>(position));
    const auto fraction = static_cast<float>(position - static_cast<double>(frame));
    return juce::jmap(fraction, buffer.getSample(selectedChannel, frame),
                     buffer.getSample(selectedChannel, frame + 1));
}

float MuDVoice::nextRandom() noexcept
{
    randomState ^= randomState << 13;
    randomState ^= randomState >> 17;
    randomState ^= randomState << 5;
    return static_cast<float>(randomState & 0x00ffffffu) /
           static_cast<float>(0x01000000u);
}

MuDVoice::StereoSample MuDVoice::renderSampleEngine(int sampleIndex, double increment)
{
    auto& playhead = playheads[static_cast<std::size_t>(sampleIndex)];
    StereoSample result;
    if (playhead.finished || playhead.asset == nullptr)
        return result;

    const auto& sampleParameters = parameters.sample[static_cast<std::size_t>(sampleIndex)];
    const auto reverse = read(sampleParameters.reverse) >= 0.5f;
    const auto looping = read(sampleParameters.loop) >= 0.5f;
    const auto granular = read(sampleParameters.grain) >= 0.5f;
    const auto globalStretch = juce::jmap(clamp01(read(parameters.stretch)), 0.5f, 2.5f);
    const auto localStretch = juce::jmax(0.25f, read(sampleParameters.stretch));
    const auto direction = reverse ? -1.0 : 1.0;
    const auto step = increment / (static_cast<double>(globalStretch) * localStretch);
    auto readPosition = playhead.position;
    auto window = 1.0f;

    if (granular)
    {
        const auto globalDensity = clamp01(read(parameters.density));
        const auto localDensity = clamp01(read(sampleParameters.density));
        const auto size = clamp01(read(sampleParameters.grainSize));
        playhead.grainLength = juce::jlimit(96, 16384,
            juce::roundToInt(sampleRate * juce::jmap(size, 0.008f, 0.28f)));

        if (playhead.grainAge == 0 || playhead.grainAge >= playhead.grainLength)
        {
            const auto localScatter = clamp01(read(sampleParameters.scatter));
            const auto globalScatter = clamp01(read(parameters.scatter));
            const auto scatter = juce::jlimit(0.0f, 1.0f,
                                              0.5f * (localScatter + globalScatter));
            const auto regionLength = playhead.regionEnd - playhead.regionStart;
            const auto randomOffset = (nextRandom() * 2.0f - 1.0f)
                                      * scatter * static_cast<float>(regionLength) * 0.5f;
            playhead.grainStart = juce::jlimit(playhead.regionStart,
                                               playhead.regionEnd,
                                               playhead.position + randomOffset);
            playhead.grainAge = 0;
        }

        readPosition = playhead.grainStart + direction * step * playhead.grainAge;
        const auto phase = static_cast<float>(playhead.grainAge)
                           / static_cast<float>(playhead.grainLength);
        window = std::sin(juce::MathConstants<float>::pi * clamp01(phase));
        window *= juce::jmap(0.5f * (globalDensity + localDensity), 0.45f, 1.0f);
        ++playhead.grainAge;
    }

    readPosition = juce::jlimit(playhead.regionStart, playhead.regionEnd, readPosition);
    result.left = interpolate(playhead.asset->audio, 0, readPosition) * window;
    result.right = interpolate(playhead.asset->audio,
        playhead.asset->audio.getNumChannels() > 1 ? 1 : 0, readPosition) * window;

    playhead.position += direction * step;
    const auto reachedEnd = (! reverse && playhead.position >= playhead.regionEnd)
                            || (reverse && playhead.position <= playhead.regionStart);
    if (reachedEnd)
    {
        if (looping || granular)
            playhead.position = reverse ? playhead.regionEnd : playhead.regionStart;
        else
            playhead.finished = true;
    }

    return result;
}

MuDVoice::StereoSample MuDVoice::filterAndPan(int sourceIndex, StereoSample input,
                                              float envelope)
{
    const auto& source = parameters.source[static_cast<std::size_t>(sourceIndex)];
    if (read(source.mute) >= 0.5f)
        return {};

    auto anySolo = false;
    for (const auto& candidate : parameters.source)
        anySolo = anySolo || read(candidate.solo) >= 0.5f;
    if (anySolo && read(source.solo) < 0.5f)
        return {};

    const auto gain = juce::Decibels::decibelsToGain(read(source.level), -72.0f)
                      * envelope * noteVelocity;
    const auto pan = juce::jlimit(-1.0f, 1.0f, read(source.pan));
    const auto leftGain = std::sqrt(0.5f * (1.0f - pan));
    const auto rightGain = std::sqrt(0.5f * (1.0f + pan));
    input.left = filters[static_cast<std::size_t>(sourceIndex)][0].process(input.left)
                 * gain * leftGain;
    input.right = filters[static_cast<std::size_t>(sourceIndex)][1].process(input.right)
                  * gain * rightGain;
    meterBus.push(sourceIndex, juce::jmax(std::abs(input.left), std::abs(input.right)));
    return input;
}

MuDVoice::StereoSample MuDVoice::combineSources(
    const std::array<StereoSample, 4>& sources, float x, float y, int mode)
{
    x = clamp01(x);
    y = clamp01(y);
    std::array<float, 4> weights {
        std::sqrt((1.0f - x) * (1.0f - y)),
        std::sqrt(x * (1.0f - y)),
        std::sqrt((1.0f - x) * y),
        std::sqrt(x * y)
    };

    StereoSample result;
    if (mode == 2)
    {
        morphGrainPhase += 1.0f / static_cast<float>(juce::jmax(16.0, sampleRate * 0.012));
        if (morphGrainPhase >= 1.0f)
        {
            morphGrainPhase -= 1.0f;
            const auto choice = nextRandom();
            auto accumulator = 0.0f;
            const auto totalWeight = juce::jmax(0.0001f,
                weights[0] + weights[1] + weights[2] + weights[3]);
            for (int index = 0; index < 4; ++index)
            {
                accumulator += weights[static_cast<std::size_t>(index)] / totalWeight;
                if (choice <= accumulator)
                {
                    selectedMorphSource = index;
                    break;
                }
            }
        }
        result = sources[static_cast<std::size_t>(selectedMorphSource)];
        return result;
    }

    for (std::size_t index = 0; index < sources.size(); ++index)
    {
        result.left += sources[index].left * weights[index];
        result.right += sources[index].right * weights[index];
    }

    if (mode == 1)
    {
        const auto crossLeft = sources[0].left * sources[2].left
                               + sources[1].left * sources[3].left;
        const auto crossRight = sources[0].right * sources[2].right
                                + sources[1].right * sources[3].right;
        result.left = std::tanh(result.left * 1.15f + crossLeft * 0.45f);
        result.right = std::tanh(result.right * 1.15f + crossRight * 0.45f);
    }
    else if (mode == 3)
    {
        result.left += 0.7f * (sources[0].left * sources[1].left
                               + sources[2].left * sources[3].left);
        result.right += 0.7f * (sources[0].right * sources[1].right
                                + sources[2].right * sources[3].right);
    }
    return result;
}

void MuDVoice::renderNextBlock(juce::AudioBuffer<float>& outputBuffer,
                               int startSample, int numSamples)
{
    if (! isVoiceActive())
        return;

    updateEnvelopes();
    const auto baseFrequency = static_cast<float>(
        juce::MidiMessage::getMidiNoteInHertz(midiNote));
    const auto mode = juce::jlimit(0, 3, juce::roundToInt(read(parameters.morphMode)));
    const auto macroMorph = clamp01(read(parameters.macroMorph));
    const auto macroMotion = clamp01(read(parameters.macroMotion));
    const auto macroDamage = clamp01(read(parameters.macroDamage));

    for (int frame = 0; frame < numSamples; ++frame)
    {
        std::array<StereoSample, 4> sourceAudio;

        const auto& synth1 = parameters.source[0];
        const auto synth1Semitones = read(synth1.tune) + read(synth1.fine) * 0.01f
                                     + pitchBendSemitones;
        const auto synth1Frequency = baseFrequency
            * std::pow(2.0f, synth1Semitones / 12.0f);
        const auto unison = juce::jlimit(1, 7,
            juce::roundToInt(read(parameters.synth1Unison)));
        const auto detune = read(parameters.synth1Detune);
        auto wavetableSample = 0.0f;
        for (int voice = 0; voice < unison; ++voice)
        {
            const auto centre = 0.5f * static_cast<float>(unison - 1);
            const auto cents = (static_cast<float>(voice) - centre) * detune;
            const auto frequency = synth1Frequency * std::pow(2.0f, cents / 1200.0f);
            auto& phase = synth1Phases[static_cast<std::size_t>(voice)];
            wavetableSample += oscillator(phase, static_cast<float>(juce::roundToInt(
                read(parameters.synth1Wave))));
            phase = wrapPhase(phase + frequency / static_cast<float>(sampleRate));
        }
        wavetableSample = fold(wavetableSample / static_cast<float>(unison),
                               read(parameters.synth1Fold));
        sourceAudio[0] = { wavetableSample, wavetableSample };

        const auto& synth2 = parameters.source[1];
        const auto synth2Semitones = read(synth2.tune) + read(synth2.fine) * 0.01f
                                     + pitchBendSemitones;
        const auto synth2Frequency = baseFrequency
            * std::pow(2.0f, synth2Semitones / 12.0f);
        const auto carrierRatio = juce::jmax(0.125f, read(parameters.synth2CarrierRatio));
        const auto modRatio = juce::jmax(0.125f, read(parameters.synth2ModRatio));
        const auto fmIndex = read(parameters.synth2Index);
        const auto feedback = read(parameters.synth2Feedback);
        const auto modulator = std::sin(twoPi * modulatorPhase
                                        + fmFeedbackSample * feedback);
        const auto modulatedCarrierPhase = wrapPhase(
            carrierPhase + modulator * fmIndex / twoPi);
        const auto fmSample = oscillator(modulatedCarrierPhase,
            juce::jlimit(0.0f, 3.0f, read(parameters.synth2Wave)));
        fmFeedbackSample = fmSample;
        carrierPhase = wrapPhase(carrierPhase + synth2Frequency * carrierRatio
                                                / static_cast<float>(sampleRate));
        modulatorPhase = wrapPhase(modulatorPhase + synth2Frequency * modRatio
                                                    / static_cast<float>(sampleRate));
        sourceAudio[1] = { fmSample, fmSample };

        for (int sampleIndex = 0; sampleIndex < 2; ++sampleIndex)
        {
            const auto sourceIndex = sampleIndex + 2;
            const auto& source = parameters.source[static_cast<std::size_t>(sourceIndex)];
            const auto asset = playheads[static_cast<std::size_t>(sampleIndex)].asset;
            if (asset == nullptr)
                continue;
            const auto root = asset->pitch.detected ? asset->pitch.midiNote : 60.0f;
            const auto semitones = static_cast<float>(midiNote) - root
                + read(source.tune) + read(source.fine) * 0.01f + pitchBendSemitones;
            const auto increment = asset->sourceSampleRate / sampleRate
                                   * std::pow(2.0, static_cast<double>(semitones) / 12.0);
            sourceAudio[static_cast<std::size_t>(sourceIndex)] =
                renderSampleEngine(sampleIndex, increment);
        }

        auto envelopesActive = false;
        for (int sourceIndex = 0; sourceIndex < 4; ++sourceIndex)
        {
            const auto env = envelopes[static_cast<std::size_t>(sourceIndex)].getNextSample();
            envelopesActive = envelopesActive
                              || envelopes[static_cast<std::size_t>(sourceIndex)].isActive();
            sourceAudio[static_cast<std::size_t>(sourceIndex)] = filterAndPan(
                sourceIndex, sourceAudio[static_cast<std::size_t>(sourceIndex)], env);
        }

        const auto motionDepth = clamp01(read(parameters.motionDepth))
                                 * juce::jmap(macroMotion, 0.25f, 1.0f);
        const auto runtimeX = parameters.runtimeMorphX.load(std::memory_order_relaxed);
        const auto runtimeY = parameters.runtimeMorphY.load(std::memory_order_relaxed);
        auto x = read(parameters.morphX) + runtimeX * motionDepth;
        auto y = read(parameters.morphY) + runtimeY * motionDepth;
        x = juce::jlimit(0.0f, 1.0f, x + (macroMorph - 0.5f) * 0.18f);
        y = juce::jlimit(0.0f, 1.0f, y - (macroMorph - 0.5f) * 0.18f);
        auto mixed = combineSources(sourceAudio, x, y, mode);

        const auto damage = clamp01(read(parameters.damage) + macroDamage * 0.65f);
        const auto grime = clamp01(read(parameters.grime));
        const auto smooth = clamp01(read(parameters.smooth));
        const auto shatter = clamp01(read(parameters.shatter));
        if (shatter > 0.001f && nextRandom() < shatter * 0.035f)
            mixed.left = mixed.right = 0.0f;

        const auto bitDepth = juce::jmap(damage, 16.0f, 4.0f);
        const auto levels = std::pow(2.0f, bitDepth);
        mixed.left = std::round(mixed.left * levels) / levels;
        mixed.right = std::round(mixed.right * levels) / levels;
        mixed.left = std::tanh(mixed.left * juce::jmap(grime, 1.0f, 7.0f)
                               + (nextRandom() - 0.5f) * grime * 0.012f);
        mixed.right = std::tanh(mixed.right * juce::jmap(grime, 1.0f, 7.0f)
                                + (nextRandom() - 0.5f) * grime * 0.012f);

        const auto smoothCoefficient = juce::jmap(smooth, 1.0f, 0.008f);
        smoothState[0] += smoothCoefficient * (mixed.left - smoothState[0]);
        smoothState[1] += smoothCoefficient * (mixed.right - smoothState[1]);
        mixed.left = juce::jmap(smooth, mixed.left, smoothState[0]);
        mixed.right = juce::jmap(smooth, mixed.right, smoothState[1]);

        outputBuffer.addSample(0, startSample + frame, mixed.left);
        if (outputBuffer.getNumChannels() > 1)
            outputBuffer.addSample(1, startSample + frame, mixed.right);

        if (! envelopesActive)
        {
            clearCurrentNote();
            break;
        }
    }
}
} // namespace mud
