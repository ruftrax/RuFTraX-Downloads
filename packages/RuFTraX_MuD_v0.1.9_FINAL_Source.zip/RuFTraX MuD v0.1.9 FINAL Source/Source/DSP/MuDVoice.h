#pragma once

#include <JuceHeader.h>
#include "SampleStore.h"
#include <array>
#include <atomic>
#include <memory>

namespace mud
{
struct SourceParameters
{
    std::atomic<float>* level = nullptr;
    std::atomic<float>* pan = nullptr;
    std::atomic<float>* tune = nullptr;
    std::atomic<float>* fine = nullptr;
    std::atomic<float>* attack = nullptr;
    std::atomic<float>* decay = nullptr;
    std::atomic<float>* sustain = nullptr;
    std::atomic<float>* release = nullptr;
    std::atomic<float>* highPass = nullptr;
    std::atomic<float>* lowPass = nullptr;
    std::atomic<float>* mute = nullptr;
    std::atomic<float>* solo = nullptr;
};

struct SampleParameters
{
    std::atomic<float>* reverse = nullptr;
    std::atomic<float>* loop = nullptr;
    std::atomic<float>* slice = nullptr;
    std::atomic<float>* grain = nullptr;
    std::atomic<float>* grainSize = nullptr;
    std::atomic<float>* density = nullptr;
    std::atomic<float>* scatter = nullptr;
    std::atomic<float>* stretch = nullptr;
};

struct VoiceParameters
{
    std::array<SourceParameters, 4> source;
    std::array<SampleParameters, 2> sample;

    std::atomic<float>* keyRoot = nullptr;
    std::atomic<float>* keyMode = nullptr;
    std::atomic<float>* keyLock = nullptr;

    std::atomic<float>* synth1Wave = nullptr;
    std::atomic<float>* synth1Unison = nullptr;
    std::atomic<float>* synth1Detune = nullptr;
    std::atomic<float>* synth1Fold = nullptr;
    std::atomic<float>* synth2CarrierRatio = nullptr;
    std::atomic<float>* synth2ModRatio = nullptr;
    std::atomic<float>* synth2Index = nullptr;
    std::atomic<float>* synth2Feedback = nullptr;
    std::atomic<float>* synth2Wave = nullptr;

    std::atomic<float>* morphX = nullptr;
    std::atomic<float>* morphY = nullptr;
    std::atomic<float>* morphMode = nullptr;
    std::atomic<float>* motionDepth = nullptr;
    std::atomic<float>* density = nullptr;
    std::atomic<float>* scatter = nullptr;
    std::atomic<float>* smear = nullptr;
    std::atomic<float>* freeze = nullptr;
    std::atomic<float>* shatter = nullptr;
    std::atomic<float>* stretch = nullptr;
    std::atomic<float>* resonate = nullptr;
    std::atomic<float>* damage = nullptr;
    std::atomic<float>* smooth = nullptr;
    std::atomic<float>* grime = nullptr;
    std::atomic<float>* macroMorph = nullptr;
    std::atomic<float>* macroMotion = nullptr;
    std::atomic<float>* macroDamage = nullptr;

    std::atomic<float> runtimeMorphX { 0.0f };
    std::atomic<float> runtimeMorphY { 0.0f };
};

class SourceMeterBus
{
public:
    SourceMeterBus();
    void push(int source, float magnitude) noexcept;
    float consume(int source) noexcept;

private:
    std::array<std::atomic<float>, 4> peaks;
};

class MuDVoice final : public juce::SynthesiserVoice
{
public:
    MuDVoice(VoiceParameters&, SampleStore&, SampleStore&, SourceMeterBus&);

    bool canPlaySound(juce::SynthesiserSound*) override;
    void startNote(int midiNoteNumber, float velocity,
                   juce::SynthesiserSound*, int pitchWheelPosition) override;
    void stopNote(float velocity, bool allowTailOff) override;
    void pitchWheelMoved(int newPitchWheelValue) override;
    void controllerMoved(int, int) override {}
    void renderNextBlock(juce::AudioBuffer<float>& outputBuffer,
                         int startSample, int numSamples) override;

private:
    struct OnePoleBand
    {
        void reset() noexcept { hpState = lpState = 0.0f; }
        void set(double sampleRate, float highPassHz, float lowPassHz) noexcept;
        float process(float input) noexcept;
        float hpCoefficient = 0.0f;
        float lpCoefficient = 1.0f;
        float hpState = 0.0f;
        float lpState = 0.0f;
    };

    struct SamplePlayhead
    {
        std::shared_ptr<const SampleAsset> asset;
        double position = 0.0;
        double regionStart = 0.0;
        double regionEnd = 0.0;
        double grainStart = 0.0;
        int grainAge = 0;
        int grainLength = 2048;
        bool finished = false;
    };

    struct StereoSample
    {
        float left = 0.0f;
        float right = 0.0f;
    };

    static float read(const std::atomic<float>* value) noexcept;
    static float oscillator(float phase, float shape) noexcept;
    static float fold(float value, float amount) noexcept;
    static float interpolate(const juce::AudioBuffer<float>&, int channel,
                             double position) noexcept;

    void updateEnvelopes();
    void initialiseSamplePlayhead(int sampleIndex);
    StereoSample renderSampleEngine(int sampleIndex, double increment);
    StereoSample filterAndPan(int sourceIndex, StereoSample input, float envelope, bool anySolo);
    StereoSample combineSources(const std::array<StereoSample, 4>& sources,
                                float x, float y, int mode);
    float nextRandom() noexcept;

    VoiceParameters& parameters;
    std::array<SampleStore*, 2> sampleStores;
    SourceMeterBus& meterBus;
    std::array<juce::ADSR, 4> envelopes;
    std::array<std::array<OnePoleBand, 2>, 4> filters;
    std::array<float, 7> synth1Phases {};
    float carrierPhase = 0.0f;
    float modulatorPhase = 0.0f;
    float fmFeedbackSample = 0.0f;
    std::array<SamplePlayhead, 2> playheads;
    double sampleRate = 44100.0;
    int midiNote = 60;
    float noteVelocity = 0.0f;
    float pitchBendSemitones = 0.0f;
    float motionPhase = 0.0f;
    float morphGrainPhase = 0.0f;
    int selectedMorphSource = 0;
    std::array<float, 2> smoothState {};
    uint32_t randomState = 0x6d2b79f5u;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MuDVoice)
};
} // namespace mud
