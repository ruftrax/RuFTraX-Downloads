#pragma once

#include <JuceHeader.h>
#include <array>

namespace mud::param
{
inline juce::String source(int index, const juce::String& suffix)
{
    return "source" + juce::String(index + 1) + suffix;
}

inline juce::String sample(int index, const juce::String& suffix)
{
    return "sample" + juce::String(index + 1) + suffix;
}

inline juce::String step(int index)
{
    return "sequenceStep" + juce::String(index + 1);
}

inline constexpr const char* synth1Wave = "synth1Wave";
inline constexpr const char* synth1Unison = "synth1Unison";
inline constexpr const char* synth1Detune = "synth1Detune";
inline constexpr const char* synth1Fold = "synth1Fold";

inline constexpr const char* synth2CarrierRatio = "synth2CarrierRatio";
inline constexpr const char* synth2ModRatio = "synth2ModRatio";
inline constexpr const char* synth2Index = "synth2Index";
inline constexpr const char* synth2Feedback = "synth2Feedback";
inline constexpr const char* synth2Wave = "synth2Wave";

inline constexpr const char* morphX = "morphX";
inline constexpr const char* morphY = "morphY";
inline constexpr const char* morphMode = "morphMode";
inline constexpr const char* motionRate = "motionRate";
inline constexpr const char* motionDepth = "motionDepth";
inline constexpr const char* motionJitter = "motionJitter";

inline constexpr const char* density = "density";
inline constexpr const char* scatter = "scatter";
inline constexpr const char* smear = "smear";
inline constexpr const char* freeze = "freeze";
inline constexpr const char* shatter = "shatter";
inline constexpr const char* stretch = "stretch";
inline constexpr const char* resonate = "resonate";
inline constexpr const char* damage = "damage";
inline constexpr const char* smooth = "smooth";
inline constexpr const char* grime = "grime";

inline constexpr const char* macroMorph = "macroMorph";
inline constexpr const char* macroMotion = "macroMotion";
inline constexpr const char* macroDamage = "macroDamage";
inline constexpr const char* macroSpace = "macroSpace";

inline constexpr const char* sequenceEnabled = "sequenceEnabled";
inline constexpr const char* sequenceRate = "sequenceRate";
inline constexpr const char* sequenceDepth = "sequenceDepth";
inline constexpr const char* sequenceTarget = "sequenceTarget";

inline constexpr const char* chorusRate = "chorusRate";
inline constexpr const char* chorusDepth = "chorusDepth";
inline constexpr const char* chorusMix = "chorusMix";
inline constexpr const char* delayType = "delayType";
inline constexpr const char* delayTime = "delayTime";
inline constexpr const char* delayFeedback = "delayFeedback";
inline constexpr const char* delayMix = "delayMix";
inline constexpr const char* reverbType = "reverbType";
inline constexpr const char* reverbSize = "reverbSize";
inline constexpr const char* reverbDamping = "reverbDamping";
inline constexpr const char* reverbMix = "reverbMix";
inline constexpr const char* spectralFreeze = "spectralFreeze";
inline constexpr const char* convolutionMix = "convolutionMix";
inline constexpr const char* masterGain = "masterGain";
inline constexpr const char* limiterEnabled = "limiterEnabled";
inline constexpr const char* bypassAll = "bypassAll";
inline constexpr const char* phaseReverse = "phaseReverse";
inline constexpr const char* tapeWobble = "tapeWobble";

inline constexpr const char* chaosAmount = "chaosAmount";
inline constexpr const char* randomSeed = "randomSeed";
inline constexpr const char* lockSources = "lockSources";
inline constexpr const char* lockPitch = "lockPitch";
inline constexpr const char* lockRhythm = "lockRhythm";
inline constexpr const char* lockFilter = "lockFilter";
inline constexpr const char* lockMod = "lockMod";
inline constexpr const char* lockFx = "lockFx";
inline constexpr const char* lockMix = "lockMix";

inline const std::array<const char*, 12> sourceSuffixes {
    "Level", "Pan", "Tune", "Fine", "Attack", "Decay",
    "Sustain", "Release", "HighPass", "LowPass", "Mute", "Solo"
};
} // namespace mud::param
