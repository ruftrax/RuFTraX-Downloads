#pragma once

#include <JuceHeader.h>
#include <array>

namespace mud::param
{
inline juce::String source(int index, const juce::String& suffix)
{
    return "source" + juce::String(index + 1) + suffix;
}

inline juce::String sample(int index, const juce::String& suffix)
{
    return "sample" + juce::String(index + 1) + suffix;
}

inline juce::String step(int index)
{
    return "sequenceStep" + juce::String(index + 1);
}

inline constexpr const char* keyRoot = "keyRoot";
inline constexpr const char* keyMode = "keyMode";
inline constexpr const char* keyLock = "keyLock";

inline const std::array<const char*, 12> keyRootNames {
    "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
};
inline const std::array<const char*, 2> keyModeNames { "Major", "Minor" };

/** Semitone offsets from the root for each scale degree, 0 = keyMode index (Major/Minor). */
inline const std::array<std::array<int, 7>, 2> keyScaleIntervals { {
    { 0, 2, 4, 5, 7, 9, 11 },  // Major
    { 0, 2, 3, 5, 7, 8, 10 },  // Natural minor
} };

/**
 * Snaps a MIDI note to the nearest note in the given key/scale. Used only when IN KEY is
 * engaged - with it off, notes pass through untouched so sound design can go anywhere
 * regardless of the selected key.
 *
 * @param midiNote The incoming note, any integer (not required to be a valid 0-127 note yet)
 * @param root     0-11, C=0 through B=11 (wraps automatically if out of that range)
 * @param mode     0 = Major, 1 = Minor (clamped)
 * @return The nearest in-scale note, clamped to the valid 0-127 MIDI range
 */
inline int quantizeToScale(int midiNote, int root, int mode) noexcept
{
    root = ((root % 12) + 12) % 12;
    mode = mode < 0 ? 0 : (mode > 1 ? 1 : mode);
    const auto& intervals = keyScaleIntervals[static_cast<std::size_t>(mode)];

    auto pitchClass = (midiNote - root) % 12;
    if (pitchClass < 0)
        pitchClass += 12;

    // Ties (equidistant between two scale degrees) round up, a common, predictable convention.
    auto bestDegree = intervals[0];
    auto bestDistance = 12;
    for (const auto degree : intervals)
        for (const auto candidate : { degree - 12, degree, degree + 12 })
        {
            const auto signedDistance = candidate - pitchClass;
            const auto distance = signedDistance < 0 ? -signedDistance : signedDistance;
            if (distance < bestDistance || (distance == bestDistance && signedDistance > 0))
            {
                bestDistance = distance;
                bestDegree = candidate;
            }
        }

    const auto quantized = midiNote - pitchClass + bestDegree;
    return quantized < 0 ? 0 : (quantized > 127 ? 127 : quantized);
}

inline constexpr const char* synth1Wave = "synth1Wave";
inline constexpr const char* synth1Unison = "synth1Unison";
inline constexpr const char* synth1Detune = "synth1Detune";
inline constexpr const char* synth1Fold = "synth1Fold";

inline constexpr const char* synth2CarrierRatio = "synth2CarrierRatio";
inline constexpr const char* synth2ModRatio = "synth2ModRatio";
inline constexpr const char* synth2Index = "synth2Index";
inline constexpr const char* synth2Feedback = "synth2Feedback";
inline constexpr const char* synth2Wave = "synth2Wave";

inline constexpr const char* morphX = "morphX";
inline constexpr const char* morphY = "morphY";
inline constexpr const char* morphMode = "morphMode";
inline constexpr const char* motionRate = "motionRate";
inline constexpr const char* motionDepth = "motionDepth";
inline constexpr const char* motionJitter = "motionJitter";

inline constexpr const char* density = "density";
inline constexpr const char* scatter = "scatter";
inline constexpr const char* smear = "smear";
inline constexpr const char* freeze = "freeze";
inline constexpr const char* shatter = "shatter";
inline constexpr const char* stretch = "stretch";
inline constexpr const char* resonate = "resonate";
inline constexpr const char* damage = "damage";
inline constexpr const char* smooth = "smooth";
inline constexpr const char* grime = "grime";

inline constexpr const char* macroMorph = "macroMorph";
inline constexpr const char* macroMotion = "macroMotion";
inline constexpr const char* macroDamage = "macroDamage";
inline constexpr const char* macroSpace = "macroSpace";

inline constexpr const char* sequenceEnabled = "sequenceEnabled";
inline constexpr const char* sequenceRate = "sequenceRate";
inline constexpr const char* sequenceDepth = "sequenceDepth";
inline constexpr const char* sequenceTarget = "sequenceTarget";

/**
 * The Delay Time parameter's declared maximum, in seconds (must match the range passed to
 * makeFloat(param::delayTime, ...) in PluginProcessor.cpp). EffectsRack sizes its delay line
 * from this constant so the two can never drift apart - a fixed sample-count buffer chosen
 * without accounting for the actual session sample rate would otherwise silently cap the real
 * delay time shorter than this knob shows at very high sample rates.
 */
inline constexpr float maxDelayTimeSeconds = 3.8f;

inline constexpr const char* chorusRate = "chorusRate";
inline constexpr const char* chorusDepth = "chorusDepth";
inline constexpr const char* chorusMix = "chorusMix";
inline constexpr const char* delayType = "delayType";
inline constexpr const char* delayTime = "delayTime";
inline constexpr const char* delayFeedback = "delayFeedback";
inline constexpr const char* delayMix = "delayMix";
inline constexpr const char* reverbType = "reverbType";
inline constexpr const char* reverbSize = "reverbSize";
inline constexpr const char* reverbDamping = "reverbDamping";
inline constexpr const char* reverbMix = "reverbMix";
inline constexpr const char* spectralFreeze = "spectralFreeze";
inline constexpr const char* convolutionMix = "convolutionMix";
inline constexpr const char* masterGain = "masterGain";
inline constexpr const char* limiterEnabled = "limiterEnabled";
inline constexpr const char* bypassAll = "bypassAll";
inline constexpr const char* phaseReverse = "phaseReverse";
inline constexpr const char* tapeWobble = "tapeWobble";

inline constexpr const char* chaosAmount = "chaosAmount";
inline constexpr const char* randomSeed = "randomSeed";
inline constexpr const char* lockSources = "lockSources";
inline constexpr const char* lockPitch = "lockPitch";
inline constexpr const char* lockRhythm = "lockRhythm";
inline constexpr const char* lockFilter = "lockFilter";
inline constexpr const char* lockMod = "lockMod";
inline constexpr const char* lockFx = "lockFx";
inline constexpr const char* lockMix = "lockMix";

inline const std::array<const char*, 12> sourceSuffixes {
    "Level", "Pan", "Tune", "Fine", "Attack", "Decay",
    "Sustain", "Release", "HighPass", "LowPass", "Mute", "Solo"
};
} // namespace mud::param
