#include "SampleStore.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>

namespace mud
{
namespace
{
struct WindowPitch
{
    float frequency = 0.0f;
    float confidence = 0.0f;
};

int rootNoteFromFileName(const juce::String& fileName)
{
    const auto text = fileName.toUpperCase();
    for (int index = 0; index < text.length(); ++index)
    {
        const auto noteLetter = text[index];
        if (noteLetter < 'A' || noteLetter > 'G')
            continue;

        if (index > 0 && juce::CharacterFunctions::isLetterOrDigit(text[index - 1]))
            continue;

        auto pitchClass = 0;
        switch (noteLetter)
        {
            case 'C': pitchClass = 0; break;
            case 'D': pitchClass = 2; break;
            case 'E': pitchClass = 4; break;
            case 'F': pitchClass = 5; break;
            case 'G': pitchClass = 7; break;
            case 'A': pitchClass = 9; break;
            case 'B': pitchClass = 11; break;
            default: break;
        }

        auto octaveIndex = index + 1;
        if (octaveIndex < text.length() && text[octaveIndex] == '#')
        {
            ++pitchClass;
            ++octaveIndex;
        }
        else if (octaveIndex < text.length() && text[octaveIndex] == 'B')
        {
            --pitchClass;
            ++octaveIndex;
        }

        auto octaveSign = 1;
        if (octaveIndex < text.length() && text[octaveIndex] == '-')
        {
            octaveSign = -1;
            ++octaveIndex;
        }
        if (octaveIndex >= text.length()
            || ! juce::CharacterFunctions::isDigit(text[octaveIndex]))
            continue;

        const auto octave = octaveSign * (text[octaveIndex] - '0');
        const auto afterOctave = octaveIndex + 1;
        if (afterOctave < text.length()
            && juce::CharacterFunctions::isDigit(text[afterOctave]))
            continue;

        const auto midiNote = (octave + 1) * 12 + pitchClass;
        if (juce::isPositiveAndBelow(midiNote, 128))
            return midiNote;
    }
    return -1;
}

float midiNoteToFrequency(float midiNote)
{
    return 440.0f * std::pow(2.0f, (midiNote - 69.0f) / 12.0f);
}

WindowPitch analyseWindow(const std::vector<float>& samples, int start,
                          int windowSize, double sampleRate)
{
    WindowPitch result;
    if (windowSize < 1024 || start < 0
        || start + windowSize > static_cast<int>(samples.size()))
        return result;

    double mean = 0.0;
    for (int index = 0; index < windowSize; ++index)
        mean += samples[static_cast<std::size_t>(start + index)];
    mean /= static_cast<double>(windowSize);

    double energy = 0.0;
    for (int index = 0; index < windowSize; ++index)
    {
        const auto sample = static_cast<double>(
            samples[static_cast<std::size_t>(start + index)]) - mean;
        energy += sample * sample;
    }

    if (std::sqrt(energy / static_cast<double>(windowSize)) < 0.0001)
        return result;

    const auto minimumLag = juce::jmax(2, static_cast<int>(sampleRate / 1800.0));
    const auto maximumLag = juce::jmin(windowSize / 2 - 2,
                                       static_cast<int>(sampleRate / 35.0));
    if (maximumLag <= minimumLag + 2)
        return result;

    std::vector<double> difference(static_cast<std::size_t>(maximumLag + 1), 0.0);
    std::vector<double> normalised(static_cast<std::size_t>(maximumLag + 1), 1.0);
    const auto comparisonCount = windowSize - maximumLag;

    for (int lag = 1; lag <= maximumLag; ++lag)
    {
        double sum = 0.0;
        for (int index = 0; index < comparisonCount; ++index)
        {
            const auto a = static_cast<double>(
                samples[static_cast<std::size_t>(start + index)]) - mean;
            const auto b = static_cast<double>(
                samples[static_cast<std::size_t>(start + index + lag)]) - mean;
            const auto delta = a - b;
            sum += delta * delta;
        }
        difference[static_cast<std::size_t>(lag)] = sum;
    }

    double runningSum = 0.0;
    for (int lag = 1; lag <= maximumLag; ++lag)
    {
        runningSum += difference[static_cast<std::size_t>(lag)];
        if (runningSum > 0.0)
            normalised[static_cast<std::size_t>(lag)] =
                difference[static_cast<std::size_t>(lag)]
                * static_cast<double>(lag) / runningSum;
    }

    auto selectedLag = 0;
    constexpr double threshold = 0.18;
    for (int lag = minimumLag + 1; lag < maximumLag - 1; ++lag)
    {
        const auto value = normalised[static_cast<std::size_t>(lag)];
        if (value < threshold
            && value <= normalised[static_cast<std::size_t>(lag - 1)]
            && value < normalised[static_cast<std::size_t>(lag + 1)])
        {
            selectedLag = lag;
            break;
        }
    }

    if (selectedLag == 0)
    {
        auto bestValue = std::numeric_limits<double>::max();
        for (int lag = minimumLag; lag <= maximumLag; ++lag)
        {
            const auto value = normalised[static_cast<std::size_t>(lag)];
            if (value < bestValue)
            {
                bestValue = value;
                selectedLag = lag;
            }
        }
    }

    if (selectedLag <= 1 || selectedLag >= maximumLag)
        return result;

    const auto left = normalised[static_cast<std::size_t>(selectedLag - 1)];
    const auto centre = normalised[static_cast<std::size_t>(selectedLag)];
    const auto right = normalised[static_cast<std::size_t>(selectedLag + 1)];
    const auto denominator = left - 2.0 * centre + right;
    auto refinedLag = static_cast<double>(selectedLag);
    if (std::abs(denominator) > 1.0e-12)
        refinedLag += 0.5 * (left - right) / denominator;

    if (refinedLag <= 0.0)
        return result;

    result.frequency = static_cast<float>(sampleRate / refinedLag);
    result.confidence = juce::jlimit(
        0.0f, 1.0f, static_cast<float>(1.0 - centre));
    return result;
}
} // namespace

SampleStore::SampleStore()
{
    formats.registerBasicFormats();
}

bool SampleStore::loadFromFile(const juce::File& file, juce::String& error)
{
    if (! file.existsAsFile())
    {
        error = "The selected sample does not exist.";
        return false;
    }

    std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(file));
    if (reader == nullptr)
    {
        error = "MuD could not read this audio format. Use WAV, AIFF or FLAC.";
        return false;
    }

    constexpr int64 maximumFrames = 192000LL * 60LL * 10LL;
    if (reader->lengthInSamples <= 0 || reader->lengthInSamples > maximumFrames)
    {
        error = "The sample is empty or longer than the 10-minute safety limit.";
        return false;
    }

    auto next = std::make_shared<SampleAsset>();
    const auto channels = juce::jlimit(1, 2, static_cast<int>(reader->numChannels));
    next->audio.setSize(channels, static_cast<int>(reader->lengthInSamples));
    reader->read(&next->audio, 0, next->audio.getNumSamples(), 0, true, true);
    next->sourceSampleRate = reader->sampleRate;
    next->name = file.getFileNameWithoutExtension();
    next->sourceFile = file;
    next->pitch = analysePitch(next->audio, next->sourceSampleRate);
    const auto fileNameRoot = rootNoteFromFileName(next->name);
    if (fileNameRoot >= 0)
    {
        // An explicit note in the filename is the most reliable octave/root
        // mapping. Preserve any fine-tuning offset measured from the audio.
        const auto fractionalOffset = next->pitch.detected
            ? next->pitch.midiNote - std::round(next->pitch.midiNote) : 0.0f;
        next->pitch.detected = true;
        next->pitch.rootFromFileName = true;
        next->pitch.rootMidiNote = fileNameRoot;
        next->pitch.midiNote = static_cast<float>(fileNameRoot) + fractionalOffset;
        next->pitch.frequencyHz = midiNoteToFrequency(next->pitch.midiNote);
        next->pitch.tuningCorrectionSemitones =
            static_cast<float>(fileNameRoot) - next->pitch.midiNote;
        next->pitch.confidence = juce::jmax(next->pitch.confidence, 0.95f);
    }
    createWaveform(*next);

    std::atomic_store(&current, std::shared_ptr<const SampleAsset>(std::move(next)));
    error.clear();
    return true;
}

PitchAnalysis SampleStore::analysePitch(const juce::AudioBuffer<float>& audio,
                                        double sourceSampleRate)
{
    PitchAnalysis result;
    if (sourceSampleRate <= 0.0 || audio.getNumSamples() < 2048)
        return result;

    const auto downsampleFactor =
        juce::jmax(1, juce::roundToInt(sourceSampleRate / 12000.0));
    const auto analysisRate = sourceSampleRate / static_cast<double>(downsampleFactor);
    const auto sourceFrames = juce::jmin(
        audio.getNumSamples(), juce::roundToInt(sourceSampleRate * 6.0));
    const auto analysisFrames = sourceFrames / downsampleFactor;
    if (analysisFrames < 2048)
        return result;

    std::vector<float> mono(static_cast<std::size_t>(analysisFrames), 0.0f);
    for (int frame = 0; frame < analysisFrames; ++frame)
    {
        double sum = 0.0;
        auto count = 0;
        const auto sourceStart = frame * downsampleFactor;
        for (int offset = 0; offset < downsampleFactor
                            && sourceStart + offset < sourceFrames; ++offset)
        {
            for (int channel = 0; channel < audio.getNumChannels(); ++channel)
            {
                sum += audio.getSample(channel, sourceStart + offset);
                ++count;
            }
        }
        if (count > 0)
            mono[static_cast<std::size_t>(frame)] =
                static_cast<float>(sum / static_cast<double>(count));
    }

    const auto windowSize = juce::jmin(8192, analysisFrames);
    const auto step = juce::jmax(512, windowSize / 2);
    const auto firstStart = juce::jmin(
        analysisFrames - windowSize,
        juce::roundToInt(analysisRate * 0.025));

    WindowPitch best;
    for (int start = juce::jmax(0, firstStart);
         start + windowSize <= analysisFrames;
         start += step)
    {
        const auto candidate = analyseWindow(mono, start, windowSize, analysisRate);
        if (candidate.confidence > best.confidence)
            best = candidate;
    }

    if (best.confidence < 0.70f || best.frequency < 35.0f || best.frequency > 5000.0f)
        return result;

    const auto midiNote = 69.0f + 12.0f
        * static_cast<float>(std::log2(best.frequency / 440.0f));
    if (! std::isfinite(midiNote) || midiNote < 0.0f || midiNote > 127.0f)
        return result;

    result.detected = true;
    result.frequencyHz = best.frequency;
    result.midiNote = midiNote;
    result.confidence = best.confidence;
    result.rootMidiNote = juce::jlimit(0, 127, juce::roundToInt(midiNote));
    result.tuningCorrectionSemitones =
        static_cast<float>(result.rootMidiNote) - midiNote;
    return result;
}

void SampleStore::createWaveform(SampleAsset& asset)
{
    const auto frames = asset.audio.getNumSamples();
    if (frames <= 0)
        return;

    for (std::size_t bin = 0; bin < asset.waveform.size(); ++bin)
    {
        const auto start = static_cast<int>(bin * static_cast<std::size_t>(frames)
                                            / asset.waveform.size());
        const auto end = juce::jmax(start + 1,
            static_cast<int>((bin + 1) * static_cast<std::size_t>(frames)
                             / asset.waveform.size()));
        auto peak = 0.0f;
        for (int frame = start; frame < juce::jmin(end, frames); ++frame)
            for (int channel = 0; channel < asset.audio.getNumChannels(); ++channel)
                peak = juce::jmax(peak, std::abs(asset.audio.getSample(channel, frame)));
        asset.waveform[bin] = peak;
    }
}

void SampleStore::clear()
{
    std::atomic_store(&current, std::shared_ptr<const SampleAsset>());
}

std::shared_ptr<const SampleAsset> SampleStore::get() const noexcept
{
    return std::atomic_load(&current);
}
} // namespace mud
