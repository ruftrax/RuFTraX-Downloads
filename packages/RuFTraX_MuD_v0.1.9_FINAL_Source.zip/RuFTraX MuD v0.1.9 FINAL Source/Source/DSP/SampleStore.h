#pragma once

#include <JuceHeader.h>
#include <array>
#include <memory>

namespace mud
{
struct PitchAnalysis
{
    bool detected = false;
    float frequencyHz = 0.0f;
    float midiNote = 60.0f;
    float confidence = 0.0f;
    int rootMidiNote = 60;
    float tuningCorrectionSemitones = 0.0f;
    bool rootFromFileName = false;
};

struct SampleAsset
{
    juce::AudioBuffer<float> audio;
    double sourceSampleRate = 44100.0;
    juce::String name;
    juce::File sourceFile;
    PitchAnalysis pitch;
    std::array<float, 256> waveform {};
};

class SampleStore
{
public:
    SampleStore();

    bool loadFromFile(const juce::File& file, juce::String& error);
    void clear();
    std::shared_ptr<const SampleAsset> get() const noexcept;

private:
    static PitchAnalysis analysePitch(const juce::AudioBuffer<float>&,
                                      double sourceSampleRate);
    static void createWaveform(SampleAsset&);

    juce::AudioFormatManager formats;
    std::shared_ptr<const SampleAsset> current;
};
} // namespace mud
