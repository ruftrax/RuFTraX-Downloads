#include "PluginEditor.h"
#include "DSP/ParameterIDs.h"
#include <cmath>

using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

namespace
{
float previewOscillator(float phase, float shape) noexcept
{
    phase -= std::floor(phase);
    const auto sine = std::sin(juce::MathConstants<float>::twoPi * phase);
    const auto triangle = 1.0f - 4.0f * std::abs(phase - 0.5f);
    const auto saw = 2.0f * phase - 1.0f;
    const auto square = phase < 0.5f ? 1.0f : -1.0f;
    shape = juce::jlimit(0.0f, 3.0f, shape);
    const auto segment = juce::jmin(2, static_cast<int>(shape));
    const auto fraction = shape - static_cast<float>(segment);
    const std::array<float, 4> values { sine, triangle, saw, square };
    return juce::jmap(fraction, values[static_cast<std::size_t>(segment)],
                     values[static_cast<std::size_t>(segment + 1)]);
}

class DiceButton final : public juce::Button
{
public:
    DiceButton() : juce::Button("Mutation Dice")
    {
        setWantsKeyboardFocus(false);
        setTooltip("Roll a new MuD mutation");
    }

    void roll()
    {
        auto& random = juce::Random::getSystemRandom();
        leftValue = 1 + random.nextInt(6);
        rightValue = 1 + random.nextInt(6);
        repaint();
    }

    void paintButton(juce::Graphics& graphics, bool highlighted, bool down) override
    {
        auto bounds = getLocalBounds().toFloat().reduced(2.0f);
        auto colour = mud::ui::Colours::panelLight();
        if (highlighted)
            colour = colour.brighter(0.10f);
        if (down)
            colour = colour.darker(0.16f);

        graphics.setColour(juce::Colours::black.withAlpha(0.65f));
        graphics.fillRoundedRectangle(bounds.translated(0.0f, 3.0f), 7.0f);
        graphics.setColour(colour);
        graphics.fillRoundedRectangle(bounds, 7.0f);
        graphics.setColour(mud::ui::Colours::acid().withAlpha(0.85f));
        graphics.drawRoundedRectangle(bounds, 7.0f, 1.5f);

        auto labelArea = bounds.removeFromBottom(19.0f);
        auto diceArea = bounds.reduced(9.0f, 5.0f);
        const auto gap = 8.0f;
        const auto dieSize = juce::jmin(diceArea.getHeight(),
            (diceArea.getWidth() - gap) * 0.5f);
        const auto totalWidth = dieSize * 2.0f + gap;
        auto leftDie = juce::Rectangle<float>(
            diceArea.getCentreX() - totalWidth * 0.5f,
            diceArea.getCentreY() - dieSize * 0.5f, dieSize, dieSize);
        auto rightDie = leftDie.translated(dieSize + gap, 0.0f);
        if (down)
        {
            leftDie.translate(0.0f, 1.5f);
            rightDie.translate(0.0f, 1.5f);
        }
        drawDie(graphics, leftDie, leftValue);
        drawDie(graphics, rightDie, rightValue);

        graphics.setColour(mud::ui::Colours::acid());
        graphics.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        graphics.drawText("RANDOMIZE", labelArea.toNearestInt(),
                          juce::Justification::centred);
    }

private:
    static void drawDie(juce::Graphics& graphics, juce::Rectangle<float> bounds,
                        int value)
    {
        graphics.setColour(mud::ui::Colours::ivory());
        graphics.fillRoundedRectangle(bounds, bounds.getWidth() * 0.18f);
        graphics.setColour(mud::ui::Colours::brass().darker(0.25f));
        graphics.drawRoundedRectangle(bounds, bounds.getWidth() * 0.18f, 1.2f);

        const auto pipColour = juce::Colour(0xff172019);
        const auto radius = juce::jmax(1.8f, bounds.getWidth() * 0.065f);
        const auto x1 = bounds.getX() + bounds.getWidth() * 0.27f;
        const auto x2 = bounds.getCentreX();
        const auto x3 = bounds.getRight() - bounds.getWidth() * 0.27f;
        const auto y1 = bounds.getY() + bounds.getHeight() * 0.27f;
        const auto y2 = bounds.getCentreY();
        const auto y3 = bounds.getBottom() - bounds.getHeight() * 0.27f;
        auto pip = [&](float x, float y)
        {
            graphics.setColour(pipColour);
            graphics.fillEllipse(x - radius, y - radius, radius * 2.0f,
                                 radius * 2.0f);
        };

        if (value == 1 || value == 3 || value == 5)
            pip(x2, y2);
        if (value >= 2)
        {
            pip(x1, y1);
            pip(x3, y3);
        }
        if (value >= 4)
        {
            pip(x3, y1);
            pip(x1, y3);
        }
        if (value == 6)
        {
            pip(x1, y2);
            pip(x3, y2);
        }
    }

    int leftValue = 5;
    int rightValue = 3;
};
} // namespace

class RuFTraXMuDAudioProcessorEditor::ParameterKnob final : public juce::Component
{
public:
    ParameterKnob(juce::AudioProcessorValueTreeState& state,
                  const juce::String& id, const juce::String& caption,
                  juce::Colour accent)
    {
        label.setText(caption, juce::dontSendNotification);
        label.setJustificationType(juce::Justification::centred);
        label.setFont(juce::FontOptions(9.0f, juce::Font::bold));
        label.setColour(juce::Label::textColourId, mud::ui::Colours::ivory());
        addAndMakeVisible(label);

        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 58, 14);
        slider.setColour(juce::Slider::rotarySliderFillColourId, accent);
        addAndMakeVisible(slider);
        attachment = std::make_unique<SliderAttachment>(state, id, slider);
    }

    void resized() override
    {
        auto area = getLocalBounds();
        label.setBounds(area.removeFromTop(13));
        slider.setBounds(area);
    }

    juce::Slider& getSlider() noexcept { return slider; }

private:
    juce::Label label;
    juce::Slider slider;
    std::unique_ptr<SliderAttachment> attachment;
};

class RuFTraXMuDAudioProcessorEditor::ParameterFader final : public juce::Component
{
public:
    ParameterFader(juce::AudioProcessorValueTreeState& state,
                   const juce::String& id, const juce::String& caption,
                   juce::Colour accent)
    {
        label.setText(caption, juce::dontSendNotification);
        label.setJustificationType(juce::Justification::centred);
        label.setFont(juce::FontOptions(9.0f, juce::Font::bold));
        label.setColour(juce::Label::textColourId, mud::ui::Colours::ivory());
        addAndMakeVisible(label);

        slider.setSliderStyle(juce::Slider::LinearVertical);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 64, 16);
        slider.setColour(juce::Slider::backgroundColourId,
                         mud::ui::Colours::screen());
        slider.setColour(juce::Slider::trackColourId, accent.withAlpha(0.88f));
        slider.setColour(juce::Slider::thumbColourId, mud::ui::Colours::ivory());
        slider.setTooltip("Master output level");
        addAndMakeVisible(slider);
        attachment = std::make_unique<SliderAttachment>(state, id, slider);
    }

    void resized() override
    {
        auto area = getLocalBounds();
        label.setBounds(area.removeFromTop(13));
        slider.setBounds(area);
    }

private:
    juce::Label label;
    juce::Slider slider;
    std::unique_ptr<SliderAttachment> attachment;
};

class RuFTraXMuDAudioProcessorEditor::ParameterToggle final : public juce::Component
{
public:
    ParameterToggle(juce::AudioProcessorValueTreeState& state,
                    const juce::String& id, const juce::String& caption,
                    juce::Colour accent)
    {
        button.setButtonText(caption);
        button.setColour(juce::TextButton::buttonColourId,
                         mud::ui::Colours::panelLight());
        button.setColour(juce::TextButton::buttonOnColourId,
                         accent.withAlpha(0.36f));
        button.setColour(juce::TextButton::textColourOffId,
                         mud::ui::Colours::ivory());
        button.setColour(juce::TextButton::textColourOnId, accent);
        button.setClickingTogglesState(true);
        addAndMakeVisible(button);
        attachment = std::make_unique<ButtonAttachment>(state, id, button);
    }

    void resized() override { button.setBounds(getLocalBounds()); }

private:
    juce::TextButton button;
    std::unique_ptr<ButtonAttachment> attachment;
};

class RuFTraXMuDAudioProcessorEditor::Panel : public juce::Component
{
public:
    Panel(juce::String panelTitle, juce::Colour panelAccent)
        : title(std::move(panelTitle)), accent(panelAccent)
    {
    }

    void paint(juce::Graphics& graphics) override
    {
        auto bounds = getLocalBounds().toFloat().reduced(1.5f);
        juce::ColourGradient panelGradient(mud::ui::Colours::panelLight(),
                                           bounds.getCentreX(), bounds.getY(),
                                           mud::ui::Colours::panel(),
                                           bounds.getCentreX(), bounds.getBottom(), false);
        graphics.setGradientFill(panelGradient);
        graphics.fillRoundedRectangle(bounds, 7.0f);
        graphics.setColour(juce::Colours::black.withAlpha(0.62f));
        graphics.drawRoundedRectangle(bounds.translated(0.0f, 2.0f), 7.0f, 2.0f);
        graphics.setColour(accent.withAlpha(0.42f));
        graphics.drawRoundedRectangle(bounds, 7.0f, 1.2f);
        graphics.setColour(mud::ui::Colours::ivory());
        graphics.setFont(juce::FontOptions(13.0f, juce::Font::bold));
        graphics.drawText(title, 8, 3, getWidth() - 16, 19,
                          juce::Justification::centred);
        graphics.setColour(mud::ui::Colours::brass().withAlpha(0.5f));
        graphics.drawHorizontalLine(22, 10.0f, static_cast<float>(getWidth() - 10));
    }

protected:
    juce::String title;
    juce::Colour accent;
};

class RuFTraXMuDAudioProcessorEditor::SourcePanel final
    : public Panel,
      public juce::FileDragAndDropTarget,
      private juce::Timer
{
public:
    SourcePanel(RuFTraXMuDAudioProcessor& owner, int sourceNumber,
                juce::Colour sourceAccent)
        : Panel(sourceNumber == 0 ? "SYNTH 1 - WAVETABLE"
                : sourceNumber == 1 ? "SYNTH 2 - FM / HARMONIC"
                : sourceNumber == 2 ? "SAMPLE A" : "SAMPLE B",
                sourceAccent),
          processor(owner), sourceIndex(sourceNumber),
          sampleSlot(sourceNumber >= 2 ? sourceNumber - 2 : -1)
    {
        const std::array<std::pair<const char*, const char*>, 10> common {{
            { "Tune", "TUNE" }, { "Fine", "FINE" },
            { "Level", "LEVEL" }, { "Pan", "PAN" },
            { "Attack", "ATTACK" }, { "Decay", "DECAY" },
            { "Sustain", "SUSTAIN" }, { "Release", "RELEASE" },
            { "HighPass", "HP" }, { "LowPass", "LP" }
        }};
        for (const auto& item : common)
            addKnob(mud::param::source(sourceIndex, item.first), item.second);

        if (sourceIndex < 2)
        {
            waveSelector.addItemList({ "SINE", "TRIANGLE", "SAW", "SQUARE" }, 1);
            waveSelector.setJustificationType(juce::Justification::centredLeft);
            waveSelector.setColour(juce::ComboBox::textColourId, accent);
            waveSelector.setTooltip(sourceIndex == 0
                ? "Select the Synth 1 wavetable waveform"
                : "Select the Synth 2 FM carrier waveform");
            addAndMakeVisible(waveSelector);
            waveAttachment = std::make_unique<ComboAttachment>(
                processor.parameters,
                sourceIndex == 0 ? mud::param::synth1Wave : mud::param::synth2Wave,
                waveSelector);
        }

        if (sourceIndex == 0)
        {
            addKnob(mud::param::synth1Unison, "UNISON");
            addKnob(mud::param::synth1Detune, "DETUNE");
            addKnob(mud::param::synth1Fold, "FOLD");
        }
        else if (sourceIndex == 1)
        {
            addKnob(mud::param::synth2CarrierRatio, "CARRIER");
            addKnob(mud::param::synth2ModRatio, "MOD RATIO");
            addKnob(mud::param::synth2Index, "INDEX");
            addKnob(mud::param::synth2Feedback, "FEEDBACK");
        }
        else
        {
            addKnob(mud::param::sample(sampleSlot, "GrainSize"), "GRAIN SIZE");
            addKnob(mud::param::sample(sampleSlot, "Density"), "DENSITY");
            addKnob(mud::param::sample(sampleSlot, "Scatter"), "SCATTER");
            addKnob(mud::param::sample(sampleSlot, "Stretch"), "STRETCH");
        }

        mute = std::make_unique<ParameterToggle>(processor.parameters,
            mud::param::source(sourceIndex, "Mute"), "MUTE", accent);
        solo = std::make_unique<ParameterToggle>(processor.parameters,
            mud::param::source(sourceIndex, "Solo"), "SOLO", accent);
        addAndMakeVisible(*mute);
        addAndMakeVisible(*solo);

        if (sampleSlot >= 0)
        {
            const std::array<std::pair<const char*, const char*>, 4> actions {{
                { "Reverse", "REVERSE" }, { "Loop", "LOOP" },
                { "Slice", "SLICE" }, { "Grain", "GRAIN" }
            }};
            for (const auto& action : actions)
            {
                auto toggle = std::make_unique<ParameterToggle>(processor.parameters,
                    mud::param::sample(sampleSlot, action.first), action.second, accent);
                addAndMakeVisible(*toggle);
                sampleToggles.push_back(std::move(toggle));
            }

            loadButton.setButtonText("LOAD SAMPLE");
            loadButton.setColour(juce::TextButton::buttonColourId,
                                 mud::ui::Colours::panelLight());
            loadButton.setColour(juce::TextButton::textColourOffId, accent);
            loadButton.onClick = [this] { chooseOrClearSample(); };
            addAndMakeVisible(loadButton);
        }
        startTimerHz(24);
    }

    ~SourcePanel() override { stopTimer(); }

    bool isInterestedInFileDrag(const juce::StringArray& files) override
    {
        if (sampleSlot < 0 || files.isEmpty())
            return false;
        const auto extension = juce::File(files[0]).getFileExtension().toLowerCase();
        return extension == ".wav" || extension == ".aif"
            || extension == ".aiff" || extension == ".flac";
    }

    void filesDropped(const juce::StringArray& files, int, int) override
    {
        if (sampleSlot >= 0 && ! files.isEmpty())
            loadFile(juce::File(files[0]));
    }

    void paint(juce::Graphics& graphics) override
    {
        Panel::paint(graphics);
        graphics.setColour(mud::ui::Colours::screen());
        graphics.fillRoundedRectangle(screenBounds.toFloat(), 4.0f);
        graphics.setColour(accent.withAlpha(0.48f));
        graphics.drawRoundedRectangle(screenBounds.toFloat(), 4.0f, 1.0f);

        auto graph = screenBounds.toFloat().reduced(7.0f);
        graph.removeFromRight(18.0f);
        juce::Path waveform;
        if (sampleSlot >= 0)
        {
            if (const auto sample = processor.getSample(sampleSlot))
            {
                auto noteReadout = graph.removeFromBottom(24.0f);
                graph.removeFromBottom(2.0f);
                for (std::size_t index = 0; index < sample->waveform.size(); ++index)
                {
                    const auto x = graph.getX() + graph.getWidth()
                        * static_cast<float>(index)
                        / static_cast<float>(sample->waveform.size() - 1);
                    const auto magnitude = sample->waveform[index] * graph.getHeight() * 0.42f;
                    if (index == 0)
                        waveform.startNewSubPath(x, graph.getCentreY() - magnitude);
                    else
                        waveform.lineTo(x, graph.getCentreY() - magnitude);
                }
                for (std::size_t index = sample->waveform.size(); index-- > 0;)
                {
                    const auto x = graph.getX() + graph.getWidth()
                        * static_cast<float>(index)
                        / static_cast<float>(sample->waveform.size() - 1);
                    waveform.lineTo(x, graph.getCentreY()
                        + sample->waveform[index] * graph.getHeight() * 0.42f);
                }
                waveform.closeSubPath();
                graphics.setColour(accent.withAlpha(0.26f));
                graphics.fillPath(waveform);
                graphics.setColour(accent);
                graphics.strokePath(waveform, juce::PathStrokeType(1.0f));
                graphics.setColour(accent.withAlpha(0.28f));
                graphics.drawHorizontalLine(juce::roundToInt(noteReadout.getY()),
                                            noteReadout.getX(), noteReadout.getRight());
                auto rootLine = noteReadout.removeFromTop(11.0f).toNearestInt();
                auto playedLine = noteReadout.toNearestInt();
                graphics.setFont(juce::FontOptions(7.8f, juce::Font::bold));
                graphics.setColour(accent.withAlpha(0.82f));
                graphics.drawFittedText(processor.getSampleDescription(sampleSlot),
                                        rootLine, juce::Justification::centred, 1);
                graphics.setFont(juce::FontOptions(9.0f, juce::Font::bold));
                graphics.setColour(mud::ui::Colours::ivory());
                graphics.drawFittedText(
                    processor.getSampleTriggeredNoteDescription(sampleSlot),
                    playedLine, juce::Justification::centred, 1);
            }
            else
            {
                graphics.setColour(accent.withAlpha(0.82f));
                graphics.setFont(juce::FontOptions(10.0f, juce::Font::bold));
                graphics.drawText("DROP SAMPLE HERE", graph.toNearestInt(),
                                  juce::Justification::centred);
            }
        }
        else
        {
            graph.removeFromTop(22.0f);
            const auto* shapeParameter = processor.parameters.getRawParameterValue(
                sourceIndex == 0 ? mud::param::synth1Wave : mud::param::synth2Wave);
            const auto shape = shapeParameter != nullptr
                ? static_cast<float>(juce::roundToInt(
                    shapeParameter->load(std::memory_order_relaxed))) : 0.0f;
            const auto* indexParameter = processor.parameters.getRawParameterValue(
                mud::param::synth2Index);
            const auto fmIndex = indexParameter != nullptr
                ? indexParameter->load(std::memory_order_relaxed) : 0.0f;
            constexpr int points = 180;
            for (int point = 0; point < points; ++point)
            {
                const auto phase = static_cast<float>(point) / static_cast<float>(points - 1);
                const auto harmonic = sourceIndex == 0
                    ? previewOscillator(phase, shape)
                    : previewOscillator(
                        phase + std::sin(phase * juce::MathConstants<float>::twoPi * 2.0f)
                            * fmIndex / juce::MathConstants<float>::twoPi,
                        shape);
                const auto x = graph.getX() + phase * graph.getWidth();
                const auto y = graph.getCentreY() - harmonic * graph.getHeight() * 0.37f;
                if (point == 0)
                    waveform.startNewSubPath(x, y);
                else
                    waveform.lineTo(x, y);
            }
            graphics.setColour(accent.withAlpha(0.92f));
            graphics.strokePath(waveform, juce::PathStrokeType(1.6f));
        }

        const auto meter = juce::Rectangle<float>(
            static_cast<float>(screenBounds.getRight() - 14),
            static_cast<float>(screenBounds.getY() + 6), 7.0f,
            static_cast<float>(screenBounds.getHeight() - 12));
        graphics.setColour(juce::Colour(0xff09100b));
        graphics.fillRoundedRectangle(meter, 2.0f);
        const auto level = juce::jlimit(0.0f, 1.0f,
            std::sqrt(processor.getSourceLevel(sourceIndex)));
        auto lit = meter;
        lit.removeFromTop(meter.getHeight() * (1.0f - level));
        juce::ColourGradient meterGradient(mud::ui::Colours::acid(),
                                           lit.getCentreX(), lit.getBottom(),
                                           accent, lit.getCentreX(), lit.getY(), false);
        graphics.setGradientFill(meterGradient);
        graphics.fillRoundedRectangle(lit, 2.0f);
    }

    void resized() override
    {
        auto area = getLocalBounds().reduced(7);
        area.removeFromTop(20);
        screenBounds = area.removeFromTop(72);
        if (sampleSlot >= 0)
            loadButton.setBounds(screenBounds.getRight() - 105,
                                 screenBounds.getY() + 5, 91, 18);
        else
            waveSelector.setBounds(screenBounds.getX() + 7,
                                   screenBounds.getY() + 5, 124, 18);
        area.removeFromTop(3);

        const auto knobAreaHeight = juce::jmax(80, area.getHeight() - 24);
        auto knobArea = area.removeFromTop(knobAreaHeight);
        const auto rowHeight = knobArea.getHeight() / 2;
        const auto columnWidth = knobArea.getWidth() / 7;
        for (std::size_t index = 0; index < knobs.size(); ++index)
        {
            const auto row = static_cast<int>(index / 7);
            const auto column = static_cast<int>(index % 7);
            knobs[index]->setBounds(knobArea.getX() + column * columnWidth,
                                    knobArea.getY() + row * rowHeight,
                                    columnWidth, rowHeight);
        }

        auto buttons = area.reduced(1, 1);
        const auto buttonWidth = buttons.getWidth()
            / (sampleSlot >= 0 ? 6 : 2);
        mute->setBounds(buttons.removeFromLeft(buttonWidth).reduced(2));
        solo->setBounds(buttons.removeFromLeft(buttonWidth).reduced(2));
        for (auto& toggle : sampleToggles)
            toggle->setBounds(buttons.removeFromLeft(buttonWidth).reduced(2));
    }

private:
    void addKnob(const juce::String& id, const juce::String& caption)
    {
        auto knob = std::make_unique<ParameterKnob>(processor.parameters,
                                                    id, caption, accent);
        addAndMakeVisible(*knob);
        knobs.push_back(std::move(knob));
    }

    void timerCallback() override
    {
        if (sampleSlot >= 0)
            loadButton.setButtonText(processor.getSample(sampleSlot) != nullptr
                                     ? "CLEAR SAMPLE" : "LOAD SAMPLE");
        repaint();
    }

    void chooseOrClearSample()
    {
        if (processor.getSample(sampleSlot) != nullptr)
        {
            processor.clearSample(sampleSlot);
            return;
        }
        chooser = std::make_unique<juce::FileChooser>(
            sampleSlot == 0 ? "Load Sample A" : "Load Sample B",
            juce::File(), "*.wav;*.aif;*.aiff;*.flac");
        const auto flags = juce::FileBrowserComponent::openMode
                         | juce::FileBrowserComponent::canSelectFiles;
        juce::Component::SafePointer<SourcePanel> safeThis(this);
        chooser->launchAsync(flags, [safeThis](const juce::FileChooser& selected)
        {
            if (safeThis == nullptr)
                return;
            const auto file = selected.getResult();
            if (file.existsAsFile())
                safeThis->loadFile(file);
        });
    }

    void loadFile(const juce::File& file)
    {
        juce::String error;
        if (! processor.loadSample(sampleSlot, file, error))
            juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,
                                                   "MuD Sample Load", error);
    }

    RuFTraXMuDAudioProcessor& processor;
    int sourceIndex = 0;
    int sampleSlot = -1;
    juce::Rectangle<int> screenBounds;
    std::vector<std::unique_ptr<ParameterKnob>> knobs;
    std::unique_ptr<ParameterToggle> mute;
    std::unique_ptr<ParameterToggle> solo;
    std::vector<std::unique_ptr<ParameterToggle>> sampleToggles;
    juce::TextButton loadButton;
    juce::ComboBox waveSelector;
    std::unique_ptr<ComboAttachment> waveAttachment;
    std::unique_ptr<juce::FileChooser> chooser;
};

class RuFTraXMuDAudioProcessorEditor::MorphPanel final : public Panel,
                                                         private juce::Timer
{
public:
    explicit MorphPanel(RuFTraXMuDAudioProcessor& owner)
        : Panel("MORPH CORE", mud::ui::Colours::cyan()), processor(owner)
    {
        mode.addItemList({ "VECTOR", "SPECTRAL", "GRAIN", "HARMONIC" }, 1);
        addAndMakeVisible(mode);
        modeAttachment = std::make_unique<ComboAttachment>(
            processor.parameters, mud::param::morphMode, mode);
        xParameter = processor.parameters.getParameter(mud::param::morphX);
        yParameter = processor.parameters.getParameter(mud::param::morphY);
        startTimerHz(30);
    }

    ~MorphPanel() override { stopTimer(); }

    void paint(juce::Graphics& graphics) override
    {
        Panel::paint(graphics);
        graphics.setColour(mud::ui::Colours::screen());
        graphics.fillRoundedRectangle(pad.toFloat(), 5.0f);
        graphics.setColour(mud::ui::Colours::cyan().withAlpha(0.32f));
        graphics.drawRoundedRectangle(pad.toFloat(), 5.0f, 1.2f);

        graphics.setColour(mud::ui::Colours::cyan().withAlpha(0.14f));
        for (int index = 1; index < 8; ++index)
        {
            const auto fraction = static_cast<float>(index) / 8.0f;
            graphics.drawVerticalLine(juce::roundToInt(pad.getX() + pad.getWidth() * fraction),
                                      static_cast<float>(pad.getY()),
                                      static_cast<float>(pad.getBottom()));
            graphics.drawHorizontalLine(juce::roundToInt(pad.getY() + pad.getHeight() * fraction),
                                        static_cast<float>(pad.getX()),
                                        static_cast<float>(pad.getRight()));
        }

        graphics.setFont(juce::FontOptions(9.0f, juce::Font::bold));
        graphics.setColour(mud::ui::Colours::cyan());
        graphics.drawText("SYNTH 1", pad.getX() + 5, pad.getY() + 3, 65, 14,
                          juce::Justification::left);
        graphics.setColour(mud::ui::Colours::violet());
        graphics.drawText("SYNTH 2", pad.getRight() - 70, pad.getY() + 3, 65, 14,
                          juce::Justification::right);
        graphics.setColour(mud::ui::Colours::amber());
        graphics.drawText("SAMPLE A", pad.getX() + 5, pad.getBottom() - 17, 70, 14,
                          juce::Justification::left);
        graphics.setColour(mud::ui::Colours::red());
        graphics.drawText("SAMPLE B", pad.getRight() - 75, pad.getBottom() - 17, 70, 14,
                          juce::Justification::right);

        const auto x = xParameter != nullptr ? xParameter->getValue() : 0.5f;
        const auto y = yParameter != nullptr ? yParameter->getValue() : 0.5f;
        const juce::Point<float> point(
            static_cast<float>(pad.getX()) + x * pad.getWidth(),
            static_cast<float>(pad.getY()) + y * pad.getHeight());
        juce::ColourGradient glow(mud::ui::Colours::cyan().withAlpha(0.85f),
                                  point.x, point.y,
                                  mud::ui::Colours::cyan().withAlpha(0.0f),
                                  point.x + 24.0f, point.y, true);
        graphics.setGradientFill(glow);
        graphics.fillEllipse(point.x - 24.0f, point.y - 24.0f, 48.0f, 48.0f);
        graphics.setColour(juce::Colours::white);
        graphics.fillEllipse(point.x - 4.0f, point.y - 4.0f, 8.0f, 8.0f);
        graphics.setColour(mud::ui::Colours::cyan());
        graphics.drawEllipse(point.x - 9.0f, point.y - 9.0f, 18.0f, 18.0f, 2.0f);
    }

    void resized() override
    {
        auto area = getLocalBounds().reduced(9);
        area.removeFromTop(20);
        mode.setBounds(area.removeFromTop(22).withSizeKeepingCentre(280, 22));
        area.removeFromTop(5);
        pad = area;
    }

    void mouseDown(const juce::MouseEvent& event) override
    {
        if (! pad.contains(event.getPosition()))
            return;
        if (xParameter != nullptr) xParameter->beginChangeGesture();
        if (yParameter != nullptr) yParameter->beginChangeGesture();
        setFromPoint(event.position);
    }

    void mouseDrag(const juce::MouseEvent& event) override
    {
        if (event.mouseWasDraggedSinceMouseDown())
            setFromPoint(event.position);
    }

    void mouseUp(const juce::MouseEvent&) override
    {
        if (xParameter != nullptr) xParameter->endChangeGesture();
        if (yParameter != nullptr) yParameter->endChangeGesture();
    }

private:
    void setFromPoint(juce::Point<float> point)
    {
        const auto x = juce::jlimit(0.0f, 1.0f,
            (point.x - static_cast<float>(pad.getX())) / static_cast<float>(pad.getWidth()));
        const auto y = juce::jlimit(0.0f, 1.0f,
            (point.y - static_cast<float>(pad.getY())) / static_cast<float>(pad.getHeight()));
        if (xParameter != nullptr) xParameter->setValueNotifyingHost(x);
        if (yParameter != nullptr) yParameter->setValueNotifyingHost(y);
        repaint();
    }

    void timerCallback() override { repaint(); }

    RuFTraXMuDAudioProcessor& processor;
    juce::ComboBox mode;
    std::unique_ptr<ComboAttachment> modeAttachment;
    juce::RangedAudioParameter* xParameter = nullptr;
    juce::RangedAudioParameter* yParameter = nullptr;
    juce::Rectangle<int> pad;
};

class RuFTraXMuDAudioProcessorEditor::TransformPanel final : public Panel
{
public:
    explicit TransformPanel(RuFTraXMuDAudioProcessor& owner)
        : Panel("MUTATION / TRANSFORM", mud::ui::Colours::amber())
    {
        const std::array<std::pair<const char*, const char*>, 17> controls {{
            { mud::param::macroMorph, "MACRO MORPH" },
            { mud::param::macroMotion, "MACRO MOTION" },
            { mud::param::macroDamage, "MACRO DAMAGE" },
            { mud::param::macroSpace, "MACRO SPACE" },
            { mud::param::motionRate, "MOTION RATE" },
            { mud::param::motionDepth, "MOTION DEPTH" },
            { mud::param::motionJitter, "JITTER" },
            { mud::param::density, "DENSITY" },
            { mud::param::scatter, "SCATTER" },
            { mud::param::smear, "SMEAR" },
            { mud::param::freeze, "FREEZE" },
            { mud::param::shatter, "SHATTER" },
            { mud::param::stretch, "STRETCH" },
            { mud::param::resonate, "RESONATE" },
            { mud::param::damage, "DAMAGE" },
            { mud::param::smooth, "SMOOTH" },
            { mud::param::grime, "GRIME" }
        }};
        for (const auto& control : controls)
        {
            auto knob = std::make_unique<ParameterKnob>(owner.parameters,
                control.first, control.second, mud::ui::Colours::amber());
            addAndMakeVisible(*knob);
            knobs.push_back(std::move(knob));
        }
    }

    void resized() override
    {
        auto area = getLocalBounds().reduced(6);
        area.removeFromTop(20);
        constexpr int columns = 6;
        constexpr int rows = 3;
        const auto cellWidth = area.getWidth() / columns;
        const auto cellHeight = area.getHeight() / rows;
        for (std::size_t index = 0; index < knobs.size(); ++index)
            knobs[index]->setBounds(area.getX() + static_cast<int>(index % columns) * cellWidth,
                                    area.getY() + static_cast<int>(index / columns) * cellHeight,
                                    cellWidth, cellHeight);
    }

private:
    std::vector<std::unique_ptr<ParameterKnob>> knobs;
};

class RuFTraXMuDAudioProcessorEditor::RandomizerPanel final : public Panel,
                                                              private juce::Timer
{
public:
    explicit RandomizerPanel(RuFTraXMuDAudioProcessor& owner)
        : Panel("MUTATION RANDOMIZER", mud::ui::Colours::acid()), processor(owner)
    {
        chaos = std::make_unique<ParameterKnob>(processor.parameters,
            mud::param::chaosAmount, "CHAOS AMOUNT", mud::ui::Colours::acid());
        addAndMakeVisible(*chaos);

        const std::array<std::pair<const char*, const char*>, 7> locks {{
            { mud::param::lockSources, "SOURCES" }, { mud::param::lockPitch, "PITCH" },
            { mud::param::lockRhythm, "RHYTHM" }, { mud::param::lockFilter, "FILTER" },
            { mud::param::lockMod, "MOD" }, { mud::param::lockFx, "FX" },
            { mud::param::lockMix, "MIX" }
        }};
        for (const auto& item : locks)
        {
            auto toggle = std::make_unique<ParameterToggle>(processor.parameters,
                item.first, item.second, mud::ui::Colours::acid());
            addAndMakeVisible(*toggle);
            lockButtons.push_back(std::move(toggle));
        }

        factoryPatches.addItemList(
            RuFTraXMuDAudioProcessor::getFactoryPatchNames(), 1);
        factoryPatches.setTextWhenNothingSelected("SIGNATURE PATCHES");
        if (const auto current = processor.getCurrentFactoryPatch(); current >= 0)
            factoryPatches.setSelectedId(current + 1, juce::dontSendNotification);
        factoryPatches.onChange = [this]
        {
            const auto patch = factoryPatches.getSelectedItemIndex();
            if (patch >= 0)
                processor.applyFactoryPatch(patch);
        };
        addAndMakeVisible(factoryPatches);

        configureAction(resetPatchButton, "RESET PATCH", mud::ui::Colours::acid(), [this]
        {
            auto patch = factoryPatches.getSelectedItemIndex();
            if (patch < 0)
                patch = juce::jmax(0, processor.getCurrentFactoryPatch());
            processor.applyFactoryPatch(patch);
            factoryPatches.setSelectedId(patch + 1, juce::dontSendNotification);
        });

        randomButton.onClick = [this]
        {
            randomButton.roll();
            processor.randomize(currentMode);
        };
        addAndMakeVisible(randomButton);

        configureAction(safeButton, "SAFE", mud::ui::Colours::cyan(), [this]
        {
            currentMode = RuFTraXMuDAudioProcessor::MutationMode::safe;
            processor.randomize(currentMode);
        });
        configureAction(wildButton, "WILD", mud::ui::Colours::amber(), [this]
        {
            currentMode = RuFTraXMuDAudioProcessor::MutationMode::wild;
            processor.randomize(currentMode);
        });
        configureAction(captureButton, "CAPTURE", mud::ui::Colours::acid(), [this]
        {
            processor.captureMutation();
        });
        configureAction(recallButton, "RECALL", mud::ui::Colours::violet(), [this]
        {
            processor.recallCapturedMutation();
        });
        configureAction(undoButton, "UNDO", mud::ui::Colours::ivory(), [this]
        {
            processor.undo();
        });
        configureAction(redoButton, "REDO", mud::ui::Colours::ivory(), [this]
        {
            processor.redo();
        });

        seed.setJustificationType(juce::Justification::centred);
        seed.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        seed.setColour(juce::Label::backgroundColourId, mud::ui::Colours::screen());
        seed.setColour(juce::Label::textColourId, mud::ui::Colours::acid());
        seed.setColour(juce::Label::outlineColourId,
                       mud::ui::Colours::brass().withAlpha(0.5f));
        addAndMakeVisible(seed);
        startTimerHz(10);
    }

    ~RandomizerPanel() override { stopTimer(); }

    void resized() override
    {
        auto area = getLocalBounds().reduced(8);
        area.removeFromTop(21);
        auto lockArea = area.removeFromLeft(82);
        const auto lockHeight = lockArea.getHeight() / 7;
        for (auto& button : lockButtons)
            button->setBounds(lockArea.removeFromTop(lockHeight).reduced(2));

        auto right = area.removeFromRight(106);
        chaos->setBounds(right.removeFromTop(105));
        seed.setBounds(right.removeFromTop(22).reduced(2, 1));
        undoButton.setBounds(right.removeFromTop(24).removeFromLeft(50).reduced(2));
        redoButton.setBounds(right.removeFromTop(24).removeFromLeft(50).reduced(2));

        auto centre = area.reduced(6);
        auto patchRow = centre.removeFromTop(27);
        resetPatchButton.setBounds(patchRow.removeFromRight(92).reduced(2));
        factoryPatches.setBounds(patchRow.reduced(2));
        centre.removeFromTop(3);
        randomButton.setBounds(centre.removeFromTop(
            juce::jmax(28, centre.getHeight() - 58)).reduced(8));
        auto firstRow = centre.removeFromTop(27);
        safeButton.setBounds(firstRow.removeFromLeft(firstRow.getWidth() / 2).reduced(2));
        wildButton.setBounds(firstRow.reduced(2));
        auto secondRow = centre;
        captureButton.setBounds(secondRow.removeFromLeft(secondRow.getWidth() / 2).reduced(2));
        recallButton.setBounds(secondRow.reduced(2));
    }

private:
    template <typename Callback>
    void configureAction(juce::TextButton& button, const juce::String& text,
                         juce::Colour colour, Callback callback)
    {
        button.setButtonText(text);
        button.setColour(juce::TextButton::buttonColourId,
                         mud::ui::Colours::panelLight());
        button.setColour(juce::TextButton::textColourOffId, colour);
        button.onClick = callback;
        addAndMakeVisible(button);
    }

    void timerCallback() override
    {
        const auto value = processor.parameters.getRawParameterValue(mud::param::randomSeed);
        seed.setText("SEED " + juce::String(value != nullptr
            ? juce::roundToInt(value->load(std::memory_order_relaxed)) : 0),
            juce::dontSendNotification);
        recallButton.setEnabled(processor.canRecallMutation());

        const auto patch = processor.getCurrentFactoryPatch();
        const auto selectedId = patch >= 0 ? patch + 1 : 0;
        if (factoryPatches.getSelectedId() != selectedId)
            factoryPatches.setSelectedId(selectedId, juce::dontSendNotification);
    }

    RuFTraXMuDAudioProcessor& processor;
    RuFTraXMuDAudioProcessor::MutationMode currentMode =
        RuFTraXMuDAudioProcessor::MutationMode::safe;
    std::unique_ptr<ParameterKnob> chaos;
    std::vector<std::unique_ptr<ParameterToggle>> lockButtons;
    DiceButton randomButton;
    juce::ComboBox factoryPatches;
    juce::TextButton safeButton, wildButton, captureButton, recallButton,
                     undoButton, redoButton, resetPatchButton;
    juce::Label seed;
};

class RuFTraXMuDAudioProcessorEditor::SequencerPanel final : public Panel,
                                                             private juce::Timer
{
public:
    explicit SequencerPanel(RuFTraXMuDAudioProcessor& owner)
        : Panel("16-STEP MUTATION SEQUENCER", mud::ui::Colours::cyan()),
          processor(owner)
    {
        enabled = std::make_unique<ParameterToggle>(processor.parameters,
            mud::param::sequenceEnabled, "RUN", mud::ui::Colours::cyan());
        addAndMakeVisible(*enabled);

        rate.addItemList({ "1/1", "1/2", "1/4", "1/8", "1/16", "1/32" }, 1);
        target.addItemList({ "MORPH X", "MORPH Y", "AXIS SPLIT", "JITTER" }, 1);
        addAndMakeVisible(rate);
        addAndMakeVisible(target);
        rateAttachment = std::make_unique<ComboAttachment>(processor.parameters,
            mud::param::sequenceRate, rate);
        targetAttachment = std::make_unique<ComboAttachment>(processor.parameters,
            mud::param::sequenceTarget, target);

        depth = std::make_unique<ParameterKnob>(processor.parameters,
            mud::param::sequenceDepth, "DEPTH", mud::ui::Colours::cyan());
        addAndMakeVisible(*depth);

        for (int index = 0; index < 16; ++index)
        {
            auto slider = std::make_unique<juce::Slider>();
            slider->setSliderStyle(juce::Slider::LinearVertical);
            slider->setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
            slider->setColour(juce::Slider::trackColourId,
                              mud::ui::Colours::cyan().withAlpha(0.72f));
            slider->setColour(juce::Slider::thumbColourId, mud::ui::Colours::ivory());
            addAndMakeVisible(*slider);
            attachments.push_back(std::make_unique<SliderAttachment>(
                processor.parameters, mud::param::step(index), *slider));
            steps.push_back(std::move(slider));
        }
        startTimerHz(20);
    }

    ~SequencerPanel() override { stopTimer(); }

    void paint(juce::Graphics& graphics) override
    {
        Panel::paint(graphics);
        const auto active = processor.getCurrentSequenceStep();
        graphics.setFont(juce::FontOptions(8.0f, juce::Font::bold));
        for (std::size_t index = 0; index < steps.size(); ++index)
        {
            const auto bounds = steps[index]->getBounds();
            if (static_cast<int>(index) == active)
            {
                graphics.setColour(mud::ui::Colours::cyan().withAlpha(0.16f));
                graphics.fillRoundedRectangle(bounds.toFloat().expanded(2.0f), 3.0f);
            }
            graphics.setColour(static_cast<int>(index) == active
                ? mud::ui::Colours::cyan() : mud::ui::Colours::brass());
            graphics.drawText(juce::String(static_cast<int>(index) + 1),
                              bounds.getX(), bounds.getBottom() - 9,
                              bounds.getWidth(), 9, juce::Justification::centred);
        }
    }

    void resized() override
    {
        auto area = getLocalBounds().reduced(7);
        area.removeFromTop(21);
        auto controlArea = area.removeFromLeft(126);
        enabled->setBounds(controlArea.removeFromTop(24).reduced(2));
        rate.setBounds(controlArea.removeFromTop(24).reduced(2));
        target.setBounds(controlArea.removeFromTop(24).reduced(2));
        depth->setBounds(controlArea.reduced(4));
        const auto stepWidth = area.getWidth() / 16;
        for (std::size_t index = 0; index < steps.size(); ++index)
            steps[index]->setBounds(area.getX() + static_cast<int>(index) * stepWidth,
                                    area.getY(), stepWidth, area.getHeight());
    }

private:
    void timerCallback() override { repaint(); }

    RuFTraXMuDAudioProcessor& processor;
    std::unique_ptr<ParameterToggle> enabled;
    juce::ComboBox rate, target;
    std::unique_ptr<ComboAttachment> rateAttachment, targetAttachment;
    std::unique_ptr<ParameterKnob> depth;
    std::vector<std::unique_ptr<juce::Slider>> steps;
    std::vector<std::unique_ptr<SliderAttachment>> attachments;
};

class RuFTraXMuDAudioProcessorEditor::EffectsPanel final : public Panel,
                                                           private juce::Timer
{
public:
    explicit EffectsPanel(RuFTraXMuDAudioProcessor& owner)
        : Panel("EFFECTS / MASTER", mud::ui::Colours::violet()), processor(owner)
    {
        const std::array<std::pair<const char*, const char*>, 11> controls {{
            { mud::param::chorusRate, "CH RATE" },
            { mud::param::chorusDepth, "CH DEPTH" },
            { mud::param::chorusMix, "CH MIX" },
            { mud::param::delayTime, "DELAY TIME" },
            { mud::param::delayFeedback, "FEEDBACK" },
            { mud::param::delayMix, "DELAY MIX" },
            { mud::param::reverbSize, "REV SIZE" },
            { mud::param::reverbDamping, "DAMP" },
            { mud::param::reverbMix, "REV MIX" },
            { mud::param::spectralFreeze, "SP FREEZE" },
            { mud::param::convolutionMix, "CHAMBER" }
        }};
        for (const auto& control : controls)
        {
            auto knob = std::make_unique<ParameterKnob>(processor.parameters,
                control.first, control.second, mud::ui::Colours::violet());
            addAndMakeVisible(*knob);
            knobs.push_back(std::move(knob));
        }

        delayType.addItemList({ "DIGITAL", "PING PONG", "TAPE" }, 1);
        reverbType.addItemList({ "ROOM", "HALL", "PLATE", "VOID" }, 1);
        addAndMakeVisible(delayType);
        addAndMakeVisible(reverbType);
        delayAttachment = std::make_unique<ComboAttachment>(processor.parameters,
            mud::param::delayType, delayType);
        reverbAttachment = std::make_unique<ComboAttachment>(processor.parameters,
            mud::param::reverbType, reverbType);

        limiter = std::make_unique<ParameterToggle>(processor.parameters,
            mud::param::limiterEnabled, "LIMITER", mud::ui::Colours::acid());
        bypass = std::make_unique<ParameterToggle>(processor.parameters,
            mud::param::bypassAll, "BYPASS FX", mud::ui::Colours::red());
        masterFader = std::make_unique<ParameterFader>(processor.parameters,
            mud::param::masterGain, "MASTER", mud::ui::Colours::violet());
        phaseReverse = std::make_unique<ParameterToggle>(processor.parameters,
            mud::param::phaseReverse, "PHASE REV", mud::ui::Colours::amber());
        tapeWobble = std::make_unique<ParameterToggle>(processor.parameters,
            mud::param::tapeWobble, "TAPE WOBBLE", mud::ui::Colours::violet());
        addAndMakeVisible(*limiter);
        addAndMakeVisible(*bypass);
        addAndMakeVisible(*masterFader);
        addAndMakeVisible(*phaseReverse);
        addAndMakeVisible(*tapeWobble);
        startTimerHz(30);
    }

    ~EffectsPanel() override { stopTimer(); }

    void paint(juce::Graphics& graphics) override
    {
        Panel::paint(graphics);

        const std::array<juce::String, 5> effectNames {
            "CHORUS", "DELAY", "REVERB", "FREEZE", "CHAMBER"
        };
        const std::array<juce::Colour, 5> effectColours {
            mud::ui::Colours::cyan(), mud::ui::Colours::amber(),
            mud::ui::Colours::violet(), mud::ui::Colours::acid(),
            mud::ui::Colours::brass()
        };
        for (std::size_t index = 0; index < effectGroupBounds.size(); ++index)
        {
            const auto group = effectGroupBounds[index];
            if (group.isEmpty())
                continue;

            graphics.setColour(mud::ui::Colours::screen().withAlpha(0.34f));
            graphics.fillRoundedRectangle(group, 4.0f);
            graphics.setColour(effectColours[index].withAlpha(0.42f));
            graphics.drawRoundedRectangle(group, 4.0f, 1.0f);
            graphics.drawHorizontalLine(juce::roundToInt(group.getY() + 20.0f),
                                        group.getX() + 4.0f,
                                        group.getRight() - 4.0f);

            auto titleArea = group.toNearestInt();
            titleArea.setHeight(19);
            titleArea.reduce(5, 1);
            titleArea.removeFromRight(15);
            graphics.setColour(mud::ui::Colours::ivory());
            graphics.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            graphics.drawFittedText(effectNames[index], titleArea,
                                    juce::Justification::centredLeft, 1, 0.55f);

            const auto level = juce::jlimit(0.0f, 1.0f,
                effectActivityLevels[index]);
            const auto led = juce::Rectangle<float>(group.getRight() - 13.0f,
                                                    group.getY() + 6.0f,
                                                    7.0f, 7.0f);
            graphics.setColour(juce::Colours::black.withAlpha(0.76f));
            graphics.fillEllipse(led.expanded(1.5f));
            if (level > 0.001f)
            {
                graphics.setColour(effectColours[index].withAlpha(0.16f + level * 0.28f));
                graphics.fillEllipse(led.expanded(3.0f * level));
                graphics.setColour(effectColours[index].brighter(level * 0.35f)
                    .withAlpha(0.48f + level * 0.52f));
            }
            else
            {
                graphics.setColour(juce::Colour(0xff172019));
            }
            graphics.fillEllipse(led);
        }

        for (int channel = 0; channel < 2; ++channel)
        {
            auto bar = meterBounds.reduced(5.0f);
            bar.setX(bar.getX() + channel * bar.getWidth() * 0.52f);
            bar.setWidth(bar.getWidth() * 0.38f);
            graphics.setColour(mud::ui::Colours::screen());
            graphics.fillRoundedRectangle(bar, 3.0f);
            const auto level = juce::jlimit(0.0f, 1.0f,
                std::sqrt(processor.getOutputLevel(channel)));
            auto lit = bar;
            lit.removeFromTop(bar.getHeight() * (1.0f - level));
            juce::ColourGradient gradient(mud::ui::Colours::acid(),
                                          lit.getCentreX(), lit.getBottom(),
                                          level > 0.8f ? mud::ui::Colours::red()
                                                       : mud::ui::Colours::amber(),
                                          lit.getCentreX(), lit.getY(), false);
            graphics.setGradientFill(gradient);
            graphics.fillRoundedRectangle(lit, 3.0f);
        }
    }

    void resized() override
    {
        auto area = getLocalBounds().reduced(7);
        area.removeFromTop(21);
        meterBounds = area.removeFromRight(48).toFloat();
        auto masterArea = area.removeFromRight(98).reduced(2);
        auto masterButtons = masterArea.removeFromBottom(92);
        phaseReverse->setBounds(masterButtons.removeFromTop(22).reduced(1));
        tapeWobble->setBounds(masterButtons.removeFromTop(22).reduced(1));
        limiter->setBounds(masterButtons.removeFromTop(22).reduced(1));
        bypass->setBounds(masterButtons.removeFromTop(22).reduced(1));
        masterFader->setBounds(masterArea.reduced(3));

        constexpr int gap = 3;
        constexpr std::array<int, 5> weights { 3, 3, 3, 1, 1 };
        constexpr std::array<int, 5> knobStarts { 0, 3, 6, 9, 10 };
        constexpr std::array<int, 5> knobCounts { 3, 3, 3, 1, 1 };
        constexpr int totalWeight = 11;
        auto groups = area;
        const auto availableWidth = juce::jmax(0, groups.getWidth() - gap * 4);

        for (int groupIndex = 0; groupIndex < 5; ++groupIndex)
        {
            const auto groupWidth = groupIndex == 4
                ? groups.getWidth()
                : juce::roundToInt(static_cast<float>(availableWidth)
                    * static_cast<float>(weights[static_cast<std::size_t>(groupIndex)])
                    / static_cast<float>(totalWeight));
            auto group = groups.removeFromLeft(groupWidth);
            effectGroupBounds[static_cast<std::size_t>(groupIndex)] = group.toFloat();
            if (groupIndex < 4)
                groups.removeFromLeft(juce::jmin(gap, groups.getWidth()));

            auto content = group.reduced(4);
            content.removeFromTop(20);
            auto selectorRow = content.removeFromTop(24);
            if (groupIndex == 1)
                delayType.setBounds(selectorRow.reduced(1, 2));
            else if (groupIndex == 2)
                reverbType.setBounds(selectorRow.reduced(1, 2));
            content.removeFromTop(1);

            auto knobRow = content;
            const auto count = knobCounts[static_cast<std::size_t>(groupIndex)];
            const auto start = knobStarts[static_cast<std::size_t>(groupIndex)];
            for (int localIndex = 0; localIndex < count; ++localIndex)
            {
                const auto cellWidth = localIndex == count - 1
                    ? knobRow.getWidth() : knobRow.getWidth() / (count - localIndex);
                knobs[static_cast<std::size_t>(start + localIndex)]->setBounds(
                    knobRow.removeFromLeft(cellWidth).reduced(1, 0));
            }
        }
    }

private:
    void timerCallback() override
    {
        for (int index = 0; index < 5; ++index)
        {
            const auto measured = std::sqrt(juce::jlimit(0.0f, 1.0f,
                processor.getEffectActivity(index)));
            auto& displayed = effectActivityLevels[static_cast<std::size_t>(index)];
            displayed = juce::jmax(measured, displayed * 0.80f);
            if (displayed < 0.002f)
                displayed = 0.0f;
        }
        repaint();
    }

    RuFTraXMuDAudioProcessor& processor;
    std::vector<std::unique_ptr<ParameterKnob>> knobs;
    std::unique_ptr<ParameterFader> masterFader;
    juce::ComboBox delayType, reverbType;
    std::unique_ptr<ComboAttachment> delayAttachment, reverbAttachment;
    std::unique_ptr<ParameterToggle> limiter, bypass, phaseReverse, tapeWobble;
    std::array<juce::Rectangle<float>, 5> effectGroupBounds;
    std::array<float, 5> effectActivityLevels {};
    juce::Rectangle<float> meterBounds;
};

RuFTraXMuDAudioProcessorEditor::RuFTraXMuDAudioProcessorEditor(
    RuFTraXMuDAudioProcessor& owner)
    : AudioProcessorEditor(&owner), processor(owner)
{
    setLookAndFeel(&lookAndFeel);
    setOpaque(true);

    const std::array<juce::Colour, 4> sourceColours {
        mud::ui::Colours::cyan(), mud::ui::Colours::violet(),
        mud::ui::Colours::amber(), mud::ui::Colours::red()
    };
    for (int index = 0; index < 4; ++index)
    {
        sources[static_cast<std::size_t>(index)] =
            std::make_unique<SourcePanel>(processor, index,
                                         sourceColours[static_cast<std::size_t>(index)]);
        addAndMakeVisible(*sources[static_cast<std::size_t>(index)]);
    }

    transforms = std::make_unique<TransformPanel>(processor);
    morph = std::make_unique<MorphPanel>(processor);
    randomizer = std::make_unique<RandomizerPanel>(processor);
    sequencer = std::make_unique<SequencerPanel>(processor);
    effects = std::make_unique<EffectsPanel>(processor);
    addAndMakeVisible(*transforms);
    addAndMakeVisible(*morph);
    addAndMakeVisible(*randomizer);
    addAndMakeVisible(*sequencer);
    addAndMakeVisible(*effects);

    // JUCE's setResizeLimits() may synchronously call resized(). Configure
    // resizing only after every child panel exists.
    setResizable(true, true);
    setResizeLimits(1180, 680, 2600, 1500);
    if (auto* constrainer = getConstrainer())
        constrainer->setFixedAspectRatio(1680.0 / 940.0);

    setSize(1680, 940);
    startTimerHz(20);
}

RuFTraXMuDAudioProcessorEditor::~RuFTraXMuDAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel(nullptr);
}

void RuFTraXMuDAudioProcessorEditor::paint(juce::Graphics& graphics)
{
    graphics.fillAll(mud::ui::Colours::background());
    juce::ColourGradient headerGradient(juce::Colour(0xff22221e),
                                        0.0f, static_cast<float>(headerBounds.getY()),
                                        juce::Colour(0xff0c0f0e),
                                        0.0f, static_cast<float>(headerBounds.getBottom()), false);
    graphics.setGradientFill(headerGradient);
    graphics.fillRect(headerBounds);
    graphics.setColour(mud::ui::Colours::brass().withAlpha(0.55f));
    graphics.drawHorizontalLine(headerBounds.getBottom() - 1,
                                16.0f, static_cast<float>(getWidth() - 16));

    graphics.setColour(mud::ui::Colours::ivory());
    graphics.setFont(juce::FontOptions(35.0f, juce::Font::bold));
    graphics.drawText("RuFTraX MuD", 24, 8, 300, 42,
                      juce::Justification::centredLeft);
    graphics.setColour(mud::ui::Colours::brass());
    graphics.setFont(juce::FontOptions(12.0f, juce::Font::bold));
    graphics.drawText("QUAD-SOURCE MUTATION INSTRUMENT", 325, 16, 300, 25,
                      juce::Justification::centredLeft);

    const auto midiText = processor.getMidiDisplayText();
    graphics.setColour(mud::ui::Colours::acid());
    graphics.fillEllipse(static_cast<float>(getWidth() - 284), 22.0f, 9.0f, 9.0f);
    graphics.setFont(juce::FontOptions(12.0f, juce::Font::bold));
    graphics.drawText("MIDI ACTIVITY", getWidth() - 420, 13, 128, 28,
                      juce::Justification::centredRight);
    graphics.setColour(mud::ui::Colours::cyan());
    graphics.drawText(midiText, getWidth() - 265, 13, 240, 28,
                      juce::Justification::centredRight);

    graphics.setColour(mud::ui::Colours::brass().withAlpha(0.22f));
    for (int x = 25; x < getWidth(); x += 137)
        graphics.drawLine(static_cast<float>(x), 3.0f,
                          static_cast<float>(x + 27), 3.0f, 1.0f);
}

void RuFTraXMuDAudioProcessorEditor::resized()
{
    auto area = getLocalBounds();
    headerBounds = area.removeFromTop(58);
    area.reduce(6, 5);

    auto sourceRow = area.removeFromTop(juce::roundToInt(area.getHeight() * 0.32f));
    const auto sourceWidth = sourceRow.getWidth() / 4;
    for (int index = 0; index < 4; ++index)
    {
        const auto sourceBounds = sourceRow.removeFromLeft(
            index == 3 ? sourceRow.getWidth() : sourceWidth).reduced(3);
        if (auto* source = sources[static_cast<std::size_t>(index)].get())
            source->setBounds(sourceBounds);
    }

    auto mutationRow = area.removeFromTop(juce::roundToInt(area.getHeight() * 0.56f));
    const auto transformWidth = juce::roundToInt(mutationRow.getWidth() * 0.30f);
    const auto morphWidth = juce::roundToInt(mutationRow.getWidth() * 0.37f);
    const auto transformBounds = mutationRow.removeFromLeft(transformWidth).reduced(3);
    const auto morphBounds = mutationRow.removeFromLeft(morphWidth).reduced(3);
    const auto randomizerBounds = mutationRow.reduced(3);
    if (transforms != nullptr)
        transforms->setBounds(transformBounds);
    if (morph != nullptr)
        morph->setBounds(morphBounds);
    if (randomizer != nullptr)
        randomizer->setBounds(randomizerBounds);

    const auto sequencerWidth = juce::roundToInt(area.getWidth() * 0.53f);
    const auto sequencerBounds = area.removeFromLeft(sequencerWidth).reduced(3);
    const auto effectsBounds = area.reduced(3);
    if (sequencer != nullptr)
        sequencer->setBounds(sequencerBounds);
    if (effects != nullptr)
        effects->setBounds(effectsBounds);
}

void RuFTraXMuDAudioProcessorEditor::timerCallback()
{
    repaint(headerBounds);
}
