#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "UI/MuDLookAndFeel.h"
#include <memory>
#include <vector>

class RuFTraXMuDAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                             private juce::Timer
{
public:
    explicit RuFTraXMuDAudioProcessorEditor(RuFTraXMuDAudioProcessor&);
    ~RuFTraXMuDAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    class ParameterKnob;
    class ParameterFader;
    class ParameterToggle;
    class Panel;
    class SourcePanel;
    class MorphPanel;
    class TransformPanel;
    class RandomizerPanel;
    class SequencerPanel;
    class EffectsPanel;
    class KeyPanel;

    void timerCallback() override;

    // Named audioProcessor (not processor) - juce::AudioProcessorEditor already declares its
    // own protected `processor` member, and this used to silently shadow it.
    RuFTraXMuDAudioProcessor& audioProcessor;
    mud::ui::MuDLookAndFeel lookAndFeel;
    std::array<std::unique_ptr<SourcePanel>, 4> sources;
    std::unique_ptr<TransformPanel> transforms;
    std::unique_ptr<MorphPanel> morph;
    std::unique_ptr<RandomizerPanel> randomizer;
    std::unique_ptr<SequencerPanel> sequencer;
    std::unique_ptr<EffectsPanel> effects;
    std::unique_ptr<KeyPanel> keyPanel;
    juce::Rectangle<int> headerBounds;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RuFTraXMuDAudioProcessorEditor)
};
