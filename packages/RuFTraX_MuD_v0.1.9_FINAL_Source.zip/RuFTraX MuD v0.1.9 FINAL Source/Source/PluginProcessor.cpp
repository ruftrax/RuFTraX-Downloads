#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "DSP/MuDSound.h"
#include "DSP/ParameterIDs.h"
#include <algorithm>
#include <cmath>
#include <random>
#include <vector>

namespace
{
using Parameter = std::unique_ptr<juce::RangedAudioParameter>;

Parameter makeFloat(const juce::String& id, const juce::String& name,
                    float minimum, float maximum, float defaultValue,
                    float interval = 0.001f, float skew = 1.0f,
                    const juce::String& label = {})
{
    juce::NormalisableRange<float> range(minimum, maximum, interval, skew);
    return std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID(id, 1), name, range, defaultValue,
        juce::AudioParameterFloatAttributes().withLabel(label));
}

Parameter makeBool(const juce::String& id, const juce::String& name,
                   bool defaultValue)
{
    return std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID(id, 1), name, defaultValue);
}

Parameter makeInt(const juce::String& id, const juce::String& name,
                  int minimum, int maximum, int defaultValue)
{
    return std::make_unique<juce::AudioParameterInt>(
        juce::ParameterID(id, 1), name, minimum, maximum, defaultValue);
}

Parameter makeChoice(const juce::String& id, const juce::String& name,
                     juce::StringArray choices, int defaultIndex)
{
    return std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID(id, 1), name, std::move(choices), defaultIndex);
}

float raw(juce::AudioProcessorValueTreeState& state, const juce::String& id)
{
    if (auto* value = state.getRawParameterValue(id))
        return value->load(std::memory_order_relaxed);
    return 0.0f;
}

juce::String noteName(int note)
{
    return juce::MidiMessage::getMidiNoteName(note, true, true, 3);
}

juce::String pitchName(float midiNote)
{
    const auto nearestNote = juce::roundToInt(midiNote);
    const auto cents = (midiNote - static_cast<float>(nearestNote)) * 100.0f;
    auto result = noteName(juce::jlimit(0, 127, nearestNote));
    if (std::abs(cents) >= 0.5f)
        result += juce::String(cents >= 0.0f ? " +" : " ")
            + juce::String(cents, 1) + " ct";
    return result;
}
} // namespace

RuFTraXMuDAudioProcessor::RuFTraXMuDAudioProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, &undoManager, "MuDState", createParameterLayout()),
      effects(parameters)
{
    for (auto& level : sourceLevels)
        level.store(0.0f);
    for (auto& level : outputLevels)
        level.store(0.0f);
    for (auto& held : heldNotes)
        held.store(false);

    cacheParameters();
    for (int voice = 0; voice < 16; ++voice)
        synthesiser.addVoice(new mud::MuDVoice(voiceParameters,
                                               sampleStores[0], sampleStores[1],
                                               sourceMeterBus));
    synthesiser.addSound(new mud::MuDSound());

    applyFactoryPatch(0);
    undoManager.clearUndoHistory();
}

juce::StringArray RuFTraXMuDAudioProcessor::getFactoryPatchNames()
{
    return {
        "RuFTraX Velvet E-Piano",
        "RuFTraX Crown Brass",
        "RuFTraX Deep Current Bass",
        "RuFTraX Glasswood Guitar",
        // Glitch/Chop/Reverse collection - 80s/70s-inspired broken machinery.
        "RuFTraX Tape Chop Stutter",
        "RuFTraX Reverse Riser Bloom",
        "RuFTraX Broken Cassette Wow",
        "RuFTraX Backwards Gate Snap",
        "RuFTraX Cassette Chew Artifact",
        "RuFTraX 8-Bit Circuit Fault",
        "RuFTraX Digital Stutter Loop",
        "RuFTraX Chopped Arcade Fault",
        "RuFTraX Glitch Hop Snare",
        "RuFTraX Static Burst Glitch",
        "RuFTraX Reverse Cymbal Swell",
        "RuFTraX Backmasked Voice Ghost",
        "RuFTraX Reverse Sweep Pad",
        "RuFTraX Freeze Frame Fault",
        "RuFTraX Reverse Bell Swell",
        "RuFTraX Vinyl Dust Glitch",
        "RuFTraX Analog Drift Failure",
        "RuFTraX Broken Synth Stab",
        "RuFTraX Chopped Brass Hit",
        "RuFTraX Retro Chop Bass"
    };
}

void RuFTraXMuDAudioProcessor::applyFactoryPatch(int patchIndex)
{
    patchIndex = juce::jlimit(0, getFactoryPatchNames().size() - 1, patchIndex);
    const auto names = getFactoryPatchNames();
    undoManager.beginNewTransaction("Load " + names[patchIndex]);

    auto setActual = [this](const juce::String& id, float value)
    {
        if (auto* parameter = parameters.getParameter(id))
            parameter->setValueNotifyingHost(parameter->convertTo0to1(value));
    };

    // Writes all 16 mutation-sequencer steps in one call; used by the chop-forward
    // glitch patches below to carve a deliberate rhythmic pattern instead of the
    // gentle default (every 4th step at 0.75, rest at 0).
    auto setSteps = [&setActual](std::initializer_list<float> values)
    {
        int index = 0;
        for (const auto value : values)
            setActual(mud::param::step(index++), value);
    };

    auto setSource = [&setActual](int source, float level, float tune,
                                  float attack, float decay, float sustain,
                                  float release, float highPass, float lowPass,
                                  bool muted)
    {
        setActual(mud::param::source(source, "Level"), level);
        setActual(mud::param::source(source, "Pan"), 0.0f);
        setActual(mud::param::source(source, "Tune"), tune);
        setActual(mud::param::source(source, "Fine"), 0.0f);
        setActual(mud::param::source(source, "Attack"), attack);
        setActual(mud::param::source(source, "Decay"), decay);
        setActual(mud::param::source(source, "Sustain"), sustain);
        setActual(mud::param::source(source, "Release"), release);
        setActual(mud::param::source(source, "HighPass"), highPass);
        setActual(mud::param::source(source, "LowPass"), lowPass);
        setActual(mud::param::source(source, "Mute"), muted ? 1.0f : 0.0f);
        setActual(mud::param::source(source, "Solo"), 0.0f);
    };

    // Keep loaded samples available, but begin every signature patch with its
    // pristine two-synth voice. The sample slots can be unmuted and morphed in.
    setSource(2, -60.0f, 0.0f, 0.005f, 0.50f, 0.50f, 0.50f,
              20.0f, 20000.0f, true);
    setSource(3, -60.0f, 0.0f, 0.005f, 0.50f, 0.50f, 0.50f,
              20.0f, 20000.0f, true);

    for (int sample = 0; sample < 2; ++sample)
    {
        setActual(mud::param::sample(sample, "Reverse"), 0.0f);
        setActual(mud::param::sample(sample, "Loop"), 1.0f);
        setActual(mud::param::sample(sample, "Slice"), 0.0f);
        setActual(mud::param::sample(sample, "Grain"), 0.0f);
        setActual(mud::param::sample(sample, "GrainSize"), 0.35f);
        setActual(mud::param::sample(sample, "Density"), 0.65f);
        setActual(mud::param::sample(sample, "Scatter"), 0.15f);
        setActual(mud::param::sample(sample, "Stretch"), 1.0f);
    }

    setActual(mud::param::morphY, 0.0f);
    setActual(mud::param::morphMode, 0.0f);
    setActual(mud::param::motionRate, 0.22f);
    setActual(mud::param::motionDepth, 0.0f);
    setActual(mud::param::motionJitter, 0.0f);

    const std::array<const char*, 9> neutralMutationIds {
        mud::param::density, mud::param::scatter, mud::param::smear,
        mud::param::freeze, mud::param::shatter, mud::param::resonate,
        mud::param::damage, mud::param::smooth, mud::param::grime
    };
    for (const auto* id : neutralMutationIds)
        setActual(id, 0.0f);
    setActual(mud::param::stretch, 0.25f);
    setActual(mud::param::macroMorph, 0.5f);
    setActual(mud::param::macroMotion, 0.0f);
    setActual(mud::param::macroDamage, 0.0f);
    setActual(mud::param::macroSpace, 0.0f);

    setActual(mud::param::sequenceEnabled, 0.0f);
    setActual(mud::param::sequenceRate, 4.0f);
    setActual(mud::param::sequenceDepth, 0.5f);
    setActual(mud::param::sequenceTarget, 0.0f);
    for (int step = 0; step < 16; ++step)
        setActual(mud::param::step(step), 0.0f);

    // Factory signatures are deliberately dry and noise-free. Effects retain
    // useful starting times/types and can be introduced from a clean zero mix.
    setActual(mud::param::chorusRate, 0.35f);
    setActual(mud::param::chorusDepth, 0.25f);
    setActual(mud::param::chorusMix, 0.0f);
    setActual(mud::param::delayType, 0.0f);
    setActual(mud::param::delayTime, 0.375f);
    setActual(mud::param::delayFeedback, 0.25f);
    setActual(mud::param::delayMix, 0.0f);
    setActual(mud::param::reverbType, 1.0f);
    setActual(mud::param::reverbSize, 0.55f);
    setActual(mud::param::reverbDamping, 0.42f);
    setActual(mud::param::reverbMix, 0.0f);
    setActual(mud::param::spectralFreeze, 0.0f);
    setActual(mud::param::convolutionMix, 0.0f);
    setActual(mud::param::bypassAll, 0.0f);
    setActual(mud::param::limiterEnabled, 1.0f);
    setActual(mud::param::masterGain, 6.0f);
    setActual(mud::param::phaseReverse, 0.0f);
    setActual(mud::param::tapeWobble, 0.0f);
    setActual(mud::param::synth2Wave, 0.0f);

    // Default to C Major with IN KEY off - factory signatures are free to roam until a
    // patch's own case below opts into a key (or the player engages IN KEY themselves).
    setActual(mud::param::keyRoot, 0.0f);
    setActual(mud::param::keyMode, 0.0f);
    setActual(mud::param::keyLock, 0.0f);

    switch (patchIndex)
    {
        case 0: // Velvet E-Piano: warm tine body plus a controlled FM bell.
            setSource(0, -5.0f, 0.0f, 0.004f, 1.25f, 0.34f, 1.40f,
                      35.0f, 14500.0f, false);
            setSource(1, -8.0f, 0.0f, 0.002f, 0.90f, 0.12f, 0.90f,
                      35.0f, 12000.0f, false);
            setActual(mud::param::synth1Wave, 0.0f);
            setActual(mud::param::synth1Unison, 2.0f);
            setActual(mud::param::synth1Detune, 2.0f);
            setActual(mud::param::synth1Fold, 0.06f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 3.0f);
            setActual(mud::param::synth2Index, 2.4f);
            setActual(mud::param::synth2Feedback, 0.04f);
            setActual(mud::param::morphX, 0.42f);
            break;

        case 1: // Crown Brass: broad saw/triangle body with a firm FM core.
            setSource(0, -3.0f, 0.0f, 0.055f, 0.48f, 0.82f, 0.32f,
                      75.0f, 9000.0f, false);
            setSource(1, -8.0f, 0.0f, 0.040f, 0.40f, 0.68f, 0.28f,
                      75.0f, 7200.0f, false);
            setActual(mud::param::synth1Wave, 2.0f);
            setActual(mud::param::synth1Unison, 3.0f);
            setActual(mud::param::synth1Detune, 4.0f);
            setActual(mud::param::synth1Fold, 0.11f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 1.05f);
            setActual(mud::param::synth2Feedback, 0.08f);
            setActual(mud::param::morphX, 0.24f);
            break;

        case 2: // Deep Current Bass: octave-down weight with a clean FM focus.
            setSource(0, -2.0f, -12.0f, 0.002f, 0.30f, 0.68f, 0.18f,
                      25.0f, 3800.0f, false);
            setSource(1, -7.0f, 0.0f, 0.002f, 0.24f, 0.58f, 0.16f,
                      25.0f, 2400.0f, false);
            setActual(mud::param::synth1Wave, 2.0f);
            setActual(mud::param::synth1Unison, 1.0f);
            setActual(mud::param::synth1Detune, 0.0f);
            setActual(mud::param::synth1Fold, 0.18f);
            setActual(mud::param::synth2CarrierRatio, 0.5f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 0.75f);
            setActual(mud::param::synth2Feedback, 0.04f);
            setActual(mud::param::morphX, 0.30f);
            break;

        case 3: // Glasswood Guitar: fast pluck, woody body and glassy edge.
            setSource(0, -4.0f, 0.0f, 0.001f, 0.70f, 0.06f, 0.50f,
                      70.0f, 11000.0f, false);
            setSource(1, -7.0f, 0.0f, 0.001f, 0.25f, 0.0f, 0.25f,
                      70.0f, 9500.0f, false);
            setActual(mud::param::synth1Wave, 1.0f);
            setActual(mud::param::synth1Unison, 2.0f);
            setActual(mud::param::synth1Detune, 1.5f);
            setActual(mud::param::synth1Fold, 0.12f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 2.01f);
            setActual(mud::param::synth2Index, 2.2f);
            setActual(mud::param::synth2Feedback, 0.03f);
            setActual(mud::param::morphX, 0.36f);
            break;

        // ---------------------------------------------------------------
        // GLITCH / CHOP / REVERSE collection - 20 patches built to show off
        // shatter, damage, grime, scatter/density granular, spectral freeze,
        // smear, resonate, the host-tempo mutation sequencer, and grain-switch
        // morphing. Every case here inherits keyLock=false from the shared
        // defaults above, exactly per spec: sound design goes wherever it
        // wants until the player deliberately engages IN KEY.
        // ---------------------------------------------------------------

        case 4: // Tape Chop Stutter: a saw pad hard-gated by the sequencer,
                // like a cassette loop being chopped in and out under a fader.
            setSource(0, -6.0f, 0.0f, 0.004f, 0.60f, 0.85f, 0.35f,
                      40.0f, 8000.0f, false);
            setSource(1, -9.0f, 0.0f, 0.004f, 0.55f, 0.70f, 0.30f,
                      40.0f, 6500.0f, false);
            setActual(mud::param::synth1Wave, 2.0f);
            setActual(mud::param::synth1Unison, 4.0f);
            setActual(mud::param::synth1Detune, 6.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 1.2f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::morphMode, 2.0f); // Grain
            setActual(mud::param::shatter, 0.35f);
            setActual(mud::param::grime, 0.20f);
            setActual(mud::param::macroMorph, 0.65f);
            setActual(mud::param::sequenceEnabled, 1.0f);
            setActual(mud::param::sequenceRate, 3.0f); // 1/8
            setActual(mud::param::sequenceDepth, 0.85f);
            setActual(mud::param::sequenceTarget, 2.0f); // Axis Split
            setSteps({ 1.0f, -1.0f, 0.6f, -1.0f, 1.0f, 0.0f, -1.0f, 0.8f,
                      1.0f, -1.0f, 0.4f, -1.0f, 1.0f, -1.0f, 0.9f, -1.0f });
            setActual(mud::param::delayType, 2.0f); // Tape
            setActual(mud::param::delayTime, 0.1875f);
            setActual(mud::param::delayFeedback, 0.30f);
            setActual(mud::param::delayMix, 0.28f);
            setActual(mud::param::tapeWobble, 1.0f);
            break;

        case 5: // Reverse Riser Bloom: no reversed audio to play with, so the
                // illusion is built the classic way - a long attack blooming
                // into a short release, plus a sample slot pre-armed to reverse
                // and grain-stretch anything the player drops in.
            setSource(0, -3.0f, 12.0f, 3.20f, 0.60f, 0.90f, 0.10f,
                      120.0f, 9000.0f, false);
            setSource(1, -8.0f, 12.0f, 2.80f, 0.50f, 0.75f, 0.08f,
                      120.0f, 7000.0f, false);
            setActual(mud::param::synth1Wave, 0.0f);
            setActual(mud::param::synth1Unison, 5.0f);
            setActual(mud::param::synth1Detune, 14.0f);
            setActual(mud::param::synth2CarrierRatio, 2.0f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 3.4f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::smear, 0.55f);
            setActual(mud::param::resonate, 0.40f);
            setActual(mud::param::macroMorph, 0.5f);
            setActual(mud::param::macroSpace, 0.60f);
            setActual(mud::param::motionRate, 0.10f);
            setActual(mud::param::motionDepth, 0.35f);
            for (int sample = 0; sample < 2; ++sample)
            {
                setActual(mud::param::sample(sample, "Reverse"), 1.0f);
                setActual(mud::param::sample(sample, "Grain"), 1.0f);
                setActual(mud::param::sample(sample, "GrainSize"), 0.75f);
                setActual(mud::param::sample(sample, "Stretch"), 2.5f);
            }
            setActual(mud::param::reverbType, 3.0f); // Void
            setActual(mud::param::reverbSize, 0.85f);
            setActual(mud::param::reverbMix, 0.42f);
            break;

        case 6: // Broken Cassette Wow: warbling pitch drift as if the capstan
                // is slipping - deep tape wobble plus slow, wide motion jitter.
            setSource(0, -5.0f, 0.0f, 0.01f, 0.9f, 0.60f, 0.9f,
                      35.0f, 6000.0f, false);
            setSource(1, -9.0f, 0.0f, 0.01f, 0.8f, 0.50f, 0.8f,
                      35.0f, 5000.0f, false);
            setActual(mud::param::synth1Wave, 1.0f);
            setActual(mud::param::synth1Unison, 3.0f);
            setActual(mud::param::synth1Detune, 9.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 0.9f);
            setActual(mud::param::morphX, 0.45f);
            setActual(mud::param::smooth, 0.30f);
            setActual(mud::param::grime, 0.15f);
            setActual(mud::param::motionRate, 0.35f);
            setActual(mud::param::motionDepth, 0.65f);
            setActual(mud::param::motionJitter, 0.55f);
            setActual(mud::param::macroMotion, 0.5f);
            setActual(mud::param::tapeWobble, 1.0f);
            setActual(mud::param::chorusRate, 0.18f);
            setActual(mud::param::chorusDepth, 0.60f);
            setActual(mud::param::chorusMix, 0.30f);
            break;

        case 7: // Backwards Gate Snap: the sample engine plays true reversed
                // audio (a swell-in), then a short synth decay behind it snaps
                // the whole voice shut like a reverse noise gate.
            setSource(0, -4.0f, 0.0f, 0.002f, 0.14f, 0.0f, 0.05f,
                      60.0f, 8500.0f, false);
            setSource(1, -8.0f, 0.0f, 0.002f, 0.10f, 0.0f, 0.04f,
                      60.0f, 7000.0f, false);
            setActual(mud::param::synth1Wave, 3.0f);
            setActual(mud::param::synth1Unison, 2.0f);
            setActual(mud::param::synth1Detune, 3.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 1.6f);
            setActual(mud::param::morphX, 0.4f);
            setActual(mud::param::shatter, 0.45f);
            for (int sample = 0; sample < 2; ++sample)
            {
                setActual(mud::param::sample(sample, "Reverse"), 1.0f);
                setActual(mud::param::sample(sample, "Density"), 0.80f);
                setActual(mud::param::sample(sample, "Scatter"), 0.10f);
            }
            setActual(mud::param::delayType, 1.0f); // Ping Pong
            setActual(mud::param::delayTime, 0.125f);
            setActual(mud::param::delayFeedback, 0.20f);
            setActual(mud::param::delayMix, 0.22f);
            break;

        case 8: // Cassette Chew Artifact: the tape got eaten - severe wobble,
                // damage (bitcrush) and grime stacked until pitch and timbre
                // both buckle.
            setSource(0, -5.0f, -5.0f, 0.02f, 0.7f, 0.55f, 0.6f,
                      45.0f, 4200.0f, false);
            setSource(1, -9.0f, -5.0f, 0.02f, 0.6f, 0.45f, 0.5f,
                      45.0f, 3400.0f, false);
            setActual(mud::param::synth1Wave, 2.0f);
            setActual(mud::param::synth1Unison, 3.0f);
            setActual(mud::param::synth1Detune, 18.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.5f);
            setActual(mud::param::synth2Index, 2.0f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::damage, 0.55f);
            setActual(mud::param::grime, 0.60f);
            setActual(mud::param::smear, 0.25f);
            setActual(mud::param::motionRate, 0.55f);
            setActual(mud::param::motionDepth, 0.85f);
            setActual(mud::param::motionJitter, 0.70f);
            setActual(mud::param::macroDamage, 0.55f);
            setActual(mud::param::tapeWobble, 1.0f);
            setActual(mud::param::phaseReverse, 1.0f);
            break;

        case 9: // 8-Bit Circuit Fault: square/square FM core, crushed hard,
                // digitally delayed - a home-computer chip that's about to die.
            setSource(0, -4.0f, 0.0f, 0.001f, 0.30f, 0.75f, 0.20f,
                      30.0f, 9000.0f, false);
            setSource(1, -7.0f, 0.0f, 0.001f, 0.25f, 0.65f, 0.15f,
                      30.0f, 8000.0f, false);
            setActual(mud::param::synth1Wave, 3.0f);
            setActual(mud::param::synth1Unison, 1.0f);
            setActual(mud::param::synth1Detune, 0.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 3.0f);
            setActual(mud::param::synth2Index, 4.5f);
            setActual(mud::param::synth2Feedback, 0.20f);
            setActual(mud::param::synth2Wave, 3.0f); // Square carrier
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::damage, 0.70f);
            setActual(mud::param::shatter, 0.30f);
            setActual(mud::param::macroDamage, 0.60f);
            setActual(mud::param::sequenceEnabled, 1.0f);
            setActual(mud::param::sequenceRate, 4.0f); // 1/16
            setActual(mud::param::sequenceDepth, 0.70f);
            setActual(mud::param::sequenceTarget, 3.0f); // Jitter
            setActual(mud::param::delayType, 0.0f); // Digital
            setActual(mud::param::delayTime, 0.09375f);
            setActual(mud::param::delayFeedback, 0.35f);
            setActual(mud::param::delayMix, 0.24f);
            break;

        case 10: // Digital Stutter Loop: the morph pad itself is set to Grain
                 // mode so the two synths trade tiny slices back and forth -
                 // a stutter-edit built entirely from live sound design.
            setSource(0, -5.0f, 0.0f, 0.001f, 0.20f, 0.60f, 0.15f,
                      40.0f, 10000.0f, false);
            setSource(1, -8.0f, 0.0f, 0.001f, 0.18f, 0.55f, 0.12f,
                      40.0f, 9000.0f, false);
            setActual(mud::param::synth1Wave, 2.0f);
            setActual(mud::param::synth1Unison, 2.0f);
            setActual(mud::param::synth1Detune, 4.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 2.0f);
            setActual(mud::param::synth2Index, 2.6f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::morphMode, 2.0f); // Grain
            setActual(mud::param::motionRate, 6.0f);
            setActual(mud::param::motionDepth, 0.75f);
            setActual(mud::param::macroMorph, 0.80f);
            setActual(mud::param::sequenceEnabled, 1.0f);
            setActual(mud::param::sequenceRate, 3.0f); // 1/8
            setActual(mud::param::sequenceDepth, 0.9f);
            setActual(mud::param::sequenceTarget, 0.0f); // Morph X
            setSteps({ 0.0f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.5f, -1.0f,
                      0.0f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, -0.5f, -1.0f });
            break;

        case 11: // Chopped Arcade Fault: the fastest sequencer rate here plus
                 // heavy shatter - a coin-op cabinet's audio chip glitching
                 // between frames.
            setSource(0, -4.0f, 0.0f, 0.001f, 0.12f, 0.70f, 0.10f,
                      50.0f, 11000.0f, false);
            setSource(1, -8.0f, 0.0f, 0.001f, 0.10f, 0.60f, 0.08f,
                      50.0f, 9500.0f, false);
            setActual(mud::param::synth1Wave, 3.0f);
            setActual(mud::param::synth1Unison, 1.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 4.0f);
            setActual(mud::param::synth2Index, 6.0f);
            setActual(mud::param::synth2Wave, 3.0f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::shatter, 0.65f);
            setActual(mud::param::damage, 0.40f);
            setActual(mud::param::macroMorph, 0.55f);
            setActual(mud::param::sequenceEnabled, 1.0f);
            setActual(mud::param::sequenceRate, 5.0f); // 1/32
            setActual(mud::param::sequenceDepth, 1.0f);
            setActual(mud::param::sequenceTarget, 2.0f); // Axis Split
            setSteps({ 1.0f, -1.0f, 1.0f, -1.0f, 0.6f, -0.6f, 1.0f, -1.0f,
                      1.0f, -1.0f, 0.3f, -0.3f, 1.0f, -1.0f, 1.0f, -1.0f });
            break;

        case 12: // Glitch Hop Snare: a short, damaged hit with a ping-pong
                 // tail - built as a percussive one-shot rather than a hold.
            setSource(0, -3.0f, 7.0f, 0.001f, 0.10f, 0.0f, 0.08f,
                      90.0f, 9000.0f, false);
            setSource(1, -6.0f, 7.0f, 0.001f, 0.08f, 0.0f, 0.06f,
                      90.0f, 8000.0f, false);
            setActual(mud::param::synth1Wave, 3.0f);
            setActual(mud::param::synth1Unison, 2.0f);
            setActual(mud::param::synth1Detune, 10.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 5.0f);
            setActual(mud::param::synth2Index, 5.5f);
            setActual(mud::param::synth2Feedback, 0.25f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::damage, 0.60f);
            setActual(mud::param::shatter, 0.50f);
            setActual(mud::param::grime, 0.30f);
            setActual(mud::param::delayType, 1.0f); // Ping Pong
            setActual(mud::param::delayTime, 0.0625f);
            setActual(mud::param::delayFeedback, 0.42f);
            setActual(mud::param::delayMix, 0.34f);
            break;

        case 13: // Static Burst Glitch: dense scattered grains plus grime and
                 // damage - closer to broadcast static than a musical tone.
            setSource(0, -6.0f, 0.0f, 0.001f, 0.40f, 0.30f, 0.30f,
                      55.0f, 12000.0f, false);
            setSource(1, -9.0f, 0.0f, 0.001f, 0.35f, 0.25f, 0.25f,
                      55.0f, 11000.0f, false);
            setActual(mud::param::synth1Wave, 3.0f);
            setActual(mud::param::synth1Unison, 6.0f);
            setActual(mud::param::synth1Detune, 30.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 7.0f);
            setActual(mud::param::synth2Index, 9.0f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::scatter, 0.75f);
            setActual(mud::param::density, 0.80f);
            setActual(mud::param::grime, 0.65f);
            setActual(mud::param::damage, 0.45f);
            setActual(mud::param::motionJitter, 0.60f);
            setActual(mud::param::macroDamage, 0.50f);
            break;

        case 14: // Reverse Cymbal Swell: bright inharmonic FM swelling in on
                 // a long attack, with the sample slots pre-armed for a real
                 // reversed cymbal/metal hit if one gets loaded.
            setSource(0, -5.0f, 12.0f, 2.60f, 0.9f, 0.85f, 0.6f,
                      200.0f, 13000.0f, false);
            setSource(1, -6.0f, 19.0f, 2.40f, 0.8f, 0.80f, 0.5f,
                      200.0f, 14000.0f, false);
            setActual(mud::param::synth1Wave, 3.0f);
            setActual(mud::param::synth1Unison, 5.0f);
            setActual(mud::param::synth1Detune, 25.0f);
            setActual(mud::param::synth2CarrierRatio, 3.0f);
            setActual(mud::param::synth2ModRatio, 3.01f);
            setActual(mud::param::synth2Index, 7.0f);
            setActual(mud::param::synth2Feedback, 0.15f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::resonate, 0.50f);
            setActual(mud::param::smear, 0.40f);
            setActual(mud::param::spectralFreeze, 0.20f);
            for (int sample = 0; sample < 2; ++sample)
            {
                setActual(mud::param::sample(sample, "Reverse"), 1.0f);
                setActual(mud::param::sample(sample, "GrainSize"), 0.60f);
                setActual(mud::param::sample(sample, "Stretch"), 1.8f);
            }
            setActual(mud::param::reverbType, 2.0f); // Plate
            setActual(mud::param::reverbSize, 0.70f);
            setActual(mud::param::reverbMix, 0.35f);
            break;

        case 15: // Backmasked Voice Ghost: both sample slots armed to reverse
                 // and smear like a backmasked vocal, buried in a huge void
                 // reverb so any loaded sample turns ghostly.
            setSource(0, -8.0f, 0.0f, 0.05f, 1.2f, 0.70f, 1.5f,
                      150.0f, 4500.0f, false);
            setSource(1, -10.0f, 3.0f, 0.05f, 1.0f, 0.60f, 1.3f,
                      150.0f, 3800.0f, false);
            setActual(mud::param::synth1Wave, 1.0f);
            setActual(mud::param::synth1Unison, 4.0f);
            setActual(mud::param::synth1Detune, 8.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.01f);
            setActual(mud::param::synth2Index, 1.4f);
            setActual(mud::param::morphX, 0.45f);
            setActual(mud::param::smear, 0.70f);
            setActual(mud::param::freeze, 0.30f);
            setActual(mud::param::macroSpace, 0.75f);
            for (int sample = 0; sample < 2; ++sample)
            {
                setActual(mud::param::sample(sample, "Reverse"), 1.0f);
                setActual(mud::param::sample(sample, "Grain"), 1.0f);
                setActual(mud::param::sample(sample, "GrainSize"), 0.85f);
                setActual(mud::param::sample(sample, "Density"), 0.55f);
                setActual(mud::param::sample(sample, "Stretch"), 3.0f);
            }
            setActual(mud::param::reverbType, 3.0f); // Void
            setActual(mud::param::reverbSize, 0.95f);
            setActual(mud::param::reverbDamping, 0.20f);
            setActual(mud::param::reverbMix, 0.55f);
            setActual(mud::param::convolutionMix, 0.25f);
            break;

        case 16: // Reverse Sweep Pad: a slow-morphing pad built around the
                 // reverse-envelope illusion, wide and patient rather than
                 // percussive.
            setSource(0, -4.0f, 0.0f, 4.50f, 1.5f, 0.90f, 2.0f,
                      60.0f, 8000.0f, false);
            setSource(1, -8.0f, 0.0f, 4.00f, 1.3f, 0.80f, 1.8f,
                      60.0f, 7000.0f, false);
            setActual(mud::param::synth1Wave, 1.0f);
            setActual(mud::param::synth1Unison, 6.0f);
            setActual(mud::param::synth1Detune, 16.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.5f);
            setActual(mud::param::synth2Index, 1.8f);
            setActual(mud::param::morphMode, 0.0f); // Vector
            setActual(mud::param::motionRate, 0.06f);
            setActual(mud::param::motionDepth, 0.5f);
            setActual(mud::param::macroMorph, 0.5f);
            setActual(mud::param::macroSpace, 0.65f);
            for (int sample = 0; sample < 2; ++sample)
                setActual(mud::param::sample(sample, "Reverse"), 1.0f);
            setActual(mud::param::reverbType, 1.0f); // Hall
            setActual(mud::param::reverbSize, 0.80f);
            setActual(mud::param::reverbMix, 0.40f);
            setActual(mud::param::chorusRate, 0.12f);
            setActual(mud::param::chorusDepth, 0.35f);
            setActual(mud::param::chorusMix, 0.20f);
            break;

        case 17: // Freeze Frame Fault: spectral freeze pushed hard so the
                 // voice locks onto a single instant and hangs there, a
                 // scratched-disc still-frame.
            setSource(0, -5.0f, 0.0f, 0.60f, 1.0f, 0.95f, 1.0f,
                      50.0f, 9000.0f, false);
            setSource(1, -8.0f, 0.0f, 0.55f, 0.9f, 0.90f, 0.9f,
                      50.0f, 8000.0f, false);
            setActual(mud::param::synth1Wave, 0.0f);
            setActual(mud::param::synth1Unison, 5.0f);
            setActual(mud::param::synth1Detune, 12.0f);
            setActual(mud::param::synth2CarrierRatio, 2.0f);
            setActual(mud::param::synth2ModRatio, 2.0f);
            setActual(mud::param::synth2Index, 2.5f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::freeze, 0.80f);
            setActual(mud::param::resonate, 0.60f);
            setActual(mud::param::smear, 0.35f);
            setActual(mud::param::spectralFreeze, 0.55f);
            setActual(mud::param::macroSpace, 0.40f);
            setActual(mud::param::reverbType, 3.0f); // Void
            setActual(mud::param::reverbSize, 0.75f);
            setActual(mud::param::reverbMix, 0.30f);
            break;

        case 18: // Reverse Bell Swell: a bright FM bell blooming in backwards
                 // via a long attack, shimmering rather than snapping.
            setSource(0, -6.0f, 12.0f, 3.0f, 1.4f, 0.20f, 1.6f,
                      100.0f, 12000.0f, false);
            setSource(1, -4.0f, 12.0f, 2.8f, 1.2f, 0.15f, 1.4f,
                      100.0f, 13500.0f, false);
            setActual(mud::param::synth1Wave, 0.0f);
            setActual(mud::param::synth1Unison, 3.0f);
            setActual(mud::param::synth1Detune, 5.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 3.5f);
            setActual(mud::param::synth2Index, 4.2f);
            setActual(mud::param::synth2Feedback, 0.06f);
            setActual(mud::param::morphX, 0.55f);
            setActual(mud::param::resonate, 0.35f);
            setActual(mud::param::smear, 0.25f);
            setActual(mud::param::macroMorph, 0.55f);
            setActual(mud::param::chorusRate, 0.28f);
            setActual(mud::param::chorusDepth, 0.30f);
            setActual(mud::param::chorusMix, 0.18f);
            setActual(mud::param::reverbType, 2.0f); // Plate
            setActual(mud::param::reverbSize, 0.60f);
            setActual(mud::param::reverbMix, 0.32f);
            break;

        case 19: // Vinyl Dust Glitch: a quiet, dusty granular texture - low
                 // density crackle and light grime instead of a full tone.
            setSource(0, -9.0f, 0.0f, 0.02f, 1.2f, 0.5f, 1.4f,
                      60.0f, 7500.0f, false);
            setSource(1, -13.0f, 0.0f, 0.02f, 1.0f, 0.4f, 1.2f,
                      60.0f, 6500.0f, false);
            setActual(mud::param::synth1Wave, 1.0f);
            setActual(mud::param::synth1Unison, 2.0f);
            setActual(mud::param::synth1Detune, 3.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 0.6f);
            setActual(mud::param::morphX, 0.4f);
            setActual(mud::param::scatter, 0.35f);
            setActual(mud::param::density, 0.30f);
            setActual(mud::param::grime, 0.22f);
            setActual(mud::param::damage, 0.10f);
            setActual(mud::param::motionRate, 0.4f);
            setActual(mud::param::motionJitter, 0.30f);
            setActual(mud::param::reverbType, 0.0f); // Room
            setActual(mud::param::reverbSize, 0.35f);
            setActual(mud::param::reverbMix, 0.20f);
            break;

        case 20: // Analog Drift Failure: an unstable analog voice slowly
                 // detuning under slow motion and heavy wobble, like an old
                 // synth losing calibration.
            setSource(0, -4.0f, 0.0f, 0.03f, 1.0f, 0.75f, 1.2f,
                      35.0f, 7000.0f, false);
            setSource(1, -8.0f, 0.0f, 0.03f, 0.9f, 0.65f, 1.0f,
                      35.0f, 6000.0f, false);
            setActual(mud::param::synth1Wave, 2.0f);
            setActual(mud::param::synth1Unison, 4.0f);
            setActual(mud::param::synth1Detune, 22.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 1.0f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::smooth, 0.20f);
            setActual(mud::param::grime, 0.25f);
            setActual(mud::param::motionRate, 0.08f);
            setActual(mud::param::motionDepth, 0.70f);
            setActual(mud::param::motionJitter, 0.45f);
            setActual(mud::param::macroMotion, 0.60f);
            setActual(mud::param::tapeWobble, 1.0f);
            break;

        case 21: // Broken Synth Stab: a short, gnarly FM stab with grime and
                 // a glitchy chorus, hitting hard and cutting off fast.
            setSource(0, -3.0f, 0.0f, 0.001f, 0.20f, 0.10f, 0.12f,
                      70.0f, 9500.0f, false);
            setSource(1, -5.0f, 0.0f, 0.001f, 0.16f, 0.08f, 0.10f,
                      70.0f, 8500.0f, false);
            setActual(mud::param::synth1Wave, 2.0f);
            setActual(mud::param::synth1Unison, 3.0f);
            setActual(mud::param::synth1Detune, 11.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 2.5f);
            setActual(mud::param::synth2Index, 4.0f);
            setActual(mud::param::synth2Feedback, 0.18f);
            setActual(mud::param::morphX, 0.5f);
            setActual(mud::param::grime, 0.50f);
            setActual(mud::param::damage, 0.30f);
            setActual(mud::param::shatter, 0.20f);
            setActual(mud::param::chorusRate, 1.4f);
            setActual(mud::param::chorusDepth, 0.55f);
            setActual(mud::param::chorusMix, 0.32f);
            break;

        case 22: // Chopped Brass Hit: a punchy FM brass body chopped by the
                 // fast sequencer, alternating full hits with dead silence.
            setSource(0, -3.0f, 0.0f, 0.05f, 0.42f, 0.78f, 0.28f,
                      75.0f, 8800.0f, false);
            setSource(1, -7.0f, 0.0f, 0.04f, 0.36f, 0.64f, 0.24f,
                      75.0f, 7200.0f, false);
            setActual(mud::param::synth1Wave, 2.0f);
            setActual(mud::param::synth1Unison, 3.0f);
            setActual(mud::param::synth1Detune, 5.0f);
            setActual(mud::param::synth2CarrierRatio, 1.0f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 1.3f);
            setActual(mud::param::synth2Feedback, 0.10f);
            setActual(mud::param::morphX, 0.28f);
            setActual(mud::param::shatter, 0.25f);
            setActual(mud::param::macroMorph, 0.60f);
            setActual(mud::param::sequenceEnabled, 1.0f);
            setActual(mud::param::sequenceRate, 3.0f); // 1/8
            setActual(mud::param::sequenceDepth, 0.75f);
            setActual(mud::param::sequenceTarget, 0.0f); // Morph X
            setSteps({ 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f,
                      1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f });
            break;

        case 23: // Retro Chop Bass: an 80s-style FM sub bass carved by the
                 // sequencer's Axis Split target for a stuttering low end.
            setSource(0, -1.0f, -12.0f, 0.002f, 0.28f, 0.72f, 0.16f,
                      25.0f, 3200.0f, false);
            setSource(1, -6.0f, -12.0f, 0.002f, 0.22f, 0.60f, 0.14f,
                      25.0f, 2200.0f, false);
            setActual(mud::param::synth1Wave, 2.0f);
            setActual(mud::param::synth1Unison, 2.0f);
            setActual(mud::param::synth1Detune, 4.0f);
            setActual(mud::param::synth2CarrierRatio, 0.5f);
            setActual(mud::param::synth2ModRatio, 1.0f);
            setActual(mud::param::synth2Index, 1.1f);
            setActual(mud::param::morphX, 0.30f);
            setActual(mud::param::damage, 0.25f);
            setActual(mud::param::grime, 0.20f);
            setActual(mud::param::macroMorph, 0.45f);
            setActual(mud::param::sequenceEnabled, 1.0f);
            setActual(mud::param::sequenceRate, 4.0f); // 1/16
            setActual(mud::param::sequenceDepth, 0.65f);
            setActual(mud::param::sequenceTarget, 2.0f); // Axis Split
            setSteps({ 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f,
                      1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f });
            setActual(mud::param::delayType, 0.0f); // Digital
            setActual(mud::param::delayTime, 0.09375f);
            setActual(mud::param::delayFeedback, 0.15f);
            setActual(mud::param::delayMix, 0.12f);
            break;

        default:
            break;
    }

    currentFactoryPatch.store(patchIndex, std::memory_order_relaxed);
}

void RuFTraXMuDAudioProcessor::cacheParameters()
{
    auto get = [this](const juce::String& id)
    {
        auto* value = parameters.getRawParameterValue(id);
        jassert(value != nullptr);
        return value;
    };

    for (int index = 0; index < 4; ++index)
    {
        auto& destination = voiceParameters.source[static_cast<std::size_t>(index)];
        destination.level = get(mud::param::source(index, "Level"));
        destination.pan = get(mud::param::source(index, "Pan"));
        destination.tune = get(mud::param::source(index, "Tune"));
        destination.fine = get(mud::param::source(index, "Fine"));
        destination.attack = get(mud::param::source(index, "Attack"));
        destination.decay = get(mud::param::source(index, "Decay"));
        destination.sustain = get(mud::param::source(index, "Sustain"));
        destination.release = get(mud::param::source(index, "Release"));
        destination.highPass = get(mud::param::source(index, "HighPass"));
        destination.lowPass = get(mud::param::source(index, "LowPass"));
        destination.mute = get(mud::param::source(index, "Mute"));
        destination.solo = get(mud::param::source(index, "Solo"));
    }

    for (int index = 0; index < 2; ++index)
    {
        auto& destination = voiceParameters.sample[static_cast<std::size_t>(index)];
        destination.reverse = get(mud::param::sample(index, "Reverse"));
        destination.loop = get(mud::param::sample(index, "Loop"));
        destination.slice = get(mud::param::sample(index, "Slice"));
        destination.grain = get(mud::param::sample(index, "Grain"));
        destination.grainSize = get(mud::param::sample(index, "GrainSize"));
        destination.density = get(mud::param::sample(index, "Density"));
        destination.scatter = get(mud::param::sample(index, "Scatter"));
        destination.stretch = get(mud::param::sample(index, "Stretch"));
    }

    voiceParameters.keyRoot = get(mud::param::keyRoot);
    voiceParameters.keyMode = get(mud::param::keyMode);
    voiceParameters.keyLock = get(mud::param::keyLock);

    voiceParameters.synth1Wave = get(mud::param::synth1Wave);
    voiceParameters.synth1Unison = get(mud::param::synth1Unison);
    voiceParameters.synth1Detune = get(mud::param::synth1Detune);
    voiceParameters.synth1Fold = get(mud::param::synth1Fold);
    voiceParameters.synth2CarrierRatio = get(mud::param::synth2CarrierRatio);
    voiceParameters.synth2ModRatio = get(mud::param::synth2ModRatio);
    voiceParameters.synth2Index = get(mud::param::synth2Index);
    voiceParameters.synth2Feedback = get(mud::param::synth2Feedback);
    voiceParameters.synth2Wave = get(mud::param::synth2Wave);
    voiceParameters.morphX = get(mud::param::morphX);
    voiceParameters.morphY = get(mud::param::morphY);
    voiceParameters.morphMode = get(mud::param::morphMode);
    voiceParameters.motionDepth = get(mud::param::motionDepth);
    voiceParameters.density = get(mud::param::density);
    voiceParameters.scatter = get(mud::param::scatter);
    voiceParameters.smear = get(mud::param::smear);
    voiceParameters.freeze = get(mud::param::freeze);
    voiceParameters.shatter = get(mud::param::shatter);
    voiceParameters.stretch = get(mud::param::stretch);
    voiceParameters.resonate = get(mud::param::resonate);
    voiceParameters.damage = get(mud::param::damage);
    voiceParameters.smooth = get(mud::param::smooth);
    voiceParameters.grime = get(mud::param::grime);
    voiceParameters.macroMorph = get(mud::param::macroMorph);
    voiceParameters.macroMotion = get(mud::param::macroMotion);
    voiceParameters.macroDamage = get(mud::param::macroDamage);
}

void RuFTraXMuDAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    synthesiser.setCurrentPlaybackSampleRate(sampleRate);
    const juce::dsp::ProcessSpec spec {
        sampleRate,
        static_cast<juce::uint32>(samplesPerBlock),
        static_cast<juce::uint32>(juce::jmax(1, getTotalNumOutputChannels()))
    };
    effects.prepare(spec);
    motionPhase = sequencePhase = 0.0;
}

void RuFTraXMuDAudioProcessor::releaseResources()
{
    effects.reset();
}

bool RuFTraXMuDAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto output = layouts.getMainOutputChannelSet();
    return output == juce::AudioChannelSet::mono()
        || output == juce::AudioChannelSet::stereo();
}

void RuFTraXMuDAudioProcessor::updateMidiDisplay(const juce::MidiBuffer& midi)
{
    for (const auto metadata : midi)
    {
        const auto message = metadata.getMessage();
        if (message.isNoteOn())
        {
            const auto note = message.getNoteNumber();
            heldNotes[static_cast<std::size_t>(note)].store(true, std::memory_order_relaxed);
            lastMidiNote.store(note, std::memory_order_relaxed);
            lastVelocity.store(juce::roundToInt(message.getFloatVelocity() * 127.0f),
                               std::memory_order_relaxed);
        }
        else if (message.isNoteOff())
        {
            heldNotes[static_cast<std::size_t>(message.getNoteNumber())].store(
                false, std::memory_order_relaxed);
        }
        else if (message.isAllNotesOff() || message.isAllSoundOff())
        {
            for (auto& held : heldNotes)
                held.store(false, std::memory_order_relaxed);
        }
        else if (message.isPitchWheel())
        {
            const auto bend = 2.0f
                * static_cast<float>(message.getPitchWheelValue() - 8192) / 8192.0f;
            currentPitchBendSemitones.store(bend, std::memory_order_relaxed);
        }
    }
}

void RuFTraXMuDAudioProcessor::updateRuntimeModulation(int numSamples)
{
    if (currentSampleRate <= 0.0)
        return;

    const auto rate = juce::jmax(0.005f, raw(parameters, mud::param::motionRate));
    motionPhase = std::fmod(motionPhase + static_cast<double>(numSamples) * rate
                           / currentSampleRate, 1.0);
    const auto angle = juce::MathConstants<double>::twoPi * motionPhase;
    auto offsetX = static_cast<float>(std::sin(angle));
    auto offsetY = static_cast<float>(std::cos(angle));
    const auto jitter = juce::jlimit(0.0f, 1.0f,
                                    raw(parameters, mud::param::motionJitter));
    modulationRandomState ^= modulationRandomState << 13;
    modulationRandomState ^= modulationRandomState >> 17;
    modulationRandomState ^= modulationRandomState << 5;
    const auto random = static_cast<float>(modulationRandomState & 0x00ffffffu)
                        / static_cast<float>(0x01000000u) * 2.0f - 1.0f;
    offsetX += random * jitter;
    offsetY -= random * jitter * 0.7f;

    if (raw(parameters, mud::param::sequenceEnabled) >= 0.5f)
    {
        auto bpm = 120.0;
        if (auto* playHead = getPlayHead())
            if (const auto position = playHead->getPosition())
                if (const auto hostBpm = position->getBpm())
                    bpm = *hostBpm;

        const std::array<double, 6> beatsPerStep { 4.0, 2.0, 1.0, 0.5, 0.25, 0.125 };
        const auto rateIndex = juce::jlimit(0, 5,
            juce::roundToInt(raw(parameters, mud::param::sequenceRate)));
        const auto secondsPerStep = 60.0 / juce::jmax(20.0, bpm)
                                    * beatsPerStep[static_cast<std::size_t>(rateIndex)];
        sequencePhase += static_cast<double>(numSamples) / currentSampleRate
                         / secondsPerStep;
        while (sequencePhase >= 1.0)
        {
            sequencePhase -= 1.0;
            sequenceStep.store((sequenceStep.load(std::memory_order_relaxed) + 1) % 16,
                               std::memory_order_relaxed);
        }

        const auto stepValue = raw(parameters,
            mud::param::step(sequenceStep.load(std::memory_order_relaxed)));
        const auto stepDepth = raw(parameters, mud::param::sequenceDepth);
        const auto target = juce::jlimit(0, 3,
            juce::roundToInt(raw(parameters, mud::param::sequenceTarget)));
        if (target == 0)
            offsetX += stepValue * stepDepth;
        else if (target == 1)
            offsetY += stepValue * stepDepth;
        else if (target == 2)
        {
            offsetX += stepValue * stepDepth;
            offsetY -= stepValue * stepDepth;
        }
        else
        {
            offsetX += random * stepValue * stepDepth;
            offsetY += random * stepValue * stepDepth;
        }
    }

    voiceParameters.runtimeMorphX.store(juce::jlimit(-1.0f, 1.0f, offsetX),
                                         std::memory_order_relaxed);
    voiceParameters.runtimeMorphY.store(juce::jlimit(-1.0f, 1.0f, offsetY),
                                         std::memory_order_relaxed);
}

void RuFTraXMuDAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,
                                            juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();
    updateMidiDisplay(midi);
    updateRuntimeModulation(buffer.getNumSamples());
    synthesiser.renderNextBlock(buffer, midi, 0, buffer.getNumSamples());
    effects.process(buffer);

    for (int source = 0; source < 4; ++source)
    {
        const auto fresh = sourceMeterBus.consume(source);
        const auto previous = sourceLevels[static_cast<std::size_t>(source)].load(
            std::memory_order_relaxed);
        sourceLevels[static_cast<std::size_t>(source)].store(
            juce::jmax(fresh, previous * 0.88f), std::memory_order_relaxed);
    }

    for (int channel = 0; channel < juce::jmin(2, buffer.getNumChannels()); ++channel)
    {
        const auto fresh = buffer.getMagnitude(channel, 0, buffer.getNumSamples());
        const auto previous = outputLevels[static_cast<std::size_t>(channel)].load(
            std::memory_order_relaxed);
        outputLevels[static_cast<std::size_t>(channel)].store(
            juce::jmax(fresh, previous * 0.90f), std::memory_order_relaxed);
    }
}

bool RuFTraXMuDAudioProcessor::loadSample(int slot, const juce::File& file,
                                         juce::String& error)
{
    if (! juce::isPositiveAndBelow(slot, 2))
    {
        error = "Invalid MuD sample slot.";
        return false;
    }
    if (! sampleStores[static_cast<std::size_t>(slot)].loadFromFile(file, error))
        return false;
    samplePaths[static_cast<std::size_t>(slot)] = file.getFullPathName();
    return true;
}

void RuFTraXMuDAudioProcessor::clearSample(int slot)
{
    if (! juce::isPositiveAndBelow(slot, 2))
        return;
    sampleStores[static_cast<std::size_t>(slot)].clear();
    samplePaths[static_cast<std::size_t>(slot)].clear();
}

std::shared_ptr<const mud::SampleAsset>
RuFTraXMuDAudioProcessor::getSample(int slot) const
{
    if (! juce::isPositiveAndBelow(slot, 2))
        return {};
    return sampleStores[static_cast<std::size_t>(slot)].get();
}

juce::String RuFTraXMuDAudioProcessor::getSampleDescription(int slot) const
{
    const auto sample = getSample(slot);
    if (sample == nullptr)
        return "DROP WAV / AIFF / FLAC";
    if (! sample->pitch.detected)
        return sample->name + " | ROOT C4 DEFAULT | UNPITCHED";

    const auto correctionCents = sample->pitch.tuningCorrectionSemitones * 100.0f;
    const auto correction = std::abs(correctionCents) < 0.05f
        ? juce::String("TUNED")
        : juce::String(correctionCents >= 0.0f ? "+" : "")
            + juce::String(correctionCents, 1) + " ct";
    return sample->name + " | ROOT " + noteName(sample->pitch.rootMidiNote)
        + (sample->pitch.rootFromFileName ? " FILE" : " AUTO")
        + " | " + correction;
}

int RuFTraXMuDAudioProcessor::getActiveMidiNote() const noexcept
{
    const auto latest = lastMidiNote.load(std::memory_order_relaxed);
    if (juce::isPositiveAndBelow(latest, 128)
        && heldNotes[static_cast<std::size_t>(latest)].load(std::memory_order_relaxed))
        return latest;

    for (int note = 127; note >= 0; --note)
        if (heldNotes[static_cast<std::size_t>(note)].load(std::memory_order_relaxed))
            return note;
    return -1;
}

juce::String RuFTraXMuDAudioProcessor::getSampleTriggeredNoteDescription(int slot) const
{
    const auto sample = getSample(slot);
    const auto midiNote = getActiveMidiNote();
    if (sample == nullptr || midiNote < 0 || ! juce::isPositiveAndBelow(slot, 2))
        return "MIDI --  ->  TONE --";

    const auto midiText = noteName(midiNote) + " (" + juce::String(midiNote) + ")";
    if (! sample->pitch.detected)
        return "MIDI " + midiText + "  ->  TONE UNPITCHED";

    const auto sourceIndex = slot + 2;
    const auto* tune = voiceParameters.source[static_cast<std::size_t>(sourceIndex)].tune;
    const auto* fine = voiceParameters.source[static_cast<std::size_t>(sourceIndex)].fine;
    const auto tuneSemitones = tune != nullptr
        ? tune->load(std::memory_order_relaxed) : 0.0f;
    const auto fineSemitones = fine != nullptr
        ? fine->load(std::memory_order_relaxed) * 0.01f : 0.0f;

    // Root-key mapping cancels the source sample's original pitch. What is
    // actually triggered is the MIDI note plus this layer's Tune/Fine offset.
    const auto triggeredPitch = static_cast<float>(midiNote)
        + tuneSemitones + fineSemitones
        + currentPitchBendSemitones.load(std::memory_order_relaxed);
    return "MIDI " + midiText + "  ->  TONE " + pitchName(triggeredPitch);
}

float RuFTraXMuDAudioProcessor::getSourceLevel(int source) const noexcept
{
    if (! juce::isPositiveAndBelow(source, 4))
        return 0.0f;
    return sourceLevels[static_cast<std::size_t>(source)].load(std::memory_order_relaxed);
}

float RuFTraXMuDAudioProcessor::getOutputLevel(int channel) const noexcept
{
    if (! juce::isPositiveAndBelow(channel, 2))
        return 0.0f;
    return outputLevels[static_cast<std::size_t>(channel)].load(std::memory_order_relaxed);
}

float RuFTraXMuDAudioProcessor::getEffectActivity(int effect) const noexcept
{
    return effects.consumeActivity(effect);
}

juce::String RuFTraXMuDAudioProcessor::getMidiDisplayText() const
{
    juce::StringArray names;
    for (int note = 0; note < 128; ++note)
        if (heldNotes[static_cast<std::size_t>(note)].load(std::memory_order_relaxed))
            names.add(noteName(note));
    if (names.isEmpty())
        return "NOTE --";
    if (names.size() == 1)
        return "NOTE " + names[0] + "  VEL "
            + juce::String(lastVelocity.load(std::memory_order_relaxed));
    return "CHORD " + names.joinIntoString(" ");
}

bool RuFTraXMuDAudioProcessor::parameterLocked(const char* lockId) const
{
    if (auto* value = parameters.getRawParameterValue(lockId))
        return value->load(std::memory_order_relaxed) >= 0.5f;
    return false;
}

void RuFTraXMuDAudioProcessor::setParameterNormalised(const juce::String& id,
                                                       float normalised)
{
    if (auto* parameter = parameters.getParameter(id))
    {
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost(juce::jlimit(0.0f, 1.0f, normalised));
        parameter->endChangeGesture();
    }
}

void RuFTraXMuDAudioProcessor::randomize(MutationMode mode)
{
    const auto seedValue = juce::roundToInt(raw(parameters, mud::param::randomSeed));
    const auto timeSalt = static_cast<uint32_t>(juce::Time::getMillisecondCounter());
    std::mt19937 generator(static_cast<uint32_t>(seedValue) ^ timeSalt);
    std::uniform_real_distribution<float> distribution(0.0f, 1.0f);
    const auto chaos = juce::jlimit(0.0f, 1.0f,
                                   raw(parameters, mud::param::chaosAmount));
    undoManager.beginNewTransaction(mode == MutationMode::safe
                                    ? "Safe MuD mutation" : "Wild MuD mutation");

    auto mutate = [&](const juce::String& id, float safeWidth = 0.22f)
    {
        if (auto* parameter = parameters.getParameter(id))
        {
            const auto current = parameter->getValue();
            const auto randomValue = distribution(generator);
            const auto next = mode == MutationMode::safe
                ? current + (randomValue * 2.0f - 1.0f) * safeWidth * chaos
                : juce::jmap(chaos, current, randomValue);
            setParameterNormalised(id, next);
        }
    };

    if (! parameterLocked(mud::param::lockMix))
        for (int source = 0; source < 4; ++source)
        {
            mutate(mud::param::source(source, "Level"), 0.12f);
            mutate(mud::param::source(source, "Pan"), 0.28f);
        }

    if (! parameterLocked(mud::param::lockPitch))
        for (int source = 0; source < 4; ++source)
        {
            mutate(mud::param::source(source, "Tune"), 0.10f);
            mutate(mud::param::source(source, "Fine"), 0.15f);
        }

    if (! parameterLocked(mud::param::lockFilter))
        for (int source = 0; source < 4; ++source)
        {
            mutate(mud::param::source(source, "HighPass"), 0.25f);
            mutate(mud::param::source(source, "LowPass"), 0.25f);
        }

    if (! parameterLocked(mud::param::lockSources))
    {
        mutate(mud::param::synth1Wave, 0.25f);
        mutate(mud::param::synth1Unison, 0.20f);
        mutate(mud::param::synth1Detune, 0.25f);
        mutate(mud::param::synth1Fold, 0.28f);
        mutate(mud::param::synth2CarrierRatio, 0.20f);
        mutate(mud::param::synth2ModRatio, 0.20f);
        mutate(mud::param::synth2Index, 0.28f);
        mutate(mud::param::synth2Feedback, 0.22f);
        mutate(mud::param::synth2Wave, 0.40f);
        for (int source = 0; source < 4; ++source)
        {
            mutate(mud::param::source(source, "Attack"), 0.18f);
            mutate(mud::param::source(source, "Decay"), 0.18f);
            mutate(mud::param::source(source, "Sustain"), 0.18f);
            mutate(mud::param::source(source, "Release"), 0.18f);
        }
    }

    if (! parameterLocked(mud::param::lockRhythm))
    {
        for (int sample = 0; sample < 2; ++sample)
        {
            mutate(mud::param::sample(sample, "Reverse"), 0.35f);
            mutate(mud::param::sample(sample, "Loop"), 0.25f);
            mutate(mud::param::sample(sample, "Slice"), 0.35f);
            mutate(mud::param::sample(sample, "Grain"), 0.35f);
            mutate(mud::param::sample(sample, "GrainSize"), 0.25f);
            mutate(mud::param::sample(sample, "Density"), 0.25f);
            mutate(mud::param::sample(sample, "Scatter"), 0.25f);
            mutate(mud::param::sample(sample, "Stretch"), 0.20f);
        }
        for (int step = 0; step < 16; ++step)
            mutate(mud::param::step(step), 0.35f);
    }

    if (! parameterLocked(mud::param::lockMod))
    {
        // freeze is deliberately not in this list - see the comment by spectralFreeze below.
        const std::array<const char*, 15> modulationIds {
            mud::param::morphX, mud::param::morphY, mud::param::morphMode,
            mud::param::motionRate, mud::param::motionDepth, mud::param::motionJitter,
            mud::param::density, mud::param::scatter, mud::param::smear,
            mud::param::shatter, mud::param::stretch,
            mud::param::resonate, mud::param::damage, mud::param::smooth,
            mud::param::grime
        };
        for (const auto* id : modulationIds)
            mutate(id, 0.25f);
    }

    if (! parameterLocked(mud::param::lockFx))
    {
        // Freeze (transform-panel Freeze and effects-panel Sp Freeze) is excluded from every
        // randomizer pass on purpose. It's a hold effect - once engaged it sustains audio
        // almost indefinitely - so it should only ever turn on when the player deliberately
        // reaches for that knob, never as a side effect of Randomize. Both freeze knobs stay
        // exactly where the player left them (0 unless they've touched it) through every
        // SAFE/WILD/MOD/FX randomization; factory patches that are built around freeze (e.g.
        // Freeze Frame Fault) still set it on load, since that's the player's own deliberate
        // choice to load that patch.
        const std::array<const char*, 13> effectIds {
            mud::param::chorusRate, mud::param::chorusDepth, mud::param::chorusMix,
            mud::param::delayType, mud::param::delayTime, mud::param::delayFeedback,
            mud::param::delayMix, mud::param::reverbType, mud::param::reverbSize,
            mud::param::reverbDamping, mud::param::reverbMix,
            mud::param::convolutionMix,
            mud::param::macroSpace
        };
        for (const auto* id : effectIds)
            mutate(id, 0.20f);

        // Randomizing delayFeedback/reverbSize/etc. can jump straight to a hot value while
        // the mix is already open. Without this, whatever was already circulating in the
        // delay/reverb buffers keeps recirculating at the new (possibly much higher)
        // feedback amount, producing a lingering build-up that previously only Bypass FX
        // could clear. Flushing here gives every FX randomization a clean start instead.
        effects.requestFlush();
    }

    setParameterNormalised(mud::param::randomSeed,
        static_cast<float>(generator() % 1000000u) / 999999.0f);
}

void RuFTraXMuDAudioProcessor::captureMutation()
{
    capturedMutation = parameters.copyState().createCopy();
}

bool RuFTraXMuDAudioProcessor::recallCapturedMutation()
{
    if (! capturedMutation.isValid())
        return false;
    parameters.replaceState(capturedMutation.createCopy());
    return true;
}

void RuFTraXMuDAudioProcessor::getStateInformation(juce::MemoryBlock& destination)
{
    auto state = parameters.copyState();
    state.setProperty("stateVersion", 6, nullptr);
    state.setProperty("factoryPatch",
                      currentFactoryPatch.load(std::memory_order_relaxed), nullptr);
    state.setProperty("sampleAPath", samplePaths[0], nullptr);
    state.setProperty("sampleBPath", samplePaths[1], nullptr);
    if (capturedMutation.isValid())
        if (const auto capturedXml = capturedMutation.createXml())
            state.setProperty("capturedMutation", capturedXml->toString(), nullptr);
    if (const auto xml = state.createXml())
        copyXmlToBinary(*xml, destination);
}

void RuFTraXMuDAudioProcessor::restoreSamplesFromState(const juce::ValueTree& state)
{
    const std::array<const char*, 2> properties { "sampleAPath", "sampleBPath" };
    for (int slot = 0; slot < 2; ++slot)
    {
        sampleStores[static_cast<std::size_t>(slot)].clear();
        samplePaths[static_cast<std::size_t>(slot)] =
            state.getProperty(properties[static_cast<std::size_t>(slot)]).toString();
        const juce::File sampleFile(samplePaths[static_cast<std::size_t>(slot)]);
        juce::String ignoredError;
        if (sampleFile.existsAsFile())
            sampleStores[static_cast<std::size_t>(slot)].loadFromFile(sampleFile, ignoredError);
    }
}

void RuFTraXMuDAudioProcessor::setStateInformation(const void* data, int size)
{
    if (data == nullptr || size <= 0)
        return;
    const auto xml = getXmlFromBinary(data, size);
    if (xml == nullptr)
        return;
    const auto state = juce::ValueTree::fromXml(*xml);
    if (! state.isValid() || state.getType() != parameters.state.getType())
        return;

    const auto stateVersion = static_cast<int>(state.getProperty("stateVersion", 1));
    parameters.replaceState(state);
    currentFactoryPatch.store(juce::jlimit(-1, getFactoryPatchNames().size() - 1,
        static_cast<int>(state.getProperty("factoryPatch", -1))),
        std::memory_order_relaxed);
    auto setActualValue = [this](const juce::String& id, float value)
    {
        if (auto* parameter = parameters.getParameter(id))
            parameter->setValueNotifyingHost(parameter->convertTo0to1(value));
    };

    if (stateVersion < 2)
    {
        const auto previousMaster = raw(parameters, mud::param::masterGain);
        setActualValue(mud::param::masterGain,
            juce::jlimit(-60.0f, 18.0f, previousMaster + 12.0f));
        setActualValue(mud::param::chorusMix, 0.0f);
        setActualValue(mud::param::delayMix, 0.0f);
        setActualValue(mud::param::reverbMix, 0.0f);
        setActualValue(mud::param::spectralFreeze, 0.0f);
        setActualValue(mud::param::convolutionMix, 0.0f);
        setActualValue(mud::param::macroSpace, 0.0f);
    }
    if (stateVersion < 4)
    {
        setActualValue(mud::param::phaseReverse, 0.0f);
        setActualValue(mud::param::tapeWobble, 0.0f);
    }
    if (stateVersion < 5)
        setActualValue(mud::param::synth2Wave, 0.0f);
    if (stateVersion < 6)
    {
        // keyLock must land OFF for any session saved before this feature existed - those
        // sessions were designed hearing every note they played, and silently snapping them
        // to a scale on load would change the sound of old work without the player asking.
        setActualValue(mud::param::keyRoot, 0.0f);
        setActualValue(mud::param::keyMode, 0.0f);
        setActualValue(mud::param::keyLock, 0.0f);
    }
    restoreSamplesFromState(state);
    capturedMutation = {};
    const auto capturedText = state.getProperty("capturedMutation").toString();
    if (capturedText.isNotEmpty())
        if (const auto capturedXml = juce::parseXML(capturedText))
            capturedMutation = juce::ValueTree::fromXml(*capturedXml);
}

juce::AudioProcessorValueTreeState::ParameterLayout
RuFTraXMuDAudioProcessor::createParameterLayout()
{
    std::vector<Parameter> layout;
    const std::array<juce::String, 4> sourceNames {
        "Synth 1", "Synth 2", "Sample A", "Sample B"
    };

    for (int source = 0; source < 4; ++source)
    {
        const auto prefix = sourceNames[static_cast<std::size_t>(source)] + " ";
        const auto defaultLevel = source == 0 ? -6.0f : (source == 1 ? -9.0f : -6.0f);
        layout.push_back(makeFloat(mud::param::source(source, "Level"),
                                   prefix + "Level", -60.0f, 6.0f, defaultLevel,
                                   0.01f, 1.0f, "dB"));
        layout.push_back(makeFloat(mud::param::source(source, "Pan"),
                                   prefix + "Pan", -1.0f, 1.0f, 0.0f));
        layout.push_back(makeFloat(mud::param::source(source, "Tune"),
                                   prefix + "Tune", -36.0f, 36.0f, 0.0f,
                                   1.0f, 1.0f, "st"));
        layout.push_back(makeFloat(mud::param::source(source, "Fine"),
                                   prefix + "Fine", -100.0f, 100.0f, 0.0f,
                                   0.1f, 1.0f, "ct"));
        layout.push_back(makeFloat(mud::param::source(source, "Attack"),
                                   prefix + "Attack", 0.001f, 8.0f, 0.01f,
                                   0.001f, 0.35f, "s"));
        layout.push_back(makeFloat(mud::param::source(source, "Decay"),
                                   prefix + "Decay", 0.001f, 8.0f, 0.24f,
                                   0.001f, 0.35f, "s"));
        layout.push_back(makeFloat(mud::param::source(source, "Sustain"),
                                   prefix + "Sustain", 0.0f, 1.0f, 0.80f));
        layout.push_back(makeFloat(mud::param::source(source, "Release"),
                                   prefix + "Release", 0.002f, 12.0f, 0.50f,
                                   0.001f, 0.35f, "s"));
        layout.push_back(makeFloat(mud::param::source(source, "HighPass"),
                                   prefix + "High Pass", 20.0f, 12000.0f, 20.0f,
                                   0.1f, 0.25f, "Hz"));
        layout.push_back(makeFloat(mud::param::source(source, "LowPass"),
                                   prefix + "Low Pass", 80.0f, 20000.0f, 20000.0f,
                                   0.1f, 0.25f, "Hz"));
        layout.push_back(makeBool(mud::param::source(source, "Mute"),
                                  prefix + "Mute", false));
        layout.push_back(makeBool(mud::param::source(source, "Solo"),
                                  prefix + "Solo", false));
    }

    {
        juce::StringArray rootChoices;
        for (const auto* name : mud::param::keyRootNames)
            rootChoices.add(name);
        layout.push_back(makeChoice(mud::param::keyRoot, "Key", rootChoices, 0));

        juce::StringArray modeChoices;
        for (const auto* name : mud::param::keyModeNames)
            modeChoices.add(name);
        layout.push_back(makeChoice(mud::param::keyMode, "Scale", modeChoices, 0));
    }
    layout.push_back(makeBool(mud::param::keyLock, "In Key", false));

    layout.push_back(makeFloat(mud::param::synth1Wave, "Wavetable Shape",
                               0.0f, 3.0f, 2.0f, 1.0f));
    layout.push_back(makeInt(mud::param::synth1Unison, "Wavetable Unison", 1, 7, 3));
    layout.push_back(makeFloat(mud::param::synth1Detune, "Wavetable Detune",
                               0.0f, 50.0f, 8.0f, 0.01f, 1.0f, "ct"));
    layout.push_back(makeFloat(mud::param::synth1Fold, "Wavetable Fold",
                               0.0f, 1.0f, 0.18f));
    layout.push_back(makeFloat(mud::param::synth2CarrierRatio, "FM Carrier Ratio",
                               0.125f, 8.0f, 1.0f, 0.001f, 0.45f));
    layout.push_back(makeFloat(mud::param::synth2ModRatio, "FM Modulator Ratio",
                               0.125f, 12.0f, 2.0f, 0.001f, 0.45f));
    layout.push_back(makeFloat(mud::param::synth2Index, "FM Index",
                               0.0f, 18.0f, 2.8f));
    layout.push_back(makeFloat(mud::param::synth2Feedback, "FM Feedback",
                               0.0f, 1.0f, 0.12f));

    for (int sample = 0; sample < 2; ++sample)
    {
        const juce::String prefix = sample == 0 ? "Sample A " : "Sample B ";
        layout.push_back(makeBool(mud::param::sample(sample, "Reverse"),
                                  prefix + "Reverse", false));
        layout.push_back(makeBool(mud::param::sample(sample, "Loop"),
                                  prefix + "Loop", true));
        layout.push_back(makeBool(mud::param::sample(sample, "Slice"),
                                  prefix + "Slice", false));
        layout.push_back(makeBool(mud::param::sample(sample, "Grain"),
                                  prefix + "Grain", false));
        layout.push_back(makeFloat(mud::param::sample(sample, "GrainSize"),
                                   prefix + "Grain Size", 0.0f, 1.0f, 0.35f));
        layout.push_back(makeFloat(mud::param::sample(sample, "Density"),
                                   prefix + "Density", 0.0f, 1.0f, 0.65f));
        layout.push_back(makeFloat(mud::param::sample(sample, "Scatter"),
                                   prefix + "Scatter", 0.0f, 1.0f, 0.15f));
        layout.push_back(makeFloat(mud::param::sample(sample, "Stretch"),
                                   prefix + "Stretch", 0.25f, 4.0f, 1.0f,
                                   0.001f, 0.5f, "x"));
    }

    layout.push_back(makeFloat(mud::param::morphX, "Morph X", 0.0f, 1.0f, 0.5f));
    layout.push_back(makeFloat(mud::param::morphY, "Morph Y", 0.0f, 1.0f, 0.5f));
    layout.push_back(makeChoice(mud::param::morphMode, "Morph Mode",
                                { "Vector", "Spectral", "Grain", "Harmonic" }, 0));
    layout.push_back(makeFloat(mud::param::motionRate, "Motion Rate",
                               0.005f, 20.0f, 0.22f, 0.001f, 0.35f, "Hz"));
    layout.push_back(makeFloat(mud::param::motionDepth, "Motion Depth", 0.0f, 1.0f, 0.0f));
    layout.push_back(makeFloat(mud::param::motionJitter, "Motion Jitter", 0.0f, 1.0f, 0.0f));

    const std::array<std::pair<const char*, const char*>, 10> mutationParameters {{
        { mud::param::density, "Density" }, { mud::param::scatter, "Scatter" },
        { mud::param::smear, "Smear" }, { mud::param::freeze, "Freeze" },
        { mud::param::shatter, "Shatter" }, { mud::param::stretch, "Stretch" },
        { mud::param::resonate, "Resonate" }, { mud::param::damage, "Damage" },
        { mud::param::smooth, "Smooth" }, { mud::param::grime, "Grime" }
    }};
    for (const auto& item : mutationParameters)
        layout.push_back(makeFloat(item.first, item.second, 0.0f, 1.0f,
                                   juce::String(item.first) == mud::param::stretch ? 0.25f : 0.0f));

    layout.push_back(makeFloat(mud::param::macroMorph, "Macro Morph", 0.0f, 1.0f, 0.5f));
    layout.push_back(makeFloat(mud::param::macroMotion, "Macro Motion", 0.0f, 1.0f, 0.0f));
    layout.push_back(makeFloat(mud::param::macroDamage, "Macro Damage", 0.0f, 1.0f, 0.0f));
    layout.push_back(makeFloat(mud::param::macroSpace, "Macro Space", 0.0f, 1.0f, 0.0f));

    layout.push_back(makeBool(mud::param::sequenceEnabled, "Mutation Sequencer", false));
    layout.push_back(makeChoice(mud::param::sequenceRate, "Sequence Rate",
                                { "1/1", "1/2", "1/4", "1/8", "1/16", "1/32" }, 4));
    layout.push_back(makeFloat(mud::param::sequenceDepth, "Sequence Depth", 0.0f, 1.0f, 0.5f));
    layout.push_back(makeChoice(mud::param::sequenceTarget, "Sequence Target",
                                { "Morph X", "Morph Y", "Axis Split", "Jitter" }, 0));
    for (int step = 0; step < 16; ++step)
        layout.push_back(makeFloat(mud::param::step(step),
                                   "Sequence Step " + juce::String(step + 1),
                                   -1.0f, 1.0f, step % 4 == 0 ? 0.75f : 0.0f));

    layout.push_back(makeFloat(mud::param::chorusRate, "Chorus Rate",
                               0.01f, 12.0f, 0.35f, 0.001f, 0.4f, "Hz"));
    layout.push_back(makeFloat(mud::param::chorusDepth, "Chorus Depth", 0.0f, 1.0f, 0.25f));
    layout.push_back(makeFloat(mud::param::chorusMix, "Chorus Mix", 0.0f, 1.0f, 0.0f));
    layout.push_back(makeChoice(mud::param::delayType, "Delay Type",
                                { "Digital", "Ping Pong", "Tape" }, 1));
    layout.push_back(makeFloat(mud::param::delayTime, "Delay Time",
                               0.005f, mud::param::maxDelayTimeSeconds, 0.375f, 0.001f, 0.45f, "s"));
    layout.push_back(makeFloat(mud::param::delayFeedback, "Delay Feedback", 0.0f, 0.96f, 0.32f));
    layout.push_back(makeFloat(mud::param::delayMix, "Delay Mix", 0.0f, 1.0f, 0.0f));
    layout.push_back(makeChoice(mud::param::reverbType, "Reverb Type",
                                { "Room", "Hall", "Plate", "Void" }, 1));
    layout.push_back(makeFloat(mud::param::reverbSize, "Reverb Size", 0.0f, 1.0f, 0.55f));
    layout.push_back(makeFloat(mud::param::reverbDamping, "Reverb Damping", 0.0f, 1.0f, 0.42f));
    layout.push_back(makeFloat(mud::param::reverbMix, "Reverb Mix", 0.0f, 1.0f, 0.0f));
    layout.push_back(makeFloat(mud::param::spectralFreeze, "Spectral Freeze", 0.0f, 1.0f, 0.0f));
    layout.push_back(makeFloat(mud::param::convolutionMix, "Convolution Mix", 0.0f, 1.0f, 0.0f));
    layout.push_back(makeFloat(mud::param::masterGain, "Master Gain",
                               -60.0f, 18.0f, 6.0f, 0.01f, 1.0f, "dB"));
    layout.push_back(makeBool(mud::param::limiterEnabled, "Limiter", true));
    layout.push_back(makeBool(mud::param::bypassAll, "Bypass Effects", false));

    layout.push_back(makeFloat(mud::param::chaosAmount, "Chaos Amount", 0.0f, 1.0f, 0.45f));
    layout.push_back(makeInt(mud::param::randomSeed, "Random Seed", 0, 999999, 314159));
    const std::array<std::pair<const char*, const char*>, 7> lockParameters {{
        { mud::param::lockSources, "Lock Sources" },
        { mud::param::lockPitch, "Lock Pitch" },
        { mud::param::lockRhythm, "Lock Rhythm" },
        { mud::param::lockFilter, "Lock Filter" },
        { mud::param::lockMod, "Lock Modulation" },
        { mud::param::lockFx, "Lock Effects" },
        { mud::param::lockMix, "Lock Mix" }
    }};
    for (const auto& item : lockParameters)
        layout.push_back(makeBool(item.first, item.second, false));

    // Append new master controls so existing host parameter indexes remain
    // unchanged for sessions created before v0.1.7.
    layout.push_back(makeBool(mud::param::phaseReverse,
                              "Master Phase Reverse", false));
    layout.push_back(makeBool(mud::param::tapeWobble,
                              "Master Tape Wobble", false));
    layout.push_back(makeChoice(mud::param::synth2Wave,
                                "FM Carrier Waveform",
                                { "Sine", "Triangle", "Saw", "Square" }, 0));

    return { layout.begin(), layout.end() };
}

juce::AudioProcessorEditor* RuFTraXMuDAudioProcessor::createEditor()
{
    return new RuFTraXMuDAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new RuFTraXMuDAudioProcessor();
}
