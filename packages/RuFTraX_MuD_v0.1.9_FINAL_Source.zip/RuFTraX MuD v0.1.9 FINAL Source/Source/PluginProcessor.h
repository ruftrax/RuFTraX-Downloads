#pragma once

#include <JuceHeader.h>
#include "DSP/EffectsRack.h"
#include "DSP/MuDVoice.h"
#include "DSP/SampleStore.h"
#include <array>
#include <atomic>

class RuFTraXMuDAudioProcessor final : public juce::AudioProcessor
{
private:
    juce::UndoManager undoManager { 2000 };

public:
    enum class MutationMode { safe, wild };

    RuFTraXMuDAudioProcessor();
    ~RuFTraXMuDAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 12.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Init MuD"; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    bool loadSample(int slot, const juce::File&, juce::String& error);
    void clearSample(int slot);
    std::shared_ptr<const mud::SampleAsset> getSample(int slot) const;
    juce::String getSampleDescription(int slot) const;
    juce::String getSampleTriggeredNoteDescription(int slot) const;

    void randomize(MutationMode);
    void applyFactoryPatch(int patchIndex);
    static juce::StringArray getFactoryPatchNames();
    int getCurrentFactoryPatch() const noexcept
    {
        return currentFactoryPatch.load(std::memory_order_relaxed);
    }
    void captureMutation();
    bool recallCapturedMutation();
    bool canRecallMutation() const noexcept { return capturedMutation.isValid(); }
    void undo() { undoManager.undo(); }
    void redo() { undoManager.redo(); }

    float getSourceLevel(int source) const noexcept;
    float getOutputLevel(int channel) const noexcept;
    float getEffectActivity(int effect) const noexcept;
    juce::String getMidiDisplayText() const;
    int getCurrentSequenceStep() const noexcept
    {
        return sequenceStep.load(std::memory_order_relaxed);
    }

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    juce::AudioProcessorValueTreeState parameters;

private:
    void cacheParameters();
    void updateRuntimeModulation(int numSamples);
    void updateMidiDisplay(const juce::MidiBuffer&);
    void restoreSamplesFromState(const juce::ValueTree&);
    void setParameterNormalised(const juce::String& id, float normalised);
    bool parameterLocked(const char* lockId) const;
    int getActiveMidiNote() const noexcept;

    std::array<mud::SampleStore, 2> sampleStores;
    std::array<juce::String, 2> samplePaths;
    mud::VoiceParameters voiceParameters;
    mud::SourceMeterBus sourceMeterBus;
    juce::Synthesiser synthesiser;
    mud::EffectsRack effects;
    juce::ValueTree capturedMutation;

    std::array<std::atomic<float>, 4> sourceLevels;
    std::array<std::atomic<float>, 2> outputLevels;
    std::array<std::atomic<bool>, 128> heldNotes;
    std::atomic<int> lastMidiNote { -1 };
    std::atomic<int> lastVelocity { 0 };
    std::atomic<float> currentPitchBendSemitones { 0.0f };
    std::atomic<int> sequenceStep { 0 };
    std::atomic<int> currentFactoryPatch { 0 };
    double currentSampleRate = 44100.0;
    double motionPhase = 0.0;
    double sequencePhase = 0.0;
    uint32_t modulationRandomState = 0x31415926u;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RuFTraXMuDAudioProcessor)
};
