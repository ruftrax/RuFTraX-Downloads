#include "MuDLookAndFeel.h"
#include <cmath>

namespace mud::ui
{
MuDLookAndFeel::MuDLookAndFeel()
{
    setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xff050806));
    setColour(juce::Slider::textBoxTextColourId, Colours::ivory());
    setColour(juce::Slider::textBoxOutlineColourId, Colours::brass().withAlpha(0.45f));
    setColour(juce::Label::textColourId, Colours::ivory());
    setColour(juce::ComboBox::backgroundColourId, Colours::screen());
    setColour(juce::ComboBox::textColourId, Colours::cyan());
    setColour(juce::ComboBox::outlineColourId, Colours::brass().withAlpha(0.7f));
    setColour(juce::ComboBox::arrowColourId, Colours::cyan());
    setColour(juce::PopupMenu::backgroundColourId, Colours::panel());
    setColour(juce::PopupMenu::textColourId, Colours::ivory());
    setColour(juce::PopupMenu::highlightedBackgroundColourId, Colours::brass());
    setColour(juce::PopupMenu::highlightedTextColourId, juce::Colours::black);
}

void MuDLookAndFeel::drawRotarySlider(juce::Graphics& graphics, int x, int y,
                                      int width, int height, float position,
                                      float startAngle, float endAngle,
                                      juce::Slider& slider)
{
    const auto diameter = static_cast<float>(juce::jmin(width, height)) * 0.76f;
    const auto centre = juce::Point<float>(static_cast<float>(x + width) * 0.5f,
                                           static_cast<float>(y + height) * 0.44f);
    const auto radius = diameter * 0.5f;
    const auto angle = startAngle + position * (endAngle - startAngle);
    const auto accent = slider.findColour(juce::Slider::rotarySliderFillColourId,
                                          true).isTransparent()
        ? Colours::cyan()
        : slider.findColour(juce::Slider::rotarySliderFillColourId, true);

    graphics.setColour(juce::Colours::black.withAlpha(0.72f));
    graphics.fillEllipse(centre.x - radius + 3.0f, centre.y - radius + 7.0f,
                         diameter, diameter);
    graphics.setColour(juce::Colour(0xff060806));
    graphics.fillEllipse(centre.x - radius - 2.0f, centre.y - radius - 2.0f,
                         diameter + 4.0f, diameter + 4.0f);

    juce::Path arc;
    arc.addCentredArc(centre.x, centre.y, radius + 3.0f, radius + 3.0f,
                      0.0f, startAngle, angle, true);
    graphics.setColour(accent.withAlpha(0.92f));
    graphics.strokePath(arc, juce::PathStrokeType(2.4f,
        juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::ColourGradient face(Colours::ivory().brighter(0.18f),
                              centre.x - radius * 0.45f, centre.y - radius * 0.55f,
                              Colours::brass().darker(0.2f),
                              centre.x + radius * 0.55f, centre.y + radius * 0.65f,
                              false);
    graphics.setGradientFill(face);
    graphics.fillEllipse(centre.x - radius * 0.78f, centre.y - radius * 0.78f,
                         radius * 1.56f, radius * 1.56f);
    graphics.setColour(juce::Colour(0xff4c351c));
    graphics.drawEllipse(centre.x - radius * 0.78f, centre.y - radius * 0.78f,
                         radius * 1.56f, radius * 1.56f, 1.5f);

    const auto pointerLength = radius * 0.58f;
    const auto pointer = juce::Point<float>(centre.x + std::sin(angle) * pointerLength,
                                            centre.y - std::cos(angle) * pointerLength);
    graphics.setColour(juce::Colour(0xff2b180d));
    graphics.drawLine(centre.x, centre.y, pointer.x, pointer.y,
                      juce::jmax(2.0f, radius * 0.09f));
}

void MuDLookAndFeel::drawButtonBackground(juce::Graphics& graphics,
                                          juce::Button& button,
                                          const juce::Colour& background,
                                          bool highlighted, bool down)
{
    auto bounds = button.getLocalBounds().toFloat().reduced(1.0f);
    auto colour = background.isTransparent() ? Colours::panelLight() : background;
    if (button.getToggleState())
        colour = button.findColour(juce::TextButton::buttonOnColourId, true);
    if (highlighted)
        colour = colour.brighter(0.12f);
    if (down)
        colour = colour.darker(0.18f);
    graphics.setColour(juce::Colours::black.withAlpha(0.6f));
    graphics.fillRoundedRectangle(bounds.translated(0.0f, 2.0f), 4.0f);
    graphics.setColour(colour);
    graphics.fillRoundedRectangle(bounds, 4.0f);
    graphics.setColour(button.getToggleState()
        ? button.findColour(juce::TextButton::textColourOnId, true).withAlpha(0.85f)
        : Colours::brass().withAlpha(0.8f));
    graphics.drawRoundedRectangle(bounds, 4.0f, 1.2f);
}

void MuDLookAndFeel::drawToggleButton(juce::Graphics& graphics,
                                      juce::ToggleButton& button,
                                      bool highlighted, bool down)
{
    auto bounds = button.getLocalBounds().toFloat().reduced(1.0f);
    auto colour = button.getToggleState() ? Colours::acid() : Colours::panelLight();
    if (highlighted)
        colour = colour.brighter(0.1f);
    if (down)
        colour = colour.darker(0.15f);
    graphics.setColour(colour.withAlpha(button.getToggleState() ? 0.38f : 1.0f));
    graphics.fillRoundedRectangle(bounds, 3.0f);
    graphics.setColour(button.getToggleState() ? Colours::acid() : Colours::brass());
    graphics.drawRoundedRectangle(bounds, 3.0f, 1.0f);
    graphics.setColour(button.getToggleState() ? juce::Colours::white : Colours::ivory());
    graphics.setFont(juce::FontOptions(10.0f, juce::Font::bold));
    graphics.drawText(button.getButtonText(), button.getLocalBounds(),
                      juce::Justification::centred);
}

void MuDLookAndFeel::drawComboBox(juce::Graphics& graphics, int width, int height,
                                  bool, int, int, int, int, juce::ComboBox&)
{
    auto bounds = juce::Rectangle<float>(0.0f, 0.0f,
                                         static_cast<float>(width),
                                         static_cast<float>(height)).reduced(1.0f);
    graphics.setColour(Colours::screen());
    graphics.fillRoundedRectangle(bounds, 4.0f);
    graphics.setColour(Colours::brass().withAlpha(0.75f));
    graphics.drawRoundedRectangle(bounds, 4.0f, 1.0f);
    juce::Path arrow;
    arrow.addTriangle(static_cast<float>(width - 17), static_cast<float>(height) * 0.40f,
                      static_cast<float>(width - 7), static_cast<float>(height) * 0.40f,
                      static_cast<float>(width - 12), static_cast<float>(height) * 0.65f);
    graphics.setColour(Colours::cyan());
    graphics.fillPath(arrow);
}

void MuDLookAndFeel::positionComboBoxText(juce::ComboBox& box, juce::Label& label)
{
    label.setBounds(7, 1, box.getWidth() - 28, box.getHeight() - 2);
    label.setFont(juce::FontOptions(11.0f, juce::Font::bold));
}
} // namespace mud::ui

