#pragma once

#include <JuceHeader.h>

namespace mud::ui
{
struct Colours
{
    static juce::Colour background() { return juce::Colour(0xff080a09); }
    static juce::Colour panel() { return juce::Colour(0xff171b18); }
    static juce::Colour panelLight() { return juce::Colour(0xff20251f); }
    static juce::Colour brass() { return juce::Colour(0xffb39a62); }
    static juce::Colour ivory() { return juce::Colour(0xffddcda8); }
    static juce::Colour cyan() { return juce::Colour(0xff33d6e7); }
    static juce::Colour violet() { return juce::Colour(0xffc36cff); }
    static juce::Colour amber() { return juce::Colour(0xffffb229); }
    static juce::Colour red() { return juce::Colour(0xffff4d3d); }
    static juce::Colour acid() { return juce::Colour(0xff71ee51); }
    static juce::Colour screen() { return juce::Colour(0xff021113); }
};

class MuDLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    MuDLookAndFeel();

    void drawRotarySlider(juce::Graphics&, int x, int y, int width, int height,
                          float sliderPos, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider&) override;
    void drawButtonBackground(juce::Graphics&, juce::Button&,
                              const juce::Colour&, bool highlighted,
                              bool down) override;
    void drawToggleButton(juce::Graphics&, juce::ToggleButton&,
                          bool highlighted, bool down) override;
    void drawComboBox(juce::Graphics&, int width, int height, bool down,
                      int buttonX, int buttonY, int buttonW, int buttonH,
                      juce::ComboBox&) override;
    void positionComboBoxText(juce::ComboBox&, juce::Label&) override;
};
} // namespace mud::ui

