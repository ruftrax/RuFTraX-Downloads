#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
SOURCE="$SCRIPT_DIR/Package/Source"
BUILD="$SOURCE/build-v5.5-distribution"
PRODUCTS="$BUILD/RuFTraXLogicChainer_artefacts/Release"
LOG="$HOME/Desktop/RuFTraX_Chainer_v5.5_Install.log"

APP_NAME="RuFTraX Plug-In Chainer.app"
AU_NAME="RuFTraX Plug-In Chainer.component"
VST3_NAME="RuFTraX Plug-In Chainer.vst3"

APP_SOURCE="$PRODUCTS/Standalone/$APP_NAME"
AU_SOURCE="$PRODUCTS/AU/$AU_NAME"
VST3_SOURCE="$PRODUCTS/VST3/$VST3_NAME"

APP_DEST="$HOME/Applications/$APP_NAME"
AU_DEST="$HOME/Library/Audio/Plug-Ins/Components/$AU_NAME"
VST3_DEST="$HOME/Library/Audio/Plug-Ins/VST3/$VST3_NAME"

BACKUP="$HOME/Library/Application Support/RuFTraX/Backups/Plug-In Chainer v5.5-$(date +%Y%m%d-%H%M%S)"

exec > >(tee "$LOG") 2>&1
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"

message()
{
    osascript -e "display dialog \"$1\" buttons {\"OK\"} default button \"OK\" with title \"RuFTraX Chainer Installer\"" >/dev/null
}

fail()
{
    echo
    echo "INSTALLATION STOPPED: $1"
    message "Installation stopped.\n\n$1\n\nDetails are on your Desktop in RuFTraX_Chainer_v5.5_Install.log."
    exit 1
}

echo "RuFTraX Plug-In Chainer v5.5 — AU / VST3 / Standalone"
echo

[[ -f "$SOURCE/CMakeLists.txt" ]] ||
    fail "The installer source package is incomplete."

if ! command -v cmake >/dev/null 2>&1; then
    if ! command -v brew >/dev/null 2>&1; then
        fail "CMake is required and Homebrew was not found."
    fi

    answer="$(osascript -e 'button returned of (display dialog "CMake is required to build the Chainer. Install it now with Homebrew?" buttons {"Cancel", "Install"} default button "Install" with title "RuFTraX Chainer Installer")')"
    [[ "$answer" == "Install" ]] ||
        fail "CMake was not installed."
    brew install cmake
fi

JUCE_PATH=""
for candidate in \
    "${JUCE_DIR:-}" \
    "/Volumes/2T BackUP/RuFTraX Projects/Logic Chainer/JUCE" \
    "$HOME/JUCE" \
    "$HOME/Downloads/JUCE"
do
    if [[ -n "$candidate" && -f "$candidate/CMakeLists.txt" ]]; then
        JUCE_PATH="$candidate"
        break
    fi
done

[[ -n "$JUCE_PATH" ]] ||
    fail "JUCE was not found. Place JUCE in Home/JUCE and run this installer again."

echo "JUCE:  $JUCE_PATH"
echo "CMake: $(command -v cmake)"
echo

chmod +x "$SOURCE/Scripts/validate_release_source.sh"
"$SOURCE/Scripts/validate_release_source.sh"

echo
echo "Building the final AU, VST3 and Standalone targets..."
cmake \
    -S "$SOURCE" \
    -B "$BUILD" \
    -DCMAKE_BUILD_TYPE=Release \
    -DJUCE_DIR="$JUCE_PATH"
cmake \
    --build "$BUILD" \
    --config Release \
    --parallel

for product in "$APP_SOURCE" "$AU_SOURCE" "$VST3_SOURCE"; do
    [[ -d "$product" ]] ||
        fail "A required build product is missing: ${product:t}"

    binary="$product/Contents/MacOS/RuFTraX Plug-In Chainer"
    [[ -f "$binary" ]] ||
        fail "A required executable is missing: $binary"

    file "$binary" | grep -q 'arm64' ||
        fail "The build is not Apple-silicon arm64: ${product:t}"

    xattr -cr "$product"
    codesign --force --deep --sign - "$product"
    codesign --verify --deep --strict "$product"
done

mkdir -p "$BACKUP"

for pair in \
    "$APP_DEST|Standalone" \
    "$AU_DEST|Audio Unit" \
    "$VST3_DEST|VST3"
do
    destination="${pair%%|*}"
    label="${pair#*|}"
    if [[ -d "$destination" ]]; then
        echo "Backing up existing $label..."
        ditto "$destination" "$BACKUP/${destination:t}"
    fi
done

mkdir -p \
    "$HOME/Applications" \
    "$HOME/Library/Audio/Plug-Ins/Components" \
    "$HOME/Library/Audio/Plug-Ins/VST3"

echo
echo "Installing Standalone application..."
ditto "$APP_SOURCE" "$APP_DEST"

echo "Installing Audio Unit..."
ditto "$AU_SOURCE" "$AU_DEST"

echo "Installing VST3..."
ditto "$VST3_SOURCE" "$VST3_DEST"

for product in "$APP_DEST" "$AU_DEST" "$VST3_DEST"; do
    codesign --verify --deep --strict "$product"
done

killall AudioComponentRegistrar 2>/dev/null || true

echo
echo "Validating the Logic Audio Unit..."
if ! auval -v aufx RfLC RfTx; then
    fail "Logic Audio Unit validation failed. The prior installed files are preserved in the dated backup."
fi

echo
echo "INSTALLATION AND AUDIO UNIT VALIDATION PASSED"
echo "Application: $APP_DEST"
echo "Audio Unit:  $AU_DEST"
echo "VST3:       $VST3_DEST"
echo "Backup:     $BACKUP"

open -R "$APP_DEST"
open "$APP_DEST"
message "RuFTraX Plug-In Chainer v5.5 is installed.\n\nStandalone, Audio Unit and VST3 are ready. The Standalone application is opening now."

