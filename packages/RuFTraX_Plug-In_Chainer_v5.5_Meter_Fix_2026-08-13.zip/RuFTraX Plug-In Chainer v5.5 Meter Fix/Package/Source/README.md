# RuFTraX Plug-In Chainer v5.5

Final Apple-silicon source for the eight-slot RuFTraX audio plug-in chainer.

## Formats

- Audio Unit for Logic Pro
- VST3 for compatible macOS DAWs
- Standalone application

AAX is intentionally excluded from this distribution.

## Final features

- Eight serial plug-in slots
- Audio Unit child plug-in hosting
- Per-slot enable, bypass, wet/dry, gain and pan
- Child plug-in editor windows
- Hard processor-level Bypass All
- Input and output gain
- Responsive stereo input/output LED metering with fast peak response and
  smooth release
- Save and restore of the chain, hosted plug-in descriptions and plug-in state
- Scalable classic console interface
- Stable `RfLC` / `RfTx` Audio Unit identifiers for Logic compatibility

## Build

JUCE and CMake are required:

```bash
export JUCE_DIR="$HOME/JUCE"
./build_mac.sh
```

The supported targets are generated in:

`build-v5.5-distribution/RuFTraXLogicChainer_artefacts/Release`

## Distribution status

The included one-click installer builds and installs the Standalone, AU and
VST3 formats for the current user. The local package uses ad-hoc signing.
Public distribution outside the developer Mac still requires an Apple
Developer ID certificate and notarization.
