#!/bin/zsh
set -euo pipefail

PROJECT="${0:A:h:h}"
CMAKE="$PROJECT/CMakeLists.txt"
PROCESSOR="$PROJECT/Source/PluginProcessor.cpp"
EDITOR="$PROJECT/Source/PluginEditor.cpp"
PROCESSOR_HEADER="$PROJECT/Source/PluginProcessor.h"
APP_ICON="$PROJECT/Assets/AppIcon.png"

fail()
{
    echo "VALIDATION FAILED: $1"
    exit 1
}

grep -q 'project(RuFTraX_PlugIn_Chainer VERSION 0.5.5)' "$CMAKE" ||
    fail "Version is not 0.5.5."
grep -q 'FORMATS AU VST3 Standalone' "$CMAKE" ||
    fail "The release formats are not AU, VST3 and Standalone."
grep -q 'PLUGIN_MANUFACTURER_CODE RfTx' "$CMAKE" ||
    fail "The locked manufacturer code changed."
grep -q 'PLUGIN_CODE RfLC' "$CMAKE" ||
    fail "The locked Audio Unit subtype changed."
[[ -s "$APP_ICON" ]] ||
    fail "The Finder application icon is missing."
grep -Fq 'ICON_BIG "${CMAKE_CURRENT_SOURCE_DIR}/Assets/AppIcon.png"' "$CMAKE" ||
    fail "The Finder application icon is not connected to the build."

if grep -Eqi 'RUFTRAX_BUILD_AAX|FORMATS.*AAX|AAX_CATEGORY|AAX_IDENTIFIER' \
    "$CMAKE"; then
    fail "AAX is still enabled in CMake."
fi

if grep -Eqi 'AAX|Pro Tools' "$EDITOR"; then
    fail "The release interface still advertises AAX or Pro Tools."
fi

grep -q 'AU + VST3 + STANDALONE' "$EDITOR" ||
    fail "The release format label is missing."
grep -q 'globalBypassRequested.load' "$PROCESSOR" ||
    fail "Processor-level Bypass All is missing."
grep -q 'updateMeterLevels(buffer, inputMeterLevels)' "$PROCESSOR" ||
    fail "Input metering is not connected to the audio input."
grep -q 'updateMeterLevels(buffer, outputMeterLevels)' "$PROCESSOR" ||
    fail "Output metering is not connected to the final audio output."
grep -q 'getInputMeterLevel' "$PROCESSOR_HEADER" "$EDITOR" ||
    fail "Input meter data is not exposed to the interface."
grep -q 'getOutputMeterLevel' "$PROCESSOR_HEADER" "$EDITOR" ||
    fail "Output meter data is not exposed to the interface."
grep -q 'startTimerHz(30)' "$EDITOR" ||
    fail "The meter refresh timer is not running at 30 Hz."
grep -q 'createPluginInstanceAsync' "$PROCESSOR" ||
    fail "Hosted Audio Unit creation is missing."
grep -q '"descriptionXml"' "$PROCESSOR" ||
    fail "Hosted plug-in description state is missing."
grep -q '"pluginState"' "$PROCESSOR" ||
    fail "Hosted plug-in state persistence is missing."

if grep -q 'scanAndAddFile' "$PROCESSOR" "$EDITOR"; then
    fail "The prohibited JUCE scanAndAddFile path returned."
fi

bypass_line="$(
    grep -n 'if (globalBypassRequested.load' "$PROCESSOR" |
    head -n 1 |
    cut -d: -f1
)"
input_gain_line="$(
    grep -n 'const float inputGain' "$PROCESSOR" |
    head -n 1 |
    cut -d: -f1
)"

if [[ -z "$bypass_line" || -z "$input_gain_line" ||
      "$bypass_line" -ge "$input_gain_line" ]]; then
    fail "Bypass All no longer runs before gain and hosted processing."
fi

echo "RuFTraX Plug-In Chainer v5.5 release-source validation passed."
