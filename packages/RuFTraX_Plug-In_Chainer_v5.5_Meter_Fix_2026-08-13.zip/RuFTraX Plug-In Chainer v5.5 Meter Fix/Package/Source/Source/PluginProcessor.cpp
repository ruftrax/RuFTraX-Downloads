#include "PluginProcessor.h"
#include "PluginEditor.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <exception>

#if JUCE_MAC
#include <AudioToolbox/AudioToolbox.h>
#include <CoreFoundation/CoreFoundation.h>
#endif

namespace
{
constexpr int slotCount = 8;
constexpr float meterReleaseSeconds = 0.30f;

bool isUsableEffect(const juce::PluginDescription& description)
{
    if (description.isInstrument)
        return false;

    if (description.name.containsIgnoreCase(
            "RuFTraX Logic Chainer")
        || description.name.containsIgnoreCase(
            "RuFTraX Plug-In Chainer"))
        return false;

    if (description.numInputChannels <= 0
        || description.numOutputChannels <= 0)
        return false;

    return true;
}
#if JUCE_MAC
juce::String fourCCToString(OSType value)
{
    char text[5]
    {
        static_cast<char>((value >> 24) & 0xff),
        static_cast<char>((value >> 16) & 0xff),
        static_cast<char>((value >> 8) & 0xff),
        static_cast<char>(value & 0xff),
        0
    };

    return juce::String::fromUTF8(text, 4);
}

juce::String audioUnitTypeLabel(OSType type)
{
    switch (type)
    {
        case kAudioUnitType_Effect:
            return "Effect";

        case kAudioUnitType_MusicEffect:
            return "MusicEffect";

        default:
            return "Effect";
    }
}

juce::String makeAudioUnitIdentifier(
    const AudioComponentDescription& description)
{
    return "AudioUnit:"
         + audioUnitTypeLabel(description.componentType)
         + "/"
         + fourCCToString(description.componentType)
         + ","
         + fourCCToString(description.componentSubType)
         + ","
         + fourCCToString(description.componentManufacturer);
}

juce::String copyAudioComponentName(AudioComponent component)
{
    CFStringRef componentName = nullptr;

    if (AudioComponentCopyName(component, &componentName) != noErr
        || componentName == nullptr)
        return {};

    char utf8[1024] {};

    const bool converted =
        CFStringGetCString(
            componentName,
            utf8,
            sizeof(utf8),
            kCFStringEncodingUTF8);

    CFRelease(componentName);

    return converted
        ? juce::String::fromUTF8(utf8)
        : juce::String();
}

juce::String formatAudioUnitVersion(UInt32 version)
{
    const auto major = (version >> 16) & 0xffff;
    const auto minor = (version >> 8) & 0xff;
    const auto patch = version & 0xff;

    return juce::String(major)
         + "."
         + juce::String(minor)
         + "."
         + juce::String(patch);
}

void addRegistryComponentsOfType(
    OSType componentType,
    juce::KnownPluginList& destination)
{
    AudioComponentDescription query {};
    query.componentType = componentType;
    query.componentSubType = 0;
    query.componentManufacturer = 0;
    query.componentFlags = 0;
    query.componentFlagsMask = 0;

    AudioComponent component = nullptr;

    while ((component = AudioComponentFindNext(
                component,
                &query)) != nullptr)
    {
        AudioComponentDescription componentDescription {};

        if (AudioComponentGetDescription(
                component,
                &componentDescription) != noErr)
            continue;

        const auto fullName =
            copyAudioComponentName(component).trim();

        if (fullName.isEmpty())
            continue;

        juce::String manufacturer;
        juce::String pluginName;

        const int separator =
            fullName.indexOfChar(':');

        if (separator >= 0)
        {
            manufacturer =
                fullName.substring(0, separator).trim();

            pluginName =
                fullName.substring(separator + 1).trim();
        }
        else
        {
            manufacturer =
                fourCCToString(
                    componentDescription.componentManufacturer);

            pluginName = fullName;
        }

        if (pluginName.isEmpty())
            pluginName = fullName;

        if (pluginName.containsIgnoreCase(
                "RuFTraX Logic Chainer")
            || pluginName.containsIgnoreCase(
                "RuFTraX Plug-In Chainer"))
            continue;

        juce::PluginDescription description;
        description.name = pluginName;
        description.descriptiveName = pluginName;
        description.manufacturerName = manufacturer;
        description.pluginFormatName = "AudioUnit";
        description.category =
            audioUnitTypeLabel(componentType);
        description.fileOrIdentifier =
            makeAudioUnitIdentifier(componentDescription);
        description.isInstrument = false;
        description.numInputChannels = 2;
        description.numOutputChannels = 2;
        description.uniqueId =
            description.fileOrIdentifier.hashCode();
        description.deprecatedUid = description.uniqueId;
        description.lastInfoUpdateTime =
            juce::Time::getCurrentTime();

        UInt32 version = 0;

        if (AudioComponentGetVersion(
                component,
                &version) == noErr)
        {
            description.version =
                formatAudioUnitVersion(version);
        }

        destination.addType(description);
    }
}
#endif

}

RuFTraXLogicChainerAudioProcessor::
RuFTraXLogicChainerAudioProcessor()
    : juce::AudioProcessor(
          BusesProperties()
              .withInput(
                  "Input",
                  juce::AudioChannelSet::stereo(),
                  true)
              .withOutput(
                  "Output",
                  juce::AudioChannelSet::stereo(),
                  true)),
      juce::Thread("RuFTraX Audio Unit Scanner"),
      apvts(*this, nullptr, "PARAMETERS",
            createParameterLayout())
{
    for (auto& generation : slotLoadGenerations)
        generation.store(0);

    for (auto& faulted : slotProcessingFaults)
        faulted.store(false);

    for (auto& level : inputMeterLevels)
        level.store(0.0f);

    for (auto& level : outputMeterLevels)
        level.store(0.0f);

    globalBypassRequested.store(
        apvts.getRawParameterValue("bypassAll")->load()
            >= 0.5f,
        std::memory_order_relaxed);
    apvts.addParameterListener("bypassAll", this);

    formatManager.addFormat(
        std::make_unique<juce::AudioUnitPluginFormat>());

    setScanStatus(
        scanNotStarted,
        "Click + INSERT to browse installed Audio Units.");
}

RuFTraXLogicChainerAudioProcessor::
~RuFTraXLogicChainerAudioProcessor()
{
    shuttingDown.store(true);
    apvts.removeParameterListener("bypassAll", this);

    {
        const juce::ScopedLock lock(asyncLifetime->lock);
        asyncLifetime->alive = false;
    }

    signalThreadShouldExit();
    stopThread(5000);
    releaseResources();

    const juce::SpinLock::ScopedLockType lock(
        hostedPluginLock);

    for (auto& plugin : hostedPlugins)
        plugin.reset();
}

juce::AudioProcessorValueTreeState::ParameterLayout
RuFTraXLogicChainerAudioProcessor::createParameterLayout()
{
    std::vector<
        std::unique_ptr<juce::RangedAudioParameter>>
        parameters;

    parameters.push_back(
        std::make_unique<juce::AudioParameterFloat>(
            "inputGain",
            "Input Gain",
            -24.0f,
            24.0f,
            0.0f));

    parameters.push_back(
        std::make_unique<juce::AudioParameterFloat>(
            "outputGain",
            "Output Gain",
            -24.0f,
            24.0f,
            0.0f));

    parameters.push_back(
        std::make_unique<juce::AudioParameterBool>(
            "bypassAll",
            "Bypass All",
            false));

    for (int slot = 0; slot < slotCount; ++slot)
    {
        const auto prefix =
            "slot" + juce::String(slot + 1);

        parameters.push_back(
            std::make_unique<juce::AudioParameterBool>(
                prefix + "Enabled",
                "Slot " + juce::String(slot + 1)
                    + " Enabled",
                false));

        parameters.push_back(
            std::make_unique<juce::AudioParameterBool>(
                prefix + "Bypass",
                "Slot " + juce::String(slot + 1)
                    + " Bypass",
                false));

        parameters.push_back(
            std::make_unique<juce::AudioParameterFloat>(
                prefix + "Mix",
                "Slot " + juce::String(slot + 1)
                    + " Mix",
                0.0f,
                1.0f,
                1.0f));

        parameters.push_back(
            std::make_unique<juce::AudioParameterFloat>(
                prefix + "Gain",
                "Slot " + juce::String(slot + 1)
                    + " Gain",
                -24.0f,
                24.0f,
                0.0f));

        parameters.push_back(
            std::make_unique<juce::AudioParameterFloat>(
                prefix + "Pan",
                "Slot " + juce::String(slot + 1)
                    + " Pan",
                -1.0f,
                1.0f,
                0.0f));
    }

    return { parameters.begin(), parameters.end() };
}

void RuFTraXLogicChainerAudioProcessor::prepareToPlay(
    double sampleRate,
    int samplesPerBlock)
{
    const double safeSampleRate =
        sampleRate > 0.0 ? sampleRate : 44100.0;

    const int safeBlockSize =
        juce::jmax(1, samplesPerBlock);

    currentSampleRate.store(safeSampleRate);
    currentBlockSize.store(safeBlockSize);

    dryBuffer.setSize(
        juce::jmax(2, getTotalNumOutputChannels()),
        safeBlockSize,
        false,
        false,
        true);

    const juce::SpinLock::ScopedLockType lock(
        hostedPluginLock);

    for (int slot = 0; slot < slotCount; ++slot)
    {
        auto& plugin = hostedPlugins[(size_t) slot];

        if (plugin != nullptr)
        {
            juce::String errorMessage;
            const bool prepared = prepareHostedPlugin(
                *plugin,
                pluginBuffers[(size_t) slot],
                errorMessage);

            slotProcessingFaults[(size_t) slot].store(!prepared);
        }
    }

    isPrepared.store(true);

    for (auto& level : inputMeterLevels)
        level.store(0.0f, std::memory_order_relaxed);

    for (auto& level : outputMeterLevels)
        level.store(0.0f, std::memory_order_relaxed);
}

void RuFTraXLogicChainerAudioProcessor::releaseResources()
{
    isPrepared.store(false);

    for (auto& level : inputMeterLevels)
        level.store(0.0f, std::memory_order_relaxed);

    for (auto& level : outputMeterLevels)
        level.store(0.0f, std::memory_order_relaxed);

    const juce::SpinLock::ScopedLockType lock(
        hostedPluginLock);

    for (auto& plugin : hostedPlugins)
    {
        if (plugin != nullptr)
            plugin->releaseResources();
    }

}

bool RuFTraXLogicChainerAudioProcessor::
isBusesLayoutSupported(
    const BusesLayout& layouts) const
{
    const auto output =
        layouts.getMainOutputChannelSet();

    const auto input =
        layouts.getMainInputChannelSet();

    if (output != juce::AudioChannelSet::mono()
        && output != juce::AudioChannelSet::stereo())
        return false;

    return input == output;
}

void RuFTraXLogicChainerAudioProcessor::processBlock(
    juce::AudioBuffer<float>& buffer,
    juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;

    for (int channel = getTotalNumInputChannels();
         channel < getTotalNumOutputChannels();
         ++channel)
    {
        buffer.clear(
            channel,
            0,
            buffer.getNumSamples());
    }

    // Capture the signal that reaches the Chainer before its input gain.
    updateMeterLevels(buffer, inputMeterLevels);

    // This is a hard, processor-level bypass.  It deliberately runs before
    // the input/output gains and before any hosted plug-in.  The original
    // host buffer therefore passes through untouched whenever the front-panel
    // switch, automation, or restored state requests Bypass All.
    if (globalBypassRequested.load(std::memory_order_relaxed))
    {
        updateMeterLevels(buffer, outputMeterLevels);
        return;
    }

    const float inputGain =
        juce::Decibels::decibelsToGain(
            apvts.getRawParameterValue(
                "inputGain")->load());

    const float outputGain =
        juce::Decibels::decibelsToGain(
            apvts.getRawParameterValue(
                "outputGain")->load());

    buffer.applyGain(inputGain);
    processHostedChain(buffer, midi);
    buffer.applyGain(outputGain);
    updateMeterLevels(buffer, outputMeterLevels);
}

void RuFTraXLogicChainerAudioProcessor::updateMeterLevels(
    const juce::AudioBuffer<float>& buffer,
    std::array<std::atomic<float>, 2>& meterLevels) noexcept
{
    const int sampleCount = buffer.getNumSamples();
    const int channelCount = buffer.getNumChannels();

    const double sampleRate =
        juce::jmax(1.0, currentSampleRate.load(
                             std::memory_order_relaxed));

    // Decay by 60 dB over the release time. New peaks always rise
    // immediately; silence falls smoothly instead of freezing the display.
    const float releaseMultiplier =
        std::pow(
            0.001f,
            (float) sampleCount
                / ((float) sampleRate * meterReleaseSeconds));

    for (int meterChannel = 0; meterChannel < 2; ++meterChannel)
    {
        float peak = 0.0f;

        if (channelCount > 0 && sampleCount > 0)
        {
            const int sourceChannel =
                juce::jmin(meterChannel, channelCount - 1);

            peak = buffer.getMagnitude(
                sourceChannel, 0, sampleCount);
        }

        const float previous =
            meterLevels[(size_t) meterChannel].load(
                std::memory_order_relaxed);

        meterLevels[(size_t) meterChannel].store(
            juce::jlimit(
                0.0f,
                4.0f,
                juce::jmax(peak, previous * releaseMultiplier)),
            std::memory_order_relaxed);
    }
}

float RuFTraXLogicChainerAudioProcessor::getInputMeterLevel(
    int channel) const noexcept
{
    if (!juce::isPositiveAndBelow(channel, 2))
        return 0.0f;

    return inputMeterLevels[(size_t) channel].load(
        std::memory_order_relaxed);
}

float RuFTraXLogicChainerAudioProcessor::getOutputMeterLevel(
    int channel) const noexcept
{
    if (!juce::isPositiveAndBelow(channel, 2))
        return 0.0f;

    return outputMeterLevels[(size_t) channel].load(
        std::memory_order_relaxed);
}

void RuFTraXLogicChainerAudioProcessor::
processHostedChain(
    juce::AudioBuffer<float>& buffer,
    juce::MidiBuffer& midi)
{
    if (buffer.getNumSamples()
        > dryBuffer.getNumSamples())
        return;

    const juce::SpinLock::ScopedTryLockType lock(
        hostedPluginLock);

    if (!lock.isLocked())
        return;

    for (int slot = 0; slot < slotCount; ++slot)
    {
        auto* plugin =
            hostedPlugins[(size_t) slot].get();

        if (plugin == nullptr)
            continue;

        if (slotProcessingFaults[(size_t) slot].load()
            || plugin->isSuspended())
            continue;

        const auto prefix =
            "slot" + juce::String(slot + 1);

        const bool enabled =
            apvts.getRawParameterValue(
                prefix + "Enabled")->load() >= 0.5f;

        const bool bypassed =
            apvts.getRawParameterValue(
                prefix + "Bypass")->load() >= 0.5f;

        if (!enabled || bypassed)
            continue;

        const int channels =
            juce::jmin(
                buffer.getNumChannels(),
                dryBuffer.getNumChannels());

        for (int channel = 0;
             channel < channels;
             ++channel)
        {
            dryBuffer.copyFrom(
                channel,
                0,
                buffer,
                channel,
                0,
                buffer.getNumSamples());
        }

        auto& pluginBuffer =
            pluginBuffers[(size_t) slot];

        const int pluginInputs =
            plugin->getTotalNumInputChannels();
        const int pluginOutputs =
            plugin->getTotalNumOutputChannels();
        const int requiredChannels =
            juce::jmax(pluginInputs, pluginOutputs);

        if (requiredChannels <= 0
            || pluginBuffer.getNumChannels() < requiredChannels
            || pluginBuffer.getNumSamples() < buffer.getNumSamples())
        {
            slotProcessingFaults[(size_t) slot].store(true);
            continue;
        }

        pluginBuffer.clear(0, buffer.getNumSamples());

        const int copiedInputs = juce::jmin(
            juce::jmin(buffer.getNumChannels(), pluginInputs),
            pluginBuffer.getNumChannels());

        for (int channel = 0; channel < copiedInputs; ++channel)
        {
            pluginBuffer.copyFrom(
                channel, 0,
                buffer, channel, 0,
                buffer.getNumSamples());
        }

        // Extra AU input buses (normally sidechains) remain silent.  The
        // hosted plug-in now receives the full number of channels it reports,
        // preventing multi-bus FabFilter/SSL Audio Units from reading beyond
        // Logic's stereo buffer.
        juce::AudioBuffer<float> processingBuffer(
            pluginBuffer.getArrayOfWritePointers(),
            requiredChannels,
            buffer.getNumSamples());

        try
        {
            plugin->setPlayHead(getPlayHead());
            plugin->processBlock(processingBuffer, midi);
        }
        catch (const std::exception&)
        {
            slotProcessingFaults[(size_t) slot].store(true);
            continue;
        }
        catch (...)
        {
            slotProcessingFaults[(size_t) slot].store(true);
            continue;
        }

        if (pluginOutputs <= 0)
            continue;

        for (int channel = 0;
             channel < buffer.getNumChannels();
             ++channel)
        {
            const int sourceChannel =
                juce::jmin(channel, pluginOutputs - 1);

            buffer.copyFrom(
                channel, 0,
                processingBuffer, sourceChannel, 0,
                buffer.getNumSamples());
        }

        const float mix =
            juce::jlimit(
                0.0f,
                1.0f,
                apvts.getRawParameterValue(
                    prefix + "Mix")->load());

        const float gain =
            juce::Decibels::decibelsToGain(
                apvts.getRawParameterValue(
                    prefix + "Gain")->load());

        const float pan =
            juce::jlimit(
                -1.0f,
                1.0f,
                apvts.getRawParameterValue(
                    prefix + "Pan")->load());

        float leftGain = gain;
        float rightGain = gain;

        if (pan > 0.0f)
            leftGain *= 1.0f - pan;
        else if (pan < 0.0f)
            rightGain *= 1.0f + pan;

        if (buffer.getNumChannels() > 0)
            buffer.applyGain(
                0,
                0,
                buffer.getNumSamples(),
                leftGain);

        if (buffer.getNumChannels() > 1)
            buffer.applyGain(
                1,
                0,
                buffer.getNumSamples(),
                rightGain);

        const float dryAmount = 1.0f - mix;

        for (int channel = 0;
             channel < channels;
             ++channel)
        {
            auto* wet =
                buffer.getWritePointer(channel);

            const auto* dry =
                dryBuffer.getReadPointer(channel);

            for (int sample = 0;
                 sample < buffer.getNumSamples();
                 ++sample)
            {
                wet[sample] =
                    wet[sample] * mix
                    + dry[sample] * dryAmount;
            }
        }
    }
}

bool RuFTraXLogicChainerAudioProcessor::
prepareHostedPlugin(
    juce::AudioPluginInstance& plugin,
    juce::AudioBuffer<float>& scratchBuffer,
    juce::String& errorMessage)
{
    try
    {
        const double sampleRate = currentSampleRate.load();
        const int blockSize = currentBlockSize.load();

        const auto originalLayout = plugin.getBusesLayout();
        auto requestedLayout = originalLayout;

        if (!requestedLayout.inputBuses.isEmpty())
        {
            requestedLayout.inputBuses.getReference(0) =
                getChannelLayoutOfBus(true, 0);

            for (int bus = 1;
                 bus < requestedLayout.inputBuses.size();
                 ++bus)
            {
                requestedLayout.inputBuses.getReference(bus) =
                    juce::AudioChannelSet::disabled();
            }
        }

        if (!requestedLayout.outputBuses.isEmpty())
        {
            requestedLayout.outputBuses.getReference(0) =
                getChannelLayoutOfBus(false, 0);

            for (int bus = 1;
                 bus < requestedLayout.outputBuses.size();
                 ++bus)
            {
                requestedLayout.outputBuses.getReference(bus) =
                    juce::AudioChannelSet::disabled();
            }
        }

        if (requestedLayout != originalLayout
            && !plugin.setBusesLayout(requestedLayout))
        {
            // Some Audio Units require their published layout.  Keep it and
            // provide enough scratch channels instead of forcing an unsafe
            // stereo configuration.
            plugin.setBusesLayout(originalLayout);
        }

        plugin.setProcessingPrecision(
            juce::AudioProcessor::singlePrecision);
        plugin.setNonRealtime(isNonRealtime());
        plugin.setRateAndBufferSizeDetails(sampleRate, blockSize);
        plugin.prepareToPlay(sampleRate, blockSize);

        const int pluginInputs =
            plugin.getTotalNumInputChannels();
        const int pluginOutputs =
            plugin.getTotalNumOutputChannels();

        if (pluginInputs <= 0 || pluginOutputs <= 0)
        {
            errorMessage =
                "The Audio Unit does not provide a usable audio layout.";
            plugin.releaseResources();
            return false;
        }

        const int scratchChannels = juce::jmax(
            juce::jmax(pluginInputs, pluginOutputs),
            juce::jmax(getTotalNumInputChannels(),
                       getTotalNumOutputChannels()));

        scratchBuffer.setSize(
            scratchChannels,
            blockSize,
            false,
            true,
            false);
        scratchBuffer.clear();
        errorMessage.clear();
        return true;
    }
    catch (const std::exception& exception)
    {
        errorMessage =
            "The Audio Unit could not be prepared: "
            + juce::String(exception.what());
    }
    catch (...)
    {
        errorMessage =
            "The Audio Unit could not be prepared safely.";
    }

    return false;
}

void RuFTraXLogicChainerAudioProcessor::
startAudioUnitScan()
{
    int expected = scanNotStarted;

    if (scanState.compare_exchange_strong(
            expected,
            scanRunning))
    {
        setScanStatus(
            scanRunning,
            "Scanning installed Audio Unit effects...");

        startThread();
    }
}

void RuFTraXLogicChainerAudioProcessor::run()
{
#if JUCE_MAC
    juce::KnownPluginList registryPlugins;

    // AudioComponentFindNext reads macOS's Audio Unit registry and metadata.
    // It does not instantiate each plug-in, so unlicensed products cannot
    // open activation windows merely because the browser is being populated.
    addRegistryComponentsOfType(
        kAudioUnitType_Effect,
        registryPlugins);

    if (threadShouldExit())
        return;

    addRegistryComponentsOfType(
        kAudioUnitType_MusicEffect,
        registryPlugins);

    if (threadShouldExit())
        return;

    registryPlugins.sort(
        juce::KnownPluginList::sortByManufacturer,
        true);

    const int pluginCount =
        registryPlugins.getNumTypes();

    {
        const juce::ScopedLock lock(
            pluginListLock);

        knownPlugins.clear();

        for (const auto& description :
             registryPlugins.getTypes())
        {
            knownPlugins.addType(description);
        }
    }

    if (pluginCount <= 0)
    {
        setScanStatus(
            scanFailed,
            "No Audio Unit effects are registered with macOS.");
        return;
    }

    setScanStatus(
        scanReady,
        juce::String(pluginCount)
            + " Audio Unit effects ready. "
              "No plug-ins were opened during discovery.");
#else
    setScanStatus(
        scanFailed,
        "Audio Unit browsing is available only on macOS.");
#endif
}

void RuFTraXLogicChainerAudioProcessor::
setScanStatus(
    ScanState state,
    const juce::String& message)
{
    {
        const juce::ScopedLock lock(
            pluginListLock);
        scanStatus = message;
    }

    scanState.store(state);
}

void RuFTraXLogicChainerAudioProcessor::
parameterChanged(
    const juce::String& parameterID,
    float newValue)
{
    if (parameterID == "bypassAll")
    {
        globalBypassRequested.store(
            newValue >= 0.5f,
            std::memory_order_relaxed);
    }
}

bool RuFTraXLogicChainerAudioProcessor::
isAudioUnitScanFinished() const noexcept
{
    const int state = scanState.load();

    return state == scanReady
        || state == scanFailed;
}

bool RuFTraXLogicChainerAudioProcessor::
didAudioUnitScanFail() const noexcept
{
    return scanState.load() == scanFailed;
}

juce::String RuFTraXLogicChainerAudioProcessor::
getAudioUnitScanStatus() const
{
    const juce::ScopedLock lock(
        pluginListLock);

    return scanStatus;
}

juce::Array<juce::PluginDescription>
RuFTraXLogicChainerAudioProcessor::
getAvailableAudioUnits() const
{
    const juce::ScopedLock lock(
        pluginListLock);

    return knownPlugins.getTypes();
}

void RuFTraXLogicChainerAudioProcessor::
loadAudioUnitInSlot(
    int slotIndex,
    const juce::PluginDescription& description,
    LoadCallback callback)
{
    if (!juce::isPositiveAndBelow(
            slotIndex,
            slotCount))
    {
        if (callback)
            callback(
                false,
                "Invalid slot number.");
        return;
    }

    const std::uint64_t loadGeneration =
        slotLoadGenerations[(size_t) slotIndex]
            .fetch_add(1)
        + 1;

    ChainSlot previousSlot;
    const auto lifetime = asyncLifetime;

    {
        const juce::ScopedLock lock(
            slotInfoLock);

        previousSlot = slots[(size_t) slotIndex];
        slots[(size_t) slotIndex].displayName =
            "Loading " + description.name + "...";
    }

    formatManager.createPluginInstanceAsync(
        description,
        currentSampleRate.load(),
        currentBlockSize.load(),
        [this,
         slotIndex,
         loadGeneration,
         lifetime,
         previousSlot,
         description,
         callback = std::move(callback)]
        (std::unique_ptr<juce::AudioPluginInstance>
             instance,
         const juce::String& errorMessage) mutable
        {
            const juce::ScopedLock lifetimeLock(
                lifetime->lock);

            if (!lifetime->alive)
                return;

            if (shuttingDown.load()
                || slotLoadGenerations[(size_t) slotIndex].load()
                    != loadGeneration)
                return;

            if (instance == nullptr)
            {
                {
                    const juce::ScopedLock lock(
                        slotInfoLock);

                    slots[(size_t) slotIndex] = previousSlot;
                }

                setBoolParameter(
                    slotParameterID(
                        slotIndex,
                        "Enabled"),
                    previousSlot.enabled);

                if (callback)
                {
                    callback(
                        false,
                        errorMessage.isNotEmpty()
                            ? errorMessage
                            : "The Audio Unit could not be loaded.");
                }

                return;
            }

            juce::AudioBuffer<float> newPluginBuffer;
            juce::String preparationError;

            if (!prepareHostedPlugin(
                    *instance,
                    newPluginBuffer,
                    preparationError))
            {
                {
                    const juce::ScopedLock lock(
                        slotInfoLock);
                    slots[(size_t) slotIndex] = previousSlot;
                }

                setBoolParameter(
                    slotParameterID(slotIndex, "Enabled"),
                    previousSlot.enabled);

                if (callback)
                {
                    callback(
                        false,
                        preparationError.isNotEmpty()
                            ? preparationError
                            : "The Audio Unit could not be prepared safely.");
                }

                return;
            }

            if (shuttingDown.load()
                || slotLoadGenerations[(size_t) slotIndex].load()
                    != loadGeneration)
            {
                instance->releaseResources();
                return;
            }

            HostedPluginPtr newPlugin(instance.release());
            HostedPluginPtr oldPlugin;

            {
                const juce::SpinLock::ScopedLockType lock(
                    hostedPluginLock);

                oldPlugin = std::move(
                    hostedPlugins[(size_t) slotIndex]);
                hostedPlugins[(size_t) slotIndex] =
                    std::move(newPlugin);
                pluginBuffers[(size_t) slotIndex] =
                    std::move(newPluginBuffer);
                slotProcessingFaults[(size_t) slotIndex]
                    .store(false);
            }

            if (oldPlugin != nullptr)
                oldPlugin->releaseResources();

            {
                const juce::ScopedLock lock(
                    slotInfoLock);

                auto& slot =
                    slots[(size_t) slotIndex];

                slot.enabled = true;
                slot.displayName =
                    description.name;
                slot.description =
                    description;
                slot.hasDescription = true;
            }

            setBoolParameter(
                slotParameterID(
                    slotIndex,
                    "Enabled"),
                true);

            setBoolParameter(
                slotParameterID(
                    slotIndex,
                    "Bypass"),
                false);

            if (callback)
            {
                callback(
                    true,
                    description.manufacturerName
                        + " - "
                        + description.name
                        + " loaded in Slot "
                        + juce::String(
                            slotIndex + 1)
                        + ".");
            }
        });
}

void RuFTraXLogicChainerAudioProcessor::
clearSlot(int slotIndex)
{
    if (!juce::isPositiveAndBelow(
            slotIndex,
            slotCount))
        return;

    slotLoadGenerations[(size_t) slotIndex]
        .fetch_add(1);

    HostedPluginPtr removedPlugin;

    {
        const juce::SpinLock::ScopedLockType lock(
            hostedPluginLock);

        removedPlugin = std::move(
            hostedPlugins[(size_t) slotIndex]);
        pluginBuffers[(size_t) slotIndex]
            .setSize(0, 0);
        slotProcessingFaults[(size_t) slotIndex]
            .store(false);
    }

    if (removedPlugin != nullptr)
        removedPlugin->releaseResources();

    {
        const juce::ScopedLock lock(
            slotInfoLock);

        slots[(size_t) slotIndex] = {};
    }

    setBoolParameter(
        slotParameterID(slotIndex, "Enabled"),
        false);

    setBoolParameter(
        slotParameterID(slotIndex, "Bypass"),
        false);
}

bool RuFTraXLogicChainerAudioProcessor::
isSlotEnabled(int slotIndex) const
{
    if (!juce::isPositiveAndBelow(
            slotIndex,
            slotCount))
        return false;

    const auto id =
        slotParameterID(slotIndex, "Enabled");

    return apvts.getRawParameterValue(id)->load()
        >= 0.5f;
}

bool RuFTraXLogicChainerAudioProcessor::
isSlotBypassed(int slotIndex) const
{
    if (!juce::isPositiveAndBelow(
            slotIndex,
            slotCount))
        return false;

    const auto id =
        slotParameterID(slotIndex, "Bypass");

    return apvts.getRawParameterValue(id)->load()
        >= 0.5f;
}

bool RuFTraXLogicChainerAudioProcessor::
isGlobalBypassed() const
{
    return globalBypassRequested.load(
        std::memory_order_relaxed);
}

void RuFTraXLogicChainerAudioProcessor::
setGlobalBypassed(bool shouldBypass)
{
    globalBypassRequested.store(
        shouldBypass,
        std::memory_order_relaxed);
    setBoolParameter("bypassAll", shouldBypass);
}

juce::String RuFTraXLogicChainerAudioProcessor::
getSlotDisplayName(int slotIndex) const
{
    if (!juce::isPositiveAndBelow(
            slotIndex,
            slotCount))
        return "<Empty Slot>";

    const juce::ScopedLock lock(
        slotInfoLock);

    return slots[(size_t) slotIndex].displayName;
}

RuFTraXLogicChainerAudioProcessor::HostedPluginPtr
RuFTraXLogicChainerAudioProcessor::
getHostedPluginHandle(int slotIndex) const
{
    if (!juce::isPositiveAndBelow(
            slotIndex,
            slotCount))
        return {};

    const juce::SpinLock::ScopedLockType lock(
        hostedPluginLock);

    return hostedPlugins[(size_t) slotIndex];
}

bool RuFTraXLogicChainerAudioProcessor::
applyHostedPluginState(
    int slotIndex,
    const juce::MemoryBlock& state)
{
    if (!juce::isPositiveAndBelow(slotIndex, slotCount)
        || state.getSize() == 0)
        return false;

    const juce::SpinLock::ScopedLockType lock(
        hostedPluginLock);

    auto& plugin = hostedPlugins[(size_t) slotIndex];

    if (plugin == nullptr)
        return false;

    try
    {
        plugin->setStateInformation(
            state.getData(),
            (int) state.getSize());
        return true;
    }
    catch (...)
    {
        slotProcessingFaults[(size_t) slotIndex].store(true);
        return false;
    }
}

void RuFTraXLogicChainerAudioProcessor::
setBoolParameter(
    const juce::String& parameterID,
    bool value)
{
    if (auto* parameter =
            apvts.getParameter(parameterID))
    {
        parameter->setValueNotifyingHost(
            value ? 1.0f : 0.0f);
    }
}

juce::String RuFTraXLogicChainerAudioProcessor::
slotParameterID(
    int slotIndex,
    const juce::String& suffix) const
{
    return "slot"
         + juce::String(slotIndex + 1)
         + suffix;
}

void RuFTraXLogicChainerAudioProcessor::
getStateInformation(
    juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    juce::ValueTree slotTree("Slots");

    const juce::SpinLock::ScopedTryLockType
        pluginLock(hostedPluginLock);

    for (int slotIndex = 0;
         slotIndex < slotCount;
         ++slotIndex)
    {
        juce::ValueTree slotState("Slot");
        slotState.setProperty(
            "index",
            slotIndex,
            nullptr);

        {
            const juce::ScopedLock lock(
                slotInfoLock);

            const auto& slot =
                slots[(size_t) slotIndex];

            slotState.setProperty(
                "name",
                slot.displayName,
                nullptr);

            if (slot.hasDescription)
            {
                if (auto xml =
                        slot.description.createXml())
                {
                    slotState.setProperty(
                        "descriptionXml",
                        xml->toString(
                            juce::XmlElement::
                                TextFormat()
                                    .singleLine()),
                        nullptr);
                }
            }
        }

        if (pluginLock.isLocked())
        {
            auto* plugin =
                hostedPlugins[
                    (size_t) slotIndex].get();

            if (plugin != nullptr)
            {
                juce::MemoryBlock pluginState;
                plugin->getStateInformation(
                    pluginState);

                slotState.setProperty(
                    "pluginState",
                    pluginState.toBase64Encoding(),
                    nullptr);
            }
        }

        slotTree.addChild(
            slotState,
            -1,
            nullptr);
    }

    state.addChild(
        slotTree,
        -1,
        nullptr);

    if (auto xml = state.createXml())
        copyXmlToBinary(*xml, destData);
}

void RuFTraXLogicChainerAudioProcessor::
setStateInformation(
    const void* data,
    int sizeInBytes)
{
    auto xmlState =
        getXmlFromBinary(
            data,
            sizeInBytes);

    if (xmlState == nullptr
        || !xmlState->hasTagName(
            apvts.state.getType()))
        return;

    auto state =
        juce::ValueTree::fromXml(
            *xmlState);

    auto slotsTree =
        state.getChildWithName("Slots");

    if (slotsTree.isValid())
        state.removeChild(
            slotsTree,
            nullptr);

    apvts.replaceState(state);
    globalBypassRequested.store(
        apvts.getRawParameterValue("bypassAll")->load()
            >= 0.5f,
        std::memory_order_relaxed);

    if (!slotsTree.isValid())
        return;

    for (int child = 0;
         child < slotsTree.getNumChildren();
         ++child)
    {
        auto slotState =
            slotsTree.getChild(child);

        const int slotIndex =
            (int) slotState.getProperty(
                "index",
                -1);

        if (!juce::isPositiveAndBelow(
                slotIndex,
                slotCount))
            continue;

        const auto descriptionText =
            slotState.getProperty(
                "descriptionXml")
                .toString();

        if (descriptionText.isEmpty())
            continue;

        auto descriptionXml =
            juce::parseXML(
                descriptionText);

        if (descriptionXml == nullptr)
            continue;

        juce::PluginDescription description;

        if (!description.loadFromXml(
                *descriptionXml))
            continue;

        const auto encodedState =
            slotState.getProperty(
                "pluginState")
                .toString();

        loadAudioUnitInSlot(
            slotIndex,
            description,
            [this,
             slotIndex,
             encodedState]
            (bool success,
             const juce::String&)
            {
                if (!success
                    || encodedState.isEmpty())
                    return;

                juce::MemoryBlock pluginState;

                if (!pluginState.fromBase64Encoding(
                        encodedState))
                    return;

                applyHostedPluginState(
                    slotIndex,
                    pluginState);
            });
    }
}

juce::AudioProcessorEditor*
RuFTraXLogicChainerAudioProcessor::createEditor()
{
    return new
        RuFTraXLogicChainerAudioProcessorEditor(
            *this);
}

juce::AudioProcessor* JUCE_CALLTYPE
createPluginFilter()
{
    return new
        RuFTraXLogicChainerAudioProcessor();
}
