#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include <array>
#include <atomic>
#include <cstdint>
#include <functional>
#include <memory>

struct ChainSlot
{
    bool enabled = false;
    juce::String displayName { "<Empty Slot>" };
    juce::PluginDescription description;
    bool hasDescription = false;
};

class RuFTraXLogicChainerAudioProcessor final
    : public juce::AudioProcessor,
      private juce::Thread,
      private juce::AudioProcessorValueTreeState::Listener
{
public:
    using LoadCallback =
        std::function<void(bool success, const juce::String& message)>;
    using HostedPluginPtr =
        std::shared_ptr<juce::AudioPluginInstance>;

    RuFTraXLogicChainerAudioProcessor();
    ~RuFTraXLogicChainerAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override
    {
        return "RuFTraX Plug-In Chainer";
    }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    void startAudioUnitScan();
    bool isAudioUnitScanFinished() const noexcept;
    bool didAudioUnitScanFail() const noexcept;
    juce::String getAudioUnitScanStatus() const;
    juce::Array<juce::PluginDescription> getAvailableAudioUnits() const;

    void loadAudioUnitInSlot(int slotIndex,
                             const juce::PluginDescription& description,
                             LoadCallback callback);

    void clearSlot(int slotIndex);

    bool isSlotEnabled(int slotIndex) const;
    bool isSlotBypassed(int slotIndex) const;
    bool isGlobalBypassed() const;
    void setGlobalBypassed(bool shouldBypass);
    juce::String getSlotDisplayName(int slotIndex) const;
    HostedPluginPtr getHostedPluginHandle(int slotIndex) const;
    bool applyHostedPluginState(int slotIndex,
                                const juce::MemoryBlock& state);

    float getInputMeterLevel(int channel) const noexcept;
    float getOutputMeterLevel(int channel) const noexcept;

    juce::AudioProcessorValueTreeState apvts;

private:
    struct AsyncLifetime
    {
        juce::CriticalSection lock;
        bool alive = true;
    };

    enum ScanState
    {
        scanNotStarted = 0,
        scanRunning,
        scanReady,
        scanFailed
    };

    juce::AudioProcessorValueTreeState::ParameterLayout
        createParameterLayout();

    void run() override;
    void parameterChanged(const juce::String& parameterID,
                          float newValue) override;
    void setScanStatus(ScanState state, const juce::String& message);

    void setBoolParameter(const juce::String& parameterID, bool value);
    juce::String slotParameterID(int slotIndex,
                                 const juce::String& suffix) const;

    bool prepareHostedPlugin(juce::AudioPluginInstance&,
                             juce::AudioBuffer<float>& scratchBuffer,
                             juce::String& errorMessage);
    void processHostedChain(juce::AudioBuffer<float>&,
                            juce::MidiBuffer&);
    void updateMeterLevels(
        const juce::AudioBuffer<float>& buffer,
        std::array<std::atomic<float>, 2>& meterLevels) noexcept;

    juce::AudioPluginFormatManager formatManager;
    juce::KnownPluginList knownPlugins;

    mutable juce::CriticalSection pluginListLock;
    mutable juce::CriticalSection slotInfoLock;
    mutable juce::SpinLock hostedPluginLock;

    std::array<ChainSlot, 8> slots;
    std::array<HostedPluginPtr, 8> hostedPlugins;
    std::array<juce::AudioBuffer<float>, 8> pluginBuffers;
    std::array<std::atomic<std::uint64_t>, 8>
        slotLoadGenerations {};
    std::array<std::atomic<bool>, 8>
        slotProcessingFaults {};

    juce::AudioBuffer<float> dryBuffer;
    std::atomic<bool> globalBypassRequested { false };

    std::array<std::atomic<float>, 2> inputMeterLevels {};
    std::array<std::atomic<float>, 2> outputMeterLevels {};

    std::atomic<int> scanState { scanNotStarted };
    juce::String scanStatus { "Audio Unit scan has not started." };

    std::atomic<bool> shuttingDown { false };
    std::shared_ptr<AsyncLifetime> asyncLifetime =
        std::make_shared<AsyncLifetime>();

    std::atomic<double> currentSampleRate { 44100.0 };
    std::atomic<int> currentBlockSize { 512 };
    std::atomic<bool> isPrepared { false };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(
        RuFTraXLogicChainerAudioProcessor)
};
