#!/bin/zsh
set -euo pipefail

if [[ -z "${JUCE_DIR:-}" || ! -f "$JUCE_DIR/CMakeLists.txt" ]]; then
    echo "Set JUCE_DIR to a valid JUCE source folder."
    echo "Example: export JUCE_DIR=\"$HOME/JUCE\""
    exit 1
fi

cmake \
    -S . \
    -B build-v5.5-distribution \
    -DCMAKE_BUILD_TYPE=Release \
    -DJUCE_DIR="$JUCE_DIR"

cmake \
    --build build-v5.5-distribution \
    --config Release \
    --parallel
