RuFTraX Plug-In Chainer v5.5
================================

Double-click:

    INSTALL_RUFTRAX_PLUGIN_CHAINER_V5.5.command

The installer builds and installs:

    • Standalone application
    • Audio Unit for Logic Pro
    • VST3 for compatible macOS DAWs

AAX is not included.

The installer automatically finds JUCE in the locations previously used by
RuFTraX, builds the final Apple-silicon version, backs up existing copies,
installs all three formats, validates the Logic Audio Unit and opens the
Standalone application.

This local package is ad-hoc signed. Public distribution on other Macs requires
Apple Developer ID signing and notarization.

