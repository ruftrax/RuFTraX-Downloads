# RuFTraX Plug-In Chainer v5.5 Distribution

Final version: 0.5.5  
Architecture: Apple silicon arm64  
Formats: Standalone, Audio Unit and VST3

## Included

- Eight serial Audio Unit hosting slots
- Per-slot enable, bypass, wet/dry, gain and pan
- Child plug-in editor windows
- Processor-level Bypass All
- Input and output gain
- Chain and hosted plug-in state restoration
- Scalable classic console interface
- Stable Logic identifiers `RfLC` and `RfTx`
- One-click build, backup, installation and Audio Unit validation

## Meter correction

- The input display now measures the stereo signal arriving from the host.
- The output display now measures the stereo signal after the eight-slot
  chain and output gain.
- Both displays use responsive 24-segment LED ladders with fast peak response
  and smooth release.
- Bypass All continues to meter the unprocessed signal at both input and
  output, so the displays never freeze when the chain is bypassed.

## Distribution correction

AAX and all AAX build settings are removed from this release. The visible
format label now reads `AU + VST3 + STANDALONE`.

## Validation status

The source validator confirms the locked version, supported formats, Logic
identifiers, processor-level Bypass All ordering, asynchronous hosted Audio Unit
creation, hosted plug-in state persistence and the absence of the prohibited
`scanAndAddFile` path.

The installer performs the final macOS build, arm64 inspection, ad-hoc signing,
signature verification and `auval -v aufx RfLC RfTx` validation.

Public distribution outside the developer Mac still requires Apple Developer
ID signing and notarization.
