#!/bin/bash
set -euo pipefail

INSTALLER_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_DIR="$INSTALLER_DIR/Source"
BUILD_DIR="$SOURCE_DIR/build-v1.3.0"
VERSION="1.3.0 FINAL"
LOG_FILE="$HOME/Desktop/RuFTraX_RM10_v1.3.0_FINAL_Install.log"

pause_on_exit() {
  local result=$?
  echo
  if [ "$result" -eq 0 ]; then
    echo "Installation completed successfully."
  else
    echo "Installation stopped with an error (code $result)."
    echo "Please send this log file for review:"
    echo "$LOG_FILE"
  fi
  echo
  read -r -n 1 -p "Press any key to close this window..." || true
  echo
  exit "$result"
}

trap pause_on_exit EXIT
exec > >(tee "$LOG_FILE") 2>&1

echo "RuFTraX RM-10 v$VERSION"
echo "Build and Install"
echo

if [ ! -x "$SOURCE_DIR/validate_release_source.sh" ]; then
  echo "Source validator is missing or is not executable."
  exit 1
fi

"$SOURCE_DIR/validate_release_source.sh"

JUCE_PATH=""
for candidate in \
  "${JUCE_DIR:-}" \
  "$HOME/JUCE" \
  "$HOME/Developer/JUCE" \
  "$HOME/SDKs/JUCE" \
  "/Applications/JUCE"; do
  if [ -n "$candidate" ] && [ -f "$candidate/CMakeLists.txt" ]; then
    JUCE_PATH="$candidate"
    break
  fi
done

if [ -z "$JUCE_PATH" ]; then
  echo "JUCE was not found."
  echo "Install JUCE in $HOME/JUCE or set JUCE_DIR before running this installer."
  exit 1
fi

if ! command -v cmake >/dev/null 2>&1; then
  echo "CMake is required. Install it, then run this installer again."
  exit 1
fi

if ! command -v codesign >/dev/null 2>&1; then
  echo "Apple command-line developer tools are required."
  exit 1
fi

export JUCE_DIR="$JUCE_PATH"

echo "JUCE: $JUCE_DIR"
echo "Build: $BUILD_DIR"
echo

cmake -S "$SOURCE_DIR" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD_DIR" --config Release --parallel

STANDALONE_SOURCE="$(find "$BUILD_DIR" -type d -name "RuFTraX RM-10.app" -print -quit)"
AU_SOURCE="$(find "$BUILD_DIR" -type d -name "RuFTraX RM-10.component" -print -quit)"

if [ -z "$STANDALONE_SOURCE" ] || [ ! -d "$STANDALONE_SOURCE" ]; then
  echo "The standalone application was not produced."
  exit 1
fi

if [ -z "$AU_SOURCE" ] || [ ! -d "$AU_SOURCE" ]; then
  echo "The Audio Unit component was not produced."
  exit 1
fi

USER_APPS_DIR="$HOME/Applications"
USER_AU_DIR="$HOME/Library/Audio/Plug-Ins/Components"
APP_DESTINATION="$USER_APPS_DIR/RuFTraX RM-10.app"
AU_DESTINATION="$USER_AU_DIR/RuFTraX RM-10.component"
BACKUP_DIR="$HOME/Documents/RuFTraX Install Backups/RM-10 $(date +%Y%m%d-%H%M%S)"

mkdir -p "$USER_APPS_DIR" "$USER_AU_DIR" "$BACKUP_DIR"

if [ -d "$APP_DESTINATION" ]; then
  echo "Backing up the previous standalone application..."
  mv "$APP_DESTINATION" "$BACKUP_DIR/"
fi

if [ -d "$AU_DESTINATION" ]; then
  echo "Backing up the previous Audio Unit..."
  mv "$AU_DESTINATION" "$BACKUP_DIR/"
fi

echo "Installing standalone application..."
ditto "$STANDALONE_SOURCE" "$APP_DESTINATION"

echo "Installing Audio Unit..."
ditto "$AU_SOURCE" "$AU_DESTINATION"

xattr -dr com.apple.quarantine "$APP_DESTINATION" 2>/dev/null || true
xattr -dr com.apple.quarantine "$AU_DESTINATION" 2>/dev/null || true

codesign --force --deep --sign - "$APP_DESTINATION"
codesign --force --deep --sign - "$AU_DESTINATION"

touch "$APP_DESTINATION" "$AU_DESTINATION"
killall -9 AudioComponentRegistrar 2>/dev/null || true

echo
echo "Installed:"
echo "  $APP_DESTINATION"
echo "  $AU_DESTINATION"
echo
echo "Previous versions, if present, were preserved in:"
echo "  $BACKUP_DIR"
echo
echo "Opening the standalone RM-10..."
open "$APP_DESTINATION"
