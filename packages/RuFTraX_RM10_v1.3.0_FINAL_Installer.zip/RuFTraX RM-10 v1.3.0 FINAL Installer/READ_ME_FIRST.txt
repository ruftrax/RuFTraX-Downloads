RUFTRAX RM-10 v1.3.0 FINAL
==========================

This release upgrades RM-10 with:

1. Track names that automatically follow the sample most recently loaded.
2. Sequence lengths of 8, 16, 24, 32, 40, 48, 56, or 64 steps.
3. A separate SHOW selector for 8 or 16 visible steps and page arrows.
4. A Reverse button for every Bank A and Bank B sample.
5. A high-pass and low-pass filter for every Bank A and Bank B sample.
6. Full state saving for the new controls, 64-step patterns, and track names.
7. A dedicated RM-10 Finder icon matching the RuFTraX app family.

INSTALL
-------

1. Keep this entire installer folder together.
2. Double-click INSTALL_RUFTRAX_RM10_V1.3.command.
3. The installer builds and installs both:
   - Standalone: ~/Applications/RuFTraX RM-10.app
   - Audio Unit: ~/Library/Audio/Plug-Ins/Components/RuFTraX RM-10.component
4. The standalone opens automatically after installation.

REQUIREMENTS
------------

- macOS
- JUCE in ~/JUCE (or JUCE_DIR set to its location)
- CMake 3.22 or newer
- Apple command-line developer tools

TEST CHECKLIST
--------------

- Load a sample in Bank A and Bank B and confirm the track label changes.
- Confirm REV works independently for A and B.
- Sweep HPF and LPF independently for A and B.
- Select each sequence length from 8 through 64.
- Switch SHOW between 8 and 16 and use the page arrows.
- Save and reopen a Logic project to confirm state recall.
- Confirm the standalone application and Logic Audio Unit both open.

The installer preserves any previous RM-10 app and component in:
~/Documents/RuFTraX Install Backups/
