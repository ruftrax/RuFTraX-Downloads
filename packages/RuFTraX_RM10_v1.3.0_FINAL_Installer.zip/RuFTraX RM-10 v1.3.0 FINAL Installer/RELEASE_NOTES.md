# RuFTraX RM-10 v1.3.0 FINAL

This release expands the sequencer from 16 to 64 steps while retaining compatibility with existing 16-step RM-10 states.

## New

- Dynamic track labels derived from loaded sample names.
- Selectable pattern length: 8, 16, 24, 32, 40, 48, 56, or 64.
- Selectable 8-step or 16-step sequencer view with page navigation.
- Independent reverse playback for all 20 sample layers.
- Independent high-pass and low-pass filtering for all 20 sample layers.
- 64-step pattern, track-name, and new parameter state persistence.
- Dedicated Finder icon.

## Preserved

- Bank A and Bank B dual-layer playback.
- MIDI notes 36-45.
- Closed/open hi-hat choke behavior.
- Auto-preview, drag and drop, Bank A user defaults, swing, tempo, master output, and scalable UI.
- Standalone and Audio Unit formats.
