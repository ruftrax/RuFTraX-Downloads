# RuFTraX RM-10 v1.3.0 FINAL

This release expands the sequencer from 16 to 64 steps while retaining compatibility with existing 16-step RM-10 states.

## 2026-08-19 update

- **40 built-in genre patterns.** A new PRESET menu holds 5 hand-programmed grooves each for Hip-Hop, Trap, Pop, House, R&B, Afrobeats, Reggaeton, and Drum & Bass. Selecting one loads its 16-step pattern plus suggested tempo/swing.
- **Genre-matched preset kits autoload.** Each preset also swaps in a real acoustic drum kit sampled from a Roland SR-JV80-10 expansion board, matched to the genre by actual signal character (e.g. Trap uses the deepest/boomiest kick of the eight kits, House uses the tightest/punchiest). Picking a pattern always plays with the right kit, no manual sample loading required.
- **RANDOM button.** Fills the pattern with a fresh, weighted random groove (kick/snare biased toward strong beats, hats busy, toms/cymbals sparse) instead of the usual manual step editing.
- **Space bar toggles play/stop**, from anywhere in the window - clicking any pad or button no longer steals the shortcut.
- Fixed: knob value readouts (Vol/Pan/Drive/HPF/LPF) were getting cut off ("2...", "-...") at default view sizes; the label font now sizes to the readout box instead of using an oversized default.
- Fixed: a reused voice slot could deallocate its previous sample buffer on the audio thread when rapidly re-triggering a pad, risking an audio-thread stall; sample cleanup is now deferred to a low-rate background timer.
- Fixed: "Save Bank A as Default" only ever persisted Layer A (Bank B) - a layered default kit would silently lose its second layer on relaunch.
- Fixed: a deprecated JUCE XML iteration API in the bank-loading path.
- Fixed: the source-tree ASCII/mojibake contract check silently never ran on stock macOS (`grep -P` unsupported); it now works on both BSD and GNU `grep` and actually catches violations.

## New

- Dynamic track labels derived from loaded sample names.
- Selectable pattern length: 8, 16, 24, 32, 40, 48, 56, or 64.
- Selectable 8-step or 16-step sequencer view with page navigation.
- Independent reverse playback for all 20 sample layers.
- Independent high-pass and low-pass filtering for all 20 sample layers.
- 64-step pattern, track-name, and new parameter state persistence.
- Dedicated Finder icon.

## Preserved

- Bank A and Bank B dual-layer playback.
- MIDI notes 36-45.
- Closed/open hi-hat choke behavior.
- Auto-preview, drag and drop, Bank A user defaults, swing, tempo, master output, and scalable UI.
- Standalone and Audio Unit formats.
