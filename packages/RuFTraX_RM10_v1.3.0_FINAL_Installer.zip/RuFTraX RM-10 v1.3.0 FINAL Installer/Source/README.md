# RuFTraX RM-10 v1.3.0

RuFTraX RM-10 is a ten-track, dual-layer vintage rhythm machine for macOS. It builds as both a standalone application and an Audio Unit instrument for Logic Pro.

## v1.3.0 upgrade

- Track names automatically follow the most recently loaded sample.
- Sequence lengths of 8, 16, 24, 32, 40, 48, 56, or 64 steps.
- Choose 8 or 16 visible steps and move between pages with the arrow controls.
- Independent Reverse controls for Bank A and Bank B on every track.
- Independent high-pass and low-pass filters for both sample layers on every track.
- All new settings, 64-step patterns, sample paths, and dynamic track names are saved in plug-in state.
- Existing 16-step RM-10 sessions remain compatible.

## Existing features retained

- Ten MIDI-triggered tracks beginning at MIDI note 36.
- Dual sample layers (Bank A and Bank B) per track.
- Per-layer volume, pan, drive, tune, and sample loading.
- Closed/open hi-hat choke behavior.
- Swing, tempo, master output, auto-preview, drag and drop, and user Bank A defaults.
- Scalable interface with Fit Screen, 50%, 67%, 75%, and 100% views.

## Build on macOS

JUCE 8, CMake 3.22 or newer, and Xcode command-line tools are required.

```bash
export JUCE_DIR="$HOME/JUCE"
chmod +x build_mac.sh
./build_mac.sh
```

The build creates `RuFTraX RM-10.app` and `RuFTraX RM-10.component`.
