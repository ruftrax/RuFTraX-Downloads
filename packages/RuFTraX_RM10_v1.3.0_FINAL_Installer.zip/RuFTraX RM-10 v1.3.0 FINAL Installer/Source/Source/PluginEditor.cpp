#include "PluginEditor.h"
#include "PresetPatterns.h"
#include <cmath>

namespace
{
juce::Colour greenPanel(0xff243b2d);
juce::Colour greenDark(0xff101a14);
juce::Colour lime(0xffa9dd72);
juce::Colour amber(0xffffb84d);
juce::Colour cream(0xffe8dfbd);

}

GreenLookAndFeel::GreenLookAndFeel()
{
    setColour(juce::Label::textColourId, cream);
    setColour(juce::Slider::textBoxTextColourId, cream);
    setColour(juce::Slider::textBoxBackgroundColourId, greenDark);
    setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    setColour(juce::ComboBox::backgroundColourId, greenDark);
    setColour(juce::ComboBox::textColourId, cream);
    setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff718a74));
    setColour(juce::PopupMenu::backgroundColourId, greenDark);
    setColour(juce::PopupMenu::textColourId, cream);
    setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff4d6754));
}

void GreenLookAndFeel::drawButtonBackground(juce::Graphics& g, juce::Button& button,
                                             const juce::Colour&, bool highlighted, bool down)
{
    auto bounds = button.getLocalBounds().toFloat().reduced(1.0f);
    const bool active = button.getToggleState();

    auto top = active ? amber : juce::Colour(0xff4d6754);
    auto bottom = active ? juce::Colour(0xff9b5a17) : juce::Colour(0xff25362b);

    if (down)
    {
        top = top.darker(0.25f);
        bottom = bottom.darker(0.25f);
    }

    juce::ColourGradient gradient(top, bounds.getCentreX(), bounds.getY(),
                                  bottom, bounds.getCentreX(), bounds.getBottom(), false);
    g.setGradientFill(gradient);
    g.fillRoundedRectangle(bounds, juce::jmax(2.0f, bounds.getHeight() * 0.12f));

    g.setColour(active ? amber.brighter(0.4f) : juce::Colour(0xff718a74));
    g.drawRoundedRectangle(bounds, juce::jmax(2.0f, bounds.getHeight() * 0.12f),
                           highlighted ? 2.0f : 1.0f);
}

juce::Font GreenLookAndFeel::getTextButtonFont(juce::TextButton&, int buttonHeight)
{
    return juce::Font(juce::FontOptions(
        juce::jmax(7.0f, (float) buttonHeight * 0.38f), juce::Font::bold));
}

juce::Font GreenLookAndFeel::getComboBoxFont(juce::ComboBox& box)
{
    return juce::Font(juce::FontOptions(
        juce::jmax(8.0f, (float) box.getHeight() * 0.42f), juce::Font::bold));
}

juce::Font GreenLookAndFeel::getLabelFont(juce::Label& label)
{
    // Most of the app's own Labels call setFont() explicitly and never reach
    // this; the ones that land here are the slider value-text-boxes, sized
    // to whatever box height this particular knob was given.
    return juce::Font(juce::FontOptions(
        juce::jlimit(7.0f, 13.0f, (float) label.getHeight() * 0.62f), juce::Font::bold));
}

void GreenLookAndFeel::drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                                        float position, float startAngle, float endAngle,
                                        juce::Slider&)
{
    const float size = (float) juce::jmin(width, juce::jmax(1, height - 18));
    auto bounds = juce::Rectangle<float>((float) x, (float) y, (float) width, size)
                      .withSizeKeepingCentre(size, size)
                      .reduced(juce::jmax(2.0f, size * 0.09f));

    g.setColour(juce::Colours::black.withAlpha(0.55f));
    g.fillEllipse(bounds.translated(2.0f, 3.0f));

    juce::ColourGradient gradient(juce::Colour(0xffd8d0ae), bounds.getCentreX(), bounds.getY(),
                                  juce::Colour(0xff80785c), bounds.getCentreX(), bounds.getBottom(),
                                  false);
    g.setGradientFill(gradient);
    g.fillEllipse(bounds);

    const float angle = startAngle + position * (endAngle - startAngle);
    juce::Path marker;
    marker.addRoundedRectangle(-2.0f, -bounds.getHeight() * 0.35f,
                               4.0f, bounds.getHeight() * 0.28f, 2.0f);
    g.setColour(greenDark);
    g.fillPath(marker, juce::AffineTransform::rotation(angle)
                             .translated(bounds.getCentreX(), bounds.getCentreY()));
}


RM10SamplePreview::RM10SamplePreview(
    RuFTraXGreenDrumAudioProcessor& p)
    : processor(p)
{
    formats.registerBasicFormats();

    setSize(300, 150);

    heading.setText("AUTO PREVIEW", juce::dontSendNotification);
    heading.setJustificationType(juce::Justification::centred);
    heading.setFont(juce::Font(juce::FontOptions(16.0f, juce::Font::bold)));
    heading.setColour(juce::Label::textColourId, lime);

    fileName.setText("Select an audio file", juce::dontSendNotification);
    fileName.setJustificationType(juce::Justification::centred);
    fileName.setColour(juce::Label::textColourId, cream);

    details.setText(
        "Click a sound to hear it before loading.",
        juce::dontSendNotification);
    details.setJustificationType(juce::Justification::centred);
    details.setColour(
        juce::Label::textColourId,
        cream.withAlpha(0.78f));

    addAndMakeVisible(heading);
    addAndMakeVisible(fileName);
    addAndMakeVisible(details);
}

RM10SamplePreview::~RM10SamplePreview()
{
    processor.stopPreview();
}

void RM10SamplePreview::selectedFileChanged(
    const juce::File& selectedFile)
{
    processor.stopPreview();

    if (!selectedFile.existsAsFile()
        || !selectedFile.hasFileExtension(
            "wav;aif;aiff;flac;mp3"))
    {
        fileName.setText(
            "Select an audio file",
            juce::dontSendNotification);
        details.setText(
            "Click a sound to hear it before loading.",
            juce::dontSendNotification);
        return;
    }

    std::unique_ptr<juce::AudioFormatReader> reader(
        formats.createReaderFor(selectedFile));

    fileName.setText(
        selectedFile.getFileName(),
        juce::dontSendNotification);

    if (reader == nullptr)
    {
        details.setText(
            "This file could not be previewed.",
            juce::dontSendNotification);
        return;
    }

    const double seconds = reader->sampleRate > 0.0
                         ? (double) reader->lengthInSamples
                               / reader->sampleRate
                         : 0.0;

    details.setText(
        juce::String((int) std::round(reader->sampleRate))
            + " Hz  |  "
            + juce::String((int) reader->bitsPerSample)
            + "-bit  |  "
            + juce::String(seconds, 2)
            + " sec  |  AUTOPLAY",
        juce::dontSendNotification);

    processor.previewSample(selectedFile);
}

void RM10SamplePreview::paint(juce::Graphics& g)
{
    g.fillAll(greenDark);
    auto bounds = getLocalBounds().toFloat().reduced(4.0f);

    g.setColour(juce::Colour(0xff718a74));
    g.drawRoundedRectangle(bounds, 5.0f, 1.0f);

    g.setColour(amber.withAlpha(0.18f));
    g.fillRoundedRectangle(
        bounds.reduced(8.0f).removeFromBottom(34.0f),
        4.0f);
}

void RM10SamplePreview::resized()
{
    auto area = getLocalBounds().reduced(10);
    heading.setBounds(area.removeFromTop(30));
    area.removeFromTop(8);
    fileName.setBounds(area.removeFromTop(34));
    details.setBounds(area.removeFromTop(42));
}

RuFTraXGreenDrumAudioProcessorEditor::RuFTraXGreenDrumAudioProcessorEditor(
    RuFTraXGreenDrumAudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    setLookAndFeel(&look);
    setResizable(false, false);

    // Let Space toggle play/stop from anywhere in the window (see
    // keyPressed() below). Buttons default to wanting keyboard focus so
    // Space/Return re-triggers whatever was last clicked; every plain click
    // button in this editor gets setWantsKeyboardFocus(false) below so focus
    // always stays here instead.
    setWantsKeyboardFocus(true);

    title.setText("RuFTraX  RM-10", juce::dontSendNotification);
    title.setColour(juce::Label::textColourId, lime);

    subtitle.setText("VINTAGE RHYTHM MACHINE  |  10 DUAL-LAYER TRACKS  |  64-STEP SEQUENCER",
                     juce::dontSendNotification);

    midiLabel.setText("MIDI", juce::dontSendNotification);
    midiLabel.setJustificationType(juce::Justification::centred);

    viewSizeLabel.setText("VIEW SIZE", juce::dontSendNotification);
    viewSizeLabel.setJustificationType(juce::Justification::centredRight);

    viewSize.addItem("Fit Screen", 1);
    viewSize.addItem("50%", 2);
    viewSize.addItem("67%", 3);
    viewSize.addItem("75%", 4);
    viewSize.addItem("100%", 5);

    sequenceLengthLabel.setText("LENGTH", juce::dontSendNotification);
    sequenceLengthLabel.setJustificationType(juce::Justification::centredRight);
    for (int length : { 8, 16, 24, 32, 40, 48, 56, 64 })
        sequenceLength.addItem(juce::String(length), sequenceLength.getNumItems() + 1);

    displayedStepsLabel.setText("SHOW", juce::dontSendNotification);
    displayedStepsLabel.setJustificationType(juce::Justification::centredRight);
    displayedSteps.addItem("8", 1);
    displayedSteps.addItem("16", 2);

    pageLabel.setJustificationType(juce::Justification::centred);

    addAndMakeVisible(title);
    addAndMakeVisible(subtitle);
    addAndMakeVisible(midiLabel);
    addAndMakeVisible(viewSizeLabel);
    addAndMakeVisible(viewSize);
    addAndMakeVisible(sequenceLengthLabel);
    addAndMakeVisible(sequenceLength);
    addAndMakeVisible(displayedStepsLabel);
    addAndMakeVisible(displayedSteps);
    addAndMakeVisible(previousPage);
    addAndMakeVisible(nextPage);
    addAndMakeVisible(pageLabel);
    addAndMakeVisible(play);
    addAndMakeVisible(stop);
    addAndMakeVisible(clear);
    addAndMakeVisible(randomize);
    addAndMakeVisible(saveDefaultA);
    addAndMakeVisible(defaultStatus);

    for (auto* button : { &previousPage, &nextPage, &play, &stop, &clear, &randomize, &saveDefaultA })
        button->setWantsKeyboardFocus(false);

    saveDefaultA.setTooltip(
        "Copy the ten current Bank A files into RM-10's permanent "
        "user-default folder.");
    saveDefaultA.onClick = [this]
    {
        saveBankAAsDefault();
    };

    defaultStatus.setText(
        "BANK A USER DEFAULTS",
        juce::dontSendNotification);
    defaultStatus.setJustificationType(
        juce::Justification::centredLeft);
    defaultStatus.setColour(
        juce::Label::textColourId,
        cream.withAlpha(0.78f));

    {
        juce::String lastGenre;
        int itemId = 1;
        for (const auto& preset : rm10presets::presets)
        {
            if (juce::String(preset.genre) != lastGenre)
            {
                lastGenre = preset.genre;
                presetBox.addSectionHeading(lastGenre);
            }
            presetBox.addItem(preset.name, itemId++);
        }
    }
    presetBox.setTextWhenNothingSelected("LOAD A PATTERN...");
    presetBox.onChange = [this]
    {
        const int itemId = presetBox.getSelectedId();
        if (itemId <= 0)
            return;

        audioProcessor.loadPreset(itemId - 1);
        currentPage = 0;
        refreshStepButtons();
        resized();
        repaint();
    };
    addAndMakeVisible(presetBox);

    play.onClick = [this] { audioProcessor.setSequencerRunning(true); };
    stop.onClick = [this] { audioProcessor.setSequencerRunning(false); };
    clear.onClick = [this]
    {
        audioProcessor.clearPattern();
        for (auto& lane : steps)
            for (auto& step : lane)
                step.setToggleState(false, juce::dontSendNotification);
    };
    randomize.setTooltip("Fill the pattern with a fresh random groove");
    randomize.onClick = [this]
    {
        audioProcessor.randomizePattern();
        refreshStepButtons();
    };

    for (int pad = 0; pad < RuFTraXGreenDrumAudioProcessor::padCount; ++pad)
    {
        auto& ui = pads[(size_t) pad];
        ui.padButton.setButtonText(audioProcessor.getTrackName(pad));
        ui.padButton.onClick = [this, pad] { audioProcessor.triggerPad(pad, 1.0f); };

        ui.loadA.setTooltip("Load Bank A sample");
        ui.loadB.setTooltip("Load Bank B sample");
        ui.loadA.onClick = [this, pad] { chooseSample(pad, 0); };
        ui.loadB.onClick = [this, pad] { chooseSample(pad, 1); };

        ui.reverseA.setClickingTogglesState(true);
        ui.reverseB.setClickingTogglesState(true);
        ui.reverseA.setTooltip("Play Bank A sample in reverse");
        ui.reverseB.setTooltip("Play Bank B sample in reverse");

        ui.nameA.setText("A: " + audioProcessor.getSampleName(pad, 0),
                         juce::dontSendNotification);
        ui.nameB.setText("B: " + audioProcessor.getSampleName(pad, 1),
                         juce::dontSendNotification);
        ui.nameA.setJustificationType(juce::Justification::centredLeft);
        ui.nameB.setJustificationType(juce::Justification::centredLeft);

        ui.midi.setText("N" + juce::String(RuFTraXGreenDrumAudioProcessor::firstMidiNote + pad),
                        juce::dontSendNotification);
        ui.midi.setJustificationType(juce::Justification::centred);

        addAndMakeVisible(ui.padButton);
        addAndMakeVisible(ui.loadA);
        addAndMakeVisible(ui.loadB);
        addAndMakeVisible(ui.reverseA);
        addAndMakeVisible(ui.reverseB);
        addAndMakeVisible(ui.nameA);
        addAndMakeVisible(ui.nameB);
        addAndMakeVisible(ui.midi);

        for (auto* button : { &ui.padButton, &ui.loadA, &ui.loadB, &ui.reverseA, &ui.reverseB })
            button->setWantsKeyboardFocus(false);

        auto setupLayerKnob = [this](juce::Slider& slider, const juce::String& suffix)
        {
            slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            slider.setTooltip(suffix);
            addAndMakeVisible(slider);
        };

        setupLayerKnob(ui.volumeA, "Bank A Volume");
        setupLayerKnob(ui.panA, "Bank A Pan");
        setupLayerKnob(ui.driveA, "Bank A Drive");
        setupLayerKnob(ui.highPassA, "Bank A High-Pass Filter");
        setupLayerKnob(ui.lowPassA, "Bank A Low-Pass Filter");
        setupLayerKnob(ui.volumeB, "Bank B Volume");
        setupLayerKnob(ui.panB, "Bank B Pan");
        setupLayerKnob(ui.driveB, "Bank B Drive");
        setupLayerKnob(ui.highPassB, "Bank B High-Pass Filter");
        setupLayerKnob(ui.lowPassB, "Bank B Low-Pass Filter");

        ui.highPassA.setNumDecimalPlacesToDisplay(0);
        ui.lowPassA.setNumDecimalPlacesToDisplay(0);
        ui.highPassB.setNumDecimalPlacesToDisplay(0);
        ui.lowPassB.setNumDecimalPlacesToDisplay(0);

        // These boxes are only ~29px wide - every character counts. Capping
        // pan/volume/drive to one decimal place keeps every readout short
        // enough to actually fit instead of ellipsizing.
        for (auto* slider : { &ui.volumeA, &ui.panA, &ui.driveA,
                              &ui.volumeB, &ui.panB, &ui.driveB })
            slider->setNumDecimalPlacesToDisplay(1);

        const auto pnum = juce::String(pad + 1);
        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer1Gain", ui.volumeA));
        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer1Pan", ui.panA));
        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer1Drive", ui.driveA));
        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer1HighPass", ui.highPassA));
        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer1LowPass", ui.lowPassA));
        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer2Gain", ui.volumeB));
        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer2Pan", ui.panB));
        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer2Drive", ui.driveB));

        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer2HighPass", ui.highPassB));
        attachments.push_back(std::make_unique<SliderAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer2LowPass", ui.lowPassB));

        buttonAttachments.push_back(std::make_unique<ButtonAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer1Reverse", ui.reverseA));
        buttonAttachments.push_back(std::make_unique<ButtonAttachment>(
            audioProcessor.parameters, "pad" + pnum + "Layer2Reverse", ui.reverseB));

        for (int step = 0; step < visibleButtonCount; ++step)
        {
            auto& button = steps[(size_t) pad][(size_t) step];
            button.setClickingTogglesState(true);
            button.setWantsKeyboardFocus(false);
            button.setButtonText(juce::String(step + 1));
            button.setToggleState(audioProcessor.getStep(pad, step), juce::dontSendNotification);
            button.onClick = [this, pad, step]
            {
                const int absoluteStep = currentPage * visibleStepCount + step;
                audioProcessor.setStep(pad, absoluteStep,
                                  steps[(size_t) pad][(size_t) step].getToggleState());
            };
            addAndMakeVisible(button);
        }
    }

    auto setupKnob = [this](juce::Slider& slider, juce::Label& label,
                            const juce::String& text)
    {
        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        label.setText(text, juce::dontSendNotification);
        label.setJustificationType(juce::Justification::centred);
        addAndMakeVisible(slider);
        addAndMakeVisible(label);
    };

    setupKnob(bpm, bpmLabel, "BPM");
    setupKnob(swing, swingLabel, "SWING");
    setupKnob(master, masterLabel, "MASTER");

    attachments.push_back(std::make_unique<SliderAttachment>(audioProcessor.parameters, "bpm", bpm));
    attachments.push_back(std::make_unique<SliderAttachment>(audioProcessor.parameters, "swing", swing));
    attachments.push_back(std::make_unique<SliderAttachment>(
        audioProcessor.parameters, "masterGain", master));

    sequenceLengthAttachment = std::make_unique<ComboBoxAttachment>(
        audioProcessor.parameters, "sequenceLength", sequenceLength);

    previousPage.onClick = [this] { changePage(-1); };
    nextPage.onClick = [this] { changePage(1); };

    juce::PropertiesFile::Options options;
    options.applicationName = "RuFTraX RM-10";
    options.filenameSuffix = "settings";
    options.folderName = "RuFTraX";
    options.osxLibrarySubFolder = "Application Support";
    options.storageFormat = juce::PropertiesFile::storeAsXML;
    settings = std::make_unique<juce::PropertiesFile>(options);

    visibleStepCount = settings->getIntValue("visibleSteps", 16) == 8 ? 8 : 16;
    displayedSteps.setSelectedId(visibleStepCount == 8 ? 1 : 2,
                                 juce::dontSendNotification);
    displayedSteps.onChange = [this]
    {
        visibleStepCount = displayedSteps.getSelectedId() == 1 ? 8 : 16;
        currentPage = juce::jmin(currentPage, getPageCount() - 1);
        if (settings != nullptr)
        {
            settings->setValue("visibleSteps", visibleStepCount);
            settings->saveIfNeeded();
        }
        refreshStepButtons();
        resized();
        repaint();
    };

    currentViewSizeId = juce::jlimit(1, 5, settings->getIntValue("viewSize", 1));
    viewSize.setSelectedId(currentViewSizeId, juce::dontSendNotification);
    viewSize.onChange = [this]
    {
        applyViewSize(viewSize.getSelectedId(), true);
    };

    refreshStepButtons();
    applyViewSize(currentViewSizeId, false);
    startTimerHz(20);
    grabKeyboardFocus();
}

RuFTraXGreenDrumAudioProcessorEditor::~RuFTraXGreenDrumAudioProcessorEditor()
{
    audioProcessor.stopPreview();

    if (settings != nullptr)
        settings->saveIfNeeded();

    setLookAndFeel(nullptr);
}

bool RuFTraXGreenDrumAudioProcessorEditor::keyPressed(const juce::KeyPress& key)
{
    if (key == juce::KeyPress::spaceKey)
    {
        audioProcessor.setSequencerRunning(!audioProcessor.isSequencerRunning());
        return true;
    }

    return false;
}

void RuFTraXGreenDrumAudioProcessorEditor::visibilityChanged()
{
    // Hosts/standalone windows can hide and re-show this editor (tab
    // switches, minimize/restore); re-claim focus each time so Space keeps
    // working without the user having to click into the plugin first.
    if (isVisible())
        grabKeyboardFocus();
}

float RuFTraXGreenDrumAudioProcessorEditor::calculateFitScale() const
{
    const auto* display = juce::Desktop::getInstance().getDisplays().getPrimaryDisplay();
    if (display == nullptr)
        return 0.75f;

    const auto area = display->userBounds.reduced(50, 70);
    const float widthScale = (float) area.getWidth() / (float) designWidth;
    const float heightScale = (float) area.getHeight() / (float) designHeight;
    return juce::jlimit(0.40f, 1.0f, juce::jmin(widthScale, heightScale));
}

void RuFTraXGreenDrumAudioProcessorEditor::applyViewSize(int selectedId, bool saveSelection)
{
    currentViewSizeId = juce::jlimit(1, 5, selectedId);

    switch (currentViewSizeId)
    {
        case 1: uiScale = calculateFitScale(); break;
        case 2: uiScale = 0.50f; break;
        case 3: uiScale = 0.67f; break;
        case 4: uiScale = 0.75f; break;
        case 5: uiScale = 1.00f; break;
        default: uiScale = 0.75f; break;
    }

    updateScaledFonts();
    setSize(juce::roundToInt((float) designWidth * uiScale),
            juce::roundToInt((float) designHeight * uiScale));

    if (saveSelection && settings != nullptr)
    {
        settings->setValue("viewSize", currentViewSizeId);
        settings->saveIfNeeded();
    }

    resized();
    repaint();
}

juce::Rectangle<int> RuFTraXGreenDrumAudioProcessorEditor::scaledBounds(
    int x, int y, int width, int height) const
{
    return {
        juce::roundToInt((float) x * uiScale),
        juce::roundToInt((float) y * uiScale),
        juce::jmax(1, juce::roundToInt((float) width * uiScale)),
        juce::jmax(1, juce::roundToInt((float) height * uiScale))
    };
}

void RuFTraXGreenDrumAudioProcessorEditor::updateScaledFonts()
{
    title.setFont(juce::Font(juce::FontOptions(34.0f * uiScale, juce::Font::bold)));
    subtitle.setFont(juce::Font(juce::FontOptions(14.0f * uiScale, juce::Font::bold)));
    midiLabel.setFont(juce::Font(juce::FontOptions(12.0f * uiScale, juce::Font::bold)));
    viewSizeLabel.setFont(juce::Font(juce::FontOptions(10.0f * uiScale, juce::Font::bold)));
    sequenceLengthLabel.setFont(juce::Font(juce::FontOptions(10.0f * uiScale,
                                                             juce::Font::bold)));
    displayedStepsLabel.setFont(juce::Font(juce::FontOptions(10.0f * uiScale,
                                                             juce::Font::bold)));
    pageLabel.setFont(juce::Font(juce::FontOptions(10.0f * uiScale, juce::Font::bold)));
    defaultStatus.setFont(juce::Font(juce::FontOptions(10.5f * uiScale, juce::Font::bold)));

    for (auto& ui : pads)
    {
        ui.nameA.setFont(juce::Font(juce::FontOptions(11.0f * uiScale)));
        ui.nameB.setFont(juce::Font(juce::FontOptions(11.0f * uiScale)));
        ui.midi.setFont(juce::Font(juce::FontOptions(10.0f * uiScale, juce::Font::bold)));

        for (auto* slider : { &ui.volumeA, &ui.panA, &ui.driveA,
                              &ui.highPassA, &ui.lowPassA,
                              &ui.volumeB, &ui.panB, &ui.driveB,
                              &ui.highPassB, &ui.lowPassB })
        {
            // Width goes right up to the ~42px gap between adjacent knobs
            // (any more and neighbouring readouts would overlap); height
            // gained a bit of floor room so the now-smaller getLabelFont()
            // text isn't also squeezed vertically.
            slider->setTextBoxStyle(juce::Slider::TextBoxBelow, false,
                                    juce::jmax(20, juce::roundToInt(41.0f * uiScale)),
                                    juce::jmax(11, juce::roundToInt(15.0f * uiScale)));
        }
    }

    bpmLabel.setFont(juce::Font(juce::FontOptions(11.0f * uiScale, juce::Font::bold)));
    swingLabel.setFont(juce::Font(juce::FontOptions(11.0f * uiScale, juce::Font::bold)));
    masterLabel.setFont(juce::Font(juce::FontOptions(11.0f * uiScale, juce::Font::bold)));

    for (auto* slider : { &bpm, &swing, &master })
    {
        slider->setTextBoxStyle(juce::Slider::TextBoxBelow, false,
                                juce::jmax(34, juce::roundToInt(78.0f * uiScale)),
                                juce::jmax(10, juce::roundToInt(18.0f * uiScale)));
    }
}

void RuFTraXGreenDrumAudioProcessorEditor::chooseSample(
    int pad, int layer)
{
    audioProcessor.stopPreview();

    const auto lastDirectory = settings != nullptr
        ? juce::File(
            settings->getValue(
                layer == 0 ? "lastBankADirectory"
                           : "lastBankBDirectory"))
        : juce::File();

    samplePreview = std::make_unique<RM10SamplePreview>(audioProcessor);

    chooser = std::make_unique<juce::FileChooser>(
        "Load sample for Pad " + juce::String(pad + 1)
            + (layer == 0 ? " Bank A" : " Bank B"),
        lastDirectory,
        "*.wav;*.aif;*.aiff;*.flac;*.mp3",
        false);

    chooser->launchAsync(
        juce::FileBrowserComponent::openMode
            | juce::FileBrowserComponent::canSelectFiles,
        [this, pad, layer](const juce::FileChooser& selected)
        {
            audioProcessor.stopPreview();

            const auto file = selected.getResult();

            if (file.existsAsFile()
                && audioProcessor.loadSample(pad, layer, file))
            {
                if (settings != nullptr)
                {
                    settings->setValue(
                        layer == 0 ? "lastBankADirectory"
                                   : "lastBankBDirectory",
                        file.getParentDirectory()
                            .getFullPathName());
                    settings->saveIfNeeded();
                }

                defaultStatus.setText(
                    "Loaded Pad " + juce::String(pad + 1)
                        + (layer == 0 ? " Bank A: "
                                      : " Bank B: ")
                        + file.getFileNameWithoutExtension(),
                    juce::dontSendNotification);
            }
        },
        samplePreview.get());
}

void RuFTraXGreenDrumAudioProcessorEditor::saveBankAAsDefault()
{
    audioProcessor.stopPreview();

    const auto result = audioProcessor.saveBankAAsUserDefault();

    if (result.wasOk())
    {
        defaultStatus.setText(
            "BANK A DEFAULT KIT SAVED",
            juce::dontSendNotification);

        juce::AlertWindow::showMessageBoxAsync(
            juce::MessageBoxIconType::InfoIcon,
            "RM-10 Bank A Defaults",
            "Your ten Bank A samples are now the RM-10 default kit.\\n\\n"
            "They were copied to:\\n"
                + audioProcessor.getUserDefaultBankADirectory()
                      .getFullPathName());
    }
    else
    {
        defaultStatus.setText(
            "DEFAULT SAVE FAILED",
            juce::dontSendNotification);

        juce::AlertWindow::showMessageBoxAsync(
            juce::MessageBoxIconType::WarningIcon,
            "RM-10 Bank A Defaults",
            result.getErrorMessage());
    }
}

bool RuFTraXGreenDrumAudioProcessorEditor::isInterestedInFileDrag(
    const juce::StringArray& files)
{
    for (const auto& path : files)
    {
        const juce::File file(path);
        if (file.hasFileExtension("wav;aif;aiff;flac;mp3"))
            return true;
    }

    return false;
}

int RuFTraXGreenDrumAudioProcessorEditor::padFromPoint(int, int y) const
{
    const int logicalY = juce::roundToInt((float) y / juce::jmax(0.01f, uiScale));
    const int top = 125;
    const int bottom = designHeight - 120;
    const int rowHeight = (bottom - top) / RuFTraXGreenDrumAudioProcessor::padCount;

    return juce::jlimit(0, RuFTraXGreenDrumAudioProcessor::padCount - 1,
                        (logicalY - top) / juce::jmax(1, rowHeight));
}

int RuFTraXGreenDrumAudioProcessorEditor::getPageCount() const
{
    return juce::jmax(1, (audioProcessor.getSequenceLength() + visibleStepCount - 1)
                           / visibleStepCount);
}

void RuFTraXGreenDrumAudioProcessorEditor::changePage(int delta)
{
    currentPage = juce::jlimit(0, getPageCount() - 1, currentPage + delta);
    refreshStepButtons();
    repaint();
}

void RuFTraXGreenDrumAudioProcessorEditor::refreshStepButtons()
{
    const int sequenceLengthValue = audioProcessor.getSequenceLength();
    currentPage = juce::jlimit(0, getPageCount() - 1, currentPage);
    const int firstStep = currentPage * visibleStepCount;

    for (int pad = 0; pad < RuFTraXGreenDrumAudioProcessor::padCount; ++pad)
    {
        for (int visibleStep = 0; visibleStep < visibleButtonCount; ++visibleStep)
        {
            auto& button = steps[(size_t) pad][(size_t) visibleStep];
            const int absoluteStep = firstStep + visibleStep;
            const bool shouldShow = visibleStep < visibleStepCount
                                 && absoluteStep < sequenceLengthValue;

            button.setVisible(shouldShow);
            if (shouldShow)
            {
                button.setButtonText(juce::String(absoluteStep + 1));
                button.setToggleState(audioProcessor.getStep(pad, absoluteStep),
                                      juce::dontSendNotification);
            }
        }
    }

    const int lastStep = juce::jmin(sequenceLengthValue, firstStep + visibleStepCount);
    pageLabel.setText(juce::String(firstStep + 1) + "-" + juce::String(lastStep)
                          + " / " + juce::String(sequenceLengthValue),
                      juce::dontSendNotification);
    previousPage.setEnabled(currentPage > 0);
    nextPage.setEnabled(currentPage + 1 < getPageCount());
}

void RuFTraXGreenDrumAudioProcessorEditor::filesDropped(
    const juce::StringArray& files, int x, int y)
{
    const int pad = padFromPoint(x, y);
    const int logicalX = juce::roundToInt((float) x / juce::jmax(0.01f, uiScale));
    int layer = logicalX >= 536 && logicalX < 914 ? 1 : 0;

    for (const auto& path : files)
    {
        const juce::File file(path);
        if (file.existsAsFile() && file.hasFileExtension("wav;aif;aiff;flac;mp3"))
        {
            audioProcessor.loadSample(pad, layer, file);
            layer = layer == 0 ? 1 : 0;
        }
    }
}

void RuFTraXGreenDrumAudioProcessorEditor::timerCallback()
{
    for (int pad = 0; pad < RuFTraXGreenDrumAudioProcessor::padCount; ++pad)
    {
        const auto trackName = audioProcessor.getTrackName(pad);
        pads[(size_t) pad].padButton.setButtonText(trackName);
        pads[(size_t) pad].padButton.setTooltip(
            "Track " + juce::String(pad + 1) + ": " + trackName);
        pads[(size_t) pad].nameA.setText(
            "A: " + audioProcessor.getSampleName(pad, 0), juce::dontSendNotification);
        pads[(size_t) pad].nameB.setText(
            "B: " + audioProcessor.getSampleName(pad, 1), juce::dontSendNotification);
    }

    refreshStepButtons();

    const auto counter = audioProcessor.getMidiActivityCounter();
    if (counter != lastMidiCounter)
    {
        lastMidiCounter = counter;
        midiLedTicks = 6;
    }
    else if (midiLedTicks > 0)
    {
        --midiLedTicks;
    }

    if (startupTicks > 0)
        --startupTicks;

    repaint();
}

void RuFTraXGreenDrumAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(greenDark);
    g.addTransform(juce::AffineTransform::scale(uiScale));

    auto panel = juce::Rectangle<float>(0.0f, 0.0f,
                                        (float) designWidth, (float) designHeight)
                     .reduced(14.0f);

    juce::ColourGradient gradient(greenPanel.brighter(0.08f), panel.getX(), panel.getY(),
                                  greenPanel.darker(0.35f), panel.getRight(), panel.getBottom(),
                                  false);
    g.setGradientFill(gradient);
    g.fillRoundedRectangle(panel, 10.0f);

    g.setColour(juce::Colour(0xff7e987d));
    g.drawRoundedRectangle(panel, 10.0f, 1.5f);

    juce::Random random(0x47524545);
    for (int i = 0; i < 220; ++i)
    {
        const float x = panel.getX() + random.nextFloat() * panel.getWidth();
        const float y = panel.getY() + random.nextFloat() * panel.getHeight();
        g.setColour((i % 4 == 0 ? cream : juce::Colours::black)
                        .withAlpha(0.02f + random.nextFloat() * 0.04f));
        g.drawLine(x, y, x + 3.0f + random.nextFloat() * 16.0f, y, 0.7f);
    }

    const auto led = juce::Rectangle<float>((float) designWidth - 92.0f, 48.0f, 16.0f, 16.0f);
    g.setColour(midiLedTicks > 0 ? lime : juce::Colour(0xff2b4c2d));
    g.fillEllipse(led);
    g.setColour(juce::Colour(0xff77946e));
    g.drawEllipse(led, 1.0f);

    g.setColour(cream.withAlpha(0.82f));
    g.setFont(juce::Font(juce::FontOptions(10.0f, juce::Font::bold)));
    g.drawText("BANK A", 152, 82, 376, 18, juce::Justification::centred);
    g.drawText("BANK B", 536, 82, 376, 18, juce::Justification::centred);

    const auto drawHeader = [&g](const juce::String& text, int x, int width)
    {
        g.drawText(text, x, 102, width, 18, juce::Justification::centred);
    };

    drawHeader("LOAD", 152, 30);
    drawHeader("SAMPLE", 188, 86);
    drawHeader("REV", 276, 42);
    drawHeader("VOL", 320, 40);
    drawHeader("PAN", 362, 40);
    drawHeader("DRV", 404, 40);
    drawHeader("HPF", 446, 40);
    drawHeader("LPF", 488, 40);

    drawHeader("LOAD", 536, 30);
    drawHeader("SAMPLE", 572, 86);
    drawHeader("REV", 660, 42);
    drawHeader("VOL", 704, 40);
    drawHeader("PAN", 746, 40);
    drawHeader("DRV", 788, 40);
    drawHeader("HPF", 830, 40);
    drawHeader("LPF", 872, 40);
    drawHeader("MIDI", 914, 44);

    g.setColour(juce::Colour(0xff7e987d).withAlpha(0.65f));
    g.drawVerticalLine(532, 79.0f, (float) designHeight - 121.0f);

    const int current = audioProcessor.getCurrentStep();
    const int firstVisibleStep = currentPage * visibleStepCount;
    const int localCurrent = current - firstVisibleStep;
    if (localCurrent >= 0 && localCurrent < visibleStepCount)
    {
        const int gridLeft = 968;
        const int gridWidth = designWidth - gridLeft - 34;
        const int cellWidth = gridWidth / visibleStepCount;
        const float x = (float) (gridLeft + localCurrent * cellWidth);
        g.setColour(amber.withAlpha(0.18f));
        g.fillRect(x, 120.0f, (float) cellWidth, (float) designHeight - 245.0f);
    }

    auto plate = juce::Rectangle<float>((float) designWidth - 390.0f,
                                        (float) designHeight - 104.0f,
                                        340.0f, 66.0f);
    g.setColour(juce::Colours::black.withAlpha(0.28f));
    g.fillRoundedRectangle(plate.translated(2.0f, 3.0f), 4.0f);

    juce::ColourGradient plateGradient(
        juce::Colour(0xffb8ad86), plate.getX(), plate.getY(),
        juce::Colour(0xff655d45), plate.getRight(), plate.getBottom(), false);
    g.setGradientFill(plateGradient);
    g.fillRoundedRectangle(plate, 4.0f);
    g.setColour(juce::Colour(0xff312b1d));
    g.drawRoundedRectangle(plate, 4.0f, 1.2f);

    auto plateArea = plate.toNearestInt().reduced(12, 6);
    g.setColour(juce::Colour(0xff2c2518));
    g.setFont(juce::Font(juce::FontOptions(17.0f, juce::Font::italic)));
    g.drawText("Designed by Michael Samuel",
               plateArea.removeFromTop(24),
               juce::Justification::centredLeft);

    g.setFont(juce::Font(juce::FontOptions(10.5f, juce::Font::bold)));
    g.drawText("RUFTRAX LLC  |  BROOKLYN, NEW YORK",
               plateArea.removeFromBottom(20),
               juce::Justification::centredLeft);

    g.setFont(juce::Font(juce::FontOptions(9.5f, juce::Font::bold)));
    g.drawText("MODEL RM-10   SERIAL 000001   REV 1.1",
               plate.toNearestInt().reduced(12, 6),
               juce::Justification::centredRight);

    if (startupTicks > 0)
    {
        const float progress = 1.0f - (float) startupTicks / 18.0f;
        g.setColour(juce::Colours::black.withAlpha(
            juce::jlimit(0.0f, 0.96f, 0.96f - progress)));
        g.fillRect(0, 0, designWidth, designHeight);

        const auto logicalBounds = juce::Rectangle<int>(0, 0, designWidth, designHeight);

        g.setColour(lime.withAlpha(juce::jlimit(0.0f, 1.0f, progress * 1.7f)));
        g.setFont(juce::Font(juce::FontOptions(36.0f, juce::Font::bold)));
        g.drawText("RuFTraX", logicalBounds.translated(0, -56),
                   juce::Justification::centred);

        g.setColour(cream.withAlpha(juce::jlimit(0.0f, 1.0f, progress * 1.5f)));
        g.setFont(juce::Font(juce::FontOptions(62.0f, juce::Font::bold)));
        g.drawText("RM-10", logicalBounds, juce::Justification::centred);

        g.setColour(amber.withAlpha(juce::jlimit(0.0f, 1.0f, progress * 1.4f)));
        g.setFont(juce::Font(juce::FontOptions(15.0f, juce::Font::bold)));
        g.drawText("VINTAGE RHYTHM MACHINE",
                   logicalBounds.translated(0, 58),
                   juce::Justification::centred);
    }
}

void RuFTraXGreenDrumAudioProcessorEditor::resized()
{
    title.setBounds(scaledBounds(38, 24, 320, 46));
    subtitle.setBounds(scaledBounds(360, 35, 555, 28));
    sequenceLengthLabel.setBounds(scaledBounds(920, 27, 58, 22));
    sequenceLength.setBounds(scaledBounds(980, 24, 64, 30));
    displayedStepsLabel.setBounds(scaledBounds(1048, 27, 50, 22));
    displayedSteps.setBounds(scaledBounds(1100, 24, 58, 30));
    previousPage.setBounds(scaledBounds(1166, 24, 34, 30));
    pageLabel.setBounds(scaledBounds(1204, 24, 116, 30));
    nextPage.setBounds(scaledBounds(1324, 24, 34, 30));
    viewSizeLabel.setBounds(scaledBounds(1360, 27, 72, 22));
    viewSize.setBounds(scaledBounds(1436, 24, 122, 30));
    midiLabel.setBounds(scaledBounds(1635, 44, 60, 24));

    play.setBounds(scaledBounds(38, designHeight - 94, 90, 42));
    stop.setBounds(scaledBounds(136, designHeight - 94, 90, 42));
    clear.setBounds(scaledBounds(234, designHeight - 94, 90, 42));
    randomize.setBounds(scaledBounds(332, designHeight - 94, 90, 42));

    bpmLabel.setBounds(scaledBounds(457, designHeight - 105, 86, 18));
    bpm.setBounds(scaledBounds(452, designHeight - 88, 96, 76));
    swingLabel.setBounds(scaledBounds(557, designHeight - 105, 86, 18));
    swing.setBounds(scaledBounds(552, designHeight - 88, 96, 76));
    masterLabel.setBounds(scaledBounds(657, designHeight - 105, 86, 18));
    master.setBounds(scaledBounds(652, designHeight - 88, 96, 76));

    saveDefaultA.setBounds(
        scaledBounds(778, designHeight - 92, 270, 42));
    defaultStatus.setBounds(
        scaledBounds(1068, designHeight - 92, 200, 42));

    // The RuFTraX badge plate lives at x=(designWidth-390)=1410 in paint() -
    // stop well short of it so the preset picker never covers the badge.
    presetBox.setBounds(scaledBounds(1280, designHeight - 92, 120, 42));

    const int top = 125;
    const int bottom = designHeight - 120;
    const int rowHeight = (bottom - top) / RuFTraXGreenDrumAudioProcessor::padCount;
    const int gridLeft = 968;
    const int gridRight = designWidth - 34;
    const int cellWidth = juce::jmax(24, (gridRight - gridLeft)
                                         / visibleStepCount);

    for (int pad = 0; pad < RuFTraXGreenDrumAudioProcessor::padCount; ++pad)
    {
        const int y = top + pad * rowHeight;
        auto& ui = pads[(size_t) pad];

        ui.padButton.setBounds(scaledBounds(38, y + 4, 108, rowHeight - 8));

        ui.loadA.setBounds(scaledBounds(152, y + 5, 30, rowHeight - 10));
        ui.nameA.setBounds(scaledBounds(188, y + 5, 86, rowHeight - 10));
        ui.reverseA.setBounds(scaledBounds(276, y + 5, 42, rowHeight - 10));

        ui.loadB.setBounds(scaledBounds(536, y + 5, 30, rowHeight - 10));
        ui.nameB.setBounds(scaledBounds(572, y + 5, 86, rowHeight - 10));
        ui.reverseB.setBounds(scaledBounds(660, y + 5, 42, rowHeight - 10));

        const int knobY = y + 1;
        const int knobW = 40;
        const int knobH = rowHeight - 2;

        ui.volumeA.setBounds(scaledBounds(320, knobY, knobW, knobH));
        ui.panA.setBounds(scaledBounds(362, knobY, knobW, knobH));
        ui.driveA.setBounds(scaledBounds(404, knobY, knobW, knobH));
        ui.highPassA.setBounds(scaledBounds(446, knobY, knobW, knobH));
        ui.lowPassA.setBounds(scaledBounds(488, knobY, knobW, knobH));

        ui.volumeB.setBounds(scaledBounds(704, knobY, knobW, knobH));
        ui.panB.setBounds(scaledBounds(746, knobY, knobW, knobH));
        ui.driveB.setBounds(scaledBounds(788, knobY, knobW, knobH));
        ui.highPassB.setBounds(scaledBounds(830, knobY, knobW, knobH));
        ui.lowPassB.setBounds(scaledBounds(872, knobY, knobW, knobH));

        ui.midi.setBounds(scaledBounds(914, y + 5, 44, rowHeight - 10));

        for (int step = 0; step < visibleButtonCount; ++step)
        {
            steps[(size_t) pad][(size_t) step].setBounds(
                scaledBounds(gridLeft + step * cellWidth + 2,
                             y + 5,
                             cellWidth - 4,
                             rowHeight - 10));
        }
    }
}
