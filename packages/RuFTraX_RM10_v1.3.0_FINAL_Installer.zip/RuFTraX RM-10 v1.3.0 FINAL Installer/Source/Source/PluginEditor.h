#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"
#include <array>
#include <memory>
#include <vector>

class GreenLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    GreenLookAndFeel();
    void drawButtonBackground(juce::Graphics&, juce::Button&, const juce::Colour&,
                              bool highlighted, bool down) override;
    juce::Font getTextButtonFont(juce::TextButton&, int buttonHeight) override;
    juce::Font getComboBoxFont(juce::ComboBox&) override;
    void drawRotarySlider(juce::Graphics&, int, int, int, int, float,
                          float, float, juce::Slider&) override;
};

class RM10SamplePreview final : public juce::FilePreviewComponent
{
public:
    explicit RM10SamplePreview(RuFTraXGreenDrumAudioProcessor&);
    ~RM10SamplePreview() override;

    void selectedFileChanged(const juce::File&) override;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    RuFTraXGreenDrumAudioProcessor& processor;
    juce::AudioFormatManager formats;
    juce::Label heading;
    juce::Label fileName;
    juce::Label details;
};

class RuFTraXGreenDrumAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                   private juce::Timer,
                                                   public juce::FileDragAndDropTarget
{
public:
    explicit RuFTraXGreenDrumAudioProcessorEditor(RuFTraXGreenDrumAudioProcessor&);
    ~RuFTraXGreenDrumAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

    bool isInterestedInFileDrag(const juce::StringArray&) override;
    void filesDropped(const juce::StringArray&, int x, int y) override;

private:
    static constexpr int designWidth = 1800;
    static constexpr int designHeight = 900;
    static constexpr int visibleButtonCount = 16;

    struct PadUI
    {
        juce::TextButton padButton;
        juce::TextButton loadA { "A" };
        juce::TextButton loadB { "B" };
        juce::TextButton reverseA { "REV" };
        juce::TextButton reverseB { "REV" };
        juce::Label nameA;
        juce::Label nameB;
        juce::Label midi;

        juce::Slider volumeA;
        juce::Slider panA;
        juce::Slider driveA;
        juce::Slider highPassA;
        juce::Slider lowPassA;
        juce::Slider volumeB;
        juce::Slider panB;
        juce::Slider driveB;
        juce::Slider highPassB;
        juce::Slider lowPassB;
    };

    void timerCallback() override;
    void chooseSample(int pad, int layer);
    void saveBankAAsDefault();
    int padFromPoint(int x, int y) const;
    void refreshStepButtons();
    void changePage(int delta);
    int getPageCount() const;

    void applyViewSize(int selectedId, bool saveSelection);
    float calculateFitScale() const;
    juce::Rectangle<int> scaledBounds(int x, int y, int width, int height) const;
    void updateScaledFonts();

    RuFTraXGreenDrumAudioProcessor& processor;
    GreenLookAndFeel look;

    std::array<PadUI, RuFTraXGreenDrumAudioProcessor::padCount> pads;
    std::array<std::array<juce::TextButton, visibleButtonCount>,
               RuFTraXGreenDrumAudioProcessor::padCount> steps;

    juce::Label title;
    juce::Label subtitle;
    juce::Label midiLabel;
    juce::Label viewSizeLabel;
    juce::ComboBox viewSize;
    juce::Label sequenceLengthLabel;
    juce::ComboBox sequenceLength;
    juce::Label displayedStepsLabel;
    juce::ComboBox displayedSteps;
    juce::TextButton previousPage { "<" };
    juce::TextButton nextPage { ">" };
    juce::Label pageLabel;
    juce::TextButton play { "PLAY" };
    juce::TextButton stop { "STOP" };
    juce::TextButton clear { "CLEAR" };
    juce::TextButton saveDefaultA { "SAVE BANK A AS DEFAULT" };
    juce::Label defaultStatus;

    juce::Slider bpm;
    juce::Slider swing;
    juce::Slider master;
    juce::Label bpmLabel;
    juce::Label swingLabel;
    juce::Label masterLabel;

    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    std::vector<std::unique_ptr<SliderAttachment>> attachments;
    std::vector<std::unique_ptr<ButtonAttachment>> buttonAttachments;
    std::unique_ptr<ComboBoxAttachment> sequenceLengthAttachment;
    std::unique_ptr<juce::FileChooser> chooser;
    std::unique_ptr<RM10SamplePreview> samplePreview;
    std::unique_ptr<juce::PropertiesFile> settings;

    float uiScale = 1.0f;
    int currentViewSizeId = 5;
    int visibleStepCount = 16;
    int currentPage = 0;

    juce::uint32 lastMidiCounter = 0;
    int midiLedTicks = 0;
    int startupTicks = 18;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RuFTraXGreenDrumAudioProcessorEditor)
};
