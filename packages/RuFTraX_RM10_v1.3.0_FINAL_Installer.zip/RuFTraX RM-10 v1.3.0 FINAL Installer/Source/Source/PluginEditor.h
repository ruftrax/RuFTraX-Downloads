#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"
#include <array>
#include <memory>
#include <vector>

class GreenLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    GreenLookAndFeel();
    void drawButtonBackground(juce::Graphics&, juce::Button&, const juce::Colour&,
                              bool highlighted, bool down) override;
    juce::Font getTextButtonFont(juce::TextButton&, int buttonHeight) override;
    juce::Font getComboBoxFont(juce::ComboBox&) override;
    // Slider value-text-boxes are internally plain Labels with no font of
    // their own, so they fall through to this - without an override here
    // they used the LookAndFeel default (sized for normal-height labels,
    // not the ~9px-tall boxes under each knob), which crushed every readout
    // down to "20..."/"-..."-style ellipsis. Sizing it off the label's own
    // height keeps it legible at every knob size/scale.
    juce::Font getLabelFont(juce::Label&) override;
    void drawRotarySlider(juce::Graphics&, int, int, int, int, float,
                          float, float, juce::Slider&) override;
};

class RM10SamplePreview final : public juce::FilePreviewComponent
{
public:
    explicit RM10SamplePreview(RuFTraXGreenDrumAudioProcessor&);
    ~RM10SamplePreview() override;

    void selectedFileChanged(const juce::File&) override;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    RuFTraXGreenDrumAudioProcessor& processor;
    juce::AudioFormatManager formats;
    juce::Label heading;
    juce::Label fileName;
    juce::Label details;
};

class RuFTraXGreenDrumAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                   private juce::Timer,
                                                   public juce::FileDragAndDropTarget
{
public:
    explicit RuFTraXGreenDrumAudioProcessorEditor(RuFTraXGreenDrumAudioProcessor&);
    ~RuFTraXGreenDrumAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

    bool isInterestedInFileDrag(const juce::StringArray&) override;
    void filesDropped(const juce::StringArray&, int x, int y) override;

    // Space bar is a global play/stop toggle, independent of which control
    // last had focus. visibilityChanged() (re-)grabs keyboard focus onto the
    // editor itself whenever it becomes visible, and every plain click
    // button below has its own keyboard focus disabled (see constructor) so
    // clicking a pad/step/load button can never steal Space away from this.
    bool keyPressed(const juce::KeyPress&) override;
    void visibilityChanged() override;

private:
    static constexpr int designWidth = 1800;
    static constexpr int designHeight = 900;
    static constexpr int visibleButtonCount = 16;

    struct PadUI
    {
        juce::TextButton padButton;
        juce::TextButton loadA { "A" };
        juce::TextButton loadB { "B" };
        juce::TextButton reverseA { "REV" };
        juce::TextButton reverseB { "REV" };
        juce::Label nameA;
        juce::Label nameB;
        juce::Label midi;

        juce::Slider volumeA;
        juce::Slider panA;
        juce::Slider driveA;
        juce::Slider highPassA;
        juce::Slider lowPassA;
        juce::Slider volumeB;
        juce::Slider panB;
        juce::Slider driveB;
        juce::Slider highPassB;
        juce::Slider lowPassB;
    };

    void timerCallback() override;
    void chooseSample(int pad, int layer);
    void saveBankAAsDefault();
    int padFromPoint(int x, int y) const;
    void refreshStepButtons();
    void changePage(int delta);
    int getPageCount() const;

    void applyViewSize(int selectedId, bool saveSelection);
    float calculateFitScale() const;
    juce::Rectangle<int> scaledBounds(int x, int y, int width, int height) const;
    void updateScaledFonts();

    // Named audioProcessor (not processor) - juce::AudioProcessorEditor already
    // declares its own protected `processor` member, and this used to silently
    // shadow it. RM10SamplePreview above has its own separate, non-shadowing
    // `processor` member (it doesn't derive from AudioProcessorEditor).
    RuFTraXGreenDrumAudioProcessor& audioProcessor;
    GreenLookAndFeel look;

    std::array<PadUI, RuFTraXGreenDrumAudioProcessor::padCount> pads;
    std::array<std::array<juce::TextButton, visibleButtonCount>,
               RuFTraXGreenDrumAudioProcessor::padCount> steps;

    juce::Label title;
    juce::Label subtitle;
    juce::Label midiLabel;
    juce::Label viewSizeLabel;
    juce::ComboBox viewSize;
    juce::Label sequenceLengthLabel;
    juce::ComboBox sequenceLength;
    juce::Label displayedStepsLabel;
    juce::ComboBox displayedSteps;
    juce::TextButton previousPage { "<" };
    juce::TextButton nextPage { ">" };
    juce::Label pageLabel;
    juce::TextButton play { "PLAY" };
    juce::TextButton stop { "STOP" };
    juce::TextButton clear { "CLEAR" };
    juce::TextButton randomize { "RANDOM" };
    juce::TextButton saveDefaultA { "SAVE BANK A AS DEFAULT" };
    juce::Label defaultStatus;

    // 40 built-in genre patterns (see PresetPatterns.h) - one flat list with
    // a section heading per genre. Selecting an item loads that pattern's
    // steps plus its suggested tempo/swing over whatever kit is loaded.
    // No separate label - the box is narrow (it has to fit beside the
    // RuFTraX badge plate) so it relies on setTextWhenNothingSelected()
    // to describe itself instead of spending width on a caption.
    juce::ComboBox presetBox;

    juce::Slider bpm;
    juce::Slider swing;
    juce::Slider master;
    juce::Label bpmLabel;
    juce::Label swingLabel;
    juce::Label masterLabel;

    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    std::vector<std::unique_ptr<SliderAttachment>> attachments;
    std::vector<std::unique_ptr<ButtonAttachment>> buttonAttachments;
    std::unique_ptr<ComboBoxAttachment> sequenceLengthAttachment;
    std::unique_ptr<juce::FileChooser> chooser;
    std::unique_ptr<RM10SamplePreview> samplePreview;
    std::unique_ptr<juce::PropertiesFile> settings;

    float uiScale = 1.0f;
    int currentViewSizeId = 5;
    int visibleStepCount = 16;
    int currentPage = 0;

    juce::uint32 lastMidiCounter = 0;
    int midiLedTicks = 0;
    int startupTicks = 18;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RuFTraXGreenDrumAudioProcessorEditor)
};
