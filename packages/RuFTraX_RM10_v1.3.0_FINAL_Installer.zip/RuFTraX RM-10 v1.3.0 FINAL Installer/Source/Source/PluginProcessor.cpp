#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "PresetPatterns.h"
#include <cmath>
#include <limits>

namespace
{
constexpr int maxVoices = 96;

constexpr std::array<const char*, RuFTraXGreenDrumAudioProcessor::padCount> defaultTrackNames
{
    "KICK", "SNARE", "RIM", "CLOSED HH", "OPEN HH",
    "HI TOM", "MED TOM", "LO TOM", "RIDE", "CRASH"
};

// Shared by saveBankAAsUserDefault() (writes "%02d_<name>.<ext>") and
// loadPreset() (reads "%02d_<name>.wav" out of a Kits/<folder> preset kit) -
// one definition so the two can never drift apart.
constexpr std::array<const char*, RuFTraXGreenDrumAudioProcessor::padCount> padFileBaseNames
{
    "Kick", "Snare", "Rim", "Closed_HH", "Open_HH",
    "Hi_Tom", "Med_Tom", "Lo_Tom", "Ride_Cymbal", "Crash_Cymbal"
};

// Pads that ship a Layer B (Bank B) sample in every genre-matched preset
// kit: Snare gets a layered Electric Snare, Crash gets a stacked Crash 2.
bool padHasKitLayerB(int pad)
{
    return pad == 1 || pad == 9;
}

constexpr std::array<int, 8> sequenceLengths { 8, 16, 24, 32, 40, 48, 56, 64 };

float equalPowerLeft(float pan)
{
    const float angle = (pan + 1.0f) * juce::MathConstants<float>::pi * 0.25f;
    return std::cos(angle);
}

float equalPowerRight(float pan)
{
    const float angle = (pan + 1.0f) * juce::MathConstants<float>::pi * 0.25f;
    return std::sin(angle);
}
}

RuFTraXGreenDrumAudioProcessor::RuFTraXGreenDrumAudioProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
    registerFormats();
    voices.resize(maxVoices);
    // Reserved capacity is generous on purpose: a single voice slot can be
    // reused many times between graveyard drains (e.g. a fast hi-hat pattern
    // repeatedly choking/restealing the same slot), so this needs headroom
    // well beyond maxVoices, not just one entry per voice.
    voiceGraveyard.reserve((size_t) maxVoices * 16);
    startTimerHz(10);

    for (auto& lane : pattern)
        for (auto& step : lane)
            step.store(false);

    for (int pad = 0; pad < padCount; ++pad)
        trackNames[(size_t) pad] = defaultTrackNames[(size_t) pad];

    // Repeat a useful four-on-the-floor pattern across all eight pages.
    // The default musical length remains 16 steps.
    for (int page = 0; page < stepCount; page += defaultStepCount)
    {
        for (int offset : { 0, 4, 8, 12 })
            pattern[0][(size_t) (page + offset)].store(true);

        for (int offset : { 4, 12 })
            pattern[1][(size_t) (page + offset)].store(true);

        for (int offset = 0; offset < defaultStepCount; offset += 2)
            pattern[3][(size_t) (page + offset)].store(true);
    }

    loadUserDefaultBankA();
}

void RuFTraXGreenDrumAudioProcessor::registerFormats()
{
    formatManager.registerBasicFormats();
}

std::shared_ptr<RuFTraXGreenDrumAudioProcessor::SampleData>
RuFTraXGreenDrumAudioProcessor::readSampleFile(const juce::File& file)
{
    if (!file.existsAsFile())
        return {};

    std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(file));
    if (reader == nullptr || reader->lengthInSamples <= 0)
        return {};

    auto data = std::make_shared<SampleData>();
    const int channels = juce::jlimit(1, 2, (int) reader->numChannels);
    const int length = (int) juce::jmin<juce::int64>(
        reader->lengthInSamples,
        (juce::int64) std::numeric_limits<int>::max());

    data->audio.setSize(channels, length);
    if (!reader->read(&data->audio, 0, length, 0, true, true))
        return {};

    data->sourceSampleRate = reader->sampleRate > 0.0
                           ? reader->sampleRate
                           : 44100.0;
    data->file = file;
    data->name = file.getFileNameWithoutExtension();
    return data;
}

juce::File RuFTraXGreenDrumAudioProcessor::getUserDefaultBankADirectory() const
{
    return juce::File::getSpecialLocation(
               juce::File::userApplicationDataDirectory)
        .getChildFile("RuFTraX")
        .getChildFile("RM-10")
        .getChildFile("DefaultBankA");
}

juce::File RuFTraXGreenDrumAudioProcessor::getKitsDirectory() const
{
    return juce::File::getSpecialLocation(
               juce::File::userApplicationDataDirectory)
        .getChildFile("RuFTraX")
        .getChildFile("RM-10")
        .getChildFile("Kits");
}

bool RuFTraXGreenDrumAudioProcessor::loadUserDefaultBankA()
{
    const auto directory = getUserDefaultBankADirectory();
    const auto manifestFile = directory.getChildFile("RM10_DefaultBankA.xml");

    if (!manifestFile.existsAsFile())
        return false;

    std::unique_ptr<juce::XmlElement> xml(
        juce::XmlDocument::parse(manifestFile));

    if (xml == nullptr || !xml->hasTagName("RM10DefaultBankA"))
        return false;

    bool loadedAny = false;

    for (auto* padElement : xml->getChildWithTagNameIterator("PAD"))
    {
        const int pad = padElement->getIntAttribute("index", -1);
        if (!juce::isPositiveAndBelow(pad, padCount))
            continue;

        const auto file = directory.getChildFile(
            padElement->getStringAttribute("file"));

        if (loadSample(pad, 0, file))
            loadedAny = true;

        // Layer B (Bank B) is optional - only present when the default kit
        // actually layers a second sample on this pad.
        if (padElement->hasAttribute("file2"))
        {
            const auto fileB = directory.getChildFile(
                padElement->getStringAttribute("file2"));

            if (loadSample(pad, 1, fileB))
                loadedAny = true;
        }
    }

    return loadedAny;
}

juce::Result RuFTraXGreenDrumAudioProcessor::saveBankAAsUserDefault()
{
    const auto& names = padFileBaseNames;

    std::array<juce::File, padCount> sourceFiles;
    std::array<juce::File, padCount> sourceFilesB;

    {
        const juce::ScopedLock lock(sampleLock);

        for (int pad = 0; pad < padCount; ++pad)
        {
            const auto& sample = samples[(size_t) pad][0];

            if (sample == nullptr || !sample->file.existsAsFile())
            {
                return juce::Result::fail(
                    "Bank A is incomplete. Load a file into every Bank A pad "
                    "before saving the default kit. Missing pad "
                    + juce::String(pad + 1) + ".");
            }

            sourceFiles[(size_t) pad] = sample->file;

            // Layer B (Bank B) is optional per pad - only pads that are
            // deliberately layered (e.g. a fatter snare or a stacked crash)
            // will have one.
            const auto& sampleB = samples[(size_t) pad][1];
            if (sampleB != nullptr && sampleB->file.existsAsFile())
                sourceFilesB[(size_t) pad] = sampleB->file;
        }
    }

    const auto directory = getUserDefaultBankADirectory();
    const auto result = directory.createDirectory();
    if (result.failed())
        return result;

    auto xml = std::make_unique<juce::XmlElement>("RM10DefaultBankA");
    std::array<juce::File, padCount> destinationFiles;
    std::array<juce::File, padCount> destinationFilesB;

    for (int pad = 0; pad < padCount; ++pad)
    {
        const auto extension = sourceFiles[(size_t) pad].getFileExtension()
                                   .toLowerCase();

        if (extension.isEmpty())
            return juce::Result::fail(
                "Pad " + juce::String(pad + 1)
                + " has a file without an extension.");

        const auto prefix = juce::String::formatted("%02d_", pad + 1)
                          + names[(size_t) pad];

        juce::Array<juce::File> oldFiles;
        directory.findChildFiles(
            oldFiles,
            juce::File::findFiles,
            false,
            prefix + ".*");

        const auto destination = directory.getChildFile(prefix + extension);
        destinationFiles[(size_t) pad] = destination;

        for (const auto& oldFile : oldFiles)
        {
            if (oldFile != sourceFiles[(size_t) pad]
                && oldFile != destination
                && oldFile != sourceFilesB[(size_t) pad])
                oldFile.deleteFile();
        }

        if (sourceFiles[(size_t) pad] != destination)
        {
            destination.deleteFile();

            if (!sourceFiles[(size_t) pad].copyFileTo(destination))
            {
                return juce::Result::fail(
                    "Could not copy Pad " + juce::String(pad + 1)
                    + " to the RM-10 defaults folder.");
            }
        }

        auto* padElement = xml->createNewChildElement("PAD");
        padElement->setAttribute("index", pad);
        padElement->setAttribute("file", destination.getFileName());

        if (sourceFilesB[(size_t) pad].existsAsFile())
        {
            const auto extensionB = sourceFilesB[(size_t) pad]
                                        .getFileExtension().toLowerCase();
            const auto destinationB = directory.getChildFile(
                prefix + "_LayerB" + extensionB);
            destinationFilesB[(size_t) pad] = destinationB;

            if (sourceFilesB[(size_t) pad] != destinationB)
            {
                destinationB.deleteFile();

                if (!sourceFilesB[(size_t) pad].copyFileTo(destinationB))
                {
                    return juce::Result::fail(
                        "Could not copy Pad " + juce::String(pad + 1)
                        + " Layer B to the RM-10 defaults folder.");
                }
            }

            padElement->setAttribute("file2", destinationB.getFileName());
        }
    }

    const auto manifestFile = directory.getChildFile("RM10_DefaultBankA.xml");
    if (!xml->writeTo(manifestFile))
        return juce::Result::fail("Could not write the default-kit manifest.");

    for (int pad = 0; pad < padCount; ++pad)
    {
        if (!loadSample(pad, 0, destinationFiles[(size_t) pad]))
        {
            return juce::Result::fail(
                "The defaults were copied, but Pad "
                + juce::String(pad + 1)
                + " could not be reloaded.");
        }

        if (destinationFilesB[(size_t) pad].existsAsFile())
            loadSample(pad, 1, destinationFilesB[(size_t) pad]);
    }

    return juce::Result::ok();
}

juce::AudioProcessorValueTreeState::ParameterLayout
RuFTraXGreenDrumAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    auto makeFrequencyRange = []
    {
        juce::NormalisableRange<float> range(20.0f, 20000.0f, 1.0f);
        range.setSkewForCentre(1000.0f);
        return range;
    };

    for (int pad = 0; pad < padCount; ++pad)
    {
        const auto p = juce::String(pad + 1);

        layout.add(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { "padGain" + p, 1 },
            "Pad " + p + " Gain",
            juce::NormalisableRange<float>(-60.0f, 6.0f, 0.1f),
            -3.0f));

        layout.add(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { "padPan" + p, 1 },
            "Pad " + p + " Pan",
            juce::NormalisableRange<float>(-1.0f, 1.0f, 0.01f),
            0.0f));

        for (int layer = 0; layer < layerCount; ++layer)
        {
            const auto l = juce::String(layer + 1);
            layout.add(std::make_unique<juce::AudioParameterFloat>(
                juce::ParameterID { "pad" + p + "Layer" + l + "Gain", 1 },
                "Pad " + p + " Layer " + l + " Gain",
                juce::NormalisableRange<float>(-60.0f, 6.0f, 0.1f),
                layer == 0 ? 0.0f : -6.0f));

            layout.add(std::make_unique<juce::AudioParameterFloat>(
                juce::ParameterID { "pad" + p + "Layer" + l + "Tune", 1 },
                "Pad " + p + " Layer " + l + " Tune",
                juce::NormalisableRange<float>(-24.0f, 24.0f, 0.01f),
                0.0f));

            layout.add(std::make_unique<juce::AudioParameterFloat>(
                juce::ParameterID { "pad" + p + "Layer" + l + "Pan", 1 },
                "Pad " + p + " Layer " + l + " Pan",
                juce::NormalisableRange<float>(-1.0f, 1.0f, 0.01f),
                0.0f));

            layout.add(std::make_unique<juce::AudioParameterFloat>(
                juce::ParameterID { "pad" + p + "Layer" + l + "Drive", 1 },
                "Pad " + p + " Layer " + l + " Drive",
                juce::NormalisableRange<float>(0.0f, 24.0f, 0.1f),
                0.0f));

            layout.add(std::make_unique<juce::AudioParameterBool>(
                juce::ParameterID { "pad" + p + "Layer" + l + "Reverse", 1 },
                "Pad " + p + " Layer " + l + " Reverse",
                false));

            layout.add(std::make_unique<juce::AudioParameterFloat>(
                juce::ParameterID { "pad" + p + "Layer" + l + "HighPass", 1 },
                "Pad " + p + " Layer " + l + " High Pass",
                makeFrequencyRange(),
                20.0f));

            layout.add(std::make_unique<juce::AudioParameterFloat>(
                juce::ParameterID { "pad" + p + "Layer" + l + "LowPass", 1 },
                "Pad " + p + " Layer " + l + " Low Pass",
                makeFrequencyRange(),
                20000.0f));
        }
    }

    layout.add(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "sequenceLength", 1 },
        "Sequence Length",
        juce::StringArray { "8", "16", "24", "32", "40", "48", "56", "64" },
        1));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "bpm", 1 }, "Tempo",
        juce::NormalisableRange<float>(40.0f, 240.0f, 0.1f), 120.0f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "swing", 1 }, "Swing",
        juce::NormalisableRange<float>(0.0f, 0.75f, 0.01f), 0.0f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "masterGain", 1 }, "Master",
        juce::NormalisableRange<float>(-60.0f, 6.0f, 0.1f), -3.0f));

    return layout;
}

void RuFTraXGreenDrumAudioProcessor::prepareToPlay(double sampleRate, int)
{
    sampleRateHz = sampleRate > 0.0 ? sampleRate : 44100.0;
    sequencerSampleCounter = 0.0;
    currentStep.store(-1);

    for (auto& voice : voices)
        voice.active = false;
}

bool RuFTraXGreenDrumAudioProcessor::isBusesLayoutSupported(const BusesLayout& layout) const
{
    return layout.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

bool RuFTraXGreenDrumAudioProcessor::loadSample(
    int pad, int layer, const juce::File& file)
{
    if (!juce::isPositiveAndBelow(pad, padCount)
        || !juce::isPositiveAndBelow(layer, layerCount))
        return false;

    auto data = readSampleFile(file);
    if (data == nullptr)
        return false;

    const juce::ScopedLock lock(sampleLock);
    trackNames[(size_t) pad] = data->name;
    samples[(size_t) pad][(size_t) layer] = std::move(data);
    return true;
}

bool RuFTraXGreenDrumAudioProcessor::previewSample(const juce::File& file)
{
    auto data = readSampleFile(file);
    if (data == nullptr)
    {
        stopPreview();
        return false;
    }

    stopPreview();

    Voice* target = nullptr;

    for (auto& voice : voices)
    {
        if (!voice.active)
        {
            target = &voice;
            break;
        }
    }

    if (target == nullptr)
        target = &voices.front();

    target->sample = std::move(data);
    target->position = 0.0;
    target->increment = target->sample->sourceSampleRate
                      / juce::jmax(1.0, sampleRateHz);
    target->gainL = 0.72f;
    target->gainR = 0.72f;
    target->driveGain = 1.0f;
    target->highPassAmount = 0.0f;
    target->lowPassAmount = 1.0f;
    target->highPassStateL = 0.0f;
    target->highPassStateR = 0.0f;
    target->lowPassStateL = 0.0f;
    target->lowPassStateR = 0.0f;
    target->highPassEnabled = false;
    target->lowPassEnabled = false;
    target->pad = previewVoicePad;
    target->active = true;
    return true;
}

void RuFTraXGreenDrumAudioProcessor::stopPreview()
{
    for (auto& voice : voices)
    {
        if (voice.pad == previewVoicePad)
            voice.active = false;
    }
}

void RuFTraXGreenDrumAudioProcessor::startVoice(int pad, int layer, float velocity)
{
    if (!juce::isPositiveAndBelow(pad, padCount)
        || !juce::isPositiveAndBelow(layer, layerCount))
        return;

    std::shared_ptr<SampleData> sample;
    {
        const juce::ScopedLock lock(sampleLock);
        sample = samples[(size_t) pad][(size_t) layer];
    }

    if (sample == nullptr || sample->audio.getNumSamples() == 0)
        return;

    Voice* target = nullptr;
    for (auto& voice : voices)
    {
        if (!voice.active)
        {
            target = &voice;
            break;
        }
    }

    if (target == nullptr)
        target = &voices.front();

    const auto p = juce::String(pad + 1);
    const auto l = juce::String(layer + 1);

    const float padGain = juce::Decibels::decibelsToGain(
        parameters.getRawParameterValue("padGain" + p)->load());
    const float layerGain = juce::Decibels::decibelsToGain(
        parameters.getRawParameterValue("pad" + p + "Layer" + l + "Gain")->load());
    const float padPan = parameters.getRawParameterValue("padPan" + p)->load();
    const float layerPan = parameters.getRawParameterValue(
        "pad" + p + "Layer" + l + "Pan")->load();
    const float pan = juce::jlimit(-1.0f, 1.0f, padPan + layerPan);
    const float tune = parameters.getRawParameterValue(
        "pad" + p + "Layer" + l + "Tune")->load();
    const float driveDb = parameters.getRawParameterValue(
        "pad" + p + "Layer" + l + "Drive")->load();
    const bool reverse = parameters.getRawParameterValue(
        "pad" + p + "Layer" + l + "Reverse")->load() >= 0.5f;
    const float highPass = parameters.getRawParameterValue(
        "pad" + p + "Layer" + l + "HighPass")->load();
    const float lowPass = parameters.getRawParameterValue(
        "pad" + p + "Layer" + l + "LowPass")->load();

    const double playbackIncrement = (sample->sourceSampleRate / sampleRateHz)
                                   * std::pow(2.0, (double) tune / 12.0);

    // See the voiceGraveyard comment in the header: hand the outgoing sample
    // off instead of letting this assignment potentially destroy it here.
    // Reserved capacity is generous, so this push never grows/reallocates
    // the vector - if it somehow ever did, growing is still a message-thread-
    // style operation (malloc, no destructor call), unlike the deallocation
    // this whole mechanism exists to keep off the audio thread.
    if (target->sample != nullptr)
    {
        const juce::ScopedLock graveyardLock(voiceGraveyardLock);
        voiceGraveyard.push_back(std::move(target->sample));
    }
    target->sample = std::move(sample);
    target->position = reverse ? (double) (target->sample->audio.getNumSamples() - 1) : 0.0;
    target->increment = reverse ? -playbackIncrement : playbackIncrement;
    target->gainL = velocity * padGain * layerGain * equalPowerLeft(pan);
    target->gainR = velocity * padGain * layerGain * equalPowerRight(pan);
    target->driveGain = juce::Decibels::decibelsToGain(driveDb);
    target->highPassAmount = 1.0f - std::exp(
        -juce::MathConstants<float>::twoPi * highPass / (float) sampleRateHz);
    target->lowPassAmount = 1.0f - std::exp(
        -juce::MathConstants<float>::twoPi * lowPass / (float) sampleRateHz);
    target->highPassStateL = 0.0f;
    target->highPassStateR = 0.0f;
    target->lowPassStateL = 0.0f;
    target->lowPassStateR = 0.0f;
    target->highPassEnabled = highPass > 20.5f;
    target->lowPassEnabled = lowPass < 19999.5f;
    target->pad = pad;
    target->active = true;
}

void RuFTraXGreenDrumAudioProcessor::triggerPad(int pad, float velocity)
{
    if (!juce::isPositiveAndBelow(pad, padCount))
        return;

    velocity = juce::jlimit(0.0f, 1.0f, velocity);

    // Apply hi-hat choke once per pad trigger, before either bank starts.
    // Pad index 3 is Closed HH and pad index 4 is Open HH.
    //
    // Closed HH stops any existing closed/open hat voices.
    // Open HH replaces an older open-hat voice, but does not erase the
    // Bank A voice when Bank B is empty.
    if (pad == 3 || pad == 4)
    {
        for (auto& voice : voices)
        {
            if (!voice.active)
                continue;

            if ((pad == 3 && (voice.pad == 3 || voice.pad == 4))
                || (pad == 4 && voice.pad == 4))
                voice.active = false;
        }
    }

    startVoice(pad, 0, velocity);
    startVoice(pad, 1, velocity);
}

void RuFTraXGreenDrumAudioProcessor::timerCallback()
{
    // Swap the graveyard out under the lock (cheap - no destructors run
    // while it's held) and let the local vector's destructor free the
    // retired samples here, on the message thread, once the lock is released.
    std::vector<std::shared_ptr<SampleData>> retired;
    {
        const juce::ScopedLock graveyardLock(voiceGraveyardLock);
        if (voiceGraveyard.empty())
            return;
        retired.swap(voiceGraveyard);
        // swap() exchanges capacity too, so voiceGraveyard is left with none -
        // reallocating here (message thread) restores the audio thread's
        // headroom before it can push into this vector again.
        voiceGraveyard.reserve(retired.capacity());
    }
}

void RuFTraXGreenDrumAudioProcessor::handleMidi(const juce::MidiMessage& message)
{
    if (!message.isActiveSense() && !message.isMidiClock())
        midiActivityCounter.fetch_add(1, std::memory_order_relaxed);

    if (message.isNoteOn())
    {
        const int pad = message.getNoteNumber() - firstMidiNote;
        if (juce::isPositiveAndBelow(pad, padCount))
            triggerPad(pad, message.getFloatVelocity());
    }
}

double RuFTraXGreenDrumAudioProcessor::getEffectiveBpm() const
{
    if (auto* playHead = getPlayHead())
    {
        if (auto position = playHead->getPosition())
        {
            if (auto hostBpm = position->getBpm())
                return juce::jlimit(20.0, 400.0, *hostBpm);
        }
    }

    return parameters.getRawParameterValue("bpm")->load();
}

int RuFTraXGreenDrumAudioProcessor::getSequenceLength() const noexcept
{
    const auto* value = parameters.getRawParameterValue("sequenceLength");
    const int choice = value != nullptr
        ? juce::jlimit(0, (int) sequenceLengths.size() - 1,
                       juce::roundToInt(value->load()))
        : 1;
    return sequenceLengths[(size_t) choice];
}

void RuFTraXGreenDrumAudioProcessor::processSequencer(int numSamples)
{
    bool shouldRun = sequencerRunning.load();

    if (auto* playHead = getPlayHead())
    {
        if (auto position = playHead->getPosition())
        {
            if (position->getIsPlaying())
                shouldRun = true;
        }
    }

    if (!shouldRun)
    {
        currentStep.store(-1);
        sequencerSampleCounter = 0.0;
        swingPhase = false;
        return;
    }

    const double bpm = getEffectiveBpm();
    const double normalStep = sampleRateHz * 60.0 / bpm / 4.0;
    const float swing = parameters.getRawParameterValue("swing")->load();
    const int sequenceLength = getSequenceLength();

    sequencerSampleCounter += numSamples;

    for (;;)
    {
        const double stepLength = normalStep
                                * (swingPhase ? 1.0 + swing : 1.0 - swing);
        if (sequencerSampleCounter < stepLength)
            break;

        sequencerSampleCounter -= stepLength;
        const int next = (currentStep.load() + 1 + sequenceLength) % sequenceLength;
        currentStep.store(next);
        swingPhase = !swingPhase;

        for (int pad = 0; pad < padCount; ++pad)
            if (pattern[(size_t) pad][(size_t) next].load())
                triggerPad(pad, 1.0f);
    }
}

void RuFTraXGreenDrumAudioProcessor::renderVoices(juce::AudioBuffer<float>& buffer)
{
    auto* left = buffer.getWritePointer(0);
    auto* right = buffer.getWritePointer(1);
    const int numSamples = buffer.getNumSamples();

    for (auto& voice : voices)
    {
        if (!voice.active || voice.sample == nullptr)
            continue;

        const auto& source = voice.sample->audio;
        const int sourceLength = source.getNumSamples();
        const int sourceChannels = source.getNumChannels();

        for (int sampleIndex = 0; sampleIndex < numSamples; ++sampleIndex)
        {
            if (voice.position < 0.0
                || voice.position > (double) (sourceLength - 1))
            {
                voice.active = false;
                break;
            }

            const int index = juce::jlimit(0, sourceLength - 1,
                                           (int) std::floor(voice.position));
            const int nextIndex = juce::jmin(index + 1, sourceLength - 1);
            const float fraction = (float) (voice.position - (double) index);
            const float l0 = source.getSample(0, index);
            const float l1 = source.getSample(0, nextIndex);
            float sampleL = l0 + fraction * (l1 - l0);

            float sampleR = sampleL;
            if (sourceChannels > 1)
            {
                const float r0 = source.getSample(1, index);
                const float r1 = source.getSample(1, nextIndex);
                sampleR = r0 + fraction * (r1 - r0);
            }

            if (voice.highPassEnabled)
            {
                voice.highPassStateL += voice.highPassAmount
                                      * (sampleL - voice.highPassStateL);
                voice.highPassStateR += voice.highPassAmount
                                      * (sampleR - voice.highPassStateR);
                sampleL -= voice.highPassStateL;
                sampleR -= voice.highPassStateR;
            }

            if (voice.lowPassEnabled)
            {
                voice.lowPassStateL += voice.lowPassAmount
                                     * (sampleL - voice.lowPassStateL);
                voice.lowPassStateR += voice.lowPassAmount
                                     * (sampleR - voice.lowPassStateR);
                sampleL = voice.lowPassStateL;
                sampleR = voice.lowPassStateR;
            }

            if (voice.driveGain > 1.0001f)
            {
                const float normaliser = 1.0f / std::tanh(voice.driveGain);
                sampleL = std::tanh(sampleL * voice.driveGain) * normaliser;
                sampleR = std::tanh(sampleR * voice.driveGain) * normaliser;
            }

            left[sampleIndex] += sampleL * voice.gainL;
            right[sampleIndex] += sampleR * voice.gainR;
            voice.position += voice.increment;
        }
    }
}

void RuFTraXGreenDrumAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,
                                                  juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();

    for (const auto metadata : midi)
        handleMidi(metadata.getMessage());

    processSequencer(buffer.getNumSamples());
    renderVoices(buffer);

    const float master = juce::Decibels::decibelsToGain(
        parameters.getRawParameterValue("masterGain")->load());
    buffer.applyGain(master);
}

juce::String RuFTraXGreenDrumAudioProcessor::getSampleName(int pad, int layer) const
{
    if (!juce::isPositiveAndBelow(pad, padCount)
        || !juce::isPositiveAndBelow(layer, layerCount))
        return {};

    const juce::ScopedLock lock(sampleLock);
    const auto& sample = samples[(size_t) pad][(size_t) layer];
    return sample != nullptr ? sample->name : "Empty";
}

juce::String RuFTraXGreenDrumAudioProcessor::getTrackName(int pad) const
{
    if (!juce::isPositiveAndBelow(pad, padCount))
        return {};

    const juce::ScopedLock lock(sampleLock);
    return trackNames[(size_t) pad];
}

juce::String RuFTraXGreenDrumAudioProcessor::getPadStatus(int pad) const
{
    return "MIDI " + juce::String(firstMidiNote + pad);
}

void RuFTraXGreenDrumAudioProcessor::setStep(int pad, int step, bool enabled)
{
    if (juce::isPositiveAndBelow(pad, padCount)
        && juce::isPositiveAndBelow(step, stepCount))
        pattern[(size_t) pad][(size_t) step].store(enabled);
}

bool RuFTraXGreenDrumAudioProcessor::getStep(int pad, int step) const
{
    return juce::isPositiveAndBelow(pad, padCount)
        && juce::isPositiveAndBelow(step, stepCount)
        && pattern[(size_t) pad][(size_t) step].load();
}

void RuFTraXGreenDrumAudioProcessor::clearPattern()
{
    for (auto& lane : pattern)
        for (auto& step : lane)
            step.store(false);
}

void RuFTraXGreenDrumAudioProcessor::randomizePattern()
{
    // Per-pad-role hit probabilities, indexed [pad][stepInBeat] where
    // stepInBeat = step % 4 (0 = downbeat, 2 = the "and"). Weighted so a
    // random pattern still reads as a groove instead of noise: kick leans
    // on downbeats, snare on the backbeat, hats stay busy, everything else
    // (toms/ride/crash) stays sparse so it can act as texture/fills.
    static constexpr std::array<std::array<float, 4>, padCount> chance
    { {
        { 0.55f, 0.10f, 0.20f, 0.10f },  // Kick
        { 0.08f, 0.08f, 0.08f, 0.08f },  // Snare (backbeat handled below)
        { 0.15f, 0.15f, 0.15f, 0.15f },  // Rim
        { 0.55f, 0.55f, 0.55f, 0.55f },  // Closed HH
        { 0.06f, 0.06f, 0.20f, 0.06f },  // Open HH
        { 0.10f, 0.10f, 0.10f, 0.10f },  // Hi Tom
        { 0.10f, 0.10f, 0.10f, 0.10f },  // Med Tom
        { 0.10f, 0.10f, 0.10f, 0.10f },  // Lo Tom
        { 0.15f, 0.15f, 0.15f, 0.15f },  // Ride
        { 0.02f, 0.02f, 0.02f, 0.02f },  // Crash (step 0 handled below)
    } };

    auto& rng = juce::Random::getSystemRandom();

    for (int pad = 0; pad < padCount; ++pad)
    {
        for (int step = 0; step < stepCount; ++step)
        {
            float p = chance[(size_t) pad][(size_t) (step % 4)];

            // Snare backbeat: strongly favour "beat 2 and 4" (every 8th
            // step, offset by 4) over everywhere else.
            if (pad == 1 && (step % 8) == 4)
                p = 0.65f;

            // Crash: only really an option right at the top of the loop.
            if (pad == 9 && step == 0)
                p = 0.25f;

            pattern[(size_t) pad][(size_t) step].store(rng.nextFloat() < p);
        }
    }
}

void RuFTraXGreenDrumAudioProcessor::loadPreset(int presetIndex)
{
    if (!juce::isPositiveAndBelow(presetIndex, (int) rm10presets::presets.size()))
        return;

    const auto& preset = rm10presets::presets[(size_t) presetIndex];

    // Autoload the drums/percussion that fit this beat: every preset names
    // a genre-matched Roland kit (see PresetPatterns.h / extract_all_kits.py's
    // rationale), and picking the preset swaps Bank A/B on every pad to that
    // kit before the pattern itself loads - a Trap pattern always plays with
    // the Trap kit, a House pattern always plays with the House kit, etc.
    const auto kitDir = getKitsDirectory().getChildFile(preset.kitFolder);
    if (kitDir.isDirectory())
    {
        for (int pad = 0; pad < padCount; ++pad)
        {
            const auto file = kitDir.getChildFile(
                juce::String::formatted("%02d_", pad + 1)
                    + padFileBaseNames[(size_t) pad] + ".wav");
            loadSample(pad, 0, file);

            if (padHasKitLayerB(pad))
            {
                const auto fileB = kitDir.getChildFile(
                    juce::String::formatted("%02d_", pad + 1)
                        + padFileBaseNames[(size_t) pad] + "_LayerB.wav");
                loadSample(pad, 1, fileB);
            }
        }
    }

    clearPattern();
    for (int pad = 0; pad < padCount; ++pad)
        for (int step = 0; step < rm10presets::stepsPerPreset; ++step)
            setStep(pad, step, preset.steps[(size_t) pad][(size_t) step]);

    // Every preset is authored as one 16-step bar - select the matching
    // "16" entry (index 1) in the sequenceLength choice so what plays back
    // is exactly what's shown, regardless of whatever length was set before.
    if (auto* seqLen = dynamic_cast<juce::AudioParameterChoice*>(
            parameters.getParameter("sequenceLength")))
        *seqLen = 1;

    if (auto* bpmParam = dynamic_cast<juce::AudioParameterFloat*>(
            parameters.getParameter("bpm")))
        *bpmParam = preset.bpm;

    if (auto* swingParam = dynamic_cast<juce::AudioParameterFloat*>(
            parameters.getParameter("swing")))
        *swingParam = preset.swing;
}

void RuFTraXGreenDrumAudioProcessor::setSequencerRunning(bool shouldRun)
{
    sequencerRunning.store(shouldRun);
    if (!shouldRun)
    {
        currentStep.store(-1);
        sequencerSampleCounter = 0.0;
    }
}

void RuFTraXGreenDrumAudioProcessor::getStateInformation(juce::MemoryBlock& destination)
{
    auto state = parameters.copyState();

    for (int pad = 0; pad < padCount; ++pad)
    {
        for (int layer = 0; layer < layerCount; ++layer)
        {
            const juce::ScopedLock lock(sampleLock);
            const auto& sample = samples[(size_t) pad][(size_t) layer];
            const auto key = "sample_" + juce::String(pad) + "_" + juce::String(layer);
            state.setProperty(key, sample != nullptr ? sample->file.getFullPathName() : "", nullptr);
        }

        juce::String patternBits;
        for (int step = 0; step < stepCount; ++step)
            patternBits << (getStep(pad, step) ? "1" : "0");

        state.setProperty("pattern_" + juce::String(pad), patternBits, nullptr);
        state.setProperty("trackName_" + juce::String(pad),
                          getTrackName(pad), nullptr);
    }

    if (auto xml = state.createXml())
        copyXmlToBinary(*xml, destination);
}

void RuFTraXGreenDrumAudioProcessor::setStateInformation(const void* data, int size)
{
    auto xml = getXmlFromBinary(data, size);
    if (xml == nullptr)
        return;

    auto state = juce::ValueTree::fromXml(*xml);
    if (!state.isValid())
        return;

    parameters.replaceState(state);

    for (int pad = 0; pad < padCount; ++pad)
    {
        for (int step = 0; step < stepCount; ++step)
            setStep(pad, step, false);

        for (int layer = 0; layer < layerCount; ++layer)
        {
            const auto key = "sample_" + juce::String(pad) + "_" + juce::String(layer);
            const juce::File file(state.getProperty(key).toString());
            if (file.existsAsFile())
                loadSample(pad, layer, file);
        }

        const auto bits = state.getProperty("pattern_" + juce::String(pad)).toString();
        for (int step = 0; step < juce::jmin(stepCount, bits.length()); ++step)
            setStep(pad, step, bits.substring(step, step + 1) == "1");

        const auto savedTrackName = state.getProperty(
            "trackName_" + juce::String(pad)).toString();
        if (savedTrackName.isNotEmpty())
        {
            const juce::ScopedLock lock(sampleLock);
            trackNames[(size_t) pad] = savedTrackName;
        }
    }
}

juce::AudioProcessorEditor* RuFTraXGreenDrumAudioProcessor::createEditor()
{
    return new RuFTraXGreenDrumAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new RuFTraXGreenDrumAudioProcessor();
}
