#pragma once
#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <memory>
#include <vector>

class RuFTraXGreenDrumAudioProcessor final : public juce::AudioProcessor,
                                             private juce::Timer
{
public:
    static constexpr int padCount = 10;
    static constexpr int layerCount = 2;
    static constexpr int stepCount = 64;
    static constexpr int defaultStepCount = 16;
    static constexpr int firstMidiNote = 36;

    RuFTraXGreenDrumAudioProcessor();
    ~RuFTraXGreenDrumAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 2.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "RM-10 User Kit"; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    bool loadSample(int pad, int layer, const juce::File&);
    bool previewSample(const juce::File&);
    void stopPreview();

    juce::Result saveBankAAsUserDefault();
    bool loadUserDefaultBankA();
    juce::File getUserDefaultBankADirectory() const;

    // Where the genre-matched preset kits live on disk (one subfolder per
    // rm10presets::RM10Preset::kitFolder, e.g. ".../Kits/Funk/01_Kick.wav").
    // Sibling of the default-bank folder, same RuFTraX/RM-10 base directory.
    juce::File getKitsDirectory() const;

    void triggerPad(int pad, float velocity = 1.0f);

    juce::String getSampleName(int pad, int layer) const;
    juce::String getTrackName(int pad) const;
    juce::String getPadStatus(int pad) const;

    void setStep(int pad, int step, bool enabled);
    bool getStep(int pad, int step) const;
    void clearPattern();

    // Fills the live pattern with a fresh random groove, weighted per pad
    // role (kick/snare biased toward strong beats, hats dense, toms/cymbals
    // sparse) rather than uniform noise, over the current sequence length.
    void randomizePattern();

    // Applies one of the 40 built-in genre presets (see PresetPatterns.h):
    // replaces the live pattern and sets tempo/swing to the preset's
    // suggested values. Sample content is untouched - presets are rhythm
    // only, layered on top of whatever kit is currently loaded.
    void loadPreset(int presetIndex);

    void setSequencerRunning(bool shouldRun);
    bool isSequencerRunning() const noexcept { return sequencerRunning.load(); }
    int getCurrentStep() const noexcept { return currentStep.load(); }
    int getSequenceLength() const noexcept;

    juce::uint32 getMidiActivityCounter() const noexcept { return midiActivityCounter.load(); }

    juce::AudioProcessorValueTreeState parameters;

private:
    static constexpr int previewVoicePad = -100;

    struct SampleData
    {
        juce::AudioBuffer<float> audio;
        double sourceSampleRate = 44100.0;
        juce::File file;
        juce::String name { "Empty" };
    };

    struct Voice
    {
        std::shared_ptr<SampleData> sample;
        double position = 0.0;
        double increment = 1.0;
        float gainL = 1.0f;
        float gainR = 1.0f;
        float driveGain = 1.0f;
        float highPassAmount = 0.0f;
        float lowPassAmount = 1.0f;
        float highPassStateL = 0.0f;
        float highPassStateR = 0.0f;
        float lowPassStateL = 0.0f;
        float lowPassStateR = 0.0f;
        bool highPassEnabled = false;
        bool lowPassEnabled = false;
        int pad = -1;
        bool active = false;
    };

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void registerFormats();
    std::shared_ptr<SampleData> readSampleFile(const juce::File&);
    void startVoice(int pad, int layer, float velocity);
    void renderVoices(juce::AudioBuffer<float>&);
    void handleMidi(const juce::MidiMessage&);
    void processSequencer(int numSamples);
    double getEffectiveBpm() const;
    void timerCallback() override;

    mutable juce::CriticalSection sampleLock;
    juce::AudioFormatManager formatManager;

    std::array<std::array<std::shared_ptr<SampleData>, layerCount>, padCount> samples;
    std::array<juce::String, padCount> trackNames;
    std::array<std::array<std::atomic<bool>, stepCount>, padCount> pattern;
    std::vector<Voice> voices;

    // A reused Voice slot almost always holds the *last* live reference to
    // whatever SampleData it played previously (a finished voice never
    // clears its own pointer). Overwriting Voice::sample directly in
    // startVoice() - which runs on the audio thread on every trigger - would
    // therefore very often run the SampleData destructor (freeing its
    // AudioBuffer) right there on the audio thread. Instead, startVoice()
    // hands the outgoing shared_ptr off into this pre-reserved list, and a
    // low-rate timer clears it from the message thread instead.
    juce::CriticalSection voiceGraveyardLock;
    std::vector<std::shared_ptr<SampleData>> voiceGraveyard;

    double sampleRateHz = 44100.0;
    double sequencerSampleCounter = 0.0;
    bool swingPhase = false;

    std::atomic<bool> sequencerRunning { false };
    std::atomic<int> currentStep { -1 };
    std::atomic<juce::uint32> midiActivityCounter { 0 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RuFTraXGreenDrumAudioProcessor)
};
