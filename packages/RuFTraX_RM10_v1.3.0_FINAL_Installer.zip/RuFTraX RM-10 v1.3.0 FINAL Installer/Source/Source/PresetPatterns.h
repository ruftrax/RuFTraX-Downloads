#pragma once
#include <array>

// 40 hand-programmed genre patterns (5 each across 8 modern/popular genres),
// designed around RM-10's fixed 10-pad layout: Kick, Snare, Rim, Closed HH,
// Open HH, Hi Tom, Med Tom, Lo Tom, Ride, Crash. Every pattern is 16 steps
// (one bar at 16th-note resolution) - RM-10's step grid is a fixed 16th-note
// grid regardless of sequence length, so 16 steps is the clearest, most
// immediately loopable unit for a preset. bpm/swing are genre-appropriate
// suggestions applied when the preset loads; the user is still free to
// tweak them afterwards like any other pattern.
namespace rm10presets
{
    static constexpr int padCount = 10;
    static constexpr int stepsPerPreset = 16;
    static constexpr int presetCount = 40;

    struct RM10Preset
    {
        const char* name;
        const char* genre;
        float bpm;
        float swing;

        // Subfolder name under the Kits directory (see
        // RuFTraXGreenDrumAudioProcessor::getKitsDirectory()) holding this
        // preset's genre-matched Roland kit - all 10 pads (12 files, two
        // pads layered) use the same fixed filenames as the Studio Kit
        // default, just pulled from a different source kit per genre.
        const char* kitFolder;

        std::array<std::array<bool, stepsPerPreset>, padCount> steps;
    };

    extern const std::array<RM10Preset, presetCount> presets;
}
