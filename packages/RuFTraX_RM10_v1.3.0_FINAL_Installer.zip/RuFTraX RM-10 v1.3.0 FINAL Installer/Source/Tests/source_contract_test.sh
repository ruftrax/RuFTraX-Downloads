#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PROCESSOR_H="$ROOT_DIR/Source/PluginProcessor.h"
PROCESSOR_CPP="$ROOT_DIR/Source/PluginProcessor.cpp"
EDITOR_H="$ROOT_DIR/Source/PluginEditor.h"
EDITOR_CPP="$ROOT_DIR/Source/PluginEditor.cpp"
CMAKE_FILE="$ROOT_DIR/CMakeLists.txt"

require_text() {
  local pattern="$1"
  local file="$2"
  if ! grep -Fq "$pattern" "$file"; then
    echo "Missing required source contract: $pattern"
    exit 1
  fi
}

require_text "static constexpr int stepCount = 64;" "$PROCESSOR_H"
require_text '"sequenceLength"' "$PROCESSOR_CPP"
require_text '"8", "16", "24", "32", "40", "48", "56", "64"' "$PROCESSOR_CPP"
require_text '"Reverse"' "$PROCESSOR_CPP"
require_text '"HighPass"' "$PROCESSOR_CPP"
require_text '"LowPass"' "$PROCESSOR_CPP"
require_text "getTrackName" "$PROCESSOR_CPP"
require_text "trackName_" "$PROCESSOR_CPP"
require_text "visibleButtonCount = 16" "$EDITOR_H"
require_text 'displayedSteps.addItem("8", 1);' "$EDITOR_CPP"
require_text 'displayedSteps.addItem("16", 2);' "$EDITOR_CPP"
require_text "currentPage * visibleStepCount" "$EDITOR_CPP"
require_text "VERSION 1.3.0" "$CMAKE_FILE"
require_text 'ICON_BIG "${CMAKE_CURRENT_SOURCE_DIR}/Assets/AppIcon.png"' "$CMAKE_FILE"

bash -n "$ROOT_DIR/build_mac.sh"

if grep -rInP '[^\x00-\x7F]' \
     "$ROOT_DIR/Source" "$ROOT_DIR/CMakeLists.txt" \
     "$ROOT_DIR/README.md" "$ROOT_DIR/build_mac.sh" >/dev/null; then
  echo "Non-ASCII visible source text detected."
  exit 1
fi

echo "RM-10 v1.3.0 source contracts passed."
