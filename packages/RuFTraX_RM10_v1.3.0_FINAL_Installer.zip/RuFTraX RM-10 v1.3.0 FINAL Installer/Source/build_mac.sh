#!/bin/bash
set -euo pipefail

if [ -z "${JUCE_DIR:-}" ]; then
  echo 'Set JUCE_DIR first, e.g.'
  echo 'export JUCE_DIR="$HOME/JUCE"'
  exit 1
fi

BUILD_DIR="build-v1.3.0"

cmake -S . -B "$BUILD_DIR" -G Xcode -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD_DIR" --config Release --target \
  RuFTraXGreenDrumMachine_AU \
  RuFTraXGreenDrumMachine_Standalone \
  --parallel
