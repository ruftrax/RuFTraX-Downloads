#!/bin/bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SOURCE_DIR"

if [ ! -f SOURCE_MANIFEST.sha256 ]; then
  echo "SOURCE_MANIFEST.sha256 is missing."
  exit 1
fi

shasum -a 256 -c SOURCE_MANIFEST.sha256
echo "RuFTraX RM-10 v1.3.0 source validation passed."
