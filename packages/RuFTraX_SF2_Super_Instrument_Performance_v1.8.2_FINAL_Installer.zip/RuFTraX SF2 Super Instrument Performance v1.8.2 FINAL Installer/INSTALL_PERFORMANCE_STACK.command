#!/bin/zsh
set -euo pipefail

PACKAGE_DIR="${0:A:h}"
SOURCE_DIR="$PACKAGE_DIR"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
LOG="$HOME/Desktop/RuFTraX_SF2_Super_Instrument_Performance_Install.log"
APP_INSTALL_DIR="$HOME/Applications"
AU_INSTALL_DIR="$HOME/Library/Audio/Plug-Ins/Components"
APP_INSTALL="$APP_INSTALL_DIR/RuFTraX SF2 Super Instrument.app"
AU_INSTALL="$AU_INSTALL_DIR/RuFTraX SF2 Super Instrument.component"
CACHE_DIR="$HOME/Library/Caches/AudioUnitCache"
CACHE_BACKUP="$HOME/.Trash/RuFTraX_AudioUnitCache_$TIMESTAMP"

exec > >(tee "$LOG") 2>&1

print "RuFTraX SF2 Super Instrument"
print "Five-Layer Performance Stack v1.8.2 FINAL"
print

if pgrep -x "Logic Pro" >/dev/null 2>&1 \
   || pgrep -x "Logic" >/dev/null 2>&1; then
    print "ERROR: Logic Pro is open."
    print "Save your project, quit Logic Pro, then run this installer again."
    exit 1
fi

"$SOURCE_DIR/Scripts/validate_release_source.sh"

[[ -f "$SOURCE_DIR/Assets/Wurly_EP1.sf2" ]] || {
    print "ERROR: The bundled Wurly sound is missing."
    print "Download a fresh copy of the FINAL installer package."
    exit 1
}

"$SOURCE_DIR/build_mac.sh"

APP_BUILD="$SOURCE_DIR/build-performance/RuFTraXSF2SuperInstrument_artefacts/Release/Standalone/RuFTraX SF2 Super Instrument.app"
AU_BUILD="$SOURCE_DIR/build-performance/RuFTraXSF2SuperInstrument_artefacts/Release/AU/RuFTraX SF2 Super Instrument.component"

print
print "Moving older installed Super Instrument versions to the Trash..."
"$SOURCE_DIR/REMOVE_OTHER_SUPER_INSTRUMENTS.command" --installer

mkdir -p "$APP_INSTALL_DIR" "$AU_INSTALL_DIR"

if [[ -d "$APP_INSTALL" ]]; then
    existing_binary="$APP_INSTALL/Contents/MacOS/RuFTraX SF2 Super Instrument"
    if [[ -f "$existing_binary" ]] \
       && strings -a "$existing_binary" \
           | grep -F "FIVE-LAYER PERFORMANCE STACK" >/dev/null; then
        backup="$HOME/.Trash/RuFTraX SF2 Super Instrument PERFORMANCE BACKUP $TIMESTAMP.app"
        mv "$APP_INSTALL" "$backup"
        print "Previous Performance Stack moved to: $backup"
    else
        print "ERROR: An unverified app remains at:"
        print "$APP_INSTALL"
        print "It was not overwritten."
        exit 1
    fi
fi

if [[ -d "$AU_INSTALL" ]]; then
    existing_binary="$(find "$AU_INSTALL/Contents/MacOS" -type f -print -quit 2>/dev/null || true)"
    if [[ -f "$existing_binary" ]] \
       && strings -a "$existing_binary" \
           | grep -F "FIVE-LAYER PERFORMANCE STACK" >/dev/null; then
        backup="$HOME/.Trash/RuFTraX SF2 Super Instrument PERFORMANCE BACKUP $TIMESTAMP.component"
        mv "$AU_INSTALL" "$backup"
        print "Previous Performance Audio Unit moved to: $backup"
    else
        print "ERROR: An unverified Audio Unit remains at:"
        print "$AU_INSTALL"
        print "It was not overwritten."
        exit 1
    fi
fi

ditto "$APP_BUILD" "$APP_INSTALL"
ditto "$AU_BUILD" "$AU_INSTALL"

xattr -dr com.apple.quarantine "$APP_INSTALL" "$AU_INSTALL" 2>/dev/null || true
codesign --force --deep --sign - "$APP_INSTALL"
codesign --force --deep --sign - "$AU_INSTALL"

installed_app_binary="$APP_INSTALL/Contents/MacOS/RuFTraX SF2 Super Instrument"
installed_au_binary="$(find "$AU_INSTALL/Contents/MacOS" -type f -print -quit 2>/dev/null || true)"

for installed_binary in "$installed_app_binary" "$installed_au_binary"; do
    [[ -f "$installed_binary" ]] || {
        print "ERROR: An installed binary is missing."
        exit 1
    }

    strings -a "$installed_binary" \
        | grep -F "FIVE-LAYER PERFORMANCE STACK" >/dev/null || {
        print "ERROR: Installed Performance Stack verification failed."
        exit 1
    }

    if strings -a "$installed_binary" \
        | grep -F "FIVE-LAYER VINTAGE STACK" >/dev/null; then
        print "ERROR: The rejected VINTAGE STACK was installed."
        exit 1
    fi
done

killall AudioComponentRegistrar >/dev/null 2>&1 || true
killall "AUHostingServiceXPC_arrow" >/dev/null 2>&1 || true
killall "AUHostingServiceXPC" >/dev/null 2>&1 || true

if [[ -d "$CACHE_DIR" ]]; then
    mv "$CACHE_DIR" "$CACHE_BACKUP"
    print "Previous Audio Unit cache moved to: $CACHE_BACKUP"
fi

if command -v auval >/dev/null 2>&1; then
    print
    print "Validating the Audio Unit for Logic Pro..."
    if auval -v aumu Sf5P Ruft; then
        print "Audio Unit validation passed."
    else
        print "NOTE: macOS did not complete command-line Audio Unit validation."
        print "Logic Pro can still rescan it in Plug-in Manager."
    fi
fi

print
print "INSTALL COMPLETE"
print "Standalone: $APP_INSTALL"
print "Audio Unit: $AU_INSTALL"
print
print "This is the approved five-column PERFORMANCE STACK."
print "Each of its five layers has a functional audio-responsive LED strip."
print "Each layer analyzes its rendered audio and shows the detected note and frequency."
print "Each layer has independent up/down semitone transpose controls beside its LED strip."
print "Each layer has independent high-pass and low-pass filters."
print "Loaded layers show CLEAR SF and can be emptied with one click."
print "Every layer loads either SF2 or SFZ and restores the correct engine with saved state."
print "Delay includes Clean, Tape, Analog, and Ping-Pong types with selectable lengths."
print "Reverb includes Studio Room, Hall, Plate, and Chamber types."
print "The title bar shows the live MIDI note name and MIDI number."
print "The Wurly default SoundFont is bundled."
print "Older installed Super Instrument versions were moved to the Trash."
print "Logic Pro will rebuild its Audio Unit cache when it opens."
print
print "Install log: $LOG"

open "$APP_INSTALL"
