RuFTraX SF2 Super Instrument
FIVE-LAYER PERFORMANCE STACK v1.8.2 FINAL

THIS IS THE KEEPER

- Five vertical layer columns labeled LAYER 1 through LAYER 5
- Dark green, bronze, teal, and wood performance interface
- Header reads FIVE-LAYER PERFORMANCE STACK
- One functional 14-segment LED level strip for every layer
- Detected audio note and frequency displayed beside every layer LED strip
- Each layer analyzes its own rendered sound instead of copying the MIDI note
- Live input MIDI note name and MIDI number beside the title-bar MIDI LED
- Input-versus-output mapping errors are visible, such as MIDI A4 sounding C4
- Per-layer up/down transpose chevrons to the right of every LED strip
- Independent signed transpose readout from -24 to +24 semitones
- Transpose changes are saved with the Audio Unit or standalone state
- Independent stereo high-pass and low-pass filters on every layer
- Neutral filter defaults: high-pass at 20 Hz and low-pass at 20000 Hz
- Per-layer filter settings are saved with the plug-in state
- Detected note and frequency follow the filtered sound you hear
- Independent SF2 and SFZ engines on every layer
- SFZ-relative sample paths, MIDI, transpose, filters, meters, and effects
- Correct sfizz compiler configuration for Apple Silicon Macs
- Correct sfizz atomic-queue syntax for Xcode 26 and Clang 21
- Per-layer Load SF2/SFZ, preset, level, pan, mute, and solo controls
- LOAD SF2/SFZ automatically changes to CLEAR SF when a layer is loaded
- CLEAR SF safely stops and empties only the selected layer
- Cleared layers remain empty when saved Logic projects reopen
- Global filter, chorus, delay, reverb, master, and stereo output meters
- Delay types: Clean, Tape, Analog, and Ping-Pong
- Delay lengths: 80, 160, 320, 480, and 640 milliseconds
- Reverb types: Studio Room, Hall, Plate, and Chamber
- Delay and reverb choices and mix levels are saved with plug-in state
- Resizable fixed-aspect interface
- Bundled Wurly default SoundFont
- Standalone and Audio Unit

THE FOLLOWING OLD VERSIONS ARE REMOVED

- FIVE-LAYER VINTAGE STACK horizontal-row interface
- Blue FIVE-LAYER SOUNDFONT INSTRUMENT
- Obsolete v3 FIVE-LAYER SF2 + SFZ interface

INSTALL

1. Double-click INSTALL_PERFORMANCE_STACK.command.
2. If asked, allow Terminal to run the installer.
3. Wait for the build, verification, and installation to finish.
4. The approved standalone app opens automatically.
5. Open Logic Pro. Its Audio Unit cache will rebuild automatically.

The installer looks for JUCE at ~/JUCE and the other known RuFTraX JUCE
locations. The Wurly default SoundFont is included in this package, so no
external sample drive is required.

Installed locations:

~/Applications/RuFTraX SF2 Super Instrument.app
~/Library/Audio/Plug-Ins/Components/RuFTraX SF2 Super Instrument.component

Logic Pro location:

AU Instruments > RuFTraX > RuFTraX SF2 Super Instrument

SAFE CLEANUP

REMOVE_OTHER_SUPER_INSTRUMENTS.command can be run separately. It protects
every bundle containing FIVE-LAYER PERFORMANCE STACK and moves older verified
Super Instrument bundles to the Trash. Nothing is permanently erased.

PUBLIC DISTRIBUTION

This test package is ad-hoc signed for local use. Public distribution still
requires an Apple Developer ID signature and notarization.
