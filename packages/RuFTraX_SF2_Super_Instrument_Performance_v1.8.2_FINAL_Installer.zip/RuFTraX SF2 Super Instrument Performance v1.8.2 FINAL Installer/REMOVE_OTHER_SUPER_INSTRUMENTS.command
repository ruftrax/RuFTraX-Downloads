#!/bin/zsh
set -euo pipefail

PRODUCT_NAME="RuFTraX SF2 Super Instrument"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
TRASH_ROOT="$HOME/.Trash/RuFTraX_Super_Instrument_Old_Versions_$TIMESTAMP"
REPORT="$HOME/Desktop/RuFTraX_Super_Instrument_Cleanup_$TIMESTAMP.txt"
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"

typeset -a CANDIDATES
typeset -A SEEN
MOVED=0
PROTECTED=0
SKIPPED=0

mkdir -p "$TRASH_ROOT"
: > "$REPORT"

log()
{
    print -r -- "$*" | tee -a "$REPORT"
}

bundle_binary()
{
    local bundle="$1"
    local executable_name
    executable_name="$(/usr/bin/defaults read \
        "$bundle/Contents/Info" CFBundleExecutable 2>/dev/null \
        || /usr/bin/defaults read \
        "$bundle/Contents/Info.plist" CFBundleExecutable 2>/dev/null \
        || true)"

    if [[ -n "$executable_name" \
          && -f "$bundle/Contents/MacOS/$executable_name" ]]; then
        print -r -- "$bundle/Contents/MacOS/$executable_name"
        return 0
    fi

    find "$bundle/Contents/MacOS" \
        -type f -perm -111 -print -quit 2>/dev/null || true
}

bundle_identifier()
{
    local bundle="$1"
    /usr/bin/defaults read \
        "$bundle/Contents/Info" CFBundleIdentifier 2>/dev/null \
        || /usr/bin/defaults read \
        "$bundle/Contents/Info.plist" CFBundleIdentifier 2>/dev/null \
        || true
}

classify_bundle()
{
    local bundle="$1"
    local binary
    binary="$(bundle_binary "$bundle")"
    [[ -f "$binary" ]] || {
        print "unknown"
        return 0
    }

    if /usr/bin/strings -a "$binary" 2>/dev/null \
        | grep -F "FIVE-LAYER PERFORMANCE STACK" >/dev/null; then
        print "keeper"
        return 0
    fi

    if /usr/bin/strings -a "$binary" 2>/dev/null \
        | grep -F "FIVE-LAYER VINTAGE STACK" >/dev/null; then
        print "old"
        return 0
    fi

    if /usr/bin/strings -a "$binary" 2>/dev/null \
        | grep -F "FIVE-LAYER SOUNDFONT INSTRUMENT" >/dev/null; then
        print "old"
        return 0
    fi

    if /usr/bin/strings -a "$binary" 2>/dev/null \
        | grep -F "FIVE-LAYER SF2 + SFZ INSTRUMENT" >/dev/null; then
        print "old"
        return 0
    fi

    local identifier
    identifier="$(bundle_identifier "$bundle")"
    if [[ "$identifier" == "com.ruftrax.sf2superinstrument" \
          || "$identifier" == "com.ruftrax.sf2superinstrument."* ]]; then
        print "old"
        return 0
    fi

    print "unrelated"
}

add_candidate()
{
    local candidate="$1"
    [[ -d "$candidate" ]] || return 0
    [[ -n "${SEEN[$candidate]:-}" ]] && return 0
    SEEN[$candidate]=1
    CANDIDATES+=("$candidate")
}

unique_destination()
{
    local bundle="$1"
    local destination="$TRASH_ROOT/${bundle:t}"
    local counter=1

    while [[ -e "$destination" ]]; do
        destination="$TRASH_ROOT/${bundle:t}.$counter"
        counter=$((counter + 1))
    done

    print -r -- "$destination"
}

move_to_trash()
{
    local bundle="$1"
    local destination
    destination="$(unique_destination "$bundle")"

    if [[ -x "$LSREGISTER" && "${bundle:e}" == "app" ]]; then
        "$LSREGISTER" -u "$bundle" >/dev/null 2>&1 || true
    fi

    if [[ -w "${bundle:h}" ]]; then
        mv "$bundle" "$destination"
    else
        sudo mv "$bundle" "$destination"
        sudo chown -R "$USER":staff "$destination"
    fi

    log "MOVED OLD VERSION: $bundle"
    log "  Recoverable at: $destination"
    MOVED=$((MOVED + 1))
}

log "RuFTraX SF2 Super Instrument cleanup"
log "REMOVE: VINTAGE STACK, blue SoundFont, and SF2/SFZ v3 builds"
log "PROTECT: FIVE-LAYER PERFORMANCE STACK"
log

standard_candidates=(
    "$HOME/Applications/$PRODUCT_NAME.app"
    "/Applications/$PRODUCT_NAME.app"
    "$HOME/Library/Audio/Plug-Ins/Components/$PRODUCT_NAME.component"
    "/Library/Audio/Plug-Ins/Components/$PRODUCT_NAME.component"
    "$HOME/Library/Audio/Plug-Ins/VST3/$PRODUCT_NAME.vst3"
    "/Library/Audio/Plug-Ins/VST3/$PRODUCT_NAME.vst3"
)

for candidate in "${standard_candidates[@]}"; do
    add_candidate "$candidate"
done

while IFS= read -r candidate; do
    add_candidate "$candidate"
done < <(/usr/bin/mdfind \
    "kMDItemDisplayName == '$PRODUCT_NAME'cd" 2>/dev/null || true)

for candidate in "${CANDIDATES[@]}"; do
    classification="$(classify_bundle "$candidate")"

    case "$classification" in
        keeper)
            log "PROTECTED PERFORMANCE STACK: $candidate"
            PROTECTED=$((PROTECTED + 1))
            ;;
        old)
            move_to_trash "$candidate"
            ;;
        *)
            log "SKIPPED UNVERIFIED OR UNRELATED: $candidate"
            SKIPPED=$((SKIPPED + 1))
            ;;
    esac
done

killall AudioComponentRegistrar >/dev/null 2>&1 || true

log
log "CLEANUP COMPLETE"
log "Old installed bundles moved to Trash: $MOVED"
log "Performance Stack bundles protected: $PROTECTED"
log "Unverified or unrelated bundles skipped: $SKIPPED"
log
log "Nothing was permanently deleted."
log "Report: $REPORT"
log "Trash staging folder: $TRASH_ROOT"

if [[ "${1:-}" != "--installer" ]]; then
    open -R "$REPORT"
    open "$TRASH_ROOT"
fi

