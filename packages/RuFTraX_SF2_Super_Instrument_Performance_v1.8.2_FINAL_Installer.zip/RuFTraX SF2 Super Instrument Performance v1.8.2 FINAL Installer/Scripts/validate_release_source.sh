#!/bin/zsh
set -euo pipefail

SOURCE_ROOT="${0:A:h:h}"

required_files=(
    "$SOURCE_ROOT/CMakeLists.txt"
    "$SOURCE_ROOT/Source/PluginProcessor.h"
    "$SOURCE_ROOT/Source/PluginProcessor.cpp"
    "$SOURCE_ROOT/Source/PluginEditor.h"
    "$SOURCE_ROOT/Source/PluginEditor.cpp"
    "$SOURCE_ROOT/Assets/Wurly_EP1.sf2"
    "$SOURCE_ROOT/Assets/AppIcon.png"
    "$SOURCE_ROOT/build_mac.sh"
    "$SOURCE_ROOT/THIRD_PARTY_NOTICES.txt"
)

for file in "${required_files[@]}"; do
    [[ -f "$file" ]] || {
        print "ERROR: Missing required source file:"
        print "$file"
        exit 1
    }
done

grep -Fq 'ICON_BIG "${CMAKE_CURRENT_SOURCE_DIR}/Assets/AppIcon.png"' \
    "$SOURCE_ROOT/CMakeLists.txt" || {
    print "ERROR: The Finder application icon is not connected to the build."
    exit 1
}

grep -Fq 'project(RuFTraXSF2SuperInstrument VERSION 1.8.2' \
    "$SOURCE_ROOT/CMakeLists.txt" || {
    print "ERROR: The CMake project version is not 1.8.2."
    exit 1
}

grep -Fq 'FORMATS AU VST3 Standalone' "$SOURCE_ROOT/CMakeLists.txt" || {
    print "ERROR: VST3 is not built alongside AU and Standalone."
    exit 1
}

[[ "$(stat -f%z "$SOURCE_ROOT/Assets/Wurly_EP1.sf2" 2>/dev/null \
      || stat -c%s "$SOURCE_ROOT/Assets/Wurly_EP1.sf2")" -gt 100000 ]] || {
    print "ERROR: The bundled Wurly sound is invalid or incomplete."
    exit 1
}

grep -Fq 'FIVE-LAYER PERFORMANCE STACK' \
    "$SOURCE_ROOT/Source/PluginEditor.cpp" || {
    print "ERROR: The approved PERFORMANCE STACK UI marker is missing."
    exit 1
}

if grep -RFq 'FIVE-LAYER VINTAGE STACK' "$SOURCE_ROOT/Source"; then
    print "ERROR: The rejected VINTAGE STACK UI marker is present."
    exit 1
fi

grep -Fq 'std::array<std::atomic<float>, layerCount> layerPeakLevels' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: Per-layer audio meters are missing."
    exit 1
}

grep -Fq 'getLayerLevel(int layer)' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: The editor cannot read per-layer levels."
    exit 1
}

grep -Fq 'getCurrentMidiNote() const noexcept' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: Live MIDI note tracking is missing."
    exit 1
}

grep -Fq 'getLayerMidiNote(int layer) const' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: Per-layer MIDI note tracking is missing."
    exit 1
}

grep -Fq 'getLayerFrequency(int layer) const' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: Per-layer detected audio frequency is missing."
    exit 1
}

grep -Fq 'detectLayerPitch(Layer&)' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: Per-layer audio pitch analysis is missing."
    exit 1
}

grep -Fq 'pitchDifference' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: The YIN audio pitch detector is missing."
    exit 1
}

grep -Fq 'juce::Label midiNoteLabel' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: The title-bar MIDI note display is missing."
    exit 1
}

grep -Fq 'layerPitchLabels' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: Per-layer detected note displays are missing."
    exit 1
}

grep -Fq 'Detected audio pitch:' \
    "$SOURCE_ROOT/Source/PluginEditor.cpp" || {
    print "ERROR: Detected audio note and frequency labels are missing."
    exit 1
}

grep -Fq '"layerTranspose" + number' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Per-layer transpose parameters are missing."
    exit 1
}

grep -Fq 'nudgeLayerTranspose(int layer, int semitones)' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: Per-layer transpose control is missing."
    exit 1
}

grep -Fq 'transposeUpButtons' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: Transpose-up chevrons are missing."
    exit 1
}

grep -Fq 'transposeDownButtons' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: Transpose-down chevrons are missing."
    exit 1
}

grep -Fq '"layerHighPass" + number' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Per-layer high-pass parameters are missing."
    exit 1
}

grep -Fq '"layerLowPass" + number' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Per-layer low-pass parameters are missing."
    exit 1
}

grep -Fq 'highPassFilter.processSample' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Per-layer high-pass DSP is missing."
    exit 1
}

grep -Fq 'lowPassFilter.processSample' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Per-layer low-pass DSP is missing."
    exit 1
}

grep -Fq 'highPassSliders' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: Per-layer high-pass controls are missing."
    exit 1
}

grep -Fq 'lowPassSliders' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: Per-layer low-pass controls are missing."
    exit 1
}

grep -Fq 'juce::ParameterID { "delayMix", 1 }' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Delay mix parameter is missing."
    exit 1
}

grep -Fq 'juce::ParameterID { "delayType", 1 }' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Delay type selection is missing."
    exit 1
}

grep -Fq 'juce::ParameterID { "delayLength", 1 }' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Delay length selection is missing."
    exit 1
}

grep -Fq 'processDelay(buffer);' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Stereo delay DSP is missing."
    exit 1
}

grep -Fq '"Ping-Pong"' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Ping-Pong delay mode is missing."
    exit 1
}

grep -Fq 'juce::ParameterID { "reverbType", 1 }' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Reverb type selection is missing."
    exit 1
}

grep -Fq '"Studio Room"' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Reverb model list is missing."
    exit 1
}

grep -Fq 'delayTypeBox' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: Delay type UI is missing."
    exit 1
}

grep -Fq 'delayLengthBox' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: Delay length UI is missing."
    exit 1
}

grep -Fq 'reverbTypeBox' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: Reverb type UI is missing."
    exit 1
}

grep -Fq 'void clearLayer(int layer)' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: Safe layer clearing is missing."
    exit 1
}

grep -Fq 'bool isLayerLoaded(int layer) const' \
    "$SOURCE_ROOT/Source/PluginProcessor.h" || {
    print "ERROR: Layer load-state detection is missing."
    exit 1
}

grep -Fq 'isLoaded ? "CLEAR SF" : "LOAD SF2/SFZ"' \
    "$SOURCE_ROOT/Source/PluginEditor.cpp" || {
    print "ERROR: Automatic LOAD SF2/SFZ / CLEAR SF switching is missing."
    exit 1
}

grep -Fq 'GIT_REPOSITORY https://github.com/sfztools/sfizz.git' \
    "$SOURCE_ROOT/CMakeLists.txt" || {
    print "ERROR: The pinned sfizz dependency is missing."
    exit 1
}

grep -Fq 'GIT_TAG 1.2.3' "$SOURCE_ROOT/CMakeLists.txt" || {
    print "ERROR: sfizz is not pinned to the approved release."
    exit 1
}

grep -Fq 'sfizz::sfizz' "$SOURCE_ROOT/CMakeLists.txt" || {
    print "ERROR: The SFZ engine is not linked."
    exit 1
}

grep -Fq 'sfizz_load_file' "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Per-layer SFZ loading is missing."
    exit 1
}

grep -Fq 'sfizz_render_block' "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Per-layer SFZ rendering is missing."
    exit 1
}

grep -Fq '"*.sf2;*.sfz"' "$SOURCE_ROOT/Source/PluginEditor.cpp" || {
    print "ERROR: The layer browser does not accept both SF2 and SFZ."
    exit 1
}

grep -Fq 'state.setProperty("format" + key' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Per-layer SF2/SFZ engine state is not saved."
    exit 1
}

grep -Fq 'state.setProperty("loaded" + key' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Cleared layer state is not saved."
    exit 1
}

grep -Fq 'state.setProperty("bundled" + key' \
    "$SOURCE_ROOT/Source/PluginProcessor.cpp" || {
    print "ERROR: Bundled SoundFont state is not saved."
    exit 1
}

grep -Fq 'std::array<LEDStrip, RuFTraXSF2SuperAudioProcessor::layerCount>' \
    "$SOURCE_ROOT/Source/PluginEditor.h" || {
    print "ERROR: The five LED strips are missing from the UI."
    exit 1
}

grep -Fq 'setFixedAspectRatio(1.6)' \
    "$SOURCE_ROOT/Source/PluginEditor.cpp" || {
    print "ERROR: Scalable fixed-aspect editor support is missing."
    exit 1
}

python3 - "$SOURCE_ROOT" <<'PY'
from pathlib import Path
import sys

root = Path(sys.argv[1])
extensions = {".cpp", ".h", ".md", ".txt", ".sh", ".command"}

for path in root.rglob("*"):
    if not path.is_file() or path.suffix not in extensions:
        continue
    data = path.read_bytes()
    try:
        data.decode("ascii")
    except UnicodeDecodeError as error:
        raise SystemExit(
            f"ERROR: Non-ASCII text found in {path.relative_to(root)} "
            f"at byte {error.start}."
        )
PY

if [[ -f "$SOURCE_ROOT/SOURCE_MANIFEST.sha256" ]]; then
    (
        cd "$SOURCE_ROOT"
        shasum -a 256 -c SOURCE_MANIFEST.sha256
    )
fi

grep -Fq 'set(PROJECT_SYSTEM_PROCESSOR "aarch64" CACHE STRING "sfizz Apple Silicon architecture" FORCE)' \
    "$SOURCE_ROOT/CMakeLists.txt" || {
    print "ERROR: The sfizz Apple Silicon compiler-flag workaround is missing."
    exit 1
}

grep -Fq 'string(REPLACE "Base::template do_pop_any" "Base::do_pop_any"' \
    "$SOURCE_ROOT/CMakeLists.txt" || {
    print "ERROR: The sfizz Xcode 26 atomic_queue pop workaround is missing."
    exit 1
}

grep -Fq 'string(REPLACE "Base::template do_push_any" "Base::do_push_any"' \
    "$SOURCE_ROOT/CMakeLists.txt" || {
    print "ERROR: The sfizz Xcode 26 atomic_queue push workaround is missing."
    exit 1
}

print "RuFTraX SF2 Super Instrument Performance v1.8.2 source validation passed."
