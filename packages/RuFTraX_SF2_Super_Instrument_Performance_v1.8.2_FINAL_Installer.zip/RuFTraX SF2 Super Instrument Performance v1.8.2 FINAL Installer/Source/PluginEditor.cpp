#include "PluginEditor.h"

#include <cmath>

namespace
{
constexpr auto background = 0xff070a08;
constexpr auto panel = 0xff17251d;
constexpr auto panelLight = 0xff203329;
constexpr auto panelDark = 0xff0d1712;
constexpr auto gold = 0xffd2ba78;
constexpr auto deepGold = 0xff745522;
constexpr auto cream = 0xfff0d99b;
constexpr auto teal = 0xff55dfc4;
constexpr auto green = 0xff45d77a;
constexpr auto amber = 0xffffb83f;
constexpr auto red = 0xffff5148;

void drawPanel(juce::Graphics& graphics,
               juce::Rectangle<float> bounds,
               float cornerSize = 14.0f)
{
    juce::ColourGradient gradient(
        juce::Colour(panelLight),
        bounds.getX(),
        bounds.getY(),
        juce::Colour(panel),
        bounds.getRight(),
        bounds.getBottom(),
        false);
    graphics.setGradientFill(gradient);
    graphics.fillRoundedRectangle(bounds, cornerSize);

    graphics.setColour(juce::Colour(deepGold).withAlpha(0.9f));
    graphics.drawRoundedRectangle(bounds.reduced(0.8f),
                                  cornerSize,
                                  1.6f);

    graphics.setColour(juce::Colours::black.withAlpha(0.45f));
    graphics.drawRoundedRectangle(bounds.translated(0.0f, 3.0f),
                                  cornerSize,
                                  3.0f);
}

void drawScrew(juce::Graphics& graphics, float x, float y)
{
    graphics.setColour(juce::Colour(gold).withAlpha(0.55f));
    graphics.fillEllipse(x - 7.0f, y - 7.0f, 14.0f, 14.0f);
    graphics.setColour(juce::Colours::black.withAlpha(0.8f));
    graphics.drawEllipse(x - 6.0f, y - 6.0f, 12.0f, 12.0f, 1.5f);
    graphics.drawLine(x - 3.0f, y, x + 3.0f, y, 1.4f);
}
}

PerformanceLookAndFeel::PerformanceLookAndFeel()
{
    setColour(juce::Label::textColourId, juce::Colour(cream));
    setColour(juce::TextButton::textColourOffId, juce::Colour(cream));
    setColour(juce::TextButton::textColourOnId, juce::Colour(background));
    setColour(juce::ComboBox::textColourId, juce::Colour(teal));
    setColour(juce::ComboBox::backgroundColourId, juce::Colour(panelDark));
    setColour(juce::ComboBox::outlineColourId, juce::Colour(deepGold));
    setColour(juce::ComboBox::arrowColourId, juce::Colour(teal));
    setColour(juce::PopupMenu::backgroundColourId, juce::Colour(panelDark));
    setColour(juce::PopupMenu::textColourId, juce::Colour(cream));
    setColour(juce::PopupMenu::highlightedBackgroundColourId,
              juce::Colour(deepGold));
    setColour(juce::Slider::textBoxTextColourId, juce::Colour(teal));
    setColour(juce::Slider::textBoxBackgroundColourId,
              juce::Colour(panelDark));
    setColour(juce::Slider::textBoxOutlineColourId,
              juce::Colour(panel).brighter(0.25f));
}

void PerformanceLookAndFeel::drawRotarySlider(
    juce::Graphics& graphics,
    int x,
    int y,
    int width,
    int height,
    float sliderPosition,
    float rotaryStartAngle,
    float rotaryEndAngle,
    juce::Slider&)
{
    auto bounds = juce::Rectangle<float>(
        static_cast<float>(x),
        static_cast<float>(y),
        static_cast<float>(width),
        static_cast<float>(height)).reduced(8.0f);

    const auto size = juce::jmin(bounds.getWidth(), bounds.getHeight());
    bounds = bounds.withSizeKeepingCentre(size, size);

    graphics.setColour(juce::Colours::black.withAlpha(0.55f));
    graphics.fillEllipse(bounds.translated(4.0f, 5.0f));

    juce::ColourGradient body(juce::Colour(0xffffedbd),
                              bounds.getCentreX(),
                              bounds.getY(),
                              juce::Colour(0xffc49a4d),
                              bounds.getCentreX(),
                              bounds.getBottom(),
                              false);
    graphics.setGradientFill(body);
    graphics.fillEllipse(bounds);

    graphics.setColour(juce::Colour(deepGold));
    graphics.drawEllipse(bounds, 2.5f);

    const auto angle =
        rotaryStartAngle
        + sliderPosition * (rotaryEndAngle - rotaryStartAngle);
    const auto radius = bounds.getWidth() * 0.36f;
    const auto centre = bounds.getCentre();

    juce::Path pointer;
    pointer.addRoundedRectangle(-2.3f,
                                -radius,
                                4.6f,
                                radius * 0.72f,
                                2.0f);
    pointer.applyTransform(
        juce::AffineTransform::rotation(angle)
            .translated(centre.x, centre.y));

    graphics.setColour(juce::Colour(0xff311d10));
    graphics.fillPath(pointer);

    juce::Path activeArc;
    activeArc.addCentredArc(
        centre.x,
        centre.y,
        bounds.getWidth() * 0.55f,
        bounds.getHeight() * 0.55f,
        0.0f,
        rotaryStartAngle,
        angle,
        true);
    graphics.setColour(juce::Colour(teal));
    graphics.strokePath(activeArc, juce::PathStrokeType(3.0f));
}

void PerformanceLookAndFeel::drawButtonBackground(
    juce::Graphics& graphics,
    juce::Button& button,
    const juce::Colour&,
    bool highlighted,
    bool down)
{
    auto bounds = button.getLocalBounds().toFloat().reduced(0.8f);
    const auto active = button.getToggleState();

    auto top = active ? juce::Colour(teal) : juce::Colour(0xff382b18);
    auto bottom = active ? juce::Colour(0xff2db79e)
                         : juce::Colour(panelDark);

    if (highlighted)
        top = top.brighter(0.15f);
    if (down)
        bottom = bottom.darker(0.25f);

    juce::ColourGradient gradient(top,
                                  bounds.getX(),
                                  bounds.getY(),
                                  bottom,
                                  bounds.getX(),
                                  bounds.getBottom(),
                                  false);
    graphics.setGradientFill(gradient);
    graphics.fillRoundedRectangle(bounds, 6.0f);

    graphics.setColour(active ? juce::Colour(teal)
                              : juce::Colour(deepGold));
    graphics.drawRoundedRectangle(bounds, 6.0f, 1.5f);
}

void PerformanceLookAndFeel::drawComboBox(
    juce::Graphics& graphics,
    int width,
    int height,
    bool,
    int,
    int,
    int,
    int,
    juce::ComboBox& box)
{
    auto bounds = juce::Rectangle<float>(
        0.0f,
        0.0f,
        static_cast<float>(width),
        static_cast<float>(height)).reduced(0.7f);

    graphics.setColour(box.findColour(juce::ComboBox::backgroundColourId));
    graphics.fillRoundedRectangle(bounds, 6.0f);
    graphics.setColour(box.findColour(juce::ComboBox::outlineColourId));
    graphics.drawRoundedRectangle(bounds, 6.0f, 1.4f);

    const auto centreY = static_cast<float>(height) * 0.5f;
    juce::Path arrow;
    arrow.addTriangle(static_cast<float>(width) - 27.0f,
                      centreY - 5.0f,
                      static_cast<float>(width) - 11.0f,
                      centreY - 5.0f,
                      static_cast<float>(width) - 19.0f,
                      centreY + 7.0f);
    graphics.setColour(box.findColour(juce::ComboBox::arrowColourId));
    graphics.fillPath(arrow);
}

juce::Font PerformanceLookAndFeel::getComboBoxFont(juce::ComboBox&)
{
    return juce::Font(juce::FontOptions(16.0f, juce::Font::bold));
}

juce::Font PerformanceLookAndFeel::getTextButtonFont(
    juce::TextButton&,
    int buttonHeight)
{
    return juce::Font(juce::FontOptions(
        juce::jlimit(13.0f,
                     20.0f,
                     static_cast<float>(buttonHeight) * 0.42f),
        juce::Font::bold));
}

void LEDStrip::setLevel(float newLevel)
{
    newLevel = juce::jlimit(0.0f, 2.0f, newLevel);
    if (std::abs(newLevel - level) > 0.002f)
    {
        level = newLevel;
        repaint();
    }
}

void LEDStrip::paint(juce::Graphics& graphics)
{
    constexpr int segmentCount = 14;

    auto bounds = getLocalBounds().toFloat();
    graphics.setColour(juce::Colours::black.withAlpha(0.58f));
    graphics.fillRoundedRectangle(bounds, 5.0f);
    graphics.setColour(juce::Colour(deepGold).withAlpha(0.8f));
    graphics.drawRoundedRectangle(bounds.reduced(0.5f), 5.0f, 1.0f);

    bounds.reduce(5.0f, 6.0f);
    const auto gap = 2.5f;
    const auto segmentHeight =
        (bounds.getHeight() - gap * static_cast<float>(segmentCount - 1))
        / static_cast<float>(segmentCount);

    const auto decibels =
        juce::Decibels::gainToDecibels(level, -60.0f);
    const auto normalized =
        juce::jlimit(0.0f, 1.0f, (decibels + 60.0f) / 60.0f);
    const auto lit =
        juce::roundToInt(normalized * static_cast<float>(segmentCount));

    for (int index = 0; index < segmentCount; ++index)
    {
        const auto visualIndex = segmentCount - 1 - index;
        const auto segment = juce::Rectangle<float>(
            bounds.getX(),
            bounds.getY()
                + static_cast<float>(visualIndex)
                    * (segmentHeight + gap),
            bounds.getWidth(),
            segmentHeight);

        auto colour = juce::Colour(green);
        if (index >= 11)
            colour = juce::Colour(red);
        else if (index >= 8)
            colour = juce::Colour(amber);

        const auto isLit = index < lit;
        graphics.setColour(
            isLit ? colour.brighter(0.25f)
                  : colour.withAlpha(0.13f));
        graphics.fillRoundedRectangle(segment, 1.5f);

        if (isLit)
        {
            graphics.setColour(colour.withAlpha(0.32f));
            graphics.drawRoundedRectangle(segment.expanded(1.0f),
                                          2.0f,
                                          1.5f);
        }
    }
}

void MidiLight::setActive(bool shouldBeActive)
{
    if (active != shouldBeActive)
    {
        active = shouldBeActive;
        repaint();
    }
}

void MidiLight::paint(juce::Graphics& graphics)
{
    auto bounds = getLocalBounds().toFloat().reduced(2.0f);
    const auto colour = active ? juce::Colour(teal)
                               : juce::Colour(0xff173c31);

    graphics.setColour(colour.withAlpha(active ? 0.35f : 0.2f));
    graphics.fillEllipse(bounds.expanded(active ? 3.0f : 0.0f));
    graphics.setColour(colour);
    graphics.fillEllipse(bounds);
    graphics.setColour(juce::Colour(gold).withAlpha(0.65f));
    graphics.drawEllipse(bounds, 1.5f);
}

RuFTraXSF2SuperAudioProcessorEditor::
    RuFTraXSF2SuperAudioProcessorEditor(
        RuFTraXSF2SuperAudioProcessor& processorToUse)
    : AudioProcessorEditor(&processorToUse),
      audioProcessor(processorToUse)
{
    setLookAndFeel(&performanceLook);
    setOpaque(true);
    setResizable(true, true);
    setResizeLimits(1120, 700, 2400, 1500);
    if (auto* constrainer = getConstrainer())
        constrainer->setFixedAspectRatio(1.6);
    setSize(1600, 1000);

    configureLabel(brandLabel, 2.25f, juce::Justification::centredLeft);
    brandLabel.setText("RuFTraX", juce::dontSendNotification);
    brandLabel.setColour(juce::Label::textColourId, juce::Colour(gold));

    configureLabel(productLabel, 1.05f, juce::Justification::centredLeft);
    productLabel.setText("SF2 SUPER INSTRUMENT",
                         juce::dontSendNotification);
    productLabel.setColour(juce::Label::textColourId, juce::Colour(teal));

    configureLabel(subtitleLabel, 0.72f, juce::Justification::centredLeft);
    subtitleLabel.setText("FIVE-LAYER PERFORMANCE STACK",
                          juce::dontSendNotification);

    configureLabel(midiNoteLabel, 0.82f, juce::Justification::centredRight);
    midiNoteLabel.setText("NOTE --", juce::dontSendNotification);
    midiNoteLabel.setColour(juce::Label::textColourId,
                            juce::Colour(teal));

    configureLabel(midiLabel, 0.72f, juce::Justification::centredRight);
    midiLabel.setText("MIDI", juce::dontSendNotification);

    addAndMakeVisible(brandLabel);
    addAndMakeVisible(productLabel);
    addAndMakeVisible(subtitleLabel);
    addAndMakeVisible(midiNoteLabel);
    addAndMakeVisible(midiLabel);
    addAndMakeVisible(midiLight);

    for (int index = 0;
         index < RuFTraXSF2SuperAudioProcessor::layerCount;
         ++index)
    {
        const auto number = juce::String(index + 1);

        configureLabel(layerTitleLabels[static_cast<std::size_t>(index)],
                       0.78f,
                       juce::Justification::centredLeft);
        layerTitleLabels[static_cast<std::size_t>(index)].setText(
            "LAYER " + number,
            juce::dontSendNotification);
        layerTitleLabels[static_cast<std::size_t>(index)].setColour(
            juce::Label::textColourId,
            juce::Colour(gold));

        configureLabel(layerNameLabels[static_cast<std::size_t>(index)],
                       0.9f,
                       juce::Justification::centredLeft);
        configureLabel(layerStatusLabels[static_cast<std::size_t>(index)],
                       0.6f,
                       juce::Justification::centredLeft);
        layerStatusLabels[static_cast<std::size_t>(index)].setColour(
            juce::Label::textColourId,
            juce::Colour(gold).withAlpha(0.82f));

        configureLabel(levelLabels[static_cast<std::size_t>(index)],
                       0.6f,
                       juce::Justification::centred);
        levelLabels[static_cast<std::size_t>(index)].setText(
            "LEVEL",
            juce::dontSendNotification);

        configureLabel(panLabels[static_cast<std::size_t>(index)],
                       0.6f,
                       juce::Justification::centred);
        panLabels[static_cast<std::size_t>(index)].setText(
            "PAN",
            juce::dontSendNotification);

        configureLabel(
            highPassLabels[static_cast<std::size_t>(index)],
            0.52f,
            juce::Justification::centred);
        highPassLabels[static_cast<std::size_t>(index)].setText(
            "HIGH PASS",
            juce::dontSendNotification);

        configureLabel(
            lowPassLabels[static_cast<std::size_t>(index)],
            0.52f,
            juce::Justification::centred);
        lowPassLabels[static_cast<std::size_t>(index)].setText(
            "LOW PASS",
            juce::dontSendNotification);

        auto& noteLabel =
            layerPitchLabels[static_cast<std::size_t>(index)];
        configureLabel(noteLabel, 0.72f, juce::Justification::centred);
        noteLabel.setText("--", juce::dontSendNotification);
        noteLabel.setColour(juce::Label::textColourId,
                            juce::Colour(teal));
        noteLabel.setColour(juce::Label::backgroundColourId,
                            juce::Colour(panelDark));
        noteLabel.setColour(juce::Label::outlineColourId,
                            juce::Colour(deepGold));

        auto& transposeValue =
            transposeValueLabels[static_cast<std::size_t>(index)];
        configureLabel(transposeValue,
                       0.68f,
                       juce::Justification::centred);
        transposeValue.setText("+0", juce::dontSendNotification);
        transposeValue.setColour(juce::Label::textColourId,
                                 juce::Colour(teal));
        transposeValue.setColour(juce::Label::backgroundColourId,
                                 juce::Colour(panelDark));
        transposeValue.setColour(juce::Label::outlineColourId,
                                 juce::Colour(deepGold));

        auto& transposeUp =
            transposeUpButtons[static_cast<std::size_t>(index)];
        transposeUp.setButtonText("^");
        transposeUp.setTooltip("Transpose up one semitone");
        transposeUp.setRepeatSpeed(350, 90, 60);
        transposeUp.onClick = [this, index]
        {
            audioProcessor.nudgeLayerTranspose(index, 1);
        };

        auto& transposeDown =
            transposeDownButtons[static_cast<std::size_t>(index)];
        transposeDown.setButtonText("v");
        transposeDown.setTooltip("Transpose down one semitone");
        transposeDown.setRepeatSpeed(350, 90, 60);
        transposeDown.onClick = [this, index]
        {
            audioProcessor.nudgeLayerTranspose(index, -1);
        };

        auto& loadButton = loadButtons[static_cast<std::size_t>(index)];
        loadButton.setButtonText("LOAD SF2/SFZ");
        loadButton.onClick = [this, index]
        {
            if (audioProcessor.isLayerLoaded(index))
            {
                audioProcessor.clearLayer(index);
                refreshLayer(index);
            }
            else
            {
                openLayerFileChooser(index);
            }
        };

        auto& muteButton = muteButtons[static_cast<std::size_t>(index)];
        muteButton.setButtonText("M");
        muteButton.setClickingTogglesState(true);

        auto& soloButton = soloButtons[static_cast<std::size_t>(index)];
        soloButton.setButtonText("S");
        soloButton.setClickingTogglesState(true);

        auto& presetBox = presetBoxes[static_cast<std::size_t>(index)];
        presetBox.setTextWhenNothingSelected("Select preset");
        presetBox.onChange = [this, index]
        {
            if (!refreshingPresetBoxes)
            {
                const auto selected =
                    presetBoxes[static_cast<std::size_t>(index)]
                        .getSelectedId();
                if (selected > 0)
                    audioProcessor.selectPreset(index, selected - 1);
            }
        };

        configureSlider(gainSliders[static_cast<std::size_t>(index)],
                        "",
                        1);
        configureSlider(panSliders[static_cast<std::size_t>(index)],
                        "",
                        2);
        configureSlider(
            highPassSliders[static_cast<std::size_t>(index)],
            " Hz",
            0);
        configureSlider(
            lowPassSliders[static_cast<std::size_t>(index)],
            " Hz",
            0);
        highPassSliders[static_cast<std::size_t>(index)]
            .setTextBoxStyle(
                juce::Slider::TextBoxBelow, false, 72, 20);
        lowPassSliders[static_cast<std::size_t>(index)]
            .setTextBoxStyle(
                juce::Slider::TextBoxBelow, false, 72, 20);
        highPassSliders[static_cast<std::size_t>(index)]
            .setDoubleClickReturnValue(true, 20.0);
        lowPassSliders[static_cast<std::size_t>(index)]
            .setDoubleClickReturnValue(true, 20000.0);
        highPassSliders[static_cast<std::size_t>(index)].setTooltip(
            "Layer high-pass filter cutoff");
        lowPassSliders[static_cast<std::size_t>(index)].setTooltip(
            "Layer low-pass filter cutoff");

        gainAttachments[static_cast<std::size_t>(index)] =
            std::make_unique<SliderAttachment>(
                audioProcessor.parameters,
                "layerGain" + number,
                gainSliders[static_cast<std::size_t>(index)]);
        panAttachments[static_cast<std::size_t>(index)] =
            std::make_unique<SliderAttachment>(
                audioProcessor.parameters,
                "layerPan" + number,
                panSliders[static_cast<std::size_t>(index)]);
        highPassAttachments[static_cast<std::size_t>(index)] =
            std::make_unique<SliderAttachment>(
                audioProcessor.parameters,
                "layerHighPass" + number,
                highPassSliders[static_cast<std::size_t>(index)]);
        lowPassAttachments[static_cast<std::size_t>(index)] =
            std::make_unique<SliderAttachment>(
                audioProcessor.parameters,
                "layerLowPass" + number,
                lowPassSliders[static_cast<std::size_t>(index)]);
        muteAttachments[static_cast<std::size_t>(index)] =
            std::make_unique<ButtonAttachment>(
                audioProcessor.parameters,
                "layerMute" + number,
                muteButton);
        soloAttachments[static_cast<std::size_t>(index)] =
            std::make_unique<ButtonAttachment>(
                audioProcessor.parameters,
                "layerSolo" + number,
                soloButton);

        addAndMakeVisible(layerTitleLabels[static_cast<std::size_t>(index)]);
        addAndMakeVisible(layerNameLabels[static_cast<std::size_t>(index)]);
        addAndMakeVisible(layerStatusLabels[static_cast<std::size_t>(index)]);
        addAndMakeVisible(levelLabels[static_cast<std::size_t>(index)]);
        addAndMakeVisible(panLabels[static_cast<std::size_t>(index)]);
        addAndMakeVisible(
            highPassLabels[static_cast<std::size_t>(index)]);
        addAndMakeVisible(
            lowPassLabels[static_cast<std::size_t>(index)]);
        addAndMakeVisible(loadButton);
        addAndMakeVisible(muteButton);
        addAndMakeVisible(soloButton);
        addAndMakeVisible(presetBox);
        addAndMakeVisible(gainSliders[static_cast<std::size_t>(index)]);
        addAndMakeVisible(panSliders[static_cast<std::size_t>(index)]);
        addAndMakeVisible(
            highPassSliders[static_cast<std::size_t>(index)]);
        addAndMakeVisible(
            lowPassSliders[static_cast<std::size_t>(index)]);
        addAndMakeVisible(noteLabel);
        addAndMakeVisible(layerMeters[static_cast<std::size_t>(index)]);
        addAndMakeVisible(transposeUp);
        addAndMakeVisible(transposeValue);
        addAndMakeVisible(transposeDown);

        auto& keyRangeLabel =
            keyRangeLabels[static_cast<std::size_t>(index)];
        configureLabel(keyRangeLabel, 0.44f, juce::Justification::centred);
        keyRangeLabel.setText("KEY RANGE", juce::dontSendNotification);

        auto& keyLowSlider =
            keyLowSliders[static_cast<std::size_t>(index)];
        auto& keyHighSlider =
            keyHighSliders[static_cast<std::size_t>(index)];
        for (auto* rangeSlider : { &keyLowSlider, &keyHighSlider })
        {
            rangeSlider->setSliderStyle(
                juce::Slider::RotaryHorizontalVerticalDrag);
            rangeSlider->setTextBoxStyle(
                juce::Slider::TextBoxBelow, false, 68, 18);
            rangeSlider->setRange(0.0, 127.0, 1.0);
            rangeSlider->textFromValueFunction =
                [](double value)
            {
                return juce::MidiMessage::getMidiNoteName(
                    juce::roundToInt(value), true, true, 4);
            };
        }
        keyLowSlider.setDoubleClickReturnValue(true, 0.0);
        keyHighSlider.setDoubleClickReturnValue(true, 127.0);
        keyLowSlider.setTooltip(
            "Lowest note this layer responds to");
        keyHighSlider.setTooltip(
            "Highest note this layer responds to");

        keyLowAttachments[static_cast<std::size_t>(index)] =
            std::make_unique<SliderAttachment>(
                audioProcessor.parameters,
                "layerKeyLow" + number,
                keyLowSlider);
        keyHighAttachments[static_cast<std::size_t>(index)] =
            std::make_unique<SliderAttachment>(
                audioProcessor.parameters,
                "layerKeyHigh" + number,
                keyHighSlider);

        addAndMakeVisible(keyRangeLabel);
        addAndMakeVisible(keyLowSlider);
        addAndMakeVisible(keyHighSlider);
    }

    configureLabel(globalToneLabel,
                   0.7f,
                   juce::Justification::centredLeft);
    globalToneLabel.setText("GLOBAL TONE", juce::dontSendNotification);
    configureLabel(spaceEffectsLabel,
                   0.7f,
                   juce::Justification::centredLeft);
    spaceEffectsLabel.setText("EFFECTS", juce::dontSendNotification);
    configureLabel(outputLabel,
                   0.7f,
                   juce::Justification::centredLeft);
    outputLabel.setText("OUTPUT", juce::dontSendNotification);

    configureLabel(cutoffLabel, 0.58f, juce::Justification::centred);
    cutoffLabel.setText("CUTOFF", juce::dontSendNotification);
    configureLabel(resonanceLabel, 0.58f, juce::Justification::centred);
    resonanceLabel.setText("RESONANCE", juce::dontSendNotification);
    configureLabel(chorusLabel, 0.58f, juce::Justification::centred);
    chorusLabel.setText("CHORUS", juce::dontSendNotification);
    configureLabel(delayLabel, 0.58f, juce::Justification::centred);
    delayLabel.setText("DELAY", juce::dontSendNotification);
    configureLabel(delayTypeLabel, 0.46f, juce::Justification::centred);
    delayTypeLabel.setText("TYPE", juce::dontSendNotification);
    configureLabel(delayLengthLabel, 0.46f, juce::Justification::centred);
    delayLengthLabel.setText("LENGTH", juce::dontSendNotification);
    configureLabel(reverbLabel, 0.58f, juce::Justification::centred);
    reverbLabel.setText("REVERB", juce::dontSendNotification);
    configureLabel(reverbTypeLabel, 0.46f, juce::Justification::centred);
    reverbTypeLabel.setText("TYPE", juce::dontSendNotification);
    configureLabel(masterLabel, 0.58f, juce::Justification::centred);
    masterLabel.setText("MASTER", juce::dontSendNotification);

    configureSlider(cutoffSlider, "", 0);
    configureSlider(resonanceSlider, "", 2);
    configureSlider(chorusSlider, "", 2);
    configureSlider(delaySlider, "", 2);
    configureSlider(reverbSlider, "", 2);
    configureSlider(masterSlider, "", 1);
    chorusSlider.setTextBoxStyle(
        juce::Slider::TextBoxBelow, false, 76, 20);
    delaySlider.setTextBoxStyle(
        juce::Slider::TextBoxBelow, false, 64, 20);
    reverbSlider.setTextBoxStyle(
        juce::Slider::TextBoxBelow, false, 64, 20);
    cutoffSlider.setDoubleClickReturnValue(true, 20000.0);
    resonanceSlider.setDoubleClickReturnValue(true, 0.71);
    chorusSlider.setDoubleClickReturnValue(true, 0.12);
    delaySlider.setDoubleClickReturnValue(true, 0.0);
    reverbSlider.setDoubleClickReturnValue(true, 0.18);
    masterSlider.setDoubleClickReturnValue(true, -6.0);
    chorusSlider.setTooltip("Chorus wet/dry mix");
    delaySlider.setTooltip("Delay wet/dry mix");
    reverbSlider.setTooltip("Reverb wet/dry mix");

    delayTypeBox.addItem("Clean", 1);
    delayTypeBox.addItem("Tape", 2);
    delayTypeBox.addItem("Analog", 3);
    delayTypeBox.addItem("Ping-Pong", 4);
    delayTypeBox.setTooltip("Select delay character");
    delayLengthBox.addItem("80 ms", 1);
    delayLengthBox.addItem("160 ms", 2);
    delayLengthBox.addItem("320 ms", 3);
    delayLengthBox.addItem("480 ms", 4);
    delayLengthBox.addItem("640 ms", 5);
    delayLengthBox.setTooltip("Select delay length");
    reverbTypeBox.addItem("Studio Room", 1);
    reverbTypeBox.addItem("Hall", 2);
    reverbTypeBox.addItem("Plate", 3);
    reverbTypeBox.addItem("Chamber", 4);
    reverbTypeBox.setTooltip("Select reverb type");

    cutoffAttachment = std::make_unique<SliderAttachment>(
        audioProcessor.parameters,
        "cutoff",
        cutoffSlider);
    resonanceAttachment = std::make_unique<SliderAttachment>(
        audioProcessor.parameters,
        "resonance",
        resonanceSlider);
    chorusAttachment = std::make_unique<SliderAttachment>(
        audioProcessor.parameters,
        "chorusMix",
        chorusSlider);
    delayAttachment = std::make_unique<SliderAttachment>(
        audioProcessor.parameters,
        "delayMix",
        delaySlider);
    reverbAttachment = std::make_unique<SliderAttachment>(
        audioProcessor.parameters,
        "reverbMix",
        reverbSlider);
    masterAttachment = std::make_unique<SliderAttachment>(
        audioProcessor.parameters,
        "masterGain",
        masterSlider);
    delayTypeAttachment = std::make_unique<ComboBoxAttachment>(
        audioProcessor.parameters,
        "delayType",
        delayTypeBox);
    delayLengthAttachment = std::make_unique<ComboBoxAttachment>(
        audioProcessor.parameters,
        "delayLength",
        delayLengthBox);
    reverbTypeAttachment = std::make_unique<ComboBoxAttachment>(
        audioProcessor.parameters,
        "reverbType",
        reverbTypeBox);

    for (auto* component : {
             static_cast<juce::Component*>(&globalToneLabel),
             static_cast<juce::Component*>(&spaceEffectsLabel),
             static_cast<juce::Component*>(&outputLabel),
             static_cast<juce::Component*>(&cutoffLabel),
             static_cast<juce::Component*>(&resonanceLabel),
             static_cast<juce::Component*>(&chorusLabel),
             static_cast<juce::Component*>(&delayLabel),
             static_cast<juce::Component*>(&delayTypeLabel),
             static_cast<juce::Component*>(&delayLengthLabel),
             static_cast<juce::Component*>(&reverbLabel),
             static_cast<juce::Component*>(&reverbTypeLabel),
             static_cast<juce::Component*>(&masterLabel),
             static_cast<juce::Component*>(&cutoffSlider),
             static_cast<juce::Component*>(&resonanceSlider),
             static_cast<juce::Component*>(&chorusSlider),
             static_cast<juce::Component*>(&delaySlider),
             static_cast<juce::Component*>(&reverbSlider),
             static_cast<juce::Component*>(&masterSlider),
             static_cast<juce::Component*>(&delayTypeBox),
             static_cast<juce::Component*>(&delayLengthBox),
             static_cast<juce::Component*>(&reverbTypeBox),
             static_cast<juce::Component*>(&outputLeftMeter),
             static_cast<juce::Component*>(&outputRightMeter) })
    {
        addAndMakeVisible(*component);
    }

    configureLabel(performanceLabel, 0.5f, juce::Justification::centredLeft);
    performanceLabel.setText("PERFORMANCE", juce::dontSendNotification);

    performanceBox.setTextWhenNothingSelected("Select a saved performance");
    performanceBox.onChange = [this]
    {
        const auto itemId = performanceBox.getSelectedId();
        if (itemId <= 0)
            return;

        const auto names = audioProcessor.getSavedPerformanceNames();
        if (juce::isPositiveAndBelow(itemId - 1, names.size()))
            audioProcessor.loadPerformance(names[itemId - 1]);

        for (int index = 0;
             index < RuFTraXSF2SuperAudioProcessor::layerCount;
             ++index)
        {
            refreshLayer(index);
        }
    };

    savePerformanceButton.setTooltip(
        "Save the current 5-layer setup as a named performance");
    savePerformanceButton.onClick = [this] { promptAndSavePerformance(); };

    deletePerformanceButton.setTooltip(
        "Delete the selected saved performance");
    deletePerformanceButton.onClick = [this]
    {
        const auto itemId = performanceBox.getSelectedId();
        if (itemId <= 0)
            return;

        const auto names = audioProcessor.getSavedPerformanceNames();
        if (juce::isPositiveAndBelow(itemId - 1, names.size()))
            audioProcessor.deletePerformance(names[itemId - 1]);

        refreshPerformanceList();
    };

    addAndMakeVisible(performanceLabel);
    addAndMakeVisible(performanceBox);
    addAndMakeVisible(savePerformanceButton);
    addAndMakeVisible(deletePerformanceButton);
    refreshPerformanceList();

    for (int index = 0;
         index < RuFTraXSF2SuperAudioProcessor::layerCount;
         ++index)
    {
        refreshLayer(index);
    }

    startTimerHz(30);
}

void RuFTraXSF2SuperAudioProcessorEditor::refreshPerformanceList()
{
    const auto names = audioProcessor.getSavedPerformanceNames();
    performanceBox.clear(juce::dontSendNotification);
    for (int index = 0; index < names.size(); ++index)
        performanceBox.addItem(names[index], index + 1);
    performanceBox.setSelectedId(0, juce::dontSendNotification);
}

void RuFTraXSF2SuperAudioProcessorEditor::promptAndSavePerformance()
{
    savePerformancePrompt = std::make_unique<juce::AlertWindow>(
        "Save Performance",
        "Name this performance:",
        juce::MessageBoxIconType::NoIcon);
    savePerformancePrompt->addTextEditor("name", "", "Name");
    savePerformancePrompt->addButton(
        "Save", 1, juce::KeyPress(juce::KeyPress::returnKey));
    savePerformancePrompt->addButton(
        "Cancel", 0, juce::KeyPress(juce::KeyPress::escapeKey));

    juce::Component::SafePointer<RuFTraXSF2SuperAudioProcessorEditor>
        safeThis(this);
    savePerformancePrompt->enterModalState(
        true,
        juce::ModalCallbackFunction::create(
            [safeThis](int result)
            {
                if (safeThis == nullptr)
                    return;

                if (result == 1)
                {
                    const auto name =
                        safeThis->savePerformancePrompt
                            ->getTextEditorContents("name");
                    const auto saveResult =
                        safeThis->audioProcessor.savePerformance(name);

                    if (saveResult.failed())
                    {
                        juce::AlertWindow::showMessageBoxAsync(
                            juce::MessageBoxIconType::WarningIcon,
                            "Could not save performance",
                            saveResult.getErrorMessage());
                    }
                    else
                    {
                        safeThis->refreshPerformanceList();
                    }
                }

                safeThis->savePerformancePrompt.reset();
            }),
        false);
}

RuFTraXSF2SuperAudioProcessorEditor::
    ~RuFTraXSF2SuperAudioProcessorEditor()
{
    stopTimer();
    fileChooser.reset();
    setLookAndFeel(nullptr);
}

void RuFTraXSF2SuperAudioProcessorEditor::configureSlider(
    juce::Slider& slider,
    const juce::String& suffix,
    int decimals)
{
    slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 92, 24);
    slider.setTextValueSuffix(suffix);
    slider.setNumDecimalPlacesToDisplay(decimals);
    slider.setDoubleClickReturnValue(true, slider.getValue());
}

void RuFTraXSF2SuperAudioProcessorEditor::configureLabel(
    juce::Label& label,
    float relativeSize,
    juce::Justification justification)
{
    label.setFont(juce::Font(juce::FontOptions(20.0f * relativeSize, juce::Font::bold)));
    label.setJustificationType(justification);
    label.setInterceptsMouseClicks(false, false);
}

void RuFTraXSF2SuperAudioProcessorEditor::paint(
    juce::Graphics& graphics)
{
    graphics.fillAll(juce::Colour(background));

    const auto width = static_cast<float>(getWidth());
    const auto height = static_cast<float>(getHeight());

    juce::ColourGradient leftWood(
        juce::Colour(0xff3a1b0d),
        0.0f,
        0.0f,
        juce::Colour(0xff6e3718),
        34.0f,
        0.0f,
        false);
    graphics.setGradientFill(leftWood);
    graphics.fillRect(0.0f, 0.0f, 36.0f, height);

    juce::ColourGradient rightWood(
        juce::Colour(0xff6e3718),
        width - 36.0f,
        0.0f,
        juce::Colour(0xff3a1b0d),
        width,
        0.0f,
        false);
    graphics.setGradientFill(rightWood);
    graphics.fillRect(width - 36.0f, 0.0f, 36.0f, height);

    for (float y = 45.0f; y < height; y += 42.0f)
    {
        graphics.setColour(juce::Colours::black.withAlpha(0.35f));
        graphics.drawLine(5.0f, y, 30.0f, y + 11.0f, 1.0f);
        graphics.drawLine(width - 30.0f,
                          y + 11.0f,
                          width - 5.0f,
                          y,
                          1.0f);
    }

    drawPanel(graphics,
              juce::Rectangle<float>(
                  50.0f,
                  24.0f,
                  width - 100.0f,
                  height * 0.13f));

    for (const auto& bounds : layerPanelBounds)
        drawPanel(graphics, bounds.toFloat());

    // Must match resized()'s bottomY/bottomHeight fractions exactly - this
    // is a separate copy only because paint() and resized() don't share a
    // layout struct.
    const auto bottom = juce::Rectangle<float>(
        50.0f,
        height * 0.815f,
        width - 100.0f,
        height * 0.14f);
    drawPanel(graphics, bottom);

    graphics.setColour(juce::Colour(deepGold).withAlpha(0.42f));
    const auto bottomInnerX = 78.0f;
    const auto bottomInnerRight = width - 72.0f;
    const auto bottomUsableWidth =
        bottomInnerRight - bottomInnerX - 32.0f;
    const auto globalSectionWidth = bottomUsableWidth * 0.24f;
    const auto effectsSectionWidth = bottomUsableWidth * 0.48f;
    const auto effectsSectionX =
        bottomInnerX + globalSectionWidth + 16.0f;
    const auto outputSectionX =
        effectsSectionX + effectsSectionWidth + 16.0f;

    graphics.drawVerticalLine(
        juce::roundToInt(effectsSectionX - 8.0f),
        bottom.getY() + 16.0f,
        bottom.getBottom() - 16.0f);
    graphics.drawVerticalLine(
        juce::roundToInt(outputSectionX - 8.0f),
        bottom.getY() + 16.0f,
        bottom.getBottom() - 16.0f);

    const auto plate = juce::Rectangle<float>(
        width * 0.40f,
        height - 34.0f,
        width * 0.20f,
        25.0f);
    juce::ColourGradient plateGradient(
        juce::Colour(0xffd6ad5a),
        plate.getX(),
        plate.getY(),
        juce::Colour(0xff7e5721),
        plate.getX(),
        plate.getBottom(),
        false);
    graphics.setGradientFill(plateGradient);
    graphics.fillRect(plate);
    graphics.setColour(juce::Colour(0xff2b1d0e));
    graphics.setFont(juce::Font(juce::FontOptions(11.0f, juce::Font::bold)));
    graphics.drawText("RUFTRAX SOUND LABS | BROOKLYN, NY",
                      plate,
                      juce::Justification::centred);

    drawScrew(graphics, 49.0f, 35.0f);
    drawScrew(graphics, width - 49.0f, 35.0f);
    drawScrew(graphics, 49.0f, height - 35.0f);
    drawScrew(graphics, width - 49.0f, height - 35.0f);
}

void RuFTraXSF2SuperAudioProcessorEditor::resized()
{
    const auto width = getWidth();
    const auto height = getHeight();
    const auto margin = 62;

    const auto headerY = 34;
    const auto headerHeight = juce::roundToInt(height * 0.11f);
    brandLabel.setBounds(margin + 18,
                         headerY + 8,
                         juce::roundToInt(width * 0.18f),
                         headerHeight - 18);
    productLabel.setBounds(juce::roundToInt(width * 0.21f),
                           headerY + 16,
                           juce::roundToInt(width * 0.24f),
                           34);
    subtitleLabel.setBounds(juce::roundToInt(width * 0.21f),
                            headerY + 49,
                            juce::roundToInt(width * 0.30f),
                            28);
    // Performance save/recall sits in the gap between the subtitle and the
    // MIDI note display.
    const auto performanceX = juce::roundToInt(width * 0.52f);
    const auto performanceRight = width - margin - 340;
    const auto performanceWidth =
        juce::jmax(120, performanceRight - performanceX);
    performanceLabel.setBounds(performanceX, headerY + 6, performanceWidth, 16);
    const auto perfButtonWidth = 52;
    const auto perfGap = 6;
    const auto comboWidth = juce::jmax(
        60,
        performanceWidth - (perfButtonWidth * 2 + perfGap * 2));
    performanceBox.setBounds(
        performanceX, headerY + 26, comboWidth, 28);
    savePerformanceButton.setBounds(
        performanceX + comboWidth + perfGap,
        headerY + 26,
        perfButtonWidth,
        28);
    deletePerformanceButton.setBounds(
        performanceX + comboWidth + perfGap * 2 + perfButtonWidth,
        headerY + 26,
        perfButtonWidth,
        28);

    midiNoteLabel.setBounds(width - margin - 325,
                            headerY + 29,
                            195,
                            30);
    midiLabel.setBounds(width - margin - 115,
                        headerY + 29,
                        58,
                        30);
    midiLight.setBounds(width - margin - 49,
                        headerY + 32,
                        24,
                        24);

    const auto layerTop = juce::roundToInt(height * 0.175f);
    // Extended from 0.745 to make room for the key-range row inserted
    // below the filters (the bottom effects row shrinks correspondingly).
    const auto layerBottom = juce::roundToInt(height * 0.805f);
    const auto layerHeight = layerBottom - layerTop;
    const auto gap = juce::jmax(8, juce::roundToInt(width * 0.008f));
    const auto available = width - margin * 2 - gap * 4;
    const auto layerWidth = available / 5;

    for (int index = 0;
         index < RuFTraXSF2SuperAudioProcessor::layerCount;
         ++index)
    {
        const auto x = margin + index * (layerWidth + gap);
        const auto panelBounds =
            juce::Rectangle<int>(x, layerTop, layerWidth, layerHeight);
        layerPanelBounds[static_cast<std::size_t>(index)] = panelBounds;

        const auto inset = juce::jmax(12, layerWidth / 16);
        const auto contentX = x + inset;
        const auto contentWidth = layerWidth - inset * 2;

        layerTitleLabels[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 20,
            contentWidth,
            26);
        layerNameLabels[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 52,
            contentWidth,
            32);
        layerStatusLabels[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 83,
            contentWidth,
            24);
        loadButtons[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 116,
            contentWidth,
            38);
        presetBoxes[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 166,
            contentWidth,
            40);

        const auto controlGap = juce::jmax(6, contentWidth / 20);
        const auto controlWidth = (contentWidth - controlGap) / 2;
        levelLabels[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 211,
            controlWidth,
            18);
        panLabels[static_cast<std::size_t>(index)].setBounds(
            contentX + controlWidth + controlGap,
            layerTop + 211,
            controlWidth,
            18);
        gainSliders[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 226,
            controlWidth,
            75);
        panSliders[static_cast<std::size_t>(index)].setBounds(
            contentX + controlWidth + controlGap,
            layerTop + 226,
            controlWidth,
            75);
        highPassLabels[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 301,
            controlWidth,
            17);
        lowPassLabels[static_cast<std::size_t>(index)].setBounds(
            contentX + controlWidth + controlGap,
            layerTop + 301,
            controlWidth,
            17);
        highPassSliders[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 317,
            controlWidth,
            66);
        lowPassSliders[static_cast<std::size_t>(index)].setBounds(
            contentX + controlWidth + controlGap,
            layerTop + 317,
            controlWidth,
            66);

        keyRangeLabels[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 388,
            contentWidth,
            13);
        keyLowSliders[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + 402,
            controlWidth,
            56);
        keyHighSliders[static_cast<std::size_t>(index)].setBounds(
            contentX + controlWidth + controlGap,
            layerTop + 402,
            controlWidth,
            56);

        const auto meterWidth = juce::jmax(26, layerWidth / 10);
        // transposeUpButtons sits at (meterTop + meterHeight/2 - 35), and
        // meterHeight can be as small as its 65px floor, so the transpose
        // stack's top can reach ~2.5px *above* meterTop - this offset
        // needs enough headroom above the key range row (which ends at
        // layerTop+458) to clear that in the worst case, not just clear
        // meterTop itself.
        const auto meterTop = layerTop + 490;
        const auto meterBottom = layerTop + layerHeight - 74;
        const auto meterHeight = juce::jmax(65, meterBottom - meterTop);
        const auto meterX = x + (layerWidth - meterWidth) / 2;
        layerMeters[static_cast<std::size_t>(index)].setBounds(
            meterX,
            meterTop,
            meterWidth,
            meterHeight);
        layerPitchLabels[static_cast<std::size_t>(index)].setBounds(
            contentX,
            meterTop + (meterHeight - 34) / 2,
            juce::jmax(1, meterX - contentX - 8),
            34);
        const auto transposeX = meterX + meterWidth + 8;
        const auto transposeWidth =
            juce::jmax(1,
                       contentX + contentWidth - transposeX);
        const auto transposeCentreY =
            meterTop + meterHeight / 2;
        // Tightened from the original +-50 footprint to fit below the
        // key-range row now above it (see meterTop's comment).
        transposeUpButtons[static_cast<std::size_t>(index)].setBounds(
            transposeX,
            transposeCentreY - 35,
            transposeWidth,
            22);
        transposeValueLabels[static_cast<std::size_t>(index)].setBounds(
            transposeX,
            transposeCentreY - 11,
            transposeWidth,
            22);
        transposeDownButtons[static_cast<std::size_t>(index)].setBounds(
            transposeX,
            transposeCentreY + 13,
            transposeWidth,
            22);

        const auto buttonGap = 10;
        const auto buttonWidth = (contentWidth - buttonGap) / 2;
        muteButtons[static_cast<std::size_t>(index)].setBounds(
            contentX,
            layerTop + layerHeight - 52,
            buttonWidth,
            34);
        soloButtons[static_cast<std::size_t>(index)].setBounds(
            contentX + buttonWidth + buttonGap,
            layerTop + layerHeight - 52,
            buttonWidth,
            34);
    }

    // Must match the `bottom` rectangle paint() draws (same two fractions)
    // and stay clear of the RUFTRAX SOUND LABS badge plate, which paint()
    // anchors at a fixed (height - 34) regardless of these fractions.
    const auto bottomY = juce::roundToInt(height * 0.815f);
    const auto bottomHeight = juce::roundToInt(height * 0.14f);
    const auto globalX = margin + 16;
    const auto bottomInnerRight = width - margin - 10;
    const auto bottomUsableWidth =
        bottomInnerRight - globalX - 32;
    const auto globalWidth =
        juce::roundToInt(bottomUsableWidth * 0.24f);
    const auto effectsWidth =
        juce::roundToInt(bottomUsableWidth * 0.48f);
    const auto effectsX = globalX + globalWidth + 16;
    const auto outputX = effectsX + effectsWidth + 16;
    const auto outputWidth = bottomInnerRight - outputX;

    globalToneLabel.setBounds(globalX,
                              bottomY + 12,
                              globalWidth,
                              25);
    spaceEffectsLabel.setBounds(effectsX,
                                bottomY + 12,
                                effectsWidth,
                                25);
    outputLabel.setBounds(outputX,
                          bottomY + 12,
                          outputWidth,
                          25);

    const auto globalControlWidth = juce::jmax(90, globalWidth / 2);
    cutoffLabel.setBounds(globalX,
                          bottomY + 42,
                          globalControlWidth,
                          20);
    resonanceLabel.setBounds(globalX + globalControlWidth,
                             bottomY + 42,
                             globalControlWidth,
                             20);
    cutoffSlider.setBounds(globalX,
                           bottomY + 60,
                           globalControlWidth,
                           bottomHeight - 73);
    resonanceSlider.setBounds(globalX + globalControlWidth,
                              bottomY + 60,
                              globalControlWidth,
                              bottomHeight - 73);

    const auto effectsControlWidth = effectsWidth / 3;
    chorusLabel.setBounds(effectsX,
                          bottomY + 42,
                          effectsControlWidth,
                          20);
    delayLabel.setBounds(effectsX + effectsControlWidth,
                          bottomY + 42,
                          effectsControlWidth,
                          20);
    reverbLabel.setBounds(effectsX + effectsControlWidth * 2,
                          bottomY + 42,
                          effectsControlWidth,
                          20);
    const auto effectKnobHeight =
        juce::jmax(54, bottomHeight - 70);
    const auto effectKnobWidth =
        juce::jmax(48, effectsControlWidth / 2);
    chorusSlider.setBounds(effectsX,
                           bottomY + 58,
                           effectsControlWidth,
                           effectKnobHeight);
    delaySlider.setBounds(effectsX + effectsControlWidth,
                          bottomY + 58,
                          effectKnobWidth,
                          effectKnobHeight);
    reverbSlider.setBounds(effectsX + effectsControlWidth * 2,
                           bottomY + 58,
                           effectKnobWidth,
                           effectKnobHeight);

    const auto detailGap = 4;
    const auto delayDetailX =
        effectsX + effectsControlWidth + effectKnobWidth
        + detailGap;
    const auto delayDetailWidth =
        effectsControlWidth - effectKnobWidth - detailGap;
    delayTypeLabel.setBounds(delayDetailX,
                             bottomY + 55,
                             delayDetailWidth,
                             12);
    delayLengthLabel.setBounds(
        delayDetailX,
        bottomY + 91,
        delayDetailWidth,
        12);
    delayTypeBox.setBounds(delayDetailX,
                           bottomY + 67,
                           delayDetailWidth,
                           24);
    delayLengthBox.setBounds(
        delayDetailX,
        bottomY + 103,
        delayDetailWidth,
        24);

    const auto reverbDetailX =
        effectsX + effectsControlWidth * 2
        + effectKnobWidth + detailGap;
    const auto reverbDetailWidth =
        effectsControlWidth - effectKnobWidth - detailGap;
    reverbTypeLabel.setBounds(reverbDetailX,
                              bottomY + 70,
                              reverbDetailWidth,
                              12);
    reverbTypeBox.setBounds(reverbDetailX,
                            bottomY + 83,
                            reverbDetailWidth,
                            26);

    const auto masterWidth = juce::jmax(100, outputWidth / 2);
    masterLabel.setBounds(outputX,
                          bottomY + 42,
                          masterWidth,
                          20);
    masterSlider.setBounds(outputX,
                           bottomY + 60,
                           masterWidth,
                           bottomHeight - 73);

    const auto meterHeight = bottomHeight - 68;
    const auto outputMeterWidth = juce::jmax(22, outputWidth / 12);
    const auto metersX = outputX + outputWidth - outputMeterWidth * 2 - 16;
    outputLeftMeter.setBounds(metersX,
                              bottomY + 47,
                              outputMeterWidth,
                              meterHeight);
    outputRightMeter.setBounds(metersX + outputMeterWidth + 8,
                               bottomY + 47,
                               outputMeterWidth,
                               meterHeight);
}

void RuFTraXSF2SuperAudioProcessorEditor::openLayerFileChooser(
    int layer)
{
    fileChooser = std::make_unique<juce::FileChooser>(
        "Choose an SF2 or SFZ for Layer " + juce::String(layer + 1),
        juce::File(),
        "*.sf2;*.sfz");

    const auto flags =
        juce::FileBrowserComponent::openMode
        | juce::FileBrowserComponent::canSelectFiles;
    juce::Component::SafePointer<
        RuFTraXSF2SuperAudioProcessorEditor> safeThis(this);

    fileChooser->launchAsync(
        flags,
        [safeThis, layer](const juce::FileChooser& chooser)
        {
            if (safeThis == nullptr)
                return;

            const auto file = chooser.getResult();
            if (file.existsAsFile())
                safeThis->loadFileIntoLayer(layer, file);

            safeThis->fileChooser.reset();
        });
}

bool RuFTraXSF2SuperAudioProcessorEditor::loadFileIntoLayer(
    int layer,
    const juce::File& file)
{
    if (!juce::isPositiveAndBelow(
            layer, RuFTraXSF2SuperAudioProcessor::layerCount))
    {
        return false;
    }

    // Loads on a background thread - a multi-GB sample library would
    // otherwise freeze this window for as long as it takes to parse.
    juce::Component::SafePointer<RuFTraXSF2SuperAudioProcessorEditor>
        safeThis(this);
    audioProcessor.loadInstrumentAsync(
        layer,
        file,
        [safeThis, layer, file](bool ok)
        {
            if (safeThis == nullptr)
                return;

            if (!ok)
            {
                juce::AlertWindow::showMessageBoxAsync(
                    juce::MessageBoxIconType::WarningIcon,
                    "Could not load instrument",
                    "RuFTraX could not load:\n"
                        + file.getFullPathName()
                        + "\n\nChoose a valid SF2 bank or an SFZ whose sample paths are available.");
            }

            safeThis->refreshLayer(layer);
        });

    refreshLayer(layer);
    return true;
}

void RuFTraXSF2SuperAudioProcessorEditor::refreshLayer(int layer)
{
    if (!juce::isPositiveAndBelow(
            layer,
            RuFTraXSF2SuperAudioProcessor::layerCount))
    {
        return;
    }

    const auto index = static_cast<std::size_t>(layer);
    const auto isLoaded = audioProcessor.isLayerLoaded(layer);
    const auto isLoading = audioProcessor.isLayerLoading(layer);
    loadButtons[index].setButtonText(
        isLoading ? "LOADING..." : (isLoaded ? "CLEAR SF" : "LOAD SF2/SFZ"));
    loadButtons[index].setTooltip(
        isLoading
            ? "This layer is loading in the background"
            : (isLoaded
                   ? "Stop and clear this SF2/SFZ layer"
                   : "Load an SF2 bank or SFZ instrument into this layer"));
    // Loading runs on a background thread precisely so this doesn't have
    // to block the UI - but a second click on the same layer mid-load
    // would race two loads against each other, so disable it meanwhile.
    loadButtons[index].setEnabled(!isLoading);
    layerNameLabels[index].setText(
        audioProcessor.getLayerName(layer),
        juce::dontSendNotification);
    layerStatusLabels[index].setText(
        audioProcessor.getLayerStatus(layer),
        juce::dontSendNotification);

    const auto names = audioProcessor.getPresetNames(layer);
    auto& box = presetBoxes[index];

    refreshingPresetBoxes = true;
    if (names != lastPresetNames[index])
    {
        box.clear(juce::dontSendNotification);
        for (int item = 0; item < names.size(); ++item)
            box.addItem(juce::String(item).paddedLeft('0', 3)
                            + "  " + names[item],
                        item + 1);
        lastPresetNames[index] = names;
    }

    const auto selected = audioProcessor.getSelectedPreset(layer);
    box.setSelectedId(names.isEmpty() ? 0 : selected + 1,
                      juce::dontSendNotification);
    refreshingPresetBoxes = false;
}

void RuFTraXSF2SuperAudioProcessorEditor::timerCallback()
{
    for (int layer = 0;
         layer < RuFTraXSF2SuperAudioProcessor::layerCount;
         ++layer)
    {
        refreshLayer(layer);
        const auto level = audioProcessor.getLayerLevel(layer);
        layerMeters[static_cast<std::size_t>(layer)]
            .setLevel(level);

        const auto frequency = audioProcessor.getLayerFrequency(layer);
        auto& lastFrequency =
            lastLayerFrequencies[static_cast<std::size_t>(layer)];
        if (frequency > 0.0f)
            lastFrequency = frequency;
        else if (level < 0.001f)
            lastFrequency = 0.0f;

        auto& pitchLabel =
            layerPitchLabels[static_cast<std::size_t>(layer)];
        const auto voiceCount = audioProcessor.getLayerVoiceCount(layer);
        const auto voiceSuffix =
            voiceCount > 0
                ? ("  |  " + juce::String(voiceCount) + "v")
                : juce::String();
        if (lastFrequency > 0.0f)
        {
            const auto detectedMidiNote =
                juce::jlimit(
                    0,
                    127,
                    juce::roundToInt(
                        69.0
                        + 12.0
                            * std::log2(
                                static_cast<double>(lastFrequency)
                                / 440.0)));
            const auto detectedNoteName =
                juce::MidiMessage::getMidiNoteName(
                    detectedMidiNote, true, true, 4);
            const auto frequencyText =
                juce::String(
                    lastFrequency,
                    lastFrequency < 1000.0f ? 1 : 0)
                + " Hz";

            pitchLabel.setText(
                detectedNoteName + "  " + frequencyText + voiceSuffix,
                juce::dontSendNotification);
            pitchLabel.setTooltip(
                "Detected audio pitch: "
                    + detectedNoteName + " at "
                    + juce::String(lastFrequency, 2) + " Hz  |  "
                    + juce::String(voiceCount) + " active voice"
                    + (voiceCount == 1 ? "" : "s"));
        }
        else
        {
            pitchLabel.setText("--" + voiceSuffix, juce::dontSendNotification);
            pitchLabel.setTooltip(
                "No stable audio pitch detected  |  "
                    + juce::String(voiceCount) + " active voice"
                    + (voiceCount == 1 ? "" : "s"));
        }

        const auto transpose =
            audioProcessor.getLayerTranspose(layer);
        auto& transposeValue =
            transposeValueLabels[static_cast<std::size_t>(layer)];
        transposeValue.setText(
            (transpose > 0 ? "+" : "")
                + juce::String(transpose),
            juce::dontSendNotification);
        transposeValue.setTooltip(
            "Layer transpose: "
                + juce::String(transpose)
                + (std::abs(transpose) == 1
                       ? " semitone"
                       : " semitones"));
    }

    outputLeftMeter.setLevel(audioProcessor.getOutputLevel(0));
    outputRightMeter.setLevel(audioProcessor.getOutputLevel(1));

    const auto midiCounter = audioProcessor.getMidiActivityCounter();
    if (midiCounter != lastMidiCounter)
    {
        lastMidiCounter = midiCounter;
        midiLightHold = 5;
    }
    else if (midiLightHold > 0)
    {
        --midiLightHold;
    }

    midiLight.setActive(midiLightHold > 0);

    const auto noteCounter = audioProcessor.getMidiNoteCounter();
    const auto activeNote = audioProcessor.getCurrentMidiNote();

    if (activeNote >= 0)
    {
        lastMidiNoteCounter = noteCounter;
        midiNoteHold = 30;
        midiNoteLabel.setText(
            "NOTE "
                + juce::MidiMessage::getMidiNoteName(
                    activeNote, true, true, 4)
                + "  (" + juce::String(activeNote) + ")",
            juce::dontSendNotification);
    }
    else if (noteCounter != lastMidiNoteCounter)
    {
        lastMidiNoteCounter = noteCounter;
        midiNoteHold = 30;

        const auto lastNote = audioProcessor.getLastMidiNote();
        if (lastNote >= 0)
        {
            midiNoteLabel.setText(
                "NOTE "
                    + juce::MidiMessage::getMidiNoteName(
                        lastNote, true, true, 4)
                    + "  (" + juce::String(lastNote) + ")",
                juce::dontSendNotification);
        }
    }
    else if (midiNoteHold > 0)
    {
        --midiNoteHold;
    }
    else
    {
        midiNoteLabel.setText("NOTE --", juce::dontSendNotification);
    }
}

bool RuFTraXSF2SuperAudioProcessorEditor::isInterestedInFileDrag(
    const juce::StringArray& files)
{
    for (const auto& path : files)
        if (juce::File(path).hasFileExtension("sf2;sfz"))
            return true;
    return false;
}

int RuFTraXSF2SuperAudioProcessorEditor::layerAtPosition(
    int x,
    int y) const
{
    for (int layer = 0;
         layer < RuFTraXSF2SuperAudioProcessor::layerCount;
         ++layer)
    {
        if (layerPanelBounds[static_cast<std::size_t>(layer)]
                .contains(x, y))
        {
            return layer;
        }
    }
    return 0;
}

void RuFTraXSF2SuperAudioProcessorEditor::filesDropped(
    const juce::StringArray& files,
    int x,
    int y)
{
    auto layer = layerAtPosition(x, y);

    for (const auto& path : files)
    {
        const juce::File file(path);
        if (!file.hasFileExtension("sf2;sfz"))
            continue;

        if (loadFileIntoLayer(layer, file))
            layer = (layer + 1)
                % RuFTraXSF2SuperAudioProcessor::layerCount;
    }
}
