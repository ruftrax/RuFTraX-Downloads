#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

#include <array>
#include <memory>

class PerformanceLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    PerformanceLookAndFeel();

    void drawRotarySlider(juce::Graphics&,
                          int x,
                          int y,
                          int width,
                          int height,
                          float sliderPosition,
                          float rotaryStartAngle,
                          float rotaryEndAngle,
                          juce::Slider&) override;

    void drawButtonBackground(juce::Graphics&,
                              juce::Button&,
                              const juce::Colour& backgroundColour,
                              bool highlighted,
                              bool down) override;

    void drawComboBox(juce::Graphics&,
                      int width,
                      int height,
                      bool isButtonDown,
                      int buttonX,
                      int buttonY,
                      int buttonWidth,
                      int buttonHeight,
                      juce::ComboBox&) override;

    juce::Font getComboBoxFont(juce::ComboBox&) override;
    juce::Font getTextButtonFont(juce::TextButton&, int buttonHeight) override;
};

class LEDStrip final : public juce::Component
{
public:
    void setLevel(float newLevel);
    void paint(juce::Graphics&) override;

private:
    float level = 0.0f;
};

class MidiLight final : public juce::Component
{
public:
    void setActive(bool shouldBeActive);
    void paint(juce::Graphics&) override;

private:
    bool active = false;
};

class RuFTraXSF2SuperAudioProcessorEditor final
    : public juce::AudioProcessorEditor,
      private juce::Timer,
      public juce::FileDragAndDropTarget
{
public:
    explicit RuFTraXSF2SuperAudioProcessorEditor(
        RuFTraXSF2SuperAudioProcessor&);
    ~RuFTraXSF2SuperAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

    bool isInterestedInFileDrag(const juce::StringArray& files) override;
    void filesDropped(const juce::StringArray& files,
                      int x,
                      int y) override;

private:
    using SliderAttachment =
        juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment =
        juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboBoxAttachment =
        juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    void timerCallback() override;
    void configureSlider(juce::Slider&,
                         const juce::String& suffix,
                         int decimals);
    void configureLabel(juce::Label&,
                        float relativeSize,
                        juce::Justification);
    void openLayerFileChooser(int layer);
    void refreshLayer(int layer);
    bool loadFileIntoLayer(int layer, const juce::File&);
    int layerAtPosition(int x, int y) const;

    RuFTraXSF2SuperAudioProcessor& audioProcessor;
    PerformanceLookAndFeel performanceLook;

    juce::Label brandLabel;
    juce::Label productLabel;
    juce::Label subtitleLabel;
    juce::Label midiNoteLabel;
    juce::Label midiLabel;
    MidiLight midiLight;

    std::array<juce::Label, RuFTraXSF2SuperAudioProcessor::layerCount>
        layerTitleLabels;
    std::array<juce::Label, RuFTraXSF2SuperAudioProcessor::layerCount>
        layerNameLabels;
    std::array<juce::Label, RuFTraXSF2SuperAudioProcessor::layerCount>
        layerStatusLabels;
    std::array<juce::Label, RuFTraXSF2SuperAudioProcessor::layerCount>
        levelLabels;
    std::array<juce::Label, RuFTraXSF2SuperAudioProcessor::layerCount>
        panLabels;
    std::array<juce::Label, RuFTraXSF2SuperAudioProcessor::layerCount>
        highPassLabels;
    std::array<juce::Label, RuFTraXSF2SuperAudioProcessor::layerCount>
        lowPassLabels;

    std::array<juce::TextButton, RuFTraXSF2SuperAudioProcessor::layerCount>
        loadButtons;
    std::array<juce::TextButton, RuFTraXSF2SuperAudioProcessor::layerCount>
        muteButtons;
    std::array<juce::TextButton, RuFTraXSF2SuperAudioProcessor::layerCount>
        soloButtons;
    std::array<juce::ComboBox, RuFTraXSF2SuperAudioProcessor::layerCount>
        presetBoxes;
    std::array<juce::Slider, RuFTraXSF2SuperAudioProcessor::layerCount>
        gainSliders;
    std::array<juce::Slider, RuFTraXSF2SuperAudioProcessor::layerCount>
        panSliders;
    std::array<juce::Slider, RuFTraXSF2SuperAudioProcessor::layerCount>
        highPassSliders;
    std::array<juce::Slider, RuFTraXSF2SuperAudioProcessor::layerCount>
        lowPassSliders;
    std::array<LEDStrip, RuFTraXSF2SuperAudioProcessor::layerCount>
        layerMeters;
    std::array<juce::Label, RuFTraXSF2SuperAudioProcessor::layerCount>
        layerPitchLabels;
    std::array<juce::TextButton,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        transposeUpButtons;
    std::array<juce::TextButton,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        transposeDownButtons;
    std::array<juce::Label,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        transposeValueLabels;
    std::array<juce::Rectangle<int>,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        layerPanelBounds;

    // Per-layer key range - which notes reach that layer's engine at all,
    // so the 5 layers can be split across the keyboard instead of always
    // all sounding together.
    std::array<juce::Label, RuFTraXSF2SuperAudioProcessor::layerCount>
        keyRangeLabels;
    std::array<juce::Slider, RuFTraXSF2SuperAudioProcessor::layerCount>
        keyLowSliders;
    std::array<juce::Slider, RuFTraXSF2SuperAudioProcessor::layerCount>
        keyHighSliders;
    std::array<std::unique_ptr<SliderAttachment>,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        keyLowAttachments;
    std::array<std::unique_ptr<SliderAttachment>,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        keyHighAttachments;

    // Saved performances (full 5-layer state, recallable in any project).
    juce::Label performanceLabel;
    juce::ComboBox performanceBox;
    juce::TextButton savePerformanceButton { "SAVE" };
    juce::TextButton deletePerformanceButton { "DEL" };
    std::unique_ptr<juce::AlertWindow> savePerformancePrompt;
    void refreshPerformanceList();
    void promptAndSavePerformance();

    std::array<std::unique_ptr<SliderAttachment>,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        gainAttachments;
    std::array<std::unique_ptr<SliderAttachment>,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        panAttachments;
    std::array<std::unique_ptr<SliderAttachment>,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        highPassAttachments;
    std::array<std::unique_ptr<SliderAttachment>,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        lowPassAttachments;
    std::array<std::unique_ptr<ButtonAttachment>,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        muteAttachments;
    std::array<std::unique_ptr<ButtonAttachment>,
               RuFTraXSF2SuperAudioProcessor::layerCount>
        soloAttachments;

    juce::Label globalToneLabel;
    juce::Label spaceEffectsLabel;
    juce::Label outputLabel;
    juce::Label cutoffLabel;
    juce::Label resonanceLabel;
    juce::Label chorusLabel;
    juce::Label delayLabel;
    juce::Label delayTypeLabel;
    juce::Label delayLengthLabel;
    juce::Label reverbLabel;
    juce::Label reverbTypeLabel;
    juce::Label masterLabel;

    juce::Slider cutoffSlider;
    juce::Slider resonanceSlider;
    juce::Slider chorusSlider;
    juce::Slider delaySlider;
    juce::Slider reverbSlider;
    juce::Slider masterSlider;
    juce::ComboBox delayTypeBox;
    juce::ComboBox delayLengthBox;
    juce::ComboBox reverbTypeBox;
    LEDStrip outputLeftMeter;
    LEDStrip outputRightMeter;

    std::unique_ptr<SliderAttachment> cutoffAttachment;
    std::unique_ptr<SliderAttachment> resonanceAttachment;
    std::unique_ptr<SliderAttachment> chorusAttachment;
    std::unique_ptr<SliderAttachment> delayAttachment;
    std::unique_ptr<SliderAttachment> reverbAttachment;
    std::unique_ptr<SliderAttachment> masterAttachment;
    std::unique_ptr<ComboBoxAttachment> delayTypeAttachment;
    std::unique_ptr<ComboBoxAttachment> delayLengthAttachment;
    std::unique_ptr<ComboBoxAttachment> reverbTypeAttachment;

    std::unique_ptr<juce::FileChooser> fileChooser;
    std::array<float, RuFTraXSF2SuperAudioProcessor::layerCount>
        lastLayerFrequencies {};
    // What each preset box was last built from - refreshLayer() only
    // rebuilds a box when its layer's real preset names have changed, not
    // merely when the count has (two different instruments can easily
    // share a preset count, which used to leave the old instrument's
    // preset names on screen after loading a new one).
    std::array<juce::StringArray, RuFTraXSF2SuperAudioProcessor::layerCount>
        lastPresetNames;
    bool refreshingPresetBoxes = false;
    juce::uint32 lastMidiCounter = 0;
    juce::uint32 lastMidiNoteCounter = 0;
    int midiLightHold = 0;
    int midiNoteHold = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(
        RuFTraXSF2SuperAudioProcessorEditor)
};
