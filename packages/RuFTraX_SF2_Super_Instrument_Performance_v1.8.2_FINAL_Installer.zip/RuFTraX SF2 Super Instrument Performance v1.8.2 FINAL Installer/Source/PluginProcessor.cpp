#include "PluginProcessor.h"
#include "PluginEditor.h"

#if RUFTRAX_HAS_BUNDLED_SF2
 #include <BinaryData.h>
#endif

#define TSF_IMPLEMENTATION
#include "tsf.h"
#include <sfizz.h>

#include <algorithm>
#include <cmath>

namespace
{
constexpr int midiChannel = 0;
constexpr std::array<float, 5> delayLengthMilliseconds {
    80.0f,
    160.0f,
    320.0f,
    480.0f,
    640.0f
};

float panLeft(float pan) noexcept
{
    return pan <= 0.0f ? 1.0f : 1.0f - pan;
}

float panRight(float pan) noexcept
{
    return pan >= 0.0f ? 1.0f : 1.0f + pan;
}

int transposeMidiNote(int note, int semitones) noexcept
{
    const auto transposed = note + semitones;
    return juce::isPositiveAndBelow(transposed, 128)
        ? transposed
        : -1;
}
}

RuFTraXSF2SuperAudioProcessor::RuFTraXSF2SuperAudioProcessor()
    : AudioProcessor(BusesProperties()
                         .withOutput("Output",
                                     juce::AudioChannelSet::stereo(),
                                     true)),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
    for (auto& meter : layerPeakLevels)
        meter.store(0.0f, std::memory_order_relaxed);

    for (auto& meter : outputPeakLevels)
        meter.store(0.0f, std::memory_order_relaxed);

    for (auto& note : activeMidiNotes)
        note.store(false, std::memory_order_relaxed);

    loadBundledSoundFont(0);
}

RuFTraXSF2SuperAudioProcessor::~RuFTraXSF2SuperAudioProcessor()
{
    const juce::ScopedLock lock(layerLock);
    for (auto& layer : layers)
        closeLayer(layer);
}

juce::AudioProcessorValueTreeState::ParameterLayout
RuFTraXSF2SuperAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    for (int index = 0; index < layerCount; ++index)
    {
        const auto number = juce::String(index + 1);

        layout.add(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { "layerGain" + number, 1 },
            "Layer " + number + " Volume",
            juce::NormalisableRange<float>(-60.0f, 6.0f, 0.1f),
            index == 0 ? -6.0f : -12.0f));

        layout.add(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { "layerPan" + number, 1 },
            "Layer " + number + " Pan",
            juce::NormalisableRange<float>(-1.0f, 1.0f, 0.01f),
            0.0f));

        layout.add(std::make_unique<juce::AudioParameterInt>(
            juce::ParameterID { "layerTranspose" + number, 1 },
            "Layer " + number + " Transpose",
            -24,
            24,
            0));

        layout.add(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { "layerHighPass" + number, 1 },
            "Layer " + number + " High Pass",
            juce::NormalisableRange<float>(
                20.0f, 10000.0f, 1.0f, 0.25f),
            20.0f));

        layout.add(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { "layerLowPass" + number, 1 },
            "Layer " + number + " Low Pass",
            juce::NormalisableRange<float>(
                100.0f, 20000.0f, 1.0f, 0.25f),
            20000.0f));

        layout.add(std::make_unique<juce::AudioParameterBool>(
            juce::ParameterID { "layerMute" + number, 1 },
            "Layer " + number + " Mute",
            false));

        layout.add(std::make_unique<juce::AudioParameterBool>(
            juce::ParameterID { "layerSolo" + number, 1 },
            "Layer " + number + " Solo",
            false));
    }

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "masterGain", 1 },
        "Master",
        juce::NormalisableRange<float>(-60.0f, 6.0f, 0.1f),
        -6.0f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "cutoff", 1 },
        "Cutoff",
        juce::NormalisableRange<float>(40.0f, 20000.0f, 1.0f, 0.28f),
        20000.0f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "resonance", 1 },
        "Resonance",
        juce::NormalisableRange<float>(0.2f, 1.4f, 0.01f),
        0.71f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "chorusMix", 1 },
        "Chorus",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),
        0.12f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "delayMix", 1 },
        "Delay Mix",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),
        0.0f));

    layout.add(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "delayType", 1 },
        "Delay Type",
        juce::StringArray { "Clean",
                            "Tape",
                            "Analog",
                            "Ping-Pong" },
        0));

    layout.add(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "delayLength", 1 },
        "Delay Length",
        juce::StringArray { "80 ms",
                            "160 ms",
                            "320 ms",
                            "480 ms",
                            "640 ms" },
        2));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "reverbMix", 1 },
        "Reverb",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),
        0.18f));

    layout.add(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "reverbType", 1 },
        "Reverb Type",
        juce::StringArray { "Studio Room",
                            "Hall",
                            "Plate",
                            "Chamber" },
        0));

    return layout;
}

void RuFTraXSF2SuperAudioProcessor::prepareToPlay(double sampleRate,
                                                  int samplesPerBlock)
{
    sampleRateHz = sampleRate;
    maximumBlockSize = juce::jmax(1, samplesPerBlock);
    pitchDecimationFactor =
        juce::jmax(1, juce::roundToInt(sampleRate / 22050.0));
    nextPitchLayer = 0;
    pitchAnalysisBlockCounter = 0;

    const juce::dsp::ProcessSpec spec {
        sampleRate,
        static_cast<juce::uint32>(samplesPerBlock),
        2
    };

    filter.prepare(spec);
    filter.setType(juce::dsp::StateVariableTPTFilterType::lowpass);

    chorus.prepare(spec);
    chorus.setRate(0.38f);
    chorus.setDepth(0.24f);
    chorus.setCentreDelay(10.0f);
    chorus.setFeedback(0.06f);

    const auto delayCapacity =
        juce::jmax(2, juce::roundToInt(sampleRate * 2.0) + 2);
    delayBuffer.setSize(2,
                        delayCapacity,
                        false,
                        true,
                        true);
    delayBuffer.clear();
    delayWritePosition = 0;
    delayToneState.fill(0.0f);
    delaySamples.reset(sampleRate, 0.05);
    delaySamples.setCurrentAndTargetValue(
        static_cast<float>(
            sampleRate * delayLengthMilliseconds[2] / 1000.0));

    reverb.reset();

    const juce::ScopedLock lock(layerLock);
    for (int index = 0; index < layerCount; ++index)
    {
        auto& layer = layers[static_cast<std::size_t>(index)];
        layer.sfzCapacity = maximumBlockSize;
        layer.sfzLeft.allocate(static_cast<std::size_t>(maximumBlockSize),
                               true);
        layer.sfzRight.allocate(static_cast<std::size_t>(maximumBlockSize),
                                true);
        layer.highPassFilter.prepare(spec);
        layer.highPassFilter.setType(
            juce::dsp::StateVariableTPTFilterType::highpass);
        layer.highPassFilter.setResonance(0.7071f);
        layer.highPassFilter.reset();

        layer.lowPassFilter.prepare(spec);
        layer.lowPassFilter.setType(
            juce::dsp::StateVariableTPTFilterType::lowpass);
        layer.lowPassFilter.setResonance(0.7071f);
        layer.lowPassFilter.reset();

        updateLayerFilters(index, layer);
        resetPitchTracking(layer);
        resetLayerNoteTracking(layer, getLayerTranspose(index));
        configureLayer(layer);
    }
}

bool RuFTraXSF2SuperAudioProcessor::layerLoaded(
    const Layer& layer) const noexcept
{
    return (layer.engine == InstrumentEngine::sf2
            && layer.synth != nullptr)
        || (layer.engine == InstrumentEngine::sfz
            && layer.sfzSynth != nullptr);
}

bool RuFTraXSF2SuperAudioProcessor::isBusesLayoutSupported(
    const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet()
        == juce::AudioChannelSet::stereo();
}

void RuFTraXSF2SuperAudioProcessor::closeLayer(Layer& layer)
{
    if (layer.synth != nullptr)
        tsf_close(layer.synth);
    if (layer.sfzSynth != nullptr)
        sfizz_free(layer.sfzSynth);

    layer.synth = nullptr;
    layer.sfzSynth = nullptr;
    layer.engine = InstrumentEngine::none;
    layer.bundledSoundFont = false;
    layer.highPassFilter.reset();
    layer.lowPassFilter.reset();
    resetPitchTracking(layer);
    resetLayerNoteTracking(layer, 0);
}

void RuFTraXSF2SuperAudioProcessor::configureLayer(Layer& layer)
{
    if (layer.engine == InstrumentEngine::sf2
        && layer.synth != nullptr)
    {
        tsf_set_output(layer.synth,
                       TSF_STEREO_INTERLEAVED,
                       static_cast<int>(sampleRateHz),
                       0.0f);
        tsf_channel_set_presetnumber(layer.synth,
                                     midiChannel,
                                     layer.preset,
                                     0);
    }
    else if (layer.engine == InstrumentEngine::sfz
             && layer.sfzSynth != nullptr)
    {
        sfizz_set_sample_rate(layer.sfzSynth,
                              static_cast<float>(sampleRateHz));
        sfizz_set_samples_per_block(layer.sfzSynth,
                                    maximumBlockSize);
    }
}

void RuFTraXSF2SuperAudioProcessor::resetPitchTracking(Layer& layer)
{
    layer.pitchHistory.fill(0.0f);
    layer.pitchWritePosition = 0;
    layer.pitchSamplesReady = 0;
    layer.pitchDecimationPhase = 0;
    layer.pitchSilentSamples = 0;
    layer.detectedPitchHz.store(0.0f, std::memory_order_relaxed);
}

void RuFTraXSF2SuperAudioProcessor::resetLayerNoteTracking(
    Layer& layer,
    int transpose)
{
    layer.outputNotesForInput.fill(-1);
    layer.inputNoteVelocities.fill(0.0f);
    layer.appliedTranspose = transpose;
}

void RuFTraXSF2SuperAudioProcessor::applyLayerTranspose(
    int layerIndex,
    Layer& layer)
{
    const auto transpose = getLayerTranspose(layerIndex);
    if (layer.appliedTranspose == transpose)
        return;

    if (layerLoaded(layer))
    {
        for (int inputNote = 0; inputNote < 128; ++inputNote)
        {
            auto& outputNote =
                layer.outputNotesForInput[
                    static_cast<std::size_t>(inputNote)];
            const auto velocity =
                layer.inputNoteVelocities[
                    static_cast<std::size_t>(inputNote)];

            if (outputNote >= 0)
            {
                if (layer.engine == InstrumentEngine::sf2)
                    tsf_channel_note_off(layer.synth,
                                         midiChannel,
                                         outputNote);
                else
                    sfizz_send_note_off(layer.sfzSynth,
                                        0,
                                        outputNote,
                                        0);
            }

            outputNote =
                velocity > 0.0f
                    ? transposeMidiNote(inputNote, transpose)
                    : -1;

            if (outputNote >= 0)
            {
                if (layer.engine == InstrumentEngine::sf2)
                    tsf_channel_note_on(layer.synth,
                                        midiChannel,
                                        outputNote,
                                        velocity);
                else
                    sfizz_send_note_on(
                        layer.sfzSynth,
                        0,
                        outputNote,
                        juce::jlimit(1,
                                     127,
                                     juce::roundToInt(velocity * 127.0f)));
            }
        }
    }

    layer.appliedTranspose = transpose;
    resetPitchTracking(layer);
}

void RuFTraXSF2SuperAudioProcessor::updateLayerFilters(
    int layerIndex,
    Layer& layer)
{
    const auto number = juce::String(layerIndex + 1);
    const auto maximumCutoff =
        static_cast<float>(
            juce::jmax(100.0, sampleRateHz * 0.45));
    const auto highPass =
        parameters
            .getRawParameterValue("layerHighPass" + number)
            ->load(std::memory_order_relaxed);
    const auto lowPass =
        parameters
            .getRawParameterValue("layerLowPass" + number)
            ->load(std::memory_order_relaxed);

    layer.highPassFilter.setCutoffFrequency(
        juce::jlimit(20.0f, maximumCutoff, highPass));
    layer.lowPassFilter.setCutoffFrequency(
        juce::jlimit(20.0f, maximumCutoff, lowPass));
}

void RuFTraXSF2SuperAudioProcessor::refreshPresets(Layer& layer)
{
    layer.presets.clear();
    if (layer.engine == InstrumentEngine::sfz
        && layer.sfzSynth != nullptr)
    {
        layer.presets.add(layer.name.isNotEmpty()
                              ? layer.name
                              : "SFZ Instrument");
        layer.preset = 0;
        return;
    }

    if (layer.engine != InstrumentEngine::sf2
        || layer.synth == nullptr)
        return;

    const auto count = tsf_get_presetcount(layer.synth);
    for (int index = 0; index < count; ++index)
    {
        const auto* name = tsf_get_presetname(layer.synth, index);
        layer.presets.add(name != nullptr
                              ? juce::String::fromUTF8(name)
                              : "Preset " + juce::String(index + 1));
    }

    if (layer.presets.isEmpty())
        layer.presets.add("Preset 1");

    layer.preset = juce::jlimit(0,
                                layer.presets.size() - 1,
                                layer.preset);
}

bool RuFTraXSF2SuperAudioProcessor::loadBundledSoundFont(int index)
{
#if RUFTRAX_HAS_BUNDLED_SF2
    if (!juce::isPositiveAndBelow(index, layerCount))
        return false;

    auto* synth = tsf_load_memory(BinaryData::Wurly_EP1_sf2,
                                  BinaryData::Wurly_EP1_sf2Size);
    if (synth == nullptr)
        return false;

    const juce::ScopedLock lock(layerLock);
    auto& layer = layers[static_cast<std::size_t>(index)];
    closeLayer(layer);
    layer.synth = synth;
    layer.engine = InstrumentEngine::sf2;
    layer.file = juce::File();
    layer.name = "+Wurly +E.P. 1";
    layer.status = "Bundled Wurly ready";
    layer.preset = 0;
    layer.bundledSoundFont = true;
    configureLayer(layer);
    refreshPresets(layer);
    return true;
#else
    juce::ignoreUnused(index);
    return false;
#endif
}

bool RuFTraXSF2SuperAudioProcessor::loadInstrument(int index,
                                                   const juce::File& file)
{
    if (!juce::isPositiveAndBelow(index, layerCount)
        || !file.existsAsFile())
    {
        return false;
    }

    const auto extension = file.getFileExtension().toLowerCase();
    if (extension != ".sf2" && extension != ".sfz")
        return false;

    if (extension == ".sf2")
    {
        auto* synth = tsf_load_filename(
            file.getFullPathName().toRawUTF8());
        if (synth == nullptr)
            return false;

        const juce::ScopedLock lock(layerLock);
        auto& layer = layers[static_cast<std::size_t>(index)];
        closeLayer(layer);
        layer.synth = synth;
        layer.engine = InstrumentEngine::sf2;
        layer.file = file;
        layer.name = file.getFileNameWithoutExtension();
        layer.status = "Loaded SF2: " + file.getFileName();
        layer.preset = 0;
        layer.bundledSoundFont = false;
        configureLayer(layer);
        refreshPresets(layer);
    }
    else
    {
        auto* synth = sfizz_create_synth();
        if (synth == nullptr)
            return false;

        sfizz_set_sample_rate(synth,
                              static_cast<float>(sampleRateHz));
        sfizz_set_samples_per_block(synth,
                                    maximumBlockSize);
        if (!sfizz_load_file(synth,
                             file.getFullPathName().toRawUTF8()))
        {
            sfizz_free(synth);
            return false;
        }

        const juce::ScopedLock lock(layerLock);
        auto& layer = layers[static_cast<std::size_t>(index)];
        closeLayer(layer);
        layer.sfzSynth = synth;
        layer.engine = InstrumentEngine::sfz;
        layer.file = file;
        layer.name = file.getFileNameWithoutExtension();
        layer.status = "Loaded SFZ: " + file.getFileName();
        layer.preset = 0;
        layer.bundledSoundFont = false;
        configureLayer(layer);
        refreshPresets(layer);
    }

    return true;
}

void RuFTraXSF2SuperAudioProcessor::clearLayer(int index)
{
    if (!juce::isPositiveAndBelow(index, layerCount))
        return;

    const juce::ScopedLock lock(layerLock);
    auto& layer = layers[static_cast<std::size_t>(index)];
    closeLayer(layer);
    layer.file = juce::File();
    layer.name = "Empty Layer";
    layer.status = "Load an SF2 or SFZ";
    layer.presets.clear();
    layer.preset = 0;
    layerPeakLevels[static_cast<std::size_t>(index)]
        .store(0.0f, std::memory_order_relaxed);
}

void RuFTraXSF2SuperAudioProcessor::selectPreset(int index, int preset)
{
    const juce::ScopedLock lock(layerLock);
    if (!juce::isPositiveAndBelow(index, layerCount))
        return;

    auto& layer = layers[static_cast<std::size_t>(index)];
    if (!layerLoaded(layer) || layer.presets.isEmpty())
        return;

    layer.preset = juce::jlimit(0,
                                layer.presets.size() - 1,
                                preset);
    if (layer.engine == InstrumentEngine::sf2)
    {
        tsf_channel_note_off_all(layer.synth, midiChannel);
        tsf_channel_set_presetnumber(layer.synth,
                                     midiChannel,
                                     layer.preset,
                                     0);
    }
    else
    {
        sfizz_send_cc(layer.sfzSynth, 0, 120, 0);
    }
    layer.status = "Preset: " + layer.presets[layer.preset];
    resetLayerNoteTracking(layer, getLayerTranspose(index));
    resetPitchTracking(layer);
}

bool RuFTraXSF2SuperAudioProcessor::layerAudible(int index) const
{
    const auto number = juce::String(index + 1);
    if (parameters.getRawParameterValue("layerMute" + number)
            ->load(std::memory_order_relaxed) > 0.5f)
    {
        return false;
    }

    auto anySolo = false;
    for (int other = 0; other < layerCount; ++other)
    {
        anySolo = anySolo
            || parameters
                   .getRawParameterValue(
                       "layerSolo" + juce::String(other + 1))
                   ->load(std::memory_order_relaxed) > 0.5f;
    }

    return !anySolo
        || parameters.getRawParameterValue("layerSolo" + number)
                   ->load(std::memory_order_relaxed) > 0.5f;
}

void RuFTraXSF2SuperAudioProcessor::handleMidi(
    const juce::MidiMessage& message)
{
    if (!message.isActiveSense() && !message.isMidiClock())
        midiActivityCounter.fetch_add(1, std::memory_order_relaxed);

    if (message.isNoteOn())
    {
        const auto note = message.getNoteNumber();
        if (juce::isPositiveAndBelow(note, 128))
        {
            activeMidiNotes[static_cast<std::size_t>(note)]
                .store(true, std::memory_order_relaxed);
            lastMidiNote.store(note, std::memory_order_relaxed);
            midiNoteCounter.fetch_add(1, std::memory_order_relaxed);
        }
    }
    else if (message.isNoteOff())
    {
        const auto note = message.getNoteNumber();
        if (juce::isPositiveAndBelow(note, 128))
        {
            activeMidiNotes[static_cast<std::size_t>(note)]
                .store(false, std::memory_order_relaxed);
        }
    }
    else if (message.isAllNotesOff() || message.isAllSoundOff())
    {
        for (auto& note : activeMidiNotes)
            note.store(false, std::memory_order_relaxed);
    }
    else if (message.isPitchWheel())
    {
        pitchWheelValue.store(message.getPitchWheelValue(),
                              std::memory_order_relaxed);
    }

    for (int layerIndex = 0;
         layerIndex < layerCount;
         ++layerIndex)
    {
        auto& layer =
            layers[static_cast<std::size_t>(layerIndex)];
        if (!layerLoaded(layer))
            continue;

        if (message.isNoteOn())
        {
            const auto inputNote = message.getNoteNumber();
            const auto velocity = message.getFloatVelocity();
            auto& outputNote =
                layer.outputNotesForInput[
                    static_cast<std::size_t>(inputNote)];

            if (outputNote >= 0)
            {
                if (layer.engine == InstrumentEngine::sf2)
                    tsf_channel_note_off(layer.synth,
                                         midiChannel,
                                         outputNote);
                else
                    sfizz_send_note_off(layer.sfzSynth,
                                        0,
                                        outputNote,
                                        0);
            }

            outputNote =
                transposeMidiNote(inputNote,
                                  getLayerTranspose(layerIndex));
            layer.inputNoteVelocities[
                static_cast<std::size_t>(inputNote)] = velocity;
            resetPitchTracking(layer);
            if (outputNote >= 0)
            {
                if (layer.engine == InstrumentEngine::sf2)
                    tsf_channel_note_on(layer.synth,
                                        midiChannel,
                                        outputNote,
                                        velocity);
                else
                    sfizz_send_note_on(
                        layer.sfzSynth,
                        0,
                        outputNote,
                        juce::jlimit(1,
                                     127,
                                     juce::roundToInt(velocity * 127.0f)));
            }
        }
        else if (message.isNoteOff())
        {
            const auto inputNote = message.getNoteNumber();
            auto& outputNote =
                layer.outputNotesForInput[
                    static_cast<std::size_t>(inputNote)];
            if (outputNote >= 0)
            {
                if (layer.engine == InstrumentEngine::sf2)
                    tsf_channel_note_off(layer.synth,
                                         midiChannel,
                                         outputNote);
                else
                    sfizz_send_note_off(
                        layer.sfzSynth,
                        0,
                        outputNote,
                        juce::jlimit(0,
                                     127,
                                     juce::roundToInt(
                                         message.getFloatVelocity() * 127.0f)));
            }

            outputNote = -1;
            layer.inputNoteVelocities[
                static_cast<std::size_t>(inputNote)] = 0.0f;
        }
        else if (message.isAllNotesOff() || message.isAllSoundOff())
        {
            if (layer.engine == InstrumentEngine::sf2)
                tsf_channel_note_off_all(layer.synth, midiChannel);
            else
                sfizz_send_cc(layer.sfzSynth, 0, 120, 0);
            resetLayerNoteTracking(
                layer,
                getLayerTranspose(layerIndex));
        }
        else if (message.isController())
        {
            if (layer.engine == InstrumentEngine::sf2)
                tsf_channel_midi_control(layer.synth,
                                         midiChannel,
                                         message.getControllerNumber(),
                                         message.getControllerValue());
            else
                sfizz_send_cc(layer.sfzSynth,
                              0,
                              message.getControllerNumber(),
                              message.getControllerValue());
        }
        else if (message.isPitchWheel())
        {
            if (layer.engine == InstrumentEngine::sf2)
                tsf_channel_set_pitchwheel(layer.synth,
                                           midiChannel,
                                           message.getPitchWheelValue());
            else
                sfizz_send_hd_pitch_wheel(
                    layer.sfzSynth,
                    0,
                    juce::jlimit(
                        -1.0f,
                        1.0f,
                        static_cast<float>(message.getPitchWheelValue() - 8192)
                            / 8192.0f));
        }
        else if (message.isAftertouch())
        {
            if (layer.engine == InstrumentEngine::sfz)
                sfizz_send_poly_aftertouch(layer.sfzSynth,
                                           0,
                                           message.getNoteNumber(),
                                           message.getAfterTouchValue());
        }
        else if (message.isChannelPressure())
        {
            if (layer.engine == InstrumentEngine::sfz)
                sfizz_send_channel_aftertouch(
                    layer.sfzSynth,
                    0,
                    message.getChannelPressureValue());
        }
        else if (message.isProgramChange() && !layer.presets.isEmpty())
        {
            if (layer.engine == InstrumentEngine::sf2)
            {
                tsf_channel_note_off_all(layer.synth, midiChannel);
                layer.preset = juce::jlimit(
                    0,
                    layer.presets.size() - 1,
                    message.getProgramChangeNumber());
                tsf_channel_set_presetnumber(layer.synth,
                                             midiChannel,
                                             layer.preset,
                                             0);
                resetLayerNoteTracking(
                    layer,
                    getLayerTranspose(layerIndex));
                resetPitchTracking(layer);
            }
            else
            {
                sfizz_send_program_change(layer.sfzSynth,
                                          0,
                                          message.getProgramChangeNumber());
            }
        }
    }
}

void RuFTraXSF2SuperAudioProcessor::renderLayer(
    int layerIndex,
    Layer& layer,
    juce::AudioBuffer<float>& output,
    int startSample,
    int numSamples,
    float gain,
    float pan,
    float& blockPeak)
{
    juce::ignoreUnused(layerIndex);

    if (!layerLoaded(layer) || numSamples <= 0)
        return;

    const auto required = numSamples * 2;
    if (required > layer.capacity)
    {
        layer.capacity = required;
        layer.interleaved.allocate(static_cast<std::size_t>(required), false);
    }

    if (layer.engine == InstrumentEngine::sf2)
    {
        tsf_render_float(layer.synth,
                         layer.interleaved.get(),
                         numSamples,
                         0);
    }
    else
    {
        int rendered = 0;
        while (rendered < numSamples)
        {
            const auto frames = juce::jmin(maximumBlockSize,
                                           numSamples - rendered);
            float* channels[] { layer.sfzLeft.get(),
                                layer.sfzRight.get() };
            sfizz_render_block(layer.sfzSynth,
                               channels,
                               2,
                               frames);

            for (int sample = 0; sample < frames; ++sample)
            {
                layer.interleaved[(rendered + sample) * 2] =
                    layer.sfzLeft[sample];
                layer.interleaved[(rendered + sample) * 2 + 1] =
                    layer.sfzRight[sample];
            }
            rendered += frames;
        }
    }

    auto* left = output.getWritePointer(0, startSample);
    auto* right = output.getWritePointer(1, startSample);
    const auto leftGain = gain * panLeft(pan);
    const auto rightGain = gain * panRight(pan);

    for (int sample = 0; sample < numSamples; ++sample)
    {
        const auto rawLeft = layer.interleaved[sample * 2];
        const auto rawRight = layer.interleaved[sample * 2 + 1];
        const auto highPassedLeft =
            layer.highPassFilter.processSample(0, rawLeft);
        const auto highPassedRight =
            layer.highPassFilter.processSample(1, rawRight);
        const auto filteredLeft =
            layer.lowPassFilter.processSample(0, highPassedLeft);
        const auto filteredRight =
            layer.lowPassFilter.processSample(1, highPassedRight);
        const auto pitchSample =
            0.5f * (filteredLeft + filteredRight);

        if (layer.pitchDecimationPhase == 0)
        {
            layer.pitchHistory[static_cast<std::size_t>(
                layer.pitchWritePosition)] = pitchSample;
            layer.pitchWritePosition =
                (layer.pitchWritePosition + 1) % pitchHistorySize;
            layer.pitchSamplesReady =
                juce::jmin(pitchHistorySize,
                           layer.pitchSamplesReady + 1);
        }

        ++layer.pitchDecimationPhase;
        if (layer.pitchDecimationPhase >= pitchDecimationFactor)
            layer.pitchDecimationPhase = 0;

        const auto contributionLeft =
            filteredLeft * leftGain;
        const auto contributionRight =
            filteredRight * rightGain;

        left[sample] += contributionLeft;
        right[sample] += contributionRight;

        blockPeak = juce::jmax(
            blockPeak,
            juce::jmax(std::abs(contributionLeft),
                       std::abs(contributionRight)));
    }
}

float RuFTraXSF2SuperAudioProcessor::detectLayerPitch(Layer& layer)
{
    if (layer.pitchSamplesReady < pitchAnalysisSize)
        return 0.0f;

    const auto historyStart =
        (layer.pitchWritePosition
         - pitchAnalysisSize
         + pitchHistorySize)
        % pitchHistorySize;

    double mean = 0.0;
    for (int sample = 0; sample < pitchAnalysisSize; ++sample)
    {
        const auto value =
            layer.pitchHistory[static_cast<std::size_t>(
                (historyStart + sample) % pitchHistorySize)];
        pitchScratch[static_cast<std::size_t>(sample)] = value;
        mean += value;
    }

    mean /= static_cast<double>(pitchAnalysisSize);

    double energy = 0.0;
    for (auto& sample : pitchScratch)
    {
        sample -= static_cast<float>(mean);
        energy += static_cast<double>(sample) * sample;
    }

    const auto rms =
        std::sqrt(energy / static_cast<double>(pitchAnalysisSize));
    if (rms < 0.0001)
        return 0.0f;

    const auto analysisRate =
        sampleRateHz / static_cast<double>(pitchDecimationFactor);
    constexpr double minimumFrequency = 30.0;
    constexpr double maximumFrequency = 5000.0;
    const auto minimumLag =
        juce::jmax(2,
                   static_cast<int>(
                       std::floor(analysisRate / maximumFrequency)));
    const auto maximumLag =
        juce::jlimit(
            minimumLag + 2,
            pitchMaxLag,
            static_cast<int>(
                std::ceil(analysisRate / minimumFrequency)));
    const auto comparisonLength = pitchAnalysisSize - maximumLag;

    pitchDifference.fill(0.0f);
    for (int lag = 1; lag <= maximumLag; ++lag)
    {
        double difference = 0.0;
        for (int sample = 0; sample < comparisonLength; ++sample)
        {
            const auto delta =
                pitchScratch[static_cast<std::size_t>(sample)]
                - pitchScratch[static_cast<std::size_t>(sample + lag)];
            difference += static_cast<double>(delta) * delta;
        }
        pitchDifference[static_cast<std::size_t>(lag)] =
            static_cast<float>(difference);
    }

    double cumulativeDifference = 0.0;
    pitchDifference[0] = 1.0f;
    for (int lag = 1; lag <= maximumLag; ++lag)
    {
        cumulativeDifference +=
            pitchDifference[static_cast<std::size_t>(lag)];
        pitchDifference[static_cast<std::size_t>(lag)] =
            cumulativeDifference > 0.0
                ? static_cast<float>(
                      pitchDifference[static_cast<std::size_t>(lag)]
                      * static_cast<double>(lag)
                      / cumulativeDifference)
                : 1.0f;
    }

    constexpr float yinThreshold = 0.18f;
    auto candidateLag = 0;
    auto bestLag = minimumLag;
    auto bestDifference =
        pitchDifference[static_cast<std::size_t>(minimumLag)];

    for (int lag = minimumLag; lag < maximumLag; ++lag)
    {
        const auto difference =
            pitchDifference[static_cast<std::size_t>(lag)];
        if (difference < bestDifference)
        {
            bestDifference = difference;
            bestLag = lag;
        }

        if (difference < yinThreshold)
        {
            candidateLag = lag;
            while (candidateLag + 1 <= maximumLag
                   && pitchDifference[static_cast<std::size_t>(
                          candidateLag + 1)]
                          < pitchDifference[static_cast<std::size_t>(
                              candidateLag)])
            {
                ++candidateLag;
            }
            break;
        }
    }

    if (candidateLag == 0)
        candidateLag = bestLag;

    if (pitchDifference[static_cast<std::size_t>(candidateLag)] > 0.42f)
        return 0.0f;

    auto refinedLag = static_cast<double>(candidateLag);
    if (candidateLag > minimumLag && candidateLag < maximumLag)
    {
        const auto left =
            pitchDifference[static_cast<std::size_t>(candidateLag - 1)];
        const auto centre =
            pitchDifference[static_cast<std::size_t>(candidateLag)];
        const auto right =
            pitchDifference[static_cast<std::size_t>(candidateLag + 1)];
        const auto curvature = left - 2.0f * centre + right;
        if (std::abs(curvature) > 1.0e-6f)
        {
            refinedLag += juce::jlimit(
                -0.5,
                0.5,
                0.5 * static_cast<double>(left - right)
                    / static_cast<double>(curvature));
        }
    }

    const auto frequency = analysisRate / refinedLag;
    return frequency >= minimumFrequency
               && frequency <= maximumFrequency
        ? static_cast<float>(frequency)
        : 0.0f;
}

void RuFTraXSF2SuperAudioProcessor::updateLayerPitchDetectors(
    const std::array<float, layerCount>& blockPeaks,
    int numSamples)
{
    constexpr float silenceThreshold = 0.00001f;
    const auto silenceLimit =
        juce::roundToInt(0.3 * sampleRateHz);

    for (int index = 0; index < layerCount; ++index)
    {
        auto& layer = layers[static_cast<std::size_t>(index)];
        if (!layerLoaded(layer)
            || !layerAudible(index)
            || blockPeaks[static_cast<std::size_t>(index)]
                   < silenceThreshold)
        {
            layer.pitchSilentSamples += numSamples;
            if (layer.pitchSilentSamples >= silenceLimit)
                layer.detectedPitchHz.store(
                    0.0f,
                    std::memory_order_relaxed);
        }
        else
        {
            layer.pitchSilentSamples = 0;
        }
    }

    constexpr int analysisBlockInterval = 4;
    ++pitchAnalysisBlockCounter;
    if (pitchAnalysisBlockCounter < analysisBlockInterval)
        return;

    pitchAnalysisBlockCounter = 0;
    auto& layer = layers[static_cast<std::size_t>(nextPitchLayer)];
    const auto layerIndex = nextPitchLayer;
    nextPitchLayer = (nextPitchLayer + 1) % layerCount;

    if (!layerLoaded(layer)
        || !layerAudible(layerIndex)
        || layer.pitchSilentSamples > 0)
    {
        return;
    }

    const auto detected = detectLayerPitch(layer);
    if (detected <= 0.0f)
        return;

    const auto previous =
        layer.detectedPitchHz.load(std::memory_order_relaxed);
    auto published = detected;
    if (previous > 0.0f)
    {
        const auto semitoneChange =
            std::abs(12.0f
                     * std::log2(detected / previous));
        if (semitoneChange < 1.0f)
            published = 0.72f * previous + 0.28f * detected;
    }

    layer.detectedPitchHz.store(published,
                                std::memory_order_relaxed);
}

void RuFTraXSF2SuperAudioProcessor::updateEffects()
{
    filter.setCutoffFrequency(
        parameters.getRawParameterValue("cutoff")
            ->load(std::memory_order_relaxed));
    filter.setResonance(
        parameters.getRawParameterValue("resonance")
            ->load(std::memory_order_relaxed));

    chorus.setMix(
        parameters.getRawParameterValue("chorusMix")
            ->load(std::memory_order_relaxed));

    const auto delayLengthIndex = juce::jlimit(
        0,
        static_cast<int>(delayLengthMilliseconds.size()) - 1,
        juce::roundToInt(
            parameters.getRawParameterValue("delayLength")
                ->load(std::memory_order_relaxed)));
    delaySamples.setTargetValue(
        static_cast<float>(
            sampleRateHz
            * delayLengthMilliseconds[
                static_cast<std::size_t>(delayLengthIndex)]
            / 1000.0));

    const auto reverbType = juce::jlimit(
        0,
        3,
        juce::roundToInt(
            parameters.getRawParameterValue("reverbType")
                ->load(std::memory_order_relaxed)));
    juce::Reverb::Parameters reverbParameters;
    if (reverbType == 1)
    {
        reverbParameters.roomSize = 0.82f;
        reverbParameters.damping = 0.34f;
        reverbParameters.width = 1.0f;
    }
    else if (reverbType == 2)
    {
        reverbParameters.roomSize = 0.68f;
        reverbParameters.damping = 0.16f;
        reverbParameters.width = 0.92f;
    }
    else if (reverbType == 3)
    {
        reverbParameters.roomSize = 0.62f;
        reverbParameters.damping = 0.52f;
        reverbParameters.width = 0.74f;
    }
    else
    {
        reverbParameters.roomSize = 0.58f;
        reverbParameters.damping = 0.45f;
        reverbParameters.width = 1.0f;
    }

    reverbParameters.wetLevel =
        parameters.getRawParameterValue("reverbMix")
            ->load(std::memory_order_relaxed);
    reverbParameters.dryLevel =
        1.0f - 0.3f * reverbParameters.wetLevel;
    reverb.setParameters(reverbParameters);
}

void RuFTraXSF2SuperAudioProcessor::processDelay(
    juce::AudioBuffer<float>& buffer)
{
    if (buffer.getNumChannels() < 2
        || delayBuffer.getNumSamples() < 2)
    {
        return;
    }

    const auto mix = juce::jlimit(
        0.0f,
        1.0f,
        parameters.getRawParameterValue("delayMix")
            ->load(std::memory_order_relaxed));
    const auto type = juce::jlimit(
        0,
        3,
        juce::roundToInt(
            parameters.getRawParameterValue("delayType")
                ->load(std::memory_order_relaxed)));
    const auto feedback = type == 1 ? 0.46f
                         : type == 2 ? 0.40f
                         : type == 3 ? 0.50f
                                     : 0.34f;
    const auto toneAmount = type == 1 ? 0.72f
                          : type == 2 ? 0.84f
                                      : 0.0f;
    const auto saturation = type == 1 ? 1.25f
                          : type == 2 ? 1.55f
                                      : 1.0f;
    const auto saturationScale =
        1.0f / std::tanh(saturation);
    const auto delayCapacity = delayBuffer.getNumSamples();
    auto* left = buffer.getWritePointer(0);
    auto* right = buffer.getWritePointer(1);

    for (int sample = 0; sample < buffer.getNumSamples(); ++sample)
    {
        const auto currentDelay = juce::jlimit(
            1.0f,
            static_cast<float>(delayCapacity - 2),
            delaySamples.getNextValue());
        auto readPosition =
            static_cast<float>(delayWritePosition) - currentDelay;
        while (readPosition < 0.0f)
            readPosition += static_cast<float>(delayCapacity);

        const auto readIndex =
            static_cast<int>(std::floor(readPosition));
        const auto nextReadIndex =
            (readIndex + 1) % delayCapacity;
        const auto fraction =
            readPosition - static_cast<float>(readIndex);

        const auto firstLeft =
            delayBuffer.getSample(0, readIndex);
        const auto firstRight =
            delayBuffer.getSample(1, readIndex);
        auto delayedLeft =
            firstLeft
            + fraction
                  * (delayBuffer.getSample(0, nextReadIndex)
                     - firstLeft);
        auto delayedRight =
            firstRight
            + fraction
                  * (delayBuffer.getSample(1, nextReadIndex)
                     - firstRight);

        if (type == 1 || type == 2)
        {
            delayToneState[0] =
                toneAmount * delayToneState[0]
                + (1.0f - toneAmount) * delayedLeft;
            delayToneState[1] =
                toneAmount * delayToneState[1]
                + (1.0f - toneAmount) * delayedRight;
            delayedLeft =
                std::tanh(delayToneState[0] * saturation)
                * saturationScale;
            delayedRight =
                std::tanh(delayToneState[1] * saturation)
                * saturationScale;
        }

        const auto inputLeft = left[sample];
        const auto inputRight = right[sample];
        if (type == 3)
        {
            delayBuffer.setSample(
                0,
                delayWritePosition,
                inputLeft + delayedRight * feedback);
            delayBuffer.setSample(
                1,
                delayWritePosition,
                inputRight + delayedLeft * feedback);
        }
        else
        {
            delayBuffer.setSample(
                0,
                delayWritePosition,
                inputLeft + delayedLeft * feedback);
            delayBuffer.setSample(
                1,
                delayWritePosition,
                inputRight + delayedRight * feedback);
        }

        const auto dryLevel = 1.0f - 0.25f * mix;
        left[sample] =
            inputLeft * dryLevel + delayedLeft * mix;
        right[sample] =
            inputRight * dryLevel + delayedRight * mix;

        delayWritePosition =
            (delayWritePosition + 1) % delayCapacity;
    }
}

void RuFTraXSF2SuperAudioProcessor::publishMeters(
    const std::array<float, layerCount>& blockPeaks,
    const juce::AudioBuffer<float>& output)
{
    const auto release = static_cast<float>(
        std::exp(-static_cast<double>(output.getNumSamples())
                 / (juce::jmax(1.0, sampleRateHz) * 0.32)));

    for (int index = 0; index < layerCount; ++index)
    {
        const auto previous =
            layerPeakLevels[static_cast<std::size_t>(index)]
                .load(std::memory_order_relaxed);
        const auto next =
            juce::jmax(blockPeaks[static_cast<std::size_t>(index)],
                       previous * release);
        layerPeakLevels[static_cast<std::size_t>(index)]
            .store(juce::jlimit(0.0f, 2.0f, next),
                   std::memory_order_relaxed);
    }

    for (int channel = 0; channel < 2; ++channel)
    {
        const auto blockPeak =
            output.getMagnitude(channel, 0, output.getNumSamples());
        const auto previous =
            outputPeakLevels[static_cast<std::size_t>(channel)]
                .load(std::memory_order_relaxed);
        outputPeakLevels[static_cast<std::size_t>(channel)]
            .store(juce::jlimit(0.0f,
                                2.0f,
                                juce::jmax(blockPeak,
                                           previous * release)),
                   std::memory_order_relaxed);
    }
}

void RuFTraXSF2SuperAudioProcessor::processBlock(
    juce::AudioBuffer<float>& buffer,
    juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();

    std::array<float, layerCount> blockPeaks {};

    {
        const juce::ScopedLock lock(layerLock);
        auto rendered = 0;

        for (int index = 0; index < layerCount; ++index)
        {
            auto& layer =
                layers[static_cast<std::size_t>(index)];
            applyLayerTranspose(
                index,
                layer);
            updateLayerFilters(index, layer);
        }

        for (const auto metadata : midiMessages)
        {
            const auto eventPosition =
                juce::jlimit(0,
                             buffer.getNumSamples(),
                             metadata.samplePosition);
            const auto segmentLength = eventPosition - rendered;

            for (int index = 0; index < layerCount; ++index)
            {
                if (!layerAudible(index))
                    continue;

                const auto number = juce::String(index + 1);
                renderLayer(
                    index,
                    layers[static_cast<std::size_t>(index)],
                    buffer,
                    rendered,
                    segmentLength,
                    juce::Decibels::decibelsToGain(
                        parameters
                            .getRawParameterValue("layerGain" + number)
                            ->load(std::memory_order_relaxed)),
                    parameters
                        .getRawParameterValue("layerPan" + number)
                        ->load(std::memory_order_relaxed),
                    blockPeaks[static_cast<std::size_t>(index)]);
            }

            handleMidi(metadata.getMessage());
            rendered = eventPosition;
        }

        const auto remaining = buffer.getNumSamples() - rendered;
        for (int index = 0; index < layerCount; ++index)
        {
            if (!layerAudible(index))
                continue;

            const auto number = juce::String(index + 1);
            renderLayer(
                index,
                layers[static_cast<std::size_t>(index)],
                buffer,
                rendered,
                remaining,
                juce::Decibels::decibelsToGain(
                    parameters.getRawParameterValue("layerGain" + number)
                        ->load(std::memory_order_relaxed)),
                parameters.getRawParameterValue("layerPan" + number)
                    ->load(std::memory_order_relaxed),
                blockPeaks[static_cast<std::size_t>(index)]);
        }

        updateLayerPitchDetectors(blockPeaks,
                                  buffer.getNumSamples());
    }

    updateEffects();

    juce::dsp::AudioBlock<float> audioBlock(buffer);
    juce::dsp::ProcessContextReplacing<float> context(audioBlock);
    filter.process(context);
    chorus.process(context);
    processDelay(buffer);
    reverb.processStereo(buffer.getWritePointer(0),
                         buffer.getWritePointer(1),
                         buffer.getNumSamples());

    buffer.applyGain(juce::Decibels::decibelsToGain(
        parameters.getRawParameterValue("masterGain")
            ->load(std::memory_order_relaxed)));

    publishMeters(blockPeaks, buffer);
}

void RuFTraXSF2SuperAudioProcessor::getStateInformation(
    juce::MemoryBlock& destination)
{
    auto state = parameters.copyState();

    {
        const juce::ScopedLock lock(layerLock);
        for (int index = 0; index < layerCount; ++index)
        {
            const auto key = juce::String(index);
            const auto& layer = layers[static_cast<std::size_t>(index)];
            state.setProperty("path" + key,
                              layer.file.getFullPathName(),
                              nullptr);
            state.setProperty("loaded" + key,
                              layerLoaded(layer),
                              nullptr);
            state.setProperty("format" + key,
                              layer.engine == InstrumentEngine::sfz
                                  ? "sfz"
                                  : "sf2",
                              nullptr);
            state.setProperty("bundled" + key,
                              layer.bundledSoundFont,
                              nullptr);
            state.setProperty("preset" + key,
                              layer.preset,
                              nullptr);
        }
    }

    if (const auto xml = state.createXml())
        copyXmlToBinary(*xml, destination);
}

void RuFTraXSF2SuperAudioProcessor::setStateInformation(
    const void* data,
    int size)
{
    const auto xml = getXmlFromBinary(data, size);
    if (xml == nullptr)
        return;

    const auto state = juce::ValueTree::fromXml(*xml);
    if (!state.isValid() || state.getType() != parameters.state.getType())
        return;

    parameters.replaceState(state);

    for (int index = 0; index < layerCount; ++index)
    {
        const auto key = juce::String(index);
        const juce::File file(state.getProperty("path" + key).toString());
        const auto shouldBeLoaded = static_cast<bool>(
            state.getProperty("loaded" + key,
                              index == 0));
        const auto useBundledSoundFont = static_cast<bool>(
            state.getProperty("bundled" + key,
                              index == 0
                                  && !file.existsAsFile()));

        if (shouldBeLoaded && file.existsAsFile())
        {
            loadInstrument(index, file);
        }
        else if (shouldBeLoaded && useBundledSoundFont)
        {
            loadBundledSoundFont(index);
        }
        else
        {
            clearLayer(index);
        }

        selectPreset(index,
                     static_cast<int>(
                         state.getProperty("preset" + key, 0)));
    }
}

bool RuFTraXSF2SuperAudioProcessor::isLayerLoaded(int index) const
{
    const juce::ScopedLock lock(layerLock);
    return juce::isPositiveAndBelow(index, layerCount)
        && layerLoaded(layers[static_cast<std::size_t>(index)]);
}

juce::String RuFTraXSF2SuperAudioProcessor::getLayerName(int index) const
{
    const juce::ScopedLock lock(layerLock);
    return juce::isPositiveAndBelow(index, layerCount)
        ? layers[static_cast<std::size_t>(index)].name
        : juce::String();
}

juce::String RuFTraXSF2SuperAudioProcessor::getLayerStatus(int index) const
{
    const juce::ScopedLock lock(layerLock);
    return juce::isPositiveAndBelow(index, layerCount)
        ? layers[static_cast<std::size_t>(index)].status
        : juce::String();
}

juce::StringArray
RuFTraXSF2SuperAudioProcessor::getPresetNames(int index) const
{
    const juce::ScopedLock lock(layerLock);
    return juce::isPositiveAndBelow(index, layerCount)
        ? layers[static_cast<std::size_t>(index)].presets
        : juce::StringArray();
}

int RuFTraXSF2SuperAudioProcessor::getSelectedPreset(int index) const
{
    const juce::ScopedLock lock(layerLock);
    return juce::isPositiveAndBelow(index, layerCount)
        ? layers[static_cast<std::size_t>(index)].preset
        : 0;
}

float RuFTraXSF2SuperAudioProcessor::getLayerLevel(int index) const noexcept
{
    return juce::isPositiveAndBelow(index, layerCount)
        ? layerPeakLevels[static_cast<std::size_t>(index)]
              .load(std::memory_order_relaxed)
        : 0.0f;
}

int RuFTraXSF2SuperAudioProcessor::getLayerMidiNote(int index) const
{
    if (!juce::isPositiveAndBelow(index, layerCount))
        return -1;

    {
        const juce::ScopedLock lock(layerLock);
        if (!layerLoaded(layers[static_cast<std::size_t>(index)]))
            return -1;
    }

    if (!layerAudible(index))
        return -1;

    return getCurrentMidiNote();
}

float RuFTraXSF2SuperAudioProcessor::getLayerFrequency(int index) const
{
    if (!juce::isPositiveAndBelow(index, layerCount))
        return 0.0f;

    return layers[static_cast<std::size_t>(index)]
        .detectedPitchHz.load(std::memory_order_relaxed);
}

int RuFTraXSF2SuperAudioProcessor::getLayerTranspose(
    int index) const noexcept
{
    if (!juce::isPositiveAndBelow(index, layerCount))
        return 0;

    return juce::roundToInt(
        parameters
            .getRawParameterValue(
                "layerTranspose" + juce::String(index + 1))
            ->load(std::memory_order_relaxed));
}

void RuFTraXSF2SuperAudioProcessor::nudgeLayerTranspose(
    int index,
    int semitones)
{
    if (!juce::isPositiveAndBelow(index, layerCount)
        || semitones == 0)
    {
        return;
    }

    auto* parameter = parameters.getParameter(
        "layerTranspose" + juce::String(index + 1));
    if (parameter == nullptr)
        return;

    const auto current = getLayerTranspose(index);
    const auto next = juce::jlimit(-24,
                                   24,
                                   current + semitones);
    if (next == current)
        return;

    parameter->beginChangeGesture();
    parameter->setValueNotifyingHost(
        parameter->convertTo0to1(static_cast<float>(next)));
    parameter->endChangeGesture();
}

float RuFTraXSF2SuperAudioProcessor::getOutputLevel(int channel) const noexcept
{
    return juce::isPositiveAndBelow(channel, 2)
        ? outputPeakLevels[static_cast<std::size_t>(channel)]
              .load(std::memory_order_relaxed)
        : 0.0f;
}

int RuFTraXSF2SuperAudioProcessor::getCurrentMidiNote() const noexcept
{
    const auto latest = lastMidiNote.load(std::memory_order_relaxed);
    if (juce::isPositiveAndBelow(latest, 128)
        && activeMidiNotes[static_cast<std::size_t>(latest)]
               .load(std::memory_order_relaxed))
    {
        return latest;
    }

    for (int note = 127; note >= 0; --note)
    {
        if (activeMidiNotes[static_cast<std::size_t>(note)]
                .load(std::memory_order_relaxed))
        {
            return note;
        }
    }

    return -1;
}

juce::AudioProcessorEditor*
RuFTraXSF2SuperAudioProcessor::createEditor()
{
    return new RuFTraXSF2SuperAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new RuFTraXSF2SuperAudioProcessor();
}
