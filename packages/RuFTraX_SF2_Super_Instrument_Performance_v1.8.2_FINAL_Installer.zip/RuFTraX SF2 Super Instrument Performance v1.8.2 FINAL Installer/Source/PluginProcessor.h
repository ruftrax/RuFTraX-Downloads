#pragma once

#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <functional>

struct tsf;
struct sfizz_synth_t;

class RuFTraXSF2SuperAudioProcessor final : public juce::AudioProcessor
{
public:
    static constexpr int layerCount = 5;

    RuFTraXSF2SuperAudioProcessor();
    ~RuFTraXSF2SuperAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 6.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Performance Stack"; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    bool loadInstrument(int layer, const juce::File&);
    bool loadSoundFont(int layer, const juce::File& file)
    {
        return loadInstrument(layer, file);
    }
    bool loadBundledSoundFont(int layer);
    void clearLayer(int layer);
    void selectPreset(int layer, int preset);

    // Loads on a background thread so a large SF2/SFZ library can't freeze
    // the UI; onComplete (if given) is called back on the message thread.
    // The synchronous loadInstrument() above still exists for
    // setStateInformation(), which JUCE expects to complete state
    // restoration synchronously.
    void loadInstrumentAsync(int layer,
                             const juce::File&,
                             std::function<void(bool)> onComplete = nullptr);
    bool isLayerLoading(int layer) const noexcept;

    bool isLayerLoaded(int layer) const;
    juce::String getLayerName(int layer) const;
    juce::String getLayerStatus(int layer) const;
    juce::StringArray getPresetNames(int layer) const;
    int getSelectedPreset(int layer) const;

    float getLayerLevel(int layer) const noexcept;
    int getLayerMidiNote(int layer) const;
    float getLayerFrequency(int layer) const;
    int getLayerTranspose(int layer) const noexcept;
    void nudgeLayerTranspose(int layer, int semitones);
    int getLayerVoiceCount(int layer) const;
    float getOutputLevel(int channel) const noexcept;

    // Per-layer key range: notes outside [low, high] are never sent to that
    // layer's engine, so up to 5 real keyboard splits are possible instead
    // of every layer always covering the full keyboard.
    int getLayerKeyLow(int layer) const noexcept;
    int getLayerKeyHigh(int layer) const noexcept;

    // A "performance" is the full plugin state (every layer's instrument,
    // preset, transpose, key range, and filters, plus the global effects)
    // saved to a named file so it can be recalled in any project, not just
    // the one it was saved from.
    juce::File getPerformancesDirectory() const;
    juce::Result savePerformance(const juce::String& name);
    bool loadPerformance(const juce::String& name);
    bool deletePerformance(const juce::String& name);
    juce::StringArray getSavedPerformanceNames() const;
    juce::uint32 getMidiActivityCounter() const noexcept
    {
        return midiActivityCounter.load(std::memory_order_relaxed);
    }
    juce::uint32 getMidiNoteCounter() const noexcept
    {
        return midiNoteCounter.load(std::memory_order_relaxed);
    }
    int getCurrentMidiNote() const noexcept;
    int getLastMidiNote() const noexcept
    {
        return lastMidiNote.load(std::memory_order_relaxed);
    }

    juce::AudioProcessorValueTreeState parameters;

private:
    static constexpr int pitchHistorySize = 4096;
    static constexpr int pitchAnalysisSize = 3072;
    static constexpr int pitchMaxLag = 1024;

    enum class InstrumentEngine
    {
        none,
        sf2,
        sfz
    };

    struct Layer
    {
        tsf* synth = nullptr;
        sfizz_synth_t* sfzSynth = nullptr;
        InstrumentEngine engine = InstrumentEngine::none;
        juce::File file;
        juce::String name { "Empty Layer" };
        juce::String status { "Load an SF2 or SFZ" };
        juce::StringArray presets;
        int preset = 0;
        bool bundledSoundFont = false;
        juce::HeapBlock<float> interleaved;
        int capacity = 0;
        juce::HeapBlock<float> sfzLeft;
        juce::HeapBlock<float> sfzRight;
        int sfzCapacity = 0;
        std::array<float, pitchHistorySize> pitchHistory {};
        int pitchWritePosition = 0;
        int pitchSamplesReady = 0;
        int pitchDecimationPhase = 0;
        int pitchSilentSamples = 0;
        std::atomic<float> detectedPitchHz { 0.0f };
        std::array<int, 128> outputNotesForInput {};
        std::array<float, 128> inputNoteVelocities {};
        int appliedTranspose = 0;
        juce::dsp::StateVariableTPTFilter<float> highPassFilter;
        juce::dsp::StateVariableTPTFilter<float> lowPassFilter;

        // Ramped instead of read raw every block, so fast gain/pan
        // automation (or a mute/solo toggle) can't zipper-click.
        juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear>
            smoothedGain;
        juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear>
            smoothedPan;
    };

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    bool layerLoaded(const Layer&) const noexcept;
    void closeLayer(Layer&);
    void configureLayer(Layer&);
    void resetPitchTracking(Layer&);
    void resetLayerNoteTracking(Layer&, int transpose);
    void applyLayerTranspose(int layerIndex, Layer&);
    void updateLayerFilters(int layerIndex, Layer&);
    void refreshPresets(Layer&);
    void handleMidi(const juce::MidiMessage&);
    bool isNoteInLayerRange(int layerIndex, int note) const;
    void renderLayer(int layerIndex,
                     Layer&,
                     juce::AudioBuffer<float>&,
                     int startSample,
                     int numSamples,
                     float targetGain,
                     float targetPan,
                     float& blockPeak);
    float detectLayerPitch(Layer&);
    void updateLayerPitchDetectors(
        const std::array<float, layerCount>& blockPeaks,
        int numSamples);
    bool layerAudible(int layer) const;
    void updateEffects();
    void processDelay(juce::AudioBuffer<float>&);
    void publishMeters(const std::array<float, layerCount>& blockPeaks,
                       const juce::AudioBuffer<float>& output);

    mutable juce::CriticalSection layerLock;
    std::array<Layer, layerCount> layers;
    std::array<std::atomic<float>, layerCount> layerPeakLevels {};
    std::array<std::atomic<float>, 2> outputPeakLevels {};
    std::array<float, pitchAnalysisSize> pitchScratch {};
    std::array<float, pitchMaxLag + 1> pitchDifference {};

    double sampleRateHz = 44100.0;
    int maximumBlockSize = 512;
    int pitchDecimationFactor = 2;
    int nextPitchLayer = 0;
    int pitchAnalysisBlockCounter = 0;
    std::atomic<juce::uint32> midiActivityCounter { 0 };
    std::atomic<juce::uint32> midiNoteCounter { 0 };
    std::atomic<int> lastMidiNote { -1 };
    std::atomic<int> pitchWheelValue { 8192 };
    std::array<std::atomic<bool>, 128> activeMidiNotes {};

    juce::dsp::StateVariableTPTFilter<float> filter;
    juce::dsp::Chorus<float> chorus;
    juce::AudioBuffer<float> delayBuffer;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear>
        delaySamples;
    std::array<float, 2> delayToneState {};
    int delayWritePosition = 0;
    juce::Reverb reverb;

    // Background loading for loadInstrumentAsync(). Two workers so loading
    // two layers at once (e.g. restoring several layers quickly) doesn't
    // serialize behind a single slow SFZ library.
    juce::ThreadPool loadingPool { 2 };
    std::array<std::atomic<bool>, layerCount> layerLoading {};

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RuFTraXSF2SuperAudioProcessor)
};
