#!/bin/zsh
set -euo pipefail

PROJECT_DIR="${0:A:h}"
BUILD_DIR="$PROJECT_DIR/build-performance"

"$PROJECT_DIR/Scripts/validate_release_source.sh"

if [[ -z "${JUCE_DIR:-}" ]]; then
    juce_candidates=(
        "$HOME/JUCE"
        "/Users/mike/JUCE"
        "/Volumes/2T BackUP/RuFTraX Projects/Logic Chainer/JUCE"
        "/Volumes/2T BackUP/RuFTraX Projects/JUCE"
    )

    for candidate in "${juce_candidates[@]}"; do
        if [[ -f "$candidate/CMakeLists.txt" ]]; then
            export JUCE_DIR="$candidate"
            break
        fi
    done
fi

if [[ -z "${JUCE_DIR:-}" || ! -f "$JUCE_DIR/CMakeLists.txt" ]]; then
    print "ERROR: JUCE was not found."
    print "Install JUCE at ~/JUCE or set JUCE_DIR before running this file."
    exit 1
fi

if ! command -v cmake >/dev/null 2>&1; then
    print "ERROR: CMake was not found."
    print "Install it with: brew install cmake"
    exit 1
fi

print "Building RuFTraX SF2 Super Instrument Performance..."
print "JUCE:  $JUCE_DIR"
print "Build: $BUILD_DIR"

cmake \
    -S "$PROJECT_DIR" \
    -B "$BUILD_DIR" \
    -DCMAKE_BUILD_TYPE=Release \
    -DJUCE_DIR="$JUCE_DIR"

cmake --build "$BUILD_DIR" --config Release -j4

APP="$BUILD_DIR/RuFTraXSF2SuperInstrument_artefacts/Release/Standalone/RuFTraX SF2 Super Instrument.app"
COMPONENT="$BUILD_DIR/RuFTraXSF2SuperInstrument_artefacts/Release/AU/RuFTraX SF2 Super Instrument.component"

[[ -d "$APP" ]] || {
    print "ERROR: The standalone app was not created."
    exit 1
}

[[ -d "$COMPONENT" ]] || {
    print "ERROR: The Audio Unit was not created."
    exit 1
}

APP_BINARY="$APP/Contents/MacOS/RuFTraX SF2 Super Instrument"
AU_BINARY="$(find "$COMPONENT/Contents/MacOS" -type f -print -quit 2>/dev/null || true)"

for binary in "$APP_BINARY" "$AU_BINARY"; do
    [[ -f "$binary" ]] || {
        print "ERROR: A built product binary is missing."
        exit 1
    }

    strings -a "$binary" \
        | grep -F "FIVE-LAYER PERFORMANCE STACK" >/dev/null || {
        print "ERROR: A built product is not the approved PERFORMANCE STACK UI."
        print "$binary"
        exit 1
    }

    if strings -a "$binary" \
        | grep -F "FIVE-LAYER VINTAGE STACK" >/dev/null; then
        print "ERROR: A built product contains the rejected VINTAGE STACK UI."
        print "$binary"
        exit 1
    fi
done

print
print "BUILD COMPLETE"
print "Standalone:"
print "$APP"
print
print "Audio Unit:"
print "$COMPONENT"
