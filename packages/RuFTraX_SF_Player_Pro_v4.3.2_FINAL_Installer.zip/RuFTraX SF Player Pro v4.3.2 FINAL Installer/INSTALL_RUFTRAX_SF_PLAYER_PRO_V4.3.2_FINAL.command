#!/bin/zsh
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_DIR="$PACKAGE_DIR/Source"
BUILD_DIR="$SOURCE_DIR/build-v4.3.2-final-install"
LOG_PATH="$HOME/Desktop/RuFTraX_SF_Player_Pro_v4.3.2_Install.log"
REPORT_PATH="$HOME/Desktop/RuFTraX_SF_Player_Pro_v4.3.2_Install_Report.txt"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
TRASH_STAGE="$HOME/.Trash/RuFTraX SF Player Pro Replaced $TIMESTAMP"

APP_NAME="RuFTraX SF Player Pro.app"
AU_NAME="RuFTraX SF Player Pro.component"
INSTALLED_APP="$HOME/Applications/$APP_NAME"
INSTALLED_AU="$HOME/Library/Audio/Plug-Ins/Components/$AU_NAME"

fail() {
    print
    print "INSTALLATION FAILED"
    print "$1"
    print
    print "Build log: $LOG_PATH"
    print
    read "?Press Return to close this window."
    exit 1
}

move_existing_to_trash() {
    local existing="$1"
    [[ -e "$existing" ]] || return 0

    mkdir -p "$TRASH_STAGE"
    local destination="$TRASH_STAGE/${existing:t}"
    local suffix=1

    while [[ -e "$destination" ]]; do
        destination="$TRASH_STAGE/${existing:t:r} $suffix.${existing:e}"
        suffix=$((suffix + 1))
    done

    if [[ -w "${existing:h}" ]]; then
        mv "$existing" "$destination"
    else
        sudo mv "$existing" "$destination"
        sudo chown -R "$USER":staff "$destination"
    fi
}

bundle_binary() {
    local bundle="$1"
    local executable_name
    executable_name="$(/usr/bin/defaults read "$bundle/Contents/Info" CFBundleExecutable 2>/dev/null \
        || /usr/bin/defaults read "$bundle/Contents/Info.plist" CFBundleExecutable 2>/dev/null \
        || true)"

    if [[ -n "$executable_name" && -f "$bundle/Contents/MacOS/$executable_name" ]]; then
        print -r -- "$bundle/Contents/MacOS/$executable_name"
        return 0
    fi

    find "$bundle/Contents/MacOS" -type f -perm -111 -print -quit 2>/dev/null || true
}

verify_final_bundle() {
    local bundle="$1"
    local binary
    binary="$(bundle_binary "$bundle")"
    [[ -f "$binary" ]] || return 1

    /usr/bin/strings -a "$binary" 2>/dev/null \
        | grep -F "MIDI / TONE / CHORD ANALYZER" >/dev/null \
        && /usr/bin/strings -a "$binary" 2>/dev/null \
        | grep -F "TRANSPOSE" >/dev/null \
        && /usr/bin/strings -a "$binary" 2>/dev/null \
        | grep -F "DRAG & DROP AN SF2 OR SFZ FILE HERE TO LOAD" >/dev/null
}

print "============================================================"
print " RuFTraX SF Player Pro v4.3.2 FINAL"
print " Build and Install"
print "============================================================"
print
print "Installing the final MIDI / Tone / Chord Analyzer version."
print

if pgrep -x "Logic Pro" >/dev/null 2>&1; then
    fail "Logic Pro is open. Save your project, quit Logic completely, and run this installer again."
fi

[[ -f "$SOURCE_DIR/CMakeLists.txt" ]] \
    || fail "The packaged CMakeLists.txt is missing."
[[ -f "$SOURCE_DIR/Assets/Wurly_EP1.sf2" ]] \
    || fail "The bundled Wurly SoundFont is missing."
[[ -f "$SOURCE_DIR/Source/PluginEditor.cpp" ]] \
    || fail "The final editor source is missing."

grep -F "MIDI / TONE / CHORD ANALYZER" "$SOURCE_DIR/Source/PluginEditor.cpp" >/dev/null \
    || fail "The packaged source is not the final analyzer version."

if ! /bin/bash "$SOURCE_DIR/Scripts/validate_release_source.sh"; then
    fail "The packaged v4.3.2 source failed validation."
fi

CMAKE_BIN="$(command -v cmake || true)"
[[ -n "$CMAKE_BIN" ]] || fail "CMake was not found. Install CMake, then run this installer again."

JUCE_PATH="${JUCE_DIR:-}"
if [[ -z "$JUCE_PATH" || ! -f "$JUCE_PATH/CMakeLists.txt" ]]; then
    for candidate in "$HOME/JUCE" "$HOME/Downloads/JUCE"; do
        if [[ -f "$candidate/CMakeLists.txt" ]]; then
            JUCE_PATH="$candidate"
            break
        fi
    done
fi

[[ -n "$JUCE_PATH" && -f "$JUCE_PATH/CMakeLists.txt" ]] \
    || fail "JUCE was not found. Keep JUCE at $HOME/JUCE, then run this installer again."

export JUCE_DIR="$JUCE_PATH"
mkdir -p "${LOG_PATH:h}"

{
print "RuFTraX SF Player Pro v4.3.2 FINAL installation"
    print "Date: $(date)"
    print "JUCE: $JUCE_DIR"
    print "CMake: $CMAKE_BIN"
    print "Source: $SOURCE_DIR"
    print
} > "$LOG_PATH"

print "Configuring the final build..."
if ! "$CMAKE_BIN" -S "$SOURCE_DIR" -B "$BUILD_DIR" -G Xcode \
    -DJUCE_DIR="$JUCE_DIR" \
    -DCMAKE_BUILD_TYPE=Release \
    2>&1 | tee -a "$LOG_PATH"; then
    fail "CMake configuration failed."
fi

print
print "Building the Audio Unit and standalone app..."
if ! "$CMAKE_BIN" --build "$BUILD_DIR" \
    --config Release \
    --parallel \
    --target RuFTraXSF2Player_AU RuFTraXSF2Player_Standalone \
    2>&1 | tee -a "$LOG_PATH"; then
    fail "The final build failed."
fi

BUILT_APP="$BUILD_DIR/RuFTraXSF2Player_artefacts/Release/Standalone/$APP_NAME"
BUILT_AU="$BUILD_DIR/RuFTraXSF2Player_artefacts/Release/AU/$AU_NAME"

[[ -d "$BUILT_APP" ]] || fail "The standalone app was not produced."
[[ -d "$BUILT_AU" ]] || fail "The Audio Unit was not produced."
verify_final_bundle "$BUILT_APP" \
    || fail "The built standalone app failed the final analyzer verification."
verify_final_bundle "$BUILT_AU" \
    || fail "The built Audio Unit failed the final analyzer verification."

print
print "Installing the verified final version..."

move_existing_to_trash "$HOME/Applications/$APP_NAME"
move_existing_to_trash "/Applications/$APP_NAME"
move_existing_to_trash "$HOME/Library/Audio/Plug-Ins/Components/$AU_NAME"
move_existing_to_trash "/Library/Audio/Plug-Ins/Components/$AU_NAME"

mkdir -p "$HOME/Applications"
mkdir -p "$HOME/Library/Audio/Plug-Ins/Components"

/usr/bin/ditto "$BUILT_APP" "$INSTALLED_APP"
/usr/bin/ditto "$BUILT_AU" "$INSTALLED_AU"

/usr/bin/xattr -dr com.apple.quarantine "$INSTALLED_APP" 2>/dev/null || true
/usr/bin/xattr -dr com.apple.quarantine "$INSTALLED_AU" 2>/dev/null || true
/usr/bin/codesign --force --deep --sign - "$INSTALLED_APP" >> "$LOG_PATH" 2>&1 \
    || fail "The standalone app could not be signed."
/usr/bin/codesign --force --deep --sign - "$INSTALLED_AU" >> "$LOG_PATH" 2>&1 \
    || fail "The Audio Unit could not be signed."

verify_final_bundle "$INSTALLED_AU" \
    || fail "The installed Audio Unit failed final verification."

if [[ -e "$HOME/Library/Caches/AudioUnitCache" ]]; then
    mkdir -p "$TRASH_STAGE"
    mv "$HOME/Library/Caches/AudioUnitCache" "$TRASH_STAGE/AudioUnitCache"
fi

killall AudioComponentRegistrar >/dev/null 2>&1 || true
killall "AUHostingServiceXPC_arrow" >/dev/null 2>&1 || true
killall "AUHostingServiceXPC" >/dev/null 2>&1 || true

{
    print "RuFTraX SF Player Pro v4.3.2 FINAL installation report"
    print "Date: $(date)"
    print
    print "Installed Audio Unit:"
    print "$INSTALLED_AU"
    print
    print "Installed standalone:"
    print "$INSTALLED_APP"
    print
    print "Verified UI:"
    print "SF PLAYER PRO | MIDI / TONE / CHORD ANALYZER"
    print "Centered Current Preset selector and saved -24 to +24 semitone transpose"
    print "Integrated SF2 and SFZ loading, rendering, and state restoration"
    print
    print "The obsolete RuFTraX SFZ Player Pro v5 product name was not reinstalled."
    if [[ -d "$TRASH_STAGE" ]]; then
        print "Replaced bundles and old Logic cache remain recoverable in:"
        print "$TRASH_STAGE"
    fi
} > "$REPORT_PATH"

print
print "============================================================"
print " INSTALLATION COMPLETE"
print "============================================================"
print
print "Installed: RuFTraX SF Player Pro v4.3.2 FINAL"
print "Verified: Analyzer, corrected preset selector, transpose, SF2, and SFZ"
print
print "Reopen Logic and allow the Audio Unit rescan to finish."
print "Logic path: AU Instruments > RuFTraX > RuFTraX SF Player Pro"
print
print "Report: $REPORT_PATH"

open "$INSTALLED_APP" >/dev/null 2>&1 || true
open -R "$REPORT_PATH" >/dev/null 2>&1 || true

print
read "?Press Return to close this window."
