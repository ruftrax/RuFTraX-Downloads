RuFTraX SF Player Pro v4.3.2 FINAL
One-click macOS Build and Install

THIS IS THE FINAL VERSION DISPLAYING:

SF PLAYER PRO | MIDI / TONE / CHORD ANALYZER

It includes:

- MIDI note, velocity, channel, and aftertouch display
- Final-output tone and tuning analysis
- Centered single Current Preset selector
- Saved -24 to +24 semitone SoundFont transpose with - / + buttons
- Live retuning while a note is held
- Chord recognition and inversion display
- SF2 loading and preset selection through TinySoundFont
- SFZ loading through the dedicated sfizz engine
- SFZ-relative sample paths, MIDI, transpose, effects, and state restoration
- Correct sfizz compiler configuration for Apple Silicon Macs
- Correct sfizz atomic-queue syntax for Xcode 26 and Clang 21
- Bundled Wurly SoundFont
- Filter, drive, chorus, reverb, volume, and pan
- Logic Audio Unit and standalone app

HOW TO INSTALL

1. Save your Logic project and quit Logic completely.
2. Double-click INSTALL_RUFTRAX_SF_PLAYER_PRO_V4.3.2_FINAL.command.
3. Wait for INSTALLATION COMPLETE.
4. Reopen Logic and allow its Audio Unit rescan to finish.
5. Select:
   AU Instruments > RuFTraX > RuFTraX SF Player Pro

The installer finds JUCE at ~/JUCE or ~/Downloads/JUCE, builds the final
v4.3.2 source, verifies the analyzer, transpose, and SFZ engine inside the binaries, and installs:

~/Library/Audio/Plug-Ins/Components/RuFTraX SF Player Pro.component
~/Applications/RuFTraX SF Player Pro.app

SFZ support is integrated into this approved Player Pro; the obsolete v5 product name is not reinstalled.
Any replaced bundles and Logic cache files are moved to the Trash.
