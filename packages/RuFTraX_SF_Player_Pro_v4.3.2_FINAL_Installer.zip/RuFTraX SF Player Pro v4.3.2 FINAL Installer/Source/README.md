# RuFTraX SF Player Pro v4.3.2 — Red 70s UI

A JUCE instrument with TinySoundFont for SF2 and sfizz for SFZ, using the approved native vintage red hardware-style interface.

## Included
- Standalone macOS app
- Logic Audio Unit instrument
- Red brushed-metal panel with dark wood side cheeks
- Ivory rotary knobs and cream labels
- OLED-style SoundFont and preset displays
- One centered Current Preset selector
- MIDI activity LED
- Live MIDI, output-pitch, tuning, and chord analysis
- Saved -24 to +24 semitone SoundFont transpose
- Clickable - / + transpose controls that retune held notes
- Drag-and-drop `.sf2` and `.sfz` loading
- SFZ-relative sample resolution, MIDI control, transpose, effects, and saved-state restoration
- Functional controls for volume, pan, cutoff, resonance, drive, chorus, reverb, and room size
- Bundled Wurly SoundFont

## Build
```bash
cd "~/Downloads/RuFTraX SF Player Pro v4.3.2 FINAL Installer/Source"
export JUCE_DIR="$HOME/JUCE"
chmod +x build_mac.sh
./build_mac.sh
```
