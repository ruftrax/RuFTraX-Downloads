# RuFTraX SF Player Pro v4.3.2 — Red 70s UI

A JUCE instrument with TinySoundFont for SF2 and sfizz for SFZ, using the approved native vintage red hardware-style interface.

## Included
- Standalone macOS app
- Logic Audio Unit instrument
- VST3 instrument for Ableton, Cubase, Reaper, Studio One, Bitwig, and any other VST3 host
- Red brushed-metal panel with dark wood side cheeks
- Ivory rotary knobs and cream labels
- OLED-style SoundFont and preset displays
- One centered Current Preset selector
- MIDI activity LED
- Live MIDI, output-pitch, tuning, and chord analysis
- Saved -24 to +24 semitone SoundFont transpose
- Clickable - / + transpose controls that retune held notes
- Drag-and-drop `.sf2` and `.sfz` loading
- SFZ-relative sample resolution, MIDI control, transpose, effects, and saved-state restoration
- Functional controls for volume, pan, cutoff, resonance, drive, chorus, reverb, and room size
- Bundled Wurly SoundFont

## Fixes in this build
- The SF2 engine now renders in fixed-size chunks instead of growing its buffer on demand,
  so it can no longer allocate memory on the real-time audio thread (the SFZ engine already
  worked this way).
- Switching instruments (loading a new SF2/SFZ, or restoring the bundled Wurly) now silences
  the outgoing instrument before it's torn down, and frees its memory after releasing the
  audio lock instead of while holding it - no more click on instrument swap, and no more risk
  of a brief audio stall while a large previous library is freed.

## Build
```bash
cd "~/Downloads/RuFTraX SF Player Pro v4.3.2 FINAL Installer/Source"
export JUCE_DIR="$HOME/JUCE"
chmod +x build_mac.sh
./build_mac.sh
```
