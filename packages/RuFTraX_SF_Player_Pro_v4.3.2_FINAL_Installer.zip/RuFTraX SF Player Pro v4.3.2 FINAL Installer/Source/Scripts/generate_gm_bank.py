#!/usr/bin/env python3
"""
generate_gm_bank.py - builds RuFTraX_GM_Bank.sf2, a complete General MIDI SoundFont.

Every sound in this bank is synthesized from scratch in this script (additive
oscillators, simple FM, Karplus-Strong plucks, and filtered noise) - nothing is
sampled, recorded, or copied from any third party. It contains all 128 GM melodic
programs plus a standard GM percussion kit on bank 128, so it works as a complete,
correct default instrument for the SF2 engine with no external dependencies.

Design pattern borrowed from analyzing a reference hardware-module GM soundfont
(structure/parameters only - key-zone layout, envelope shape, sample counts; no
audio, samples, or other copyrighted content of any kind was read, copied, or
reused from that reference): every instrument here is split into three
independently-rendered key zones (low/mid/high) instead of one sample stretched
across the whole keyboard by pitch-shifting, and every instrument uses its own
distinct synthesis recipe rather than sharing one formula with a neighbour and
just changing pan/filter. That combination is what gives real multi-sampled
instruments their register-to-register character and keeps neighbouring GM
programs from converging on the same sound.

Sound character is deliberately that of a compact hardware GM synth (think a
90s sound module), not a sampled orchestra - that trade-off is what makes it
possible to generate the whole bank, correctly, with zero licensing risk, at a
tiny fraction of the size of a sampled General MIDI set.

Usage:
    python3 generate_gm_bank.py [output_path]

Requires only the Python standard library (no numpy) so it can be re-run by
anyone building this project without extra setup.
"""

import math
import random
import struct
import sys

SAMPLE_RATE = 24000
random.seed(20260819)  # deterministic output across regenerations

# Three independently-rendered key zones per instrument (see module docstring).
# Each zone is (key_lo, key_hi, reference_note) - reference_note is the MIDI
# note the zone is rendered at/for, so a zone never has to be pitch-shifted
# more than roughly a fifth in either direction to cover its range.
ZONES = [
    (0, 52, 36),    # low   - rendered around C2
    (53, 76, 60),   # mid   - rendered around C4
    (77, 127, 84),  # high  - rendered around C6
]


def note_to_hz(note):
    return 440.0 * (2.0 ** ((note - 69) / 12.0))


# =====================================================================
# DSP primitives
# =====================================================================

def _normalise(samples, peak_target=0.92):
    peak = max((abs(x) for x in samples), default=0.0)
    if peak <= 1e-9:
        return samples
    scale = peak_target / peak
    return [x * scale for x in samples]


def render_additive(freq, periods, harmonics, sr=SAMPLE_RATE):
    """Renders `periods` full cycles of `freq` Hz as a sum of harmonics.

    harmonics: list of (ratio, amplitude) pairs, ratio need not be an integer,
    but every ratio used together in one call must divide evenly into
    `periods` cycles of the fundamental or the loop will click.
    """
    n = max(8, round(periods * sr / freq))
    out = [0.0] * n
    for ratio, amp in harmonics:
        w = 2.0 * math.pi * freq * ratio / sr
        for i in range(n):
            out[i] += amp * math.sin(w * i)
    return _normalise(out)


def saw_harmonics(count, rolloff=1.0):
    return [(h, rolloff / h) for h in range(1, count + 1)][::-1] and \
        [(h, ((-1) ** (h + 1)) / (h ** rolloff)) for h in range(1, count + 1)]


def square_harmonics(count, rolloff=1.0):
    return [(2 * k + 1, 1.0 / ((2 * k + 1) ** rolloff)) for k in range(count)]


def triangle_harmonics(count):
    return [(2 * k + 1, ((-1) ** k) / ((2 * k + 1) ** 2)) for k in range(count)]


def pulse_harmonics(duty, count):
    out = []
    for h in range(1, count + 1):
        v = (2.0 / (h * math.pi)) * math.sin(h * math.pi * duty)
        if abs(v) > 1e-6:
            out.append((h, v))
    return out


def render_karplus(freq, duration, sr=SAMPLE_RATE, decay=0.9965, brightness=0.5,
                    seed_offset=0):
    """Karplus-Strong plucked string: a noise-filled ring buffer that decays
    as it's averaged with itself each cycle. Naturally decaying - no separate
    envelope needed."""
    rng = random.Random(20260819 + seed_offset)
    period = max(2, round(sr / freq))
    ring = [rng.uniform(-1.0, 1.0) for _ in range(period)]
    n = int(duration * sr)
    out = [0.0] * n
    prev = 0.0
    for i in range(n):
        j = i % period
        cur = ring[j]
        avg = brightness * cur + (1.0 - brightness) * ((cur + prev) * 0.5)
        avg *= decay
        ring[j] = avg
        prev = cur
        out[i] = avg
    return _normalise(out)


def render_two_layer_pluck(freq, duration, sr=SAMPLE_RATE, decay=0.9965,
                            brightness=0.5, detune_cents=14, seed_offset=0):
    """Two Karplus-Strong plucks, one detuned, summed - the classic
    slightly-out-of-tune-unison colour (honky-tonk piano, 12-string-ish
    guitars, doubled mallets)."""
    a = render_karplus(freq, duration, sr, decay, brightness, seed_offset)
    b = render_karplus(freq * (2.0 ** (detune_cents / 1200.0)), duration, sr,
                        decay, brightness, seed_offset + 1000)
    n = min(len(a), len(b))
    return _normalise([a[i] + b[i] for i in range(n)])


def render_fm(carrier, ratio, index0, duration, sr=SAMPLE_RATE,
              amp_decay=4.0, index_decay=8.0, feedback=0.0):
    """2-operator FM tone with independent amplitude/index decay, and
    optional operator feedback for extra edge/bark on the attack."""
    n = int(duration * sr)
    out = [0.0] * n
    wc = 2.0 * math.pi * carrier / sr
    wm = 2.0 * math.pi * carrier * ratio / sr
    fb_state = 0.0
    for i in range(n):
        t = i / sr
        amp_env = math.exp(-amp_decay * t)
        idx_env = index0 * math.exp(-index_decay * t)
        modulator = math.sin(wm * i + feedback * fb_state)
        fb_state = modulator
        out[i] = amp_env * math.sin(wc * i + idx_env * modulator)
    return _normalise(out)


def render_harpsichord(freq, duration, sr=SAMPLE_RATE):
    """A hard, fast pluck dominated by odd harmonics with almost no sustain -
    quite different in character (and mechanism) from the FM piano voices."""
    n = int(duration * sr)
    harmonics = [(h, 1.0 / h) for h in (1, 2, 3, 5, 7, 9, 11)]
    tone = render_additive(freq, max(1, round(duration * freq)), harmonics)[:n]
    tone += [0.0] * (n - len(tone))
    click = render_karplus(freq * 2.0, 0.05, sr, decay=0.985, brightness=0.85)
    click += [0.0] * (n - len(click))
    combined = [t + c for t, c in zip(tone, click)]
    env = [math.exp(-9.0 * (i / sr)) for i in range(n)]
    return _normalise([c * e for c, e in zip(combined, env)])


def render_clavinet(freq, duration, sr=SAMPLE_RATE):
    """A resonant-sounding, filtered pluck - funky/percussive rather than
    smooth. Built from two of the already-stable one-pole filters (a
    highpass and a lowpass bracketing a "resonant" band) rather than a
    hand-rolled biquad/SVF, which can blow up to NaN/inf at high frequencies
    under naive explicit-Euler integration - not a risk worth taking for a
    filter whose only job is to add a bit of wah-ish colour."""
    raw = render_karplus(freq, duration, sr, decay=0.997, brightness=0.75)
    band_centre = min(freq * 3.2, sr * 0.4)
    lo_alpha = min(0.95, 2.0 * math.pi * (band_centre * 0.7) / sr)
    hi_alpha = min(0.95, 2.0 * math.pi * (band_centre * 1.4) / sr)
    band = one_pole_highpass(one_pole_lowpass(raw, hi_alpha), lo_alpha)
    mixed = [0.6 * r + 0.8 * b for r, b in zip(raw, band)]
    return _normalise(mixed)


def white_noise(duration, sr=SAMPLE_RATE, seed_offset=0):
    rng = random.Random(20260819 + seed_offset)
    return [rng.uniform(-1.0, 1.0) for _ in range(int(duration * sr))]


def one_pole_lowpass(signal, alpha):
    out = [0.0] * len(signal)
    state = 0.0
    for i, x in enumerate(signal):
        state += alpha * (x - state)
        out[i] = state
    return out


def one_pole_highpass(signal, alpha):
    low = one_pole_lowpass(signal, alpha)
    return [x - y for x, y in zip(signal, low)]


def exp_envelope(n, decay_rate, sr=SAMPLE_RATE):
    return [math.exp(-decay_rate * (i / sr)) for i in range(n)]


def apply_envelope(signal, envelope):
    return [s * e for s, e in zip(signal, envelope)]


def mix(*signals):
    n = max(len(s) for s in signals)
    out = [0.0] * n
    for s in signals:
        for i, v in enumerate(s):
            out[i] += v
    return out


def register_lerp(reference_note, low_val, high_val, low_note=36, high_note=84):
    """Interpolates a parameter across the instrument's playable range so
    low zones and high zones get register-appropriate character (e.g.
    darker/longer in the bass, brighter/shorter in the treble) instead of
    identical treatment stretched across five-plus octaves."""
    t = (reference_note - low_note) / float(high_note - low_note)
    t = max(0.0, min(1.0, t))
    return low_val + (high_val - low_val) * t


# =====================================================================
# One-shot percussion / pluck / bell voice builders
# =====================================================================

def voice_kick(duration=0.5, start_hz=150.0, end_hz=48.0, sr=SAMPLE_RATE):
    n = int(duration * sr)
    out = [0.0] * n
    phase = 0.0
    for i in range(n):
        t = i / sr
        freq = end_hz + (start_hz - end_hz) * math.exp(-28.0 * t)
        phase += 2.0 * math.pi * freq / sr
        out[i] = math.sin(phase) * math.exp(-7.5 * t)
    click = apply_envelope(white_noise(0.012, sr), exp_envelope(int(0.012 * sr), 220.0, sr))
    return _normalise(mix(out, click + [0.0] * (n - len(click))))


def voice_tom(duration=0.55, start_hz=280.0, end_hz=140.0, sr=SAMPLE_RATE):
    n = int(duration * sr)
    out = [0.0] * n
    phase = 0.0
    for i in range(n):
        t = i / sr
        freq = end_hz + (start_hz - end_hz) * math.exp(-18.0 * t)
        phase += 2.0 * math.pi * freq / sr
        out[i] = math.sin(phase) * math.exp(-5.2 * t)
    return _normalise(out)


def voice_snare(duration=0.35, sr=SAMPLE_RATE):
    n = int(duration * sr)
    body = render_additive(190.0, max(1, round(duration * 190.0)), [(1, 1.0), (2.3, 0.35)])[:n]
    body += [0.0] * (n - len(body))
    body = apply_envelope(body, exp_envelope(n, 16.0, sr))
    noise = one_pole_highpass(white_noise(duration, sr), 0.35)
    noise = apply_envelope(noise, exp_envelope(n, 11.0, sr))
    return _normalise(mix(body, noise))


def voice_clap(duration=0.4, sr=SAMPLE_RATE):
    n = int(duration * sr)
    out = [0.0] * n
    bursts = [0.0, 0.012, 0.024, 0.045]
    for bi, onset in enumerate(bursts):
        start = int(onset * sr)
        burst_len = int(0.03 * sr)
        burst = one_pole_highpass(white_noise(burst_len / sr, sr, seed_offset=bi), 0.4)
        burst = apply_envelope(burst, exp_envelope(len(burst), 45.0, sr))
        for i, v in enumerate(burst):
            if start + i < n:
                out[start + i] += v
    tail = one_pole_highpass(white_noise(duration, sr, seed_offset=99), 0.3)
    tail = apply_envelope(tail, exp_envelope(n, 9.0, sr))
    return _normalise(mix(out, tail))


def voice_hat(duration, sr=SAMPLE_RATE, decay_rate=35.0):
    n = int(duration * sr)
    noise = one_pole_highpass(white_noise(duration, sr), 0.55)
    return _normalise(apply_envelope(noise, exp_envelope(n, decay_rate, sr)))


def voice_cymbal(duration=2.2, sr=SAMPLE_RATE):
    n = int(duration * sr)
    partial_ratios = [1.0, 1.34, 1.79, 2.23, 2.71, 3.12, 3.68]
    tones = [0.0] * n
    for ratio in partial_ratios:
        freq = 260.0 * ratio
        phase_inc = 2.0 * math.pi * freq / sr
        for i in range(n):
            tones[i] += math.sin(phase_inc * i) / len(partial_ratios)
    tones = apply_envelope(tones, exp_envelope(n, 2.6, sr))
    noise = one_pole_highpass(white_noise(duration, sr), 0.5)
    noise = apply_envelope(noise, exp_envelope(n, 2.0, sr))
    return _normalise(mix(tones, noise))


def voice_cowbell(duration=0.3, sr=SAMPLE_RATE):
    n = int(duration * sr)
    a = square_harmonics(3)
    tone1 = render_additive(800.0, max(1, round(duration * 800.0)), a)[:n]
    tone2 = render_additive(540.0, max(1, round(duration * 540.0)), a)[:n]
    tone1 += [0.0] * (n - len(tone1))
    tone2 += [0.0] * (n - len(tone2))
    env = exp_envelope(n, 14.0, sr)
    return _normalise(apply_envelope(mix(tone1, tone2), env))


def voice_clave(duration=0.18, freq=1800.0, sr=SAMPLE_RATE):
    n = int(duration * sr)
    tone = render_additive(freq, max(1, round(duration * freq)), [(1, 1.0)])[:n]
    tone += [0.0] * (n - len(tone))
    click = one_pole_highpass(white_noise(0.006, sr), 0.5)
    out = mix(tone, click + [0.0] * (n - len(click)))
    return _normalise(apply_envelope(out, exp_envelope(n, 30.0, sr)))


def voice_shaker(duration=0.3, sr=SAMPLE_RATE):
    n = int(duration * sr)
    noise = one_pole_highpass(white_noise(duration, sr), 0.45)
    return _normalise(apply_envelope(noise, exp_envelope(n, 12.0, sr)))


def voice_rim(duration=0.09, sr=SAMPLE_RATE):
    n = int(duration * sr)
    noise = one_pole_highpass(white_noise(duration, sr), 0.6)
    tone = render_additive(1200.0, max(1, round(duration * 1200.0)), [(1, 1.0)])[:n]
    tone += [0.0] * (n - len(tone))
    out = mix(noise, tone)
    return _normalise(apply_envelope(out, exp_envelope(n, 45.0, sr)))


def voice_bell(duration=2.2, carrier=440.0, ratio=3.5, sr=SAMPLE_RATE):
    return render_fm(carrier, ratio, index0=3.2, duration=duration, sr=sr,
                      amp_decay=1.6, index_decay=5.0)


VOICE_BUILDERS = {}


def _register_looped(name, freq, periods, harmonics):
    samples = render_additive(freq, periods, harmonics)
    VOICE_BUILDERS[name] = ("loop", samples, freq)


_register_looped("sine", 220.0, 40, [(1, 1.0)])
_register_looped("triangle", 220.0, 40, triangle_harmonics(8))
_register_looped("saw", 220.0, 60, saw_harmonics(16))
_register_looped("saw_soft", 220.0, 60, saw_harmonics(16, rolloff=1.4))
_register_looped("square", 220.0, 60, square_harmonics(12))
_register_looped("pulse25", 220.0, 60, pulse_harmonics(0.25, 16))
_register_looped("pulse12", 220.0, 60, pulse_harmonics(0.125, 16))
_register_looped("organ", 220.0, 24, [(1, 0.85), (2, 0.5), (3, 0.3), (4, 0.25), (6, 0.15), (8, 0.1)])

ONE_SHOT_CACHE = {}


def get_one_shot(key, builder):
    if key not in ONE_SHOT_CACHE:
        ONE_SHOT_CACHE[key] = builder()
    return ONE_SHOT_CACHE[key]


# =====================================================================
# Sample / instrument bookkeeping
# =====================================================================

class SamplePool:
    """Accumulates raw 16-bit mono PCM sample data and shdr records."""

    def __init__(self):
        self.pcm_words = []
        self.headers = []
        self._cache = {}

    def add(self, name, floats, sr, root_key, loop=False, loop_start_frac=0.0):
        cache_key = (name,)
        if cache_key in self._cache:
            return self._cache[cache_key]

        start = len(self.pcm_words)
        ints = [max(-32768, min(32767, int(round(x * 32767.0)))) for x in floats]
        self.pcm_words.extend(ints)
        self.pcm_words.extend([0] * 46)  # required trailing padding, see SF2 spec
        end = start + len(ints)

        if loop:
            loop_start = start + int(len(ints) * loop_start_frac)
            loop_end = end
        else:
            loop_start = start
            loop_end = end

        index = len(self.headers)
        self.headers.append((name[:20], start, end, loop_start, loop_end, sr, root_key, 0))
        self._cache[cache_key] = index
        return index


class InstrumentPool:
    def __init__(self):
        self.instruments = []

    def add(self, name, zones):
        index = len(self.instruments)
        self.instruments.append((name[:20], zones))
        return index


# =====================================================================
# Generator opcode table (SoundFont 2.01 spec, section 8.1.2)
# =====================================================================

GEN = dict(
    startAddrsOffset=0, endAddrsOffset=1, startloopAddrsOffset=2, endloopAddrsOffset=3,
    startAddrsCoarseOffset=4, modLfoToPitch=5, vibLfoToPitch=6, modEnvToPitch=7,
    initialFilterFc=8, initialFilterQ=9, modLfoToFilterFc=10, modEnvToFilterFc=11,
    endAddrsCoarseOffset=12, modLfoToVolume=13, chorusEffectsSend=15, reverbEffectsSend=16,
    pan=17, delayModLFO=21, freqModLFO=22, delayVibLFO=23, freqVibLFO=24,
    delayModEnv=25, attackModEnv=26, holdModEnv=27, decayModEnv=28, sustainModEnv=29,
    releaseModEnv=30, keynumToModEnvHold=31, keynumToModEnvDecay=32,
    delayVolEnv=33, attackVolEnv=34, holdVolEnv=35, decayVolEnv=36, sustainVolEnv=37,
    releaseVolEnv=38, keynumToVolEnvHold=39, keynumToVolEnvDecay=40,
    instrument=41, keyRange=43, velRange=44, startloopAddrsCoarseOffset=45,
    keynum=46, velocity=47, initialAttenuation=48, endloopAddrsCoarseOffset=50,
    coarseTune=51, fineTune=52, sampleID=53, sampleModes=54, scaleTuning=56,
    exclusiveClass=57, overridingRootKey=58,
)


def sec_to_timecents(seconds):
    seconds = max(0.001, seconds)
    return max(-12000, min(8000, round(1200.0 * math.log2(seconds))))


def hz_to_abscents(hz):
    """Absolute-cents encoding for initialFilterFc - valid/sensible range is
    1500..13500 cents (roughly 19Hz..20kHz), per spec section 8.1.3."""
    hz = max(1.0, hz)
    return max(1500, min(13500, round(1200.0 * math.log2(hz / 8.176))))


def hz_to_abscents_lfo(hz):
    """Absolute-cents encoding for LFO-rate generators (freqVibLFO/freqModLFO).
    These need sub-audio rates (a few Hz), which fall well below
    hz_to_abscents()'s filter-cutoff range - reusing that clamp here would
    silently floor every vibrato rate up to ~19Hz. Valid range per spec is
    -16000..4500 cents relative to the same 8.176Hz reference."""
    hz = max(0.01, hz)
    return max(-16000, min(4500, round(1200.0 * math.log2(hz / 8.176))))


# =====================================================================
# SF2 chunk writer
# =====================================================================

def chunk(fourcc, data):
    if len(fourcc) != 4:
        raise ValueError(fourcc)
    out = fourcc.encode("ascii") + struct.pack("<I", len(data)) + data
    if len(data) % 2 == 1:
        out += b"\x00"
    return out


def list_chunk(fourcc, subchunks_bytes):
    return chunk("LIST", fourcc.encode("ascii") + subchunks_bytes)


def cstr(s, size):
    b = s.encode("ascii", errors="replace")[: size - 1]
    return b + b"\x00" * (size - len(b))


def build_sf2(bank_name, samples: SamplePool, instruments: InstrumentPool, presets):
    ifil = struct.pack("<HH", 2, 1)
    info = b""
    info += chunk("ifil", ifil)
    info += chunk("isng", cstr("EMU8000", 8))
    info += chunk("INAM", cstr(bank_name, len(bank_name) + 1))
    info += chunk("ISFT", cstr("RuFTraX generate_gm_bank.py", 28))
    info_chunk = list_chunk("INFO", info)

    smpl_data = struct.pack("<%dh" % len(samples.pcm_words), *samples.pcm_words)
    sdta_chunk = list_chunk("sdta", chunk("smpl", smpl_data))

    phdr_records = []
    pbag_records = []
    pgen_records = []
    inst_records = []
    ibag_records = []
    igen_records = []
    shdr_records = []

    def write_gen(rec_list, name, value):
        op = GEN[name]
        if name in ("keyRange", "velRange"):
            lo, hi = value
            rec_list.append(struct.pack("<HBB", op, lo, hi))
        elif name in ("sampleID", "instrument"):
            rec_list.append(struct.pack("<HH", op, value))
        else:
            rec_list.append(struct.pack("<Hh", op, int(value)))

    for name, zones in instruments.instruments:
        inst_records.append((name, len(ibag_records)))
        for zone in zones:
            ibag_records.append((len(igen_records), 0))
            zone_gens = [(k, v) for k, v in zone.items() if k != "sampleID"]
            for k, v in zone_gens:
                write_gen(igen_records, k, v)
            write_gen(igen_records, "sampleID", zone["sampleID"])
    ibag_records.append((len(igen_records), 0))
    inst_records.append(("EOI", len(ibag_records) - 1))

    for (name, start, end, loop_start, loop_end, sr, root_key, correction) in samples.headers:
        shdr_records.append(struct.pack(
            "<20sIIIIIbbHH", cstr(name, 20), start, end, loop_start, loop_end,
            sr, root_key, correction, 0, 1))
    shdr_records.append(struct.pack("<20sIIIIIbbHH", cstr("EOS", 20), 0, 0, 0, 0, 0, 0, 0, 0, 0))

    for name, program, bank, zones in presets:
        phdr_records.append((name, program, bank, len(pbag_records)))
        for zone in zones:
            pbag_records.append((len(pgen_records), 0))
            zone_gens = [(k, v) for k, v in zone.items() if k != "instrument"]
            for k, v in zone_gens:
                write_gen(pgen_records, k, v)
            write_gen(pgen_records, "instrument", zone["instrument"])
    pbag_records.append((len(pgen_records), 0))
    phdr_records.append(("EOP", 0, 0, len(pbag_records) - 1))

    def pack_phdr():
        out = b""
        for name, program, bank, bagndx in phdr_records:
            out += struct.pack("<20sHHHIII", cstr(name, 20), program, bank, bagndx, 0, 0, 0)
        return out

    def pack_bag(records):
        return b"".join(struct.pack("<HH", g, m) for g, m in records)

    def pack_inst():
        out = b""
        for name, bagndx in inst_records:
            out += struct.pack("<20sH", cstr(name, 20), bagndx)
        return out

    pdta = b""
    pdta += chunk("phdr", pack_phdr())
    pdta += chunk("pbag", pack_bag(pbag_records))
    pdta += chunk("pmod", struct.pack("<10s", b"\x00" * 10))
    pdta += chunk("pgen", b"".join(pgen_records))
    pdta += chunk("inst", pack_inst())
    pdta += chunk("ibag", pack_bag(ibag_records))
    pdta += chunk("imod", struct.pack("<10s", b"\x00" * 10))
    pdta += chunk("igen", b"".join(igen_records))
    pdta += chunk("shdr", b"".join(shdr_records))
    pdta_chunk = list_chunk("pdta", pdta)

    body = info_chunk + sdta_chunk + pdta_chunk
    return chunk("RIFF", b"sfbk" + body)


# =====================================================================
# Zone helpers
# =====================================================================

def looped_zone_gens(attack, decay, sustain_cb, release, filter_hz=None,
                      pan=0, coarse=0, fine=0, vibrato_depth=0,
                      key_lo=0, key_hi=127):
    zone = {
        "keyRange": (key_lo, key_hi),
        "sampleModes": 1,
        "attackVolEnv": sec_to_timecents(attack),
        "holdVolEnv": sec_to_timecents(0.001),
        "decayVolEnv": sec_to_timecents(decay),
        "sustainVolEnv": sustain_cb,
        "releaseVolEnv": sec_to_timecents(release),
        "pan": pan,
        "coarseTune": coarse,
        "fineTune": fine,
        "scaleTuning": 100,
    }
    if filter_hz is not None:
        zone["initialFilterFc"] = hz_to_abscents(filter_hz)
        zone["initialFilterQ"] = 20
    if vibrato_depth:
        zone["vibLfoToPitch"] = vibrato_depth
        zone["freqVibLFO"] = hz_to_abscents_lfo(5.5)
        zone["delayVibLFO"] = sec_to_timecents(0.35)
    return zone


def oneshot_zone_gens(pan=0, coarse=0, fine=0, key_lo=0, key_hi=127,
                       release=0.25, attack=0.004):
    return {
        "keyRange": (key_lo, key_hi),
        "sampleModes": 0,
        "attackVolEnv": sec_to_timecents(attack),
        "holdVolEnv": sec_to_timecents(0.001),
        "decayVolEnv": sec_to_timecents(0.001),
        "sustainVolEnv": 0,
        "releaseVolEnv": sec_to_timecents(release),
        "pan": pan,
        "coarseTune": coarse,
        "fineTune": fine,
        "scaleTuning": 100,
    }


# =====================================================================
# Bank assembly
# =====================================================================

def build_bank(output_path):
    samples = SamplePool()
    instruments = InstrumentPool()
    presets = []

    def add_preset(program, name, instrument_index, bank=0):
        presets.append((name, program, bank, [{"instrument": instrument_index}]))

    # ---- Multi-zone one-shot instrument: one independently-rendered sample
    # per register (see ZONES / module docstring), each zone panned as a true
    # stereo pair so the instrument has real width, not just a centred mono
    # source. `render_fn(freq, zone_index)` must return mono floats; `decay_fn`
    # and `bright_fn` (if given) let the caller vary duration/brightness per
    # register the way real instruments naturally do.
    def make_oneshot_instrument(name, key_prefix, render_fn, release=0.3,
                                 stereo_spread_cents=6):
        zones = []
        for zi, (key_lo, key_hi, ref_note) in enumerate(ZONES):
            freq = note_to_hz(ref_note)
            floats = get_one_shot(f"{key_prefix}_{zi}", lambda f=freq, z=zi: render_fn(f, z))
            for side, pan, detune in (("L", -400, -stereo_spread_cents),
                                       ("R", 400, stereo_spread_cents)):
                sample_key = f"{key_prefix}_{zi}{side}"
                idx = samples.add(sample_key, floats, SAMPLE_RATE, ref_note, loop=False)
                zone = oneshot_zone_gens(pan=pan, fine=detune, key_lo=key_lo,
                                          key_hi=key_hi, release=release)
                zone["sampleID"] = idx
                zones.append(zone)
        return instruments.add(name, zones)

    def make_looped_instrument(name, voice_fn, attack, decay, sustain_cb, release,
                                filter_lo=None, filter_hi=None, pan=0, coarse=0,
                                vibrato_depth=0, key_prefix=None):
        """voice_fn(freq, zone_index) -> mono floats for one loop cycle block
        (must already be phase-aligned for looping, e.g. render_additive())."""
        zones = []
        prefix = key_prefix or name
        for zi, (key_lo, key_hi, ref_note) in enumerate(ZONES):
            freq = note_to_hz(ref_note)
            floats = voice_fn(freq, zi)
            filt = None
            if filter_lo is not None:
                filt = register_lerp(ref_note, filter_lo, filter_hi)
            # Spread every instrument to a true stereo pair - full width when it
            # has no directional bias, or a narrower spread centred on `pan`
            # when it does (e.g. Trumpet's rightward bias), so a nonzero `pan`
            # never collapses both sides onto the same position.
            spread = 400 if pan == 0 else 150
            for side, stereo_pan, detune in (("L", max(-500, pan - spread), -5),
                                              ("R", min(500, pan + spread), 5)):
                sample_key = f"{prefix}_{zi}{side}"
                idx = samples.add(sample_key, floats, SAMPLE_RATE, ref_note, loop=True)
                zone = looped_zone_gens(attack, decay, sustain_cb, release,
                                         filter_hz=filt, pan=stereo_pan,
                                         coarse=coarse, fine=detune,
                                         vibrato_depth=vibrato_depth,
                                         key_lo=key_lo, key_hi=key_hi)
                zone["sampleID"] = idx
                zones.append(zone)
        return instruments.add(name, zones)

    # =================================================================
    # 0-7 Piano - each instrument is a genuinely different synthesis recipe,
    # not a shared formula with only carrier frequency/pan changed.
    # =================================================================

    def rf_acoustic_grand(freq, zi):
        dur = register_lerp(freq_to_note(freq), 2.2, 1.1)
        return render_fm(freq, 1.4, index0=3.2, duration=dur,
                          amp_decay=register_lerp(freq_to_note(freq), 1.4, 3.2),
                          index_decay=6.0)

    def rf_bright_acoustic(freq, zi):
        dur = register_lerp(freq_to_note(freq), 1.8, 0.9)
        return render_fm(freq, 1.0, index0=5.0, duration=dur,
                          amp_decay=register_lerp(freq_to_note(freq), 2.0, 4.5),
                          index_decay=9.0)

    def rf_electric_grand(freq, zi):
        dur = register_lerp(freq_to_note(freq), 2.0, 1.0)
        return render_fm(freq, 2.0, index0=2.4, duration=dur,
                          amp_decay=register_lerp(freq_to_note(freq), 1.6, 3.4),
                          index_decay=5.0, feedback=0.15)

    def rf_honky_tonk(freq, zi):
        dur = register_lerp(freq_to_note(freq), 2.0, 1.0)
        a = render_fm(freq, 1.4, index0=3.0, duration=dur, amp_decay=2.0, index_decay=6.0)
        b = render_fm(freq * (2.0 ** (16.0 / 1200.0)), 1.4, index0=3.0, duration=dur,
                      amp_decay=2.0, index_decay=6.0)
        n = min(len(a), len(b))
        return _normalise([a[i] + b[i] for i in range(n)])

    def rf_ep1(freq, zi):
        dur = register_lerp(freq_to_note(freq), 2.4, 1.3)
        return render_fm(freq, 14.0, index0=1.6, duration=dur,
                          amp_decay=register_lerp(freq_to_note(freq), 1.2, 2.6),
                          index_decay=11.0)

    def rf_ep2(freq, zi):
        dur = register_lerp(freq_to_note(freq), 2.2, 1.2)
        return render_fm(freq, 7.0, index0=3.4, duration=dur,
                          amp_decay=register_lerp(freq_to_note(freq), 1.6, 3.2),
                          index_decay=7.5, feedback=0.25)

    def rf_harpsichord(freq, zi):
        dur = register_lerp(freq_to_note(freq), 1.4, 0.7)
        return render_harpsichord(freq, dur)

    def rf_clavinet(freq, zi):
        dur = register_lerp(freq_to_note(freq), 1.0, 0.5)
        return render_clavinet(freq, dur)

    piano_defs = [
        (0, "Acoustic Grand Piano", rf_acoustic_grand, 0.5),
        (1, "Bright Acoustic Piano", rf_bright_acoustic, 0.35),
        (2, "Electric Grand Piano", rf_electric_grand, 0.4),
        (3, "Honky-tonk Piano", rf_honky_tonk, 0.4),
        (4, "Electric Piano 1", rf_ep1, 0.5),
        (5, "Electric Piano 2", rf_ep2, 0.4),
        (6, "Harpsichord", rf_harpsichord, 0.15),
        (7, "Clavinet", rf_clavinet, 0.2),
    ]
    for prog, name, render_fn, release in piano_defs:
        inst = make_oneshot_instrument(name, f"p{prog}", render_fn, release=release)
        add_preset(prog, name, inst)

    # =================================================================
    # 8-15 Chromatic Percussion - bells/mallets, each a different FM/additive
    # recipe so glockenspiel, vibraphone, marimba, and tubular bells don't
    # collapse into the same "bell" patch.
    # =================================================================

    def rf_celesta(freq, zi):
        return render_fm(freq * 2.0, 4.0, index0=2.0,
                          duration=register_lerp(freq_to_note(freq), 2.6, 1.4),
                          amp_decay=1.4, index_decay=4.0)

    def rf_glockenspiel(freq, zi):
        return render_fm(freq * 3.0, 3.01, index0=3.6,
                          duration=register_lerp(freq_to_note(freq), 2.4, 1.6),
                          amp_decay=1.8, index_decay=5.5)

    def rf_music_box(freq, zi):
        return render_fm(freq * 2.0, 7.0, index0=1.8,
                          duration=register_lerp(freq_to_note(freq), 1.8, 1.0),
                          amp_decay=2.4, index_decay=8.0)

    def rf_vibraphone(freq, zi):
        return render_fm(freq, 4.01, index0=1.4,
                          duration=register_lerp(freq_to_note(freq), 3.0, 2.0),
                          amp_decay=1.1, index_decay=3.0)

    def rf_marimba(freq, zi):
        n_dur = register_lerp(freq_to_note(freq), 1.6, 0.8)
        harmonics = [(1, 1.0), (3.9, 0.5), (9.2, 0.2)]
        n = int(n_dur * SAMPLE_RATE)
        tone = render_additive(freq, max(1, round(n_dur * freq)), harmonics)[:n]
        tone += [0.0] * (n - len(tone))
        return _normalise(apply_envelope(tone, exp_envelope(n, 3.6, SAMPLE_RATE)))

    def rf_xylophone(freq, zi):
        n_dur = register_lerp(freq_to_note(freq), 1.0, 0.5)
        harmonics = [(1, 1.0), (3.0, 0.6), (6.2, 0.3), (11.0, 0.15)]
        n = int(n_dur * SAMPLE_RATE)
        tone = render_additive(freq, max(1, round(n_dur * freq)), harmonics)[:n]
        tone += [0.0] * (n - len(tone))
        return _normalise(apply_envelope(tone, exp_envelope(n, 5.5, SAMPLE_RATE)))

    def rf_tubular_bells(freq, zi):
        return render_fm(freq, 1.4, index0=4.5,
                          duration=register_lerp(freq_to_note(freq), 3.2, 2.0),
                          amp_decay=0.9, index_decay=2.6)

    def rf_dulcimer(freq, zi):
        return render_two_layer_pluck(freq, register_lerp(freq_to_note(freq), 1.6, 0.8),
                                       decay=0.996, brightness=0.65, detune_cents=9)

    mallet_defs = [
        (8, "Celesta", rf_celesta, 0.5),
        (9, "Glockenspiel", rf_glockenspiel, 0.5),
        (10, "Music Box", rf_music_box, 0.4),
        (11, "Vibraphone", rf_vibraphone, 0.6),
        (12, "Marimba", rf_marimba, 0.35),
        (13, "Xylophone", rf_xylophone, 0.25),
        (14, "Tubular Bells", rf_tubular_bells, 0.6),
        (15, "Dulcimer", rf_dulcimer, 0.3),
    ]
    for prog, name, render_fn, release in mallet_defs:
        inst = make_oneshot_instrument(name, f"p{prog}", render_fn, release=release)
        add_preset(prog, name, inst)

    # =================================================================
    # 16-23 Organ
    # =================================================================

    def loop_organ_drawbars(harmonics):
        def fn(freq, zi):
            return render_additive(freq, 24, harmonics)
        return fn

    organ_defs = [
        (16, "Drawbar Organ", loop_organ_drawbars(
            [(1, 0.8), (2, 0.55), (3, 0.35), (4, 0.3), (6, 0.2), (8, 0.15)]),
         0.01, 0.05, 0, 0.15, 9000, 12000, 0),
        (17, "Percussive Organ", loop_organ_drawbars(
            [(1, 0.9), (2, 0.7), (4, 0.3)]),
         0.004, 0.2, 0, 0.1, 4000, 7500, 0),
        (18, "Rock Organ", loop_organ_drawbars(
            [(1, 0.7), (2, 0.6), (3, 0.5), (5, 0.3), (7, 0.25)]),
         0.008, 0.05, 0, 0.15, 6000, 9500, 0),
        (19, "Church Organ", loop_organ_drawbars(
            [(1, 0.85), (2, 0.4), (3, 0.4), (4, 0.35), (6, 0.3), (8, 0.25)]),
         0.5, 0.3, 0, 1.2, 3500, 6500, 0),
        (20, "Reed Organ", None, 0.08, 0.1, 0, 0.3, 3200, 4600, 0),
        (21, "Accordion", None, 0.03, 0.1, 0, 0.2, 4200, 5800, 100),
        (22, "Harmonica", None, 0.02, 0.1, 0, 0.15, 3800, 5400, -100),
        (23, "Tango Accordion", None, 0.03, 0.1, 0, 0.2, 4200, 5800, -100),
    ]
    for prog, name, render_fn, a, d, s, r, flo, fhi, pan in organ_defs:
        if render_fn is None:
            voice = "pulse25" if prog in (21, 23) else "square"
            kind, base_samples, base_freq = VOICE_BUILDERS[voice]

            def render_fn(freq, zi, _base=base_samples, _bf=base_freq):
                ratio = freq / _bf
                return _base  # reused as-is; register variation via filter only

        inst = make_looped_instrument(name, render_fn, a, d, s, r,
                                       filter_lo=flo, filter_hi=fhi, pan=pan,
                                       key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    # =================================================================
    # 24-31 Guitar
    # =================================================================

    guitar_defs = [
        (24, "Acoustic Guitar (nylon)", 196.0, 0.55, 0.45, False),
        (25, "Acoustic Guitar (steel)", 220.0, 0.75, 0.3, False),
        (26, "Electric Guitar (jazz)", 175.0, 0.45, 0.55, False),
        (27, "Electric Guitar (clean)", 220.0, 0.65, 0.35, True),
        (28, "Electric Guitar (muted)", 247.0, 0.25, 0.25, False),
        (29, "Overdriven Guitar", 220.0, 0.55, 0.996, True),
        (30, "Distortion Guitar", 220.0, 0.6, 0.994, True),
        (31, "Guitar Harmonics", 440.0, 0.75, 0.9992, False),
    ]
    for prog, name, ref_freq, brightness, decay, two_layer in guitar_defs:
        def render_fn(freq, zi, br=brightness, dc=decay, two=two_layer, p=prog):
            dur = register_lerp(freq_to_note(freq), 1.8, 1.0)
            if two:
                return render_two_layer_pluck(freq, dur, decay=dc, brightness=br,
                                               detune_cents=6, seed_offset=p * 10)
            return render_karplus(freq, dur, decay=dc, brightness=br, seed_offset=p * 10)
        inst = make_oneshot_instrument(name, f"p{prog}", render_fn, release=0.3)
        add_preset(prog, name, inst)

    # =================================================================
    # 32-39 Bass
    # =================================================================

    bass_defs = [
        (32, "Acoustic Bass", "sine", None, 4500),
        (33, "Electric Bass (finger)", "triangle", None, 3200),
        (34, "Electric Bass (pick)", "saw", None, 2200),
        (35, "Fretless Bass", "triangle", None, 3600),
        (36, "Slap Bass 1", "square", None, 2600),
        (37, "Slap Bass 2", "pulse12", None, 2400),
        (38, "Synth Bass 1", "saw_soft", None, 1800),
        (39, "Synth Bass 2", "pulse25", None, 1600),
    ]
    for prog, name, voice, _unused, filt in bass_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, 0.006, 0.15, 200, 0.2,
                                       filter_lo=filt - 800, filter_hi=filt + 800,
                                       coarse=-24, key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    # =================================================================
    # 40-47 Strings
    # =================================================================

    string_defs = [
        (40, "Violin", "saw", 12, 5500, 8000, 0),
        (41, "Viola", "saw", 10, 4200, 6200, 0),
        (42, "Cello", "saw", 8, 3200, 5000, -19),
        (43, "Contrabass", "saw_soft", 6, 2400, 3800, -31),
        (44, "Tremolo Strings", "saw", 20, 5000, 7200, 0),
    ]
    for prog, name, voice, vib, flo, fhi, coarse in string_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, 0.12, 0.3, 0, 0.5,
                                       filter_lo=flo, filter_hi=fhi, coarse=coarse,
                                       vibrato_depth=vib, key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    def rf_pizzicato(freq, zi):
        return render_karplus(freq, register_lerp(freq_to_note(freq), 0.5, 0.25),
                               decay=0.994, brightness=0.6)

    def rf_harp(freq, zi):
        return render_two_layer_pluck(freq, register_lerp(freq_to_note(freq), 0.9, 0.5),
                                       decay=0.9965, brightness=0.7, detune_cents=4)

    def rf_timpani(freq, zi):
        return voice_tom(0.9, freq * 1.4, freq * 0.9)

    add_preset(45, "Pizzicato Strings",
               make_oneshot_instrument("Pizzicato Strings", "p45", rf_pizzicato, release=0.2))
    add_preset(46, "Orchestral Harp",
               make_oneshot_instrument("Orchestral Harp", "p46", rf_harp, release=0.4))
    add_preset(47, "Timpani",
               make_oneshot_instrument("Timpani", "p47", rf_timpani, release=0.5))

    # =================================================================
    # 48-55 Ensemble
    # =================================================================

    ensemble_defs = [
        (48, "String Ensemble 1", "saw", 6000, 7200, 10),
        (49, "String Ensemble 2", "saw_soft", 4500, 5800, 10),
        (50, "Synth Strings 1", "saw", 5000, 6600, 14),
        (51, "Synth Strings 2", "square", 4200, 5600, 12),
        (52, "Choir Aahs", "triangle", 2800, 3800, 8),
        (53, "Voice Oohs", "sine", 2200, 3000, 6),
        (54, "Synth Voice", "pulse25", 3200, 4400, 10),
    ]
    for prog, name, voice, flo, fhi, vib in ensemble_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, 0.25, 0.3, 0, 0.7,
                                       filter_lo=flo, filter_hi=fhi,
                                       vibrato_depth=vib, key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    def rf_orchestra_hit(freq, zi):
        parts = []
        dur = 0.4
        for ratio in (1.0, 1.26, 1.5, 0.84):
            parts.append(render_additive(freq * ratio, max(1, round(dur * freq * ratio)),
                                          saw_harmonics(10))[: int(dur * SAMPLE_RATE)])
        noise = one_pole_lowpass(white_noise(0.05), 0.5)
        n = int(dur * SAMPLE_RATE)
        combined = mix(*parts, noise + [0.0] * (n - len(noise)))
        env = exp_envelope(n, 6.0)
        return _normalise(apply_envelope(combined[:n], env))

    add_preset(55, "Orchestra Hit",
               make_oneshot_instrument("Orchestra Hit", "p55", rf_orchestra_hit,
                                       release=0.4))

    # =================================================================
    # 56-63 Brass
    # =================================================================

    brass_defs = [
        (56, "Trumpet", "saw", 5000, 7000, 200, 0),
        (57, "Trombone", "saw_soft", 3600, 5200, -200, 0),
        (58, "Tuba", "saw_soft", 2000, 3200, 0, -12),
        (59, "Muted Trumpet", "square", 3200, 4600, 200, 0),
        (60, "French Horn", "triangle", 3000, 4400, -100, 0),
        (61, "Brass Section", "saw", 4600, 6400, 0, 0),
        (62, "Synth Brass 1", "saw", 5600, 7600, 0, 0),
        (63, "Synth Brass 2", "pulse25", 4600, 6400, 0, 0),
    ]
    for prog, name, voice, flo, fhi, pan, coarse in brass_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, 0.06, 0.15, 0, 0.25,
                                       filter_lo=flo, filter_hi=fhi, pan=pan,
                                       coarse=coarse, key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    # =================================================================
    # 64-71 Reed
    # =================================================================

    reed_defs = [
        (64, "Soprano Sax", "square", 4600, 6200, 250),
        (65, "Alto Sax", "square", 3800, 5200, 150),
        (66, "Tenor Sax", "pulse25", 3000, 4200, -150),
        (67, "Baritone Sax", "pulse12", 2200, 3200, -250),
        (68, "Oboe", "saw", 4200, 5800, 0),
        (69, "English Horn", "saw_soft", 3200, 4400, 0),
        (70, "Bassoon", "saw_soft", 2200, 3200, 0),
        (71, "Clarinet", "pulse12", 3000, 4200, 0),
    ]
    for prog, name, voice, flo, fhi, pan in reed_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, 0.08, 0.12, 0, 0.2,
                                       filter_lo=flo, filter_hi=fhi, pan=pan,
                                       vibrato_depth=6, key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    # =================================================================
    # 72-79 Pipe
    # =================================================================

    pipe_defs = [
        (72, "Piccolo", "sine", 6200, 7800, 300, 12),
        (73, "Flute", "sine", 5200, 6600, 0, 0),
        (74, "Recorder", "triangle", 4400, 5800, 0, 0),
        (75, "Pan Flute", "sine", 3800, 5000, 0, 0),
        (76, "Blown Bottle", "triangle", 3000, 4000, 0, 0),
        (77, "Shakuhachi", "triangle", 3400, 4600, 0, 0),
        (78, "Whistle", "sine", 7000, 8800, 0, 0),
        (79, "Ocarina", "sine", 3600, 4600, 0, 0),
    ]
    for prog, name, voice, flo, fhi, pan, coarse in pipe_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, 0.1, 0.15, 0, 0.25,
                                       filter_lo=flo, filter_hi=fhi, pan=pan,
                                       coarse=coarse, vibrato_depth=8,
                                       key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    # =================================================================
    # 80-87 Synth Lead
    # =================================================================

    lead_defs = [
        (80, "Lead 1 (square)", "square", 5600, 7400, 0),
        (81, "Lead 2 (sawtooth)", "saw", 6800, 8600, 0),
        (82, "Lead 3 (calliope)", "sine", 4800, 6200, 0),
        (83, "Lead 4 (chiff)", "pulse12", 4200, 5600, 0),
        (84, "Lead 5 (charang)", "saw", 7200, 9000, 0),
        (85, "Lead 6 (voice)", "triangle", 3600, 4800, 0),
        (86, "Lead 7 (fifths)", "saw", 6000, 7800, 0),
        (87, "Lead 8 (bass + lead)", "saw_soft", 5200, 6800, -12),
    ]
    for prog, name, voice, flo, fhi, coarse in lead_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, 0.01, 0.08, 0, 0.15,
                                       filter_lo=flo, filter_hi=fhi, coarse=coarse,
                                       key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    # =================================================================
    # 88-95 Synth Pad
    # =================================================================

    pad_defs = [
        (88, "Pad 1 (new age)", "sine", 2800, 3800),
        (89, "Pad 2 (warm)", "triangle", 2400, 3200),
        (90, "Pad 3 (polysynth)", "saw", 3800, 5000),
        (91, "Pad 4 (choir)", "triangle", 2600, 3400),
        (92, "Pad 5 (bowed)", "saw_soft", 3200, 4200),
        (93, "Pad 6 (metallic)", "square", 4000, 5200),
        (94, "Pad 7 (halo)", "sine", 3400, 4400),
        (95, "Pad 8 (sweep)", "saw", 4400, 6000),
    ]
    for prog, name, voice, flo, fhi in pad_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, 0.9, 0.6, 0, 1.2,
                                       filter_lo=flo, filter_hi=fhi,
                                       vibrato_depth=8, key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    # =================================================================
    # 96-103 Synth Effects
    # =================================================================

    fx_defs = [
        (96, "FX 1 (rain)", "sine", 2800, 3800, 0.6),
        (97, "FX 2 (soundtrack)", "saw", 3800, 5000, 0.8),
        (98, "FX 3 (crystal)", "triangle", 4600, 6000, 0.5),
        (99, "FX 4 (atmosphere)", "triangle", 2600, 3600, 1.0),
        (100, "FX 5 (brightness)", "square", 5600, 7200, 0.6),
        (101, "FX 6 (goblins)", "pulse12", 2200, 3200, 0.7),
        (102, "FX 7 (echoes)", "saw_soft", 3200, 4400, 1.1),
        (103, "FX 8 (sci-fi)", "pulse25", 4200, 5600, 0.9),
    ]
    for prog, name, voice, flo, fhi, att in fx_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, att, 0.4, 0, 1.0,
                                       filter_lo=flo, filter_hi=fhi,
                                       vibrato_depth=14, key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    # =================================================================
    # 104-111 Ethnic
    # =================================================================

    ethnic_pluck_defs = [
        (104, "Sitar", 220.0, 0.995, 0.6),
        (105, "Banjo", 246.9, 0.992, 0.6),
        (106, "Shamisen", 293.7, 0.993, 0.5),
        (107, "Koto", 261.6, 0.994, 0.55),
        (108, "Kalimba", 349.2, 0.996, 0.4),
    ]
    for prog, name, _ref, decay, brightness in ethnic_pluck_defs:
        def render_fn(freq, zi, dc=decay, br=brightness, p=prog):
            dur = register_lerp(freq_to_note(freq), 0.9, 0.5)
            return render_karplus(freq, dur, decay=dc, brightness=br, seed_offset=p * 10)
        inst = make_oneshot_instrument(name, f"p{prog}", render_fn, release=0.3)
        add_preset(prog, name, inst)

    ethnic_loop_defs = [
        (109, "Bag pipe", "pulse25", 4000, 5200),
        (110, "Fiddle", "saw", 4600, 6200),
        (111, "Shanai", "square", 4000, 5400),
    ]
    for prog, name, voice, flo, fhi in ethnic_loop_defs:
        kind, base_samples, base_freq = VOICE_BUILDERS[voice]

        def render_fn(freq, zi, _base=base_samples):
            return _base

        inst = make_looped_instrument(name, render_fn, 0.06, 0.1, 0, 0.2,
                                       filter_lo=flo, filter_hi=fhi, vibrato_depth=10,
                                       key_prefix=f"p{prog}")
        add_preset(prog, name, inst)

    # =================================================================
    # 112-119 Percussive
    # =================================================================

    def rf_tinkle_bell(freq, zi):
        return voice_bell(1.0, freq * 3.0, 4.0)

    def rf_agogo(freq, zi):
        return voice_cowbell(0.25)

    def rf_steel_drums(freq, zi):
        return render_fm(freq, 2.0, index0=2.2,
                          duration=register_lerp(freq_to_note(freq), 1.4, 0.8),
                          amp_decay=2.6, index_decay=4.0)

    def rf_woodblock(freq, zi):
        return voice_clave(0.15, freq * 4.0)

    def rf_taiko(freq, zi):
        return voice_tom(0.9, freq * 1.1, freq * 0.55)

    def rf_melodic_tom(freq, zi):
        return voice_tom(0.5, freq * 1.6, freq * 0.9)

    def rf_synth_drum(freq, zi):
        return voice_kick(0.4, freq * 1.4, freq * 0.6)

    def rf_reverse_cymbal(freq, zi):
        forward = voice_cymbal(1.6)
        n = len(forward)
        ramp = [i / n for i in range(n)]
        return _normalise(apply_envelope(list(reversed(forward)), ramp))

    perc_defs = [
        (112, "Tinkle Bell", rf_tinkle_bell),
        (113, "Agogo", rf_agogo),
        (114, "Steel Drums", rf_steel_drums),
        (115, "Woodblock", rf_woodblock),
        (116, "Taiko Drum", rf_taiko),
        (117, "Melodic Tom", rf_melodic_tom),
        (118, "Synth Drum", rf_synth_drum),
        (119, "Reverse Cymbal", rf_reverse_cymbal),
    ]
    for prog, name, render_fn in perc_defs:
        inst = make_oneshot_instrument(name, f"p{prog}", render_fn, release=0.15)
        add_preset(prog, name, inst)

    # =================================================================
    # 120-127 Sound Effects
    # =================================================================

    def rf_fret_noise(freq, zi):
        return voice_shaker(0.12)

    def rf_breath_noise(freq, zi):
        n = int(0.5 * SAMPLE_RATE)
        return _normalise(apply_envelope(white_noise(0.5), exp_envelope(n, 4.0)))

    def rf_seashore(freq, zi):
        n = int(2.0 * SAMPLE_RATE)
        noise = one_pole_lowpass(white_noise(2.0), 0.15)
        swell = [0.5 + 0.5 * math.sin(2 * math.pi * 0.3 * (i / SAMPLE_RATE)) for i in range(n)]
        return _normalise(apply_envelope(noise[:n], swell))

    def rf_bird(freq, zi):
        n = int(0.7 * SAMPLE_RATE)
        out = [0.0] * n
        for chirp_start in (0.0, 0.18, 0.36):
            s = int(chirp_start * SAMPLE_RATE)
            length = int(0.12 * SAMPLE_RATE)
            for i in range(length):
                if s + i >= n:
                    break
                t = i / SAMPLE_RATE
                cf = 2800.0 + 1400.0 * math.sin(2 * math.pi * 6.0 * t)
                out[s + i] += math.sin(2 * math.pi * cf * t) * math.exp(-14.0 * t)
        return _normalise(out)

    def rf_telephone(freq, zi):
        n = int(1.0 * SAMPLE_RATE)
        a = render_additive(950.0, round(1.0 * 950.0), [(1, 1.0)])[:n]
        b = render_additive(1400.0, round(1.0 * 1400.0), [(1, 1.0)])[:n]
        a += [0.0] * (n - len(a))
        b += [0.0] * (n - len(b))
        gate = [1.0 if (int(i / SAMPLE_RATE / 0.2) % 2 == 0) else 0.0 for i in range(n)]
        return _normalise(apply_envelope(mix(a, b), gate))

    def rf_helicopter(freq, zi):
        n = int(1.5 * SAMPLE_RATE)
        noise = one_pole_lowpass(white_noise(1.5), 0.2)
        chop = [0.4 + 0.6 * (0.5 + 0.5 * math.sin(2 * math.pi * 9.0 * (i / SAMPLE_RATE)))
                for i in range(n)]
        return _normalise(apply_envelope(noise[:n], chop))

    def rf_applause(freq, zi):
        n = int(1.8 * SAMPLE_RATE)
        noise = one_pole_highpass(white_noise(1.8), 0.3)
        swell = [min(1.0, (i / SAMPLE_RATE) / 0.3) * math.exp(-0.9 * (i / SAMPLE_RATE))
                 for i in range(n)]
        return _normalise(apply_envelope(noise[:n], swell))

    def rf_gunshot(freq, zi):
        n = int(0.6 * SAMPLE_RATE)
        crack = one_pole_highpass(white_noise(0.6)[:n], 0.2)
        return _normalise(apply_envelope(crack, exp_envelope(n, 9.0)))

    sfx_defs = [
        (120, "Guitar Fret Noise", rf_fret_noise),
        (121, "Breath Noise", rf_breath_noise),
        (122, "Seashore", rf_seashore),
        (123, "Bird Tweet", rf_bird),
        (124, "Telephone Ring", rf_telephone),
        (125, "Helicopter", rf_helicopter),
        (126, "Applause", rf_applause),
        (127, "Gunshot", rf_gunshot),
    ]
    for prog, name, render_fn in sfx_defs:
        inst = make_oneshot_instrument(name, f"p{prog}", render_fn, release=0.2)
        add_preset(prog, name, inst)

    # =================================================================
    # Percussion kit (bank 128)
    # =================================================================

    drum_zones = []
    drum_defs = [
        (35, "Acoustic Bass Drum", lambda: voice_kick(0.55, 150.0, 45.0), 36),
        (36, "Bass Drum 1", lambda: voice_kick(0.5, 150.0, 48.0), 36),
        (37, "Side Stick", voice_rim, 38),
        (38, "Acoustic Snare", voice_snare, 38),
        (39, "Hand Clap", voice_clap, 39),
        (40, "Electric Snare", lambda: voice_snare(0.3), 38),
        (41, "Low Floor Tom", lambda: voice_tom(0.6, 180.0, 90.0), 41),
        (42, "Closed Hi Hat", lambda: voice_hat(0.09, decay_rate=70.0), 42),
        (43, "High Floor Tom", lambda: voice_tom(0.55, 210.0, 105.0), 43),
        (44, "Pedal Hi-Hat", lambda: voice_hat(0.1, decay_rate=55.0), 42),
        (45, "Low Tom", lambda: voice_tom(0.55, 240.0, 120.0), 45),
        (46, "Open Hi-Hat", lambda: voice_hat(0.45, decay_rate=8.0), 46),
        (47, "Low-Mid Tom", lambda: voice_tom(0.5, 270.0, 135.0), 47),
        (48, "Hi-Mid Tom", lambda: voice_tom(0.5, 300.0, 150.0), 48),
        (49, "Crash Cymbal 1", lambda: voice_cymbal(2.4), 49),
        (50, "High Tom", lambda: voice_tom(0.45, 330.0, 165.0), 50),
        (51, "Ride Cymbal 1", lambda: voice_cymbal(1.8), 51),
        (52, "Chinese Cymbal", lambda: voice_cymbal(2.0), 52),
        (53, "Ride Bell", lambda: voice_bell(0.9, 900.0, 2.0), 53),
        (54, "Tambourine", lambda: voice_shaker(0.35), 54),
        (55, "Splash Cymbal", lambda: voice_cymbal(1.4), 55),
        (56, "Cowbell", lambda: voice_cowbell(0.3), 56),
        (57, "Crash Cymbal 2", lambda: voice_cymbal(2.2), 57),
        (58, "Vibraslap", lambda: voice_shaker(0.4), 58),
        (59, "Ride Cymbal 2", lambda: voice_cymbal(1.9), 59),
        (60, "Hi Bongo", lambda: voice_tom(0.3, 420.0, 300.0), 60),
        (61, "Low Bongo", lambda: voice_tom(0.35, 320.0, 220.0), 61),
        (62, "Mute Hi Conga", lambda: voice_tom(0.2, 380.0, 280.0), 62),
        (63, "Open Hi Conga", lambda: voice_tom(0.4, 360.0, 250.0), 63),
        (64, "Low Conga", lambda: voice_tom(0.4, 280.0, 190.0), 64),
        (65, "High Timbale", lambda: voice_tom(0.3, 460.0, 340.0), 65),
        (66, "Low Timbale", lambda: voice_tom(0.35, 360.0, 260.0), 66),
        (67, "High Agogo", lambda: voice_cowbell(0.2), 67),
        (68, "Low Agogo", lambda: voice_cowbell(0.25), 68),
        (69, "Cabasa", lambda: voice_shaker(0.2), 69),
        (70, "Maracas", lambda: voice_shaker(0.15), 70),
        (71, "Short Whistle", lambda: voice_bell(0.2, 1600.0, 1.0), 71),
        (72, "Long Whistle", lambda: voice_bell(0.5, 1600.0, 1.0), 72),
        (73, "Short Guiro", lambda: voice_shaker(0.15), 73),
        (74, "Long Guiro", lambda: voice_shaker(0.4), 74),
        (75, "Claves", lambda: voice_clave(0.12, 1800.0), 75),
        (76, "Hi Wood Block", lambda: voice_clave(0.12, 1500.0), 76),
        (77, "Low Wood Block", lambda: voice_clave(0.14, 1100.0), 77),
        (78, "Mute Cuica", lambda: voice_tom(0.2, 500.0, 350.0), 78),
        (79, "Open Cuica", lambda: voice_tom(0.35, 400.0, 250.0), 79),
        (80, "Mute Triangle", lambda: voice_bell(0.15, 2400.0, 1.0), 80),
        (81, "Open Triangle", lambda: voice_bell(0.7, 2400.0, 1.0), 81),
    ]
    for note, name, builder, root in drum_defs:
        floats = get_one_shot(f"drum_{note}", builder)
        idx = samples.add(f"drum_{note}", floats, SAMPLE_RATE, root, loop=False)
        zone = oneshot_zone_gens(key_lo=note, key_hi=note, release=0.08, attack=0.001)
        zone["scaleTuning"] = 0
        zone["sampleID"] = idx
        drum_zones.append(zone)
    drum_inst = instruments.add("Standard Kit", drum_zones)
    presets.append(("Standard Kit", 0, 128, [{"instrument": drum_inst}]))

    sf2_bytes = build_sf2("RuFTraX GM Bank", samples, instruments, presets)
    with open(output_path, "wb") as f:
        f.write(sf2_bytes)
    return sf2_bytes, len(presets) - 1, len(instruments.instruments) - 1, len(samples.headers) - 1


def freq_to_note(freq):
    return 69.0 + 12.0 * math.log2(freq / 440.0)


if __name__ == "__main__":
    out_path = sys.argv[1] if len(sys.argv) > 1 else "RuFTraX_GM_Bank.sf2"
    _, n_presets, n_instruments, n_samples = build_bank(out_path)
    print(f"Wrote {out_path}")
    print(f"Presets: {n_presets + 1} (128 melodic + 1 drum kit)")
    print(f"Instruments: {n_instruments + 1}")
    print(f"Samples: {n_samples + 1}")
