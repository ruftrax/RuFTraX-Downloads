#!/bin/bash
set -euo pipefail

SOURCE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EDITOR_CPP="$SOURCE_ROOT/Source/PluginEditor.cpp"
EDITOR_H="$SOURCE_ROOT/Source/PluginEditor.h"
PROCESSOR_CPP="$SOURCE_ROOT/Source/PluginProcessor.cpp"
PROCESSOR_H="$SOURCE_ROOT/Source/PluginProcessor.h"
CMAKE_FILE="$SOURCE_ROOT/CMakeLists.txt"
APP_ICON="$SOURCE_ROOT/Assets/AppIcon.png"
NOTICES="$SOURCE_ROOT/../THIRD_PARTY_NOTICES.txt"

fail() {
    echo "Validation failed: $1" >&2
    exit 1
}

[[ -f "$EDITOR_CPP" ]] || fail "PluginEditor.cpp is missing"
[[ -f "$PROCESSOR_CPP" ]] || fail "PluginProcessor.cpp is missing"
[[ -s "$APP_ICON" ]] || fail "Finder application icon is missing"
[[ -s "$NOTICES" ]] || fail "third-party software notices are missing"

grep -F 'project(RuFTraXSF2Player VERSION 4.3.2)' "$CMAKE_FILE" >/dev/null \
    || fail "CMake project version is not 4.3.2"

grep -F 'set(PROJECT_SYSTEM_PROCESSOR "aarch64" CACHE STRING "sfizz Apple Silicon architecture" FORCE)' "$CMAKE_FILE" >/dev/null \
    || fail "The sfizz Apple Silicon compiler-flag workaround is missing"
grep -F 'string(REPLACE "Base::template do_pop_any" "Base::do_pop_any"' "$CMAKE_FILE" >/dev/null \
    || fail "The sfizz Xcode 26 atomic_queue pop workaround is missing"
grep -F 'string(REPLACE "Base::template do_push_any" "Base::do_push_any"' "$CMAKE_FILE" >/dev/null \
    || fail "The sfizz Xcode 26 atomic_queue push workaround is missing"
grep -F 'ICON_BIG "${CMAKE_CURRENT_SOURCE_DIR}/Assets/AppIcon.png"' "$CMAKE_FILE" >/dev/null \
    || fail "Finder application icon is not connected to the build"

[[ "$(grep -F -c '"CURRENT PRESET"' "$EDITOR_CPP")" -eq 1 ]] \
    || fail "Current Preset must be drawn exactly once"

if grep -F 'presetLabel' "$EDITOR_CPP" "$EDITOR_H" >/dev/null; then
    fail "the duplicate Current Preset label still exists"
fi

if grep -F 'drawDisplay(g, { x + 356.0f' "$EDITOR_CPP" >/dev/null; then
    fail "the duplicate preset display background still exists"
fi

grep -F 'juce::AudioParameterInt' "$PROCESSOR_CPP" | grep -F '"transpose"' >/dev/null \
    || fail "the saved transpose parameter is missing"
grep -F 'applyTransposeChangeIfNeeded' "$PROCESSOR_CPP" >/dev/null \
    || fail "live SoundFont retuning is missing"
grep -F 'transposeDownButton' "$EDITOR_CPP" >/dev/null \
    || fail "the transpose down button is missing"
grep -F 'transposeUpButton' "$EDITOR_CPP" >/dev/null \
    || fail "the transpose up button is missing"
grep -F 'getTransposeSemitones' "$PROCESSOR_H" >/dev/null \
    || fail "the transpose API is missing"

grep -F 'GIT_REPOSITORY https://github.com/sfztools/sfizz.git' "$CMAKE_FILE" >/dev/null \
    || fail "the pinned sfizz dependency is missing"
grep -F 'GIT_TAG 1.2.3' "$CMAKE_FILE" >/dev/null \
    || fail "sfizz is not pinned to the approved release"
grep -F 'sfizz::sfizz' "$CMAKE_FILE" >/dev/null \
    || fail "the SFZ engine is not linked"
grep -F 'sfizz_load_file' "$PROCESSOR_CPP" >/dev/null \
    || fail "SFZ file loading is missing"
grep -F 'sfizz_render_block' "$PROCESSOR_CPP" >/dev/null \
    || fail "SFZ audio rendering is missing"
grep -F 'state.setProperty("instrumentPath"' "$PROCESSOR_CPP" >/dev/null \
    || fail "SF2/SFZ saved-state restoration is missing"
grep -F '"*.sf2;*.sfz"' "$EDITOR_CPP" >/dev/null \
    || fail "the file browser does not accept both SF2 and SFZ"
grep -F 'DRAG & DROP AN SF2 OR SFZ FILE HERE TO LOAD' "$EDITOR_CPP" >/dev/null \
    || fail "the SF2/SFZ drag-and-drop target is missing"

if LC_ALL=C grep -R -n -E 'â|�' "$SOURCE_ROOT/Source" "$SOURCE_ROOT/README.md"; then
    fail "mojibake characters were found"
fi

grep -F 'FORMATS AU VST3 Standalone' "$CMAKE_FILE" >/dev/null \
    || fail "VST3 is not in the build formats"
grep -F 'RuFTraXSF2Player_VST3' "$SOURCE_ROOT/build_mac.sh" >/dev/null \
    || fail "build_mac.sh does not build the VST3 target"

grep -F 'void silenceCurrentInstrument();' "$PROCESSOR_H" >/dev/null \
    || fail "the silence-before-swap safeguard is missing"
grep -F 'void swapInSf2(tsf* newSynth);' "$PROCESSOR_H" >/dev/null \
    || fail "the safe SF2 instrument-swap helper is missing"
grep -F 'void swapInSfz(sfizz_synth_t* newSynth);' "$PROCESSOR_H" >/dev/null \
    || fail "the safe SFZ instrument-swap helper is missing"
[[ "$(grep -F -c 'interleavedBuffer.allocate' "$PROCESSOR_CPP")" -eq 1 ]] \
    || fail "interleavedBuffer must only be allocated once, in prepareToPlay() - not on the audio thread"
[[ "$(grep -F -c 'juce::jmin(maximumBlockSize' "$PROCESSOR_CPP")" -eq 2 ]] \
    || fail "the SF2 render path is not chunked the same way as the SFZ path"

[[ -s "$SOURCE_ROOT/Assets/RuFTraX_GM_Bank.sf2" ]] \
    || fail "the built-in General MIDI bank is missing"
[[ -f "$SOURCE_ROOT/Scripts/generate_gm_bank.py" ]] \
    || fail "the GM bank generator script is missing (the bank must stay regeneratable from source)"
grep -F 'SOURCES Assets/RuFTraX_GM_Bank.sf2' "$CMAKE_FILE" >/dev/null \
    || fail "the GM bank is not embedded as the plug-in's binary data"
grep -F 'BinaryData::RuFTraX_GM_Bank_sf2' "$PROCESSOR_CPP" >/dev/null \
    || fail "the GM bank is not loaded as the default instrument"

echo "RuFTraX SF Player Pro v4.3.2 source validation passed."
