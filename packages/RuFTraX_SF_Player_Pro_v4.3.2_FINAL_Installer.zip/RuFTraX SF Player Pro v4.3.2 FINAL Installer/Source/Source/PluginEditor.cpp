#include "PluginEditor.h"
#include <array>
#include <cmath>
#include <cstdint>


namespace
{
constexpr auto faceRed      = 0xff8d160f;
constexpr auto faceRedDark  = 0xff4d0806;
constexpr auto cream        = 0xffffe6ad;
constexpr auto creamDark    = 0xffc99948;
constexpr auto displayBlack = 0xff090604;
constexpr auto displayRed   = 0xffff3a27;
constexpr auto woodDark     = 0xff2b1108;
constexpr auto woodLight    = 0xff6f3218;
}

RetroLookAndFeel::RetroLookAndFeel()
{
    setColour(juce::Slider::textBoxTextColourId, juce::Colour(cream));
    setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(displayBlack));
    setColour(juce::Slider::textBoxOutlineColourId, juce::Colour(creamDark).withAlpha(0.45f));
    setColour(juce::ComboBox::textColourId, juce::Colour(displayRed));
    setColour(juce::ComboBox::backgroundColourId, juce::Colour(displayBlack));
    setColour(juce::ComboBox::outlineColourId, juce::Colour(creamDark));
    setColour(juce::Label::textColourId, juce::Colour(cream));
    setColour(juce::TextButton::textColourOffId, juce::Colour(0xff2a1608));
    setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff160c08));
    setColour(juce::PopupMenu::textColourId, juce::Colour(cream));
    setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(faceRed));
}

juce::Font RetroLookAndFeel::getLabelFont(juce::Label& label)
{
    return juce::Font(juce::FontOptions(label.getName() == "title" ? 34.0f : 15.0f,
                                        juce::Font::bold));
}

void RetroLookAndFeel::drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                                        float sliderPos, float startAngle, float endAngle,
                                        juce::Slider&)
{
    const auto size = (float) juce::jmin(width, height - 24);
    auto bounds = juce::Rectangle<float>((float) x, (float) y, (float) width, size)
                    .withSizeKeepingCentre(size, size).reduced(7.0f);
    const auto centre = bounds.getCentre();
    const auto radius = bounds.getWidth() * 0.5f;

    g.setColour(juce::Colours::black.withAlpha(0.45f));
    g.fillEllipse(bounds.translated(3.0f, 5.0f));

    juce::ColourGradient rim(juce::Colour(0xfff3d187), centre.x, bounds.getY(),
                             juce::Colour(0xff8b4b15), centre.x, bounds.getBottom(), false);
    g.setGradientFill(rim);
    g.fillEllipse(bounds);

    auto inner = bounds.reduced(5.0f);
    juce::ColourGradient knob(juce::Colour(0xffffefbf), inner.getCentreX(), inner.getY(),
                              juce::Colour(0xffd5a654), inner.getCentreX(), inner.getBottom(), false);
    g.setGradientFill(knob);
    g.fillEllipse(inner);
    g.setColour(juce::Colour(0xff6b3a13));
    g.drawEllipse(inner, 1.4f);

    const auto angle = startAngle + sliderPos * (endAngle - startAngle);
    juce::Path pointer;
    pointer.addRoundedRectangle(-2.1f, -radius + 12.0f, 4.2f, radius * 0.54f, 2.0f);
    g.setColour(juce::Colour(0xff35180b));
    g.fillPath(pointer, juce::AffineTransform::rotation(angle).translated(centre.x, centre.y));

    g.setColour(juce::Colour(cream).withAlpha(0.78f));
    for (int i = 0; i <= 10; ++i)
    {
        const auto a = startAngle + (endAngle - startAngle) * ((float) i / 10.0f);
        const auto p1 = centre + juce::Point<float>(std::sin(a), -std::cos(a)) * (radius + 1.0f);
        const auto p2 = centre + juce::Point<float>(std::sin(a), -std::cos(a)) * (radius + 6.0f);
        g.drawLine({ p1, p2 }, i == 0 || i == 10 ? 1.5f : 1.0f);
    }
}

void RetroLookAndFeel::drawButtonBackground(juce::Graphics& g, juce::Button& button,
                                             const juce::Colour&, bool highlighted, bool down)
{
    auto b = button.getLocalBounds().toFloat().reduced(1.0f);
    const auto top = down ? juce::Colour(0xffb47b2a) : juce::Colour(0xffffe4a4);
    const auto bottom = down ? juce::Colour(0xff8d571b) : juce::Colour(0xffc58b39);
    juce::ColourGradient grad(top.brighter(highlighted ? 0.08f : 0.0f), b.getCentreX(), b.getY(),
                              bottom, b.getCentreX(), b.getBottom(), false);
    g.setGradientFill(grad);
    g.fillRoundedRectangle(b, 4.0f);
    g.setColour(juce::Colour(0xff4a250c));
    g.drawRoundedRectangle(b, 4.0f, 1.4f);
    g.setColour(juce::Colours::white.withAlpha(0.25f));
    g.drawLine(b.getX() + 4.0f, b.getY() + 2.0f, b.getRight() - 4.0f, b.getY() + 2.0f, 1.0f);
}

void RetroLookAndFeel::drawComboBox(juce::Graphics& g, int width, int height, bool,
                                    int, int, int, int, juce::ComboBox&)
{
    auto b = juce::Rectangle<float>(0.0f, 0.0f, (float) width, (float) height).reduced(1.0f);
    g.setColour(juce::Colour(displayBlack));
    g.fillRoundedRectangle(b, 5.0f);
    g.setColour(juce::Colour(creamDark));
    g.drawRoundedRectangle(b, 5.0f, 1.2f);

    juce::Path arrow;
    arrow.addTriangle((float) width - 24.0f, (float) height * 0.36f,
                      (float) width - 12.0f, (float) height * 0.36f,
                      (float) width - 18.0f, (float) height * 0.64f);
    g.setColour(juce::Colour(displayRed));
    g.fillPath(arrow);
}

RuFTraXSF2PlayerAudioProcessorEditor::RuFTraXSF2PlayerAudioProcessorEditor(RuFTraXSF2PlayerAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    setLookAndFeel(&retroLook);
    setSize(1180, 820);
    setResizable(true, true);
    setResizeLimits(980, 720, 1600, 1050);

    titleLabel.setName("title");
    titleLabel.setText("RuFTraX", juce::dontSendNotification);
    titleLabel.setFont(juce::Font(juce::FontOptions(46.0f, juce::Font::bold)));
    titleLabel.setJustificationType(juce::Justification::centredLeft);

    subtitleLabel.setText("SF PLAYER PRO   |   MIDI / TONE / CHORD ANALYZER", juce::dontSendNotification);
    subtitleLabel.setFont(juce::Font(juce::FontOptions(17.0f, juce::Font::bold)));
    subtitleLabel.setJustificationType(juce::Justification::centredLeft);

    soundLabel.setFont(juce::Font(juce::FontOptions(19.0f, juce::Font::bold)));
    soundLabel.setJustificationType(juce::Justification::centred);
    soundLabel.setColour(juce::Label::textColourId, juce::Colour(displayRed));

    statusLabel.setFont(juce::Font(juce::FontOptions(13.0f)));
    statusLabel.setJustificationType(juce::Justification::centred);
    statusLabel.setColour(juce::Label::textColourId, juce::Colour(cream).withAlpha(0.82f));

    addAndMakeVisible(titleLabel);
    addAndMakeVisible(subtitleLabel);
    addAndMakeVisible(soundLabel);
    addAndMakeVisible(statusLabel);
    addAndMakeVisible(presetBox);
    addAndMakeVisible(loadButton);
    addAndMakeVisible(restoreButton);
    addAndMakeVisible(transposeDownButton);
    addAndMakeVisible(transposeValueLabel);
    addAndMakeVisible(transposeUpButton);

    transposeValueLabel.setJustificationType(juce::Justification::centred);
    transposeValueLabel.setFont(juce::Font(juce::FontOptions(11.0f, juce::Font::bold)));
    transposeValueLabel.setColour(juce::Label::textColourId, juce::Colour(displayRed));
    transposeValueLabel.setColour(juce::Label::backgroundColourId, juce::Colour(displayBlack));
    transposeValueLabel.setColour(juce::Label::outlineColourId,
                                  juce::Colour(creamDark).withAlpha(0.65f));

    transposeDownButton.setTooltip("Transpose the SoundFont down one semitone");
    transposeUpButton.setTooltip("Transpose the SoundFont up one semitone");
    transposeDownButton.onClick = [this]
    {
        processor.setTransposeSemitones(processor.getTransposeSemitones() - 1);
    };
    transposeUpButton.onClick = [this]
    {
        processor.setTransposeSemitones(processor.getTransposeSemitones() + 1);
    };

    configureKnob(volumeSlider, volumeLabel, "VOLUME");
    configureKnob(panSlider, panLabel, "PAN");
    configureKnob(cutoffSlider, cutoffLabel, "CUTOFF");
    configureKnob(resonanceSlider, resonanceLabel, "RESONANCE");
    configureKnob(driveSlider, driveLabel, "DRIVE");
    configureKnob(chorusSlider, chorusLabel, "CHORUS");
    configureKnob(reverbSlider, reverbLabel, "REVERB");
    configureKnob(roomSlider, roomLabel, "ROOM SIZE");

    volumeSlider.setTextValueSuffix(" dB");
    cutoffSlider.setTextValueSuffix(" Hz");
    driveSlider.setTextValueSuffix(" dB");

    const char* ids[] = { "gain", "pan", "cutoff", "resonance", "drive", "chorusMix", "reverbMix", "reverbSize" };
    juce::Slider* sliders[] = { &volumeSlider, &panSlider, &cutoffSlider, &resonanceSlider,
                                &driveSlider, &chorusSlider, &reverbSlider, &roomSlider };
    for (int i = 0; i < 8; ++i)
        attachments.push_back(std::make_unique<SliderAttachment>(processor.parameters, ids[i], *sliders[i]));

    presetBox.setJustificationType(juce::Justification::centred);
    presetBox.onChange = [this]
    {
        if (presetBox.getSelectedId() > 0)
            processor.selectPreset(presetBox.getSelectedId() - 1);
    };

    loadButton.onClick = [this]
    {
        chooser = std::make_unique<juce::FileChooser>(
            "Choose an SF2 or SFZ instrument",
            juce::File(),
            "*.sf2;*.sfz");
        chooser->launchAsync(juce::FileBrowserComponent::openMode |
                             juce::FileBrowserComponent::canSelectFiles,
            [this](const juce::FileChooser& fc)
            {
                const auto file = fc.getResult();
                if (file.existsAsFile())
                    processor.loadInstrument(file);
            });
    };

    restoreButton.onClick = [this] { processor.loadBundledSoundFont(); };
    startTimerHz(12);
}

RuFTraXSF2PlayerAudioProcessorEditor::~RuFTraXSF2PlayerAudioProcessorEditor()
{
    setLookAndFeel(nullptr);
}

void RuFTraXSF2PlayerAudioProcessorEditor::configureKnob(juce::Slider& slider,
                                                         juce::Label& label,
                                                         const juce::String& text)
{
    addAndMakeVisible(slider);
    addAndMakeVisible(label);
    slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 92, 22);
    label.setText(text, juce::dontSendNotification);
    label.setFont(juce::Font(juce::FontOptions(14.0f, juce::Font::bold)));
    label.setJustificationType(juce::Justification::centred);
}

bool RuFTraXSF2PlayerAudioProcessorEditor::isInterestedInFileDrag(const juce::StringArray& files)
{
    for (const auto& path : files)
        if (path.endsWithIgnoreCase(".sf2")
            || path.endsWithIgnoreCase(".sfz"))
            return true;
    return false;
}

void RuFTraXSF2PlayerAudioProcessorEditor::filesDropped(const juce::StringArray& files, int, int)
{
    for (const auto& path : files)
    {
        juce::File file(path);
        if (file.hasFileExtension("sf2;sfz") && file.existsAsFile())
        {
            processor.loadInstrument(file);
            break;
        }
    }
}

void RuFTraXSF2PlayerAudioProcessorEditor::timerCallback()
{
    soundLabel.setText(processor.getLoadedSoundFontName(), juce::dontSendNotification);
    statusLabel.setText(processor.getStatus(), juce::dontSendNotification);

    const auto names = processor.getPresetNames();
    if (names != displayedPresets)
    {
        displayedPresets = names;
        presetBox.clear(juce::dontSendNotification);
        for (int i = 0; i < names.size(); ++i)
            presetBox.addItem(juce::String(i).paddedLeft('0', 3) + "   " + names[i], i + 1);
    }
    presetBox.setSelectedId(processor.getCurrentProgram() + 1, juce::dontSendNotification);

    displayedMidiNote = processor.getLastMidiNote();
    displayedMidiVelocity = processor.getLastMidiVelocity();
    displayedMidiChannel = processor.getLastMidiChannel();
    displayedAftertouch = processor.getLastAftertouch();
    displayedFrequencyHz = processor.getOutputFrequencyHz();
    displayedLevelDb = processor.getOutputLevelDb();
    displayedCents = processor.getOutputCents();
    displayedChord = analyseChord(processor.getActiveNotes());
    const int transpose = processor.getTransposeSemitones();
    transposeValueLabel.setText((transpose >= 0 ? "+" : "") + juce::String(transpose) + " ST",
                                juce::dontSendNotification);

    const auto activity = processor.getMidiActivityCounter();
    if (activity != lastMidiActivityCounter)
    {
        lastMidiActivityCounter = activity;
        midiLedHoldTicks = 5;
    }
    else if (midiLedHoldTicks > 0)
    {
        --midiLedHoldTicks;
    }

    repaint();
}

juce::String RuFTraXSF2PlayerAudioProcessorEditor::noteName(int midiNote, bool includeOctave)
{
    if (!juce::isPositiveAndBelow(midiNote, 128))
        return "-";

    return juce::MidiMessage::getMidiNoteName(midiNote, true, includeOctave, 4);
}

juce::String RuFTraXSF2PlayerAudioProcessorEditor::soundingNotesText(const juce::Array<int>& notes)
{
    if (notes.isEmpty())
        return "No notes sounding";

    juce::String result;
    const int maximumShown = juce::jmin(8, notes.size());

    for (int index = 0; index < maximumShown; ++index)
    {
        if (index > 0)
            result << "  ";

        result << noteName(notes[index], true);
    }

    if (notes.size() > maximumShown)
        result << "  +" << juce::String(notes.size() - maximumShown);

    return result;
}

RuFTraXSF2PlayerAudioProcessorEditor::ChordDisplay
RuFTraXSF2PlayerAudioProcessorEditor::analyseChord(const juce::Array<int>& notes)
{
    ChordDisplay result;
    result.notes = soundingNotesText(notes);

    if (notes.isEmpty())
        return result;

    std::array<bool, 12> pitchClasses {};
    for (const int note : notes)
        pitchClasses[static_cast<size_t>(note % 12)] = true;

    int uniquePitchClasses = 0;
    std::uint16_t absoluteMask = 0;

    for (int pitchClass = 0; pitchClass < 12; ++pitchClass)
    {
        if (pitchClasses[static_cast<size_t>(pitchClass)])
        {
            ++uniquePitchClasses;
            absoluteMask |= static_cast<std::uint16_t>(1u << pitchClass);
        }
    }

    const int bassPitchClass = notes[0] % 12;

    if (uniquePitchClasses == 1)
    {
        const auto root = noteName(notes[0], false);
        result.name = root;
        result.rootAndQuality = "SINGLE NOTE  |  ROOT " + root;
        result.inversion = "ROOT POSITION";
        return result;
    }

    struct ChordTemplate
    {
        std::uint16_t mask;
        const char* suffix;
        const char* quality;
        int toneCount;
    };

    static constexpr std::array<ChordTemplate, 20> templates
    {{
        { 1173, "9",     "Dominant ninth",          5 },
        { 2197, "maj9",  "Major ninth",             5 },
        { 1165, "m9",    "Minor ninth",             5 },
        { 1185, "7sus4", "Dominant seventh sus4",   4 },
        { 2193, "maj7",  "Major seventh",           4 },
        { 1169, "7",     "Dominant seventh",        4 },
        { 1161, "m7",    "Minor seventh",           4 },
        { 2185, "mMaj7", "Minor major seventh",     4 },
        { 1097, "m7b5",  "Half-diminished seventh", 4 },
        {  585, "dim7",  "Diminished seventh",      4 },
        {  657, "6",     "Major sixth",             4 },
        {  649, "m6",    "Minor sixth",             4 },
        {  149, "add9",  "Major add nine",          4 },
        {  141, "madd9", "Minor add nine",          4 },
        {  145, " Major","Major triad",             3 },
        {  137, " Minor","Minor triad",             3 },
        {   73, "dim",   "Diminished triad",        3 },
        {  273, "aug",   "Augmented triad",         3 },
        {  133, "sus2",  "Suspended second",        3 },
        {  161, "sus4",  "Suspended fourth",        3 }
    }};

    int bestRoot = -1;
    const ChordTemplate* bestTemplate = nullptr;
    int bestScore = -1;

    for (int root = 0; root < 12; ++root)
    {
        std::uint16_t relativeMask = 0;

        for (int pitchClass = 0; pitchClass < 12; ++pitchClass)
            if ((absoluteMask & static_cast<std::uint16_t>(1u << pitchClass)) != 0)
                relativeMask |= static_cast<std::uint16_t>(
                    1u << ((pitchClass - root + 12) % 12));

        for (const auto& chordTemplate : templates)
        {
            if (relativeMask != chordTemplate.mask)
                continue;

            int score = chordTemplate.toneCount * 100;
            if (bassPitchClass == root)
                score += 40;

            if (score > bestScore)
            {
                bestScore = score;
                bestRoot = root;
                bestTemplate = &chordTemplate;
            }
        }
    }

    // A two-note root/fifth shape is intentionally handled separately.
    if (bestTemplate == nullptr && uniquePitchClasses == 2)
    {
        for (int root = 0; root < 12; ++root)
        {
            std::uint16_t relativeMask = 0;
            for (int pitchClass = 0; pitchClass < 12; ++pitchClass)
                if ((absoluteMask & static_cast<std::uint16_t>(1u << pitchClass)) != 0)
                    relativeMask |= static_cast<std::uint16_t>(
                        1u << ((pitchClass - root + 12) % 12));

            if (relativeMask == 129)
            {
                bestRoot = root;
                break;
            }
        }

        if (bestRoot >= 0)
        {
            const auto root = noteName(bestRoot + 60, false);
            result.name = root + "5";
            result.rootAndQuality = "ROOT " + root + "  |  POWER CHORD";
            result.inversion = bassPitchClass == bestRoot ? "ROOT POSITION" : "INVERTED FIFTH";
            return result;
        }
    }

    if (bestTemplate == nullptr || bestRoot < 0)
    {
        result.name = "Unrecognized voicing";
        result.rootAndQuality = juce::String(uniquePitchClasses) + " PITCH CLASSES";
        result.inversion = "BASS " + noteName(notes[0], false);
        return result;
    }

    const auto root = noteName(bestRoot + 60, false);
    result.name = root + bestTemplate->suffix;
    result.rootAndQuality = "ROOT " + root + "  |  "
                          + juce::String(bestTemplate->quality).toUpperCase();

    const int bassInterval = (bassPitchClass - bestRoot + 12) % 12;

    if (bassInterval == 0)
        result.inversion = "ROOT POSITION";
    else if (bassInterval == 3 || bassInterval == 4)
        result.inversion = "1ST INVERSION  |  BASS " + noteName(notes[0], false);
    else if (bassInterval == 6 || bassInterval == 7 || bassInterval == 8)
        result.inversion = "2ND INVERSION  |  BASS " + noteName(notes[0], false);
    else if (bassInterval >= 9)
        result.inversion = "3RD INVERSION  |  BASS " + noteName(notes[0], false);
    else
        result.inversion = "SLASH BASS  |  " + noteName(notes[0], false);

    return result;
}

void RuFTraXSF2PlayerAudioProcessorEditor::drawScrew(juce::Graphics& g, float x, float y)
{
    auto r = juce::Rectangle<float>(x - 8.0f, y - 8.0f, 16.0f, 16.0f);
    g.setColour(juce::Colour(0xff080605));
    g.fillEllipse(r);
    g.setColour(juce::Colour(0xff655a4e));
    g.drawEllipse(r, 1.3f);
    g.drawLine(x - 4.0f, y - 1.0f, x + 4.0f, y + 1.0f, 1.4f);
}

void RuFTraXSF2PlayerAudioProcessorEditor::drawPanel(juce::Graphics& g,
                                                     juce::Rectangle<float> r,
                                                     const juce::String& title)
{
    g.setColour(juce::Colours::black.withAlpha(0.32f));
    g.fillRoundedRectangle(r.translated(2.0f, 3.0f), 5.0f);
    juce::ColourGradient grad(juce::Colour(faceRed).brighter(0.08f), r.getX(), r.getY(),
                              juce::Colour(faceRedDark), r.getRight(), r.getBottom(), false);
    g.setGradientFill(grad);
    g.fillRoundedRectangle(r, 4.0f);
    g.setColour(juce::Colour(creamDark).withAlpha(0.65f));
    g.drawRoundedRectangle(r, 4.0f, 1.0f);
    g.setColour(juce::Colour(cream));
    g.setFont(juce::Font(juce::FontOptions(16.0f, juce::Font::bold)));
    g.drawText(title, r.removeFromTop(26.0f), juce::Justification::centred);
}

void RuFTraXSF2PlayerAudioProcessorEditor::drawDisplay(juce::Graphics& g, juce::Rectangle<float> r)
{
    g.setColour(juce::Colours::black.withAlpha(0.5f));
    g.fillRoundedRectangle(r.translated(2.0f, 3.0f), 6.0f);
    g.setColour(juce::Colour(displayBlack));
    g.fillRoundedRectangle(r, 6.0f);
    g.setColour(juce::Colour(creamDark).withAlpha(0.7f));
    g.drawRoundedRectangle(r, 6.0f, 1.1f);
}

void RuFTraXSF2PlayerAudioProcessorEditor::drawAnalysisSection(
    juce::Graphics& g,
    juce::Rectangle<float> area,
    const juce::String& title,
    const juce::String& primary,
    const juce::String& lineOne,
    const juce::String& lineTwo)
{
    g.setColour(juce::Colours::black.withAlpha(0.45f));
    g.fillRoundedRectangle(area.translated(2.0f, 2.0f), 5.0f);
    g.setColour(juce::Colour(displayBlack));
    g.fillRoundedRectangle(area, 5.0f);
    g.setColour(juce::Colour(creamDark).withAlpha(0.72f));
    g.drawRoundedRectangle(area, 5.0f, 1.0f);

    g.setColour(juce::Colour(cream));
    g.setFont(juce::Font(juce::FontOptions(13.0f, juce::Font::bold)));
    g.drawText(title, area.getX() + 8.0f, area.getY() + 5.0f,
               area.getWidth() - 16.0f, 18.0f, juce::Justification::centred);

    g.setColour(juce::Colour(displayRed));
    g.setFont(juce::Font(juce::FontOptions(27.0f, juce::Font::bold)));
    g.drawFittedText(primary,
                     juce::Rectangle<int>(
                         juce::roundToInt(area.getX() + 8.0f),
                         juce::roundToInt(area.getY() + 25.0f),
                         juce::roundToInt(area.getWidth() - 16.0f),
                         32),
                     juce::Justification::centred,
                     1);

    g.setColour(juce::Colour(cream).withAlpha(0.92f));
    g.setFont(juce::Font(juce::FontOptions(12.0f, juce::Font::bold)));
    g.drawFittedText(lineOne,
                     juce::Rectangle<int>(
                         juce::roundToInt(area.getX() + 8.0f),
                         juce::roundToInt(area.getY() + 59.0f),
                         juce::roundToInt(area.getWidth() - 16.0f),
                         19),
                     juce::Justification::centred,
                     1);

    g.setColour(juce::Colour(cream).withAlpha(0.72f));
    g.setFont(juce::Font(juce::FontOptions(11.0f, juce::Font::bold)));
    g.drawFittedText(lineTwo,
                     juce::Rectangle<int>(
                         juce::roundToInt(area.getX() + 8.0f),
                         juce::roundToInt(area.getY() + 79.0f),
                         juce::roundToInt(area.getWidth() - 16.0f),
                         18),
                     juce::Justification::centred,
                     1);
}

void RuFTraXSF2PlayerAudioProcessorEditor::drawToneMeters(
    juce::Graphics& g,
    juce::Rectangle<float> area) const
{
    auto meterArea = area.removeFromBottom(17.0f).reduced(10.0f, 3.0f);
    meterArea.removeFromRight(118.0f);
    auto tuningArea = meterArea.removeFromLeft(meterArea.getWidth() * 0.66f);
    meterArea.removeFromLeft(8.0f);
    auto levelArea = meterArea;

    g.setColour(juce::Colour(0xff30241a));
    g.fillRoundedRectangle(tuningArea, 2.0f);
    g.setColour(juce::Colour(creamDark).withAlpha(0.55f));
    g.drawRoundedRectangle(tuningArea, 2.0f, 0.8f);

    const float centreX = tuningArea.getCentreX();
    g.setColour(juce::Colour(cream).withAlpha(0.55f));
    g.drawLine(centreX, tuningArea.getY(), centreX, tuningArea.getBottom(), 1.0f);

    const float centsPosition = juce::jmap(
        juce::jlimit(-50.0f, 50.0f, displayedCents),
        -50.0f, 50.0f,
        tuningArea.getX() + 3.0f,
        tuningArea.getRight() - 3.0f);
    g.setColour(std::abs(displayedCents) <= 5.0f
                    ? juce::Colour(0xff5cff5a)
                    : juce::Colour(displayRed));
    g.fillEllipse(centsPosition - 3.0f, tuningArea.getCentreY() - 3.0f, 6.0f, 6.0f);

    g.setColour(juce::Colour(0xff30241a));
    g.fillRoundedRectangle(levelArea, 2.0f);
    g.setColour(juce::Colour(creamDark).withAlpha(0.55f));
    g.drawRoundedRectangle(levelArea, 2.0f, 0.8f);

    const float levelNormalised = juce::jmap(
        juce::jlimit(-60.0f, 0.0f, displayedLevelDb),
        -60.0f, 0.0f, 0.0f, 1.0f);
    auto fill = levelArea.reduced(2.0f);
    fill.setWidth(fill.getWidth() * levelNormalised);
    g.setColour(juce::Colour(0xff5cff5a));
    g.fillRoundedRectangle(fill, 1.5f);
}

void RuFTraXSF2PlayerAudioProcessorEditor::paint(juce::Graphics& g)
{
    constexpr float designWidth = 1180.0f;
    constexpr float designHeight = 820.0f;

    g.fillAll(juce::Colour(0xff120805));

    const float scaleX = static_cast<float>(getWidth()) / designWidth;
    const float scaleY = static_cast<float>(getHeight()) / designHeight;
    juce::Graphics::ScopedSaveState saveState(g);
    g.addTransform(juce::AffineTransform::scale(scaleX, scaleY));

    const auto bounds = juce::Rectangle<float>(0.0f, 0.0f, designWidth, designHeight);

    juce::ColourGradient wood(juce::Colour(woodLight), 0.0f, 0.0f,
                              juce::Colour(woodDark), 48.0f, 0.0f, false);
    g.setGradientFill(wood);
    g.fillRect(0.0f, 0.0f, 42.0f, bounds.getHeight());
    g.fillRect(bounds.getWidth() - 42.0f, 0.0f, 42.0f, bounds.getHeight());
    g.setColour(juce::Colours::black.withAlpha(0.45f));
    for (int y = 8; y < static_cast<int>(designHeight); y += 18)
    {
        g.drawLine(5.0f, static_cast<float>(y), 36.0f, static_cast<float>(y) + 4.0f, 0.8f);
        g.drawLine(bounds.getWidth() - 36.0f, static_cast<float>(y) + 3.0f,
                   bounds.getWidth() - 5.0f, static_cast<float>(y), 0.8f);
    }

    auto face = bounds.reduced(42.0f, 10.0f);
    juce::ColourGradient red(juce::Colour(0xffa51b12), face.getX(), face.getY(),
                             juce::Colour(0xff570906), face.getRight(), face.getBottom(), false);
    g.setGradientFill(red);
    g.fillRoundedRectangle(face, 8.0f);
    g.setColour(juce::Colour(creamDark));
    g.drawRoundedRectangle(face, 8.0f, 1.4f);

    constexpr float x = 58.0f;
    constexpr float w = designWidth - 116.0f;

    drawPanel(g, { x, 112.0f, 320.0f, 142.0f }, "SOUNDFONT");
    drawPanel(g, { x + 330.0f, 112.0f, w - 610.0f, 142.0f }, "CURRENT PRESET");
    drawPanel(g, { designWidth - 320.0f, 112.0f, 262.0f, 142.0f }, "MASTER");

    drawPanel(g, { x, 266.0f, w, 100.0f }, "BANK / PRESET BROWSER");
    drawPanel(g, { x, 378.0f, w, 166.0f }, "LIVE ANALYSIS");
    drawPanel(g, { x, 556.0f, 430.0f, 200.0f }, "FILTER & DRIVE");
    drawPanel(g, { x + 440.0f, 556.0f, w - 440.0f, 200.0f }, "EFFECTS");

    drawDisplay(g, { x + 20.0f, 158.0f, 280.0f, 50.0f });

    const auto led = juce::Rectangle<float>(designWidth - 178.0f, 72.0f, 16.0f, 16.0f);
    g.setColour(midiLedHoldTicks > 0 ? juce::Colour(0xff5cff5a) : juce::Colour(0xff173b18));
    g.fillEllipse(led);
    g.setColour(juce::Colour(creamDark));
    g.drawEllipse(led, 1.1f);
    g.setColour(juce::Colour(cream));
    g.setFont(juce::Font(juce::FontOptions(14.0f, juce::Font::bold)));
    g.drawText("MIDI ACTIVITY", static_cast<int>(designWidth) - 310, 68, 124, 24,
               juce::Justification::centredRight);

    const auto midiPrimary = noteName(displayedMidiNote, true);
    const auto midiLineOne = displayedMidiNote >= 0
        ? "NOTE " + juce::String(displayedMidiNote)
            + "   |   VELOCITY " + juce::String(displayedMidiVelocity)
        : "WAITING FOR MIDI INPUT";
    const auto midiLineTwo = "CHANNEL " + juce::String(displayedMidiChannel)
        + "   |   AFTERTOUCH " + juce::String(displayedAftertouch);

    juce::String tonePrimary = "-";
    juce::String toneLineOne = "LISTENING TO FINAL OUTPUT";
    const int transpose = processor.getTransposeSemitones();
    const auto transposeText = "TRANSPOSE "
        + juce::String(transpose >= 0 ? "+" : "") + juce::String(transpose) + " ST";
    juce::String toneLineTwo = juce::String(displayedLevelDb, 1) + " dB   |   "
        + transposeText;

    if (displayedFrequencyHz > 0.0f && displayedLevelDb > -72.0f)
    {
        const int nearestMidi = juce::jlimit(
            0, 127,
            juce::roundToInt(69.0f + 12.0f * std::log2(displayedFrequencyHz / 440.0f)));
        tonePrimary = noteName(nearestMidi, true);
        toneLineOne = juce::String(displayedFrequencyHz, 2) + " Hz"
            + "   |   " + juce::String(displayedLevelDb, 1) + " dB";
        toneLineTwo = (displayedCents >= 0.0f ? "+" : "")
            + juce::String(displayedCents, 1) + " cents   |   " + transposeText;
    }

    const juce::Rectangle<float> midiArea { 70.0f, 410.0f, 338.0f, 122.0f };
    const juce::Rectangle<float> toneArea { 421.0f, 410.0f, 338.0f, 122.0f };
    const juce::Rectangle<float> chordArea { 772.0f, 410.0f, 338.0f, 122.0f };

    drawAnalysisSection(g, midiArea, "1  |  MIDI NOTE RECEIVED",
                        midiPrimary, midiLineOne, midiLineTwo);
    drawAnalysisSection(g, toneArea, "2  |  TONE OUTPUT ANALYSIS",
                        tonePrimary, toneLineOne, toneLineTwo);
    drawToneMeters(g, toneArea);
    drawAnalysisSection(g, chordArea, "3  |  CHORD OUTPUT ANALYSIS",
                        displayedChord.name,
                        displayedChord.rootAndQuality,
                        displayedChord.inversion + "   |   " + displayedChord.notes);

    g.setColour(juce::Colour(cream).withAlpha(0.75f));
    g.setFont(juce::Font(juce::FontOptions(13.0f, juce::Font::bold)));
    g.drawText("DRAG & DROP AN SF2 OR SFZ FILE HERE TO LOAD", 58, 772,
               static_cast<int>(designWidth) - 116, 28, juce::Justification::centred);

    drawScrew(g, 64.0f, 28.0f);
    drawScrew(g, designWidth - 64.0f, 28.0f);
    drawScrew(g, 64.0f, designHeight - 28.0f);
    drawScrew(g, designWidth - 64.0f, designHeight - 28.0f);
}

void RuFTraXSF2PlayerAudioProcessorEditor::resized()
{
    const auto scaleX = static_cast<float>(getWidth()) / 1180.0f;
    const auto scaleY = static_cast<float>(getHeight()) / 820.0f;
    auto S = [scaleX, scaleY](int x, int y, int w, int h)
    {
        return juce::Rectangle<int>(juce::roundToInt(static_cast<float>(x) * scaleX),
                                    juce::roundToInt(static_cast<float>(y) * scaleY),
                                    juce::roundToInt(static_cast<float>(w) * scaleX),
                                    juce::roundToInt(static_cast<float>(h) * scaleY));
    };

    titleLabel.setBounds(S(98, 24, 330, 62));
    subtitleLabel.setBounds(S(410, 34, 460, 44));
    soundLabel.setBounds(S(78, 166, 280, 34));
    statusLabel.setBounds(S(78, 210, 280, 28));
    presetBox.setBounds(S(408, 166, 414, 40));
    loadButton.setBounds(S(86, 218, 128, 30));
    restoreButton.setBounds(S(222, 218, 136, 30));
    transposeDownButton.setBounds(S(644, 510, 28, 20));
    transposeValueLabel.setBounds(S(675, 510, 45, 20));
    transposeUpButton.setBounds(S(723, 510, 28, 20));

    volumeLabel.setBounds(S(900, 128, 110, 24));
    volumeSlider.setBounds(S(896, 150, 118, 94));
    panLabel.setBounds(S(1020, 128, 110, 24));
    panSlider.setBounds(S(1016, 150, 118, 94));

    cutoffLabel.setBounds(S(82, 582, 110, 24));
    cutoffSlider.setBounds(S(76, 608, 122, 132));
    resonanceLabel.setBounds(S(210, 582, 110, 24));
    resonanceSlider.setBounds(S(204, 608, 122, 132));
    driveLabel.setBounds(S(338, 582, 100, 24));
    driveSlider.setBounds(S(330, 608, 122, 132));

    chorusLabel.setBounds(S(548, 582, 120, 24));
    chorusSlider.setBounds(S(546, 608, 124, 132));
    reverbLabel.setBounds(S(754, 582, 120, 24));
    reverbSlider.setBounds(S(752, 608, 124, 132));
    roomLabel.setBounds(S(960, 582, 120, 24));
    roomSlider.setBounds(S(958, 608, 124, 132));
}
