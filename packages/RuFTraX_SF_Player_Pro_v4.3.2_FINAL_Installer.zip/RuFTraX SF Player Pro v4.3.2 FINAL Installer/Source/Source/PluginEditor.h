#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class RetroLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    RetroLookAndFeel();
    void drawRotarySlider(juce::Graphics&, int, int, int, int, float,
                          float, float, juce::Slider&) override;
    void drawButtonBackground(juce::Graphics&, juce::Button&, const juce::Colour&,
                              bool, bool) override;
    void drawComboBox(juce::Graphics&, int, int, bool, int, int, int, int,
                      juce::ComboBox&) override;
    juce::Font getLabelFont(juce::Label&) override;
};

class RuFTraXSF2PlayerAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                    private juce::Timer,
                                                    public juce::FileDragAndDropTarget
{
public:
    explicit RuFTraXSF2PlayerAudioProcessorEditor(RuFTraXSF2PlayerAudioProcessor&);
    ~RuFTraXSF2PlayerAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    bool isInterestedInFileDrag(const juce::StringArray&) override;
    void filesDropped(const juce::StringArray&, int, int) override;

private:
    struct ChordDisplay
    {
        juce::String name { "-" };
        juce::String rootAndQuality { "NO CHORD" };
        juce::String inversion { "-" };
        juce::String notes { "No notes sounding" };
    };

    void timerCallback() override;
    void configureKnob(juce::Slider&, juce::Label&, const juce::String&);
    void drawPanel(juce::Graphics&, juce::Rectangle<float>, const juce::String&);
    void drawScrew(juce::Graphics&, float, float);
    void drawDisplay(juce::Graphics&, juce::Rectangle<float>);
    void drawAnalysisSection(juce::Graphics&, juce::Rectangle<float>,
                             const juce::String&, const juce::String&,
                             const juce::String&, const juce::String&);
    void drawToneMeters(juce::Graphics&, juce::Rectangle<float>) const;

    static juce::String noteName(int midiNote, bool includeOctave);
    static juce::String soundingNotesText(const juce::Array<int>& notes);
    static ChordDisplay analyseChord(const juce::Array<int>& notes);

    RuFTraXSF2PlayerAudioProcessor& processor;
    RetroLookAndFeel retroLook;

    juce::TextButton loadButton { "LOAD / REPLACE" };
    juce::TextButton restoreButton { "GM DEFAULT" };
    juce::TextButton transposeDownButton { "-" };
    juce::TextButton transposeUpButton { "+" };
    juce::Label titleLabel, subtitleLabel, soundLabel, statusLabel, transposeValueLabel;
    juce::ComboBox presetBox;

    juce::Slider volumeSlider, panSlider, cutoffSlider, resonanceSlider;
    juce::Slider driveSlider, chorusSlider, reverbSlider, roomSlider;
    juce::Label volumeLabel, panLabel, cutoffLabel, resonanceLabel;
    juce::Label driveLabel, chorusLabel, reverbLabel, roomLabel;

    std::unique_ptr<juce::FileChooser> chooser;
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    std::vector<std::unique_ptr<SliderAttachment>> attachments;
    juce::StringArray displayedPresets;
    juce::uint32 lastMidiActivityCounter = 0;
    int midiLedHoldTicks = 0;

    int displayedMidiNote = -1;
    int displayedMidiVelocity = 0;
    int displayedMidiChannel = 1;
    int displayedAftertouch = 0;
    float displayedFrequencyHz = 0.0f;
    float displayedLevelDb = -100.0f;
    float displayedCents = 0.0f;
    ChordDisplay displayedChord;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RuFTraXSF2PlayerAudioProcessorEditor)
};
