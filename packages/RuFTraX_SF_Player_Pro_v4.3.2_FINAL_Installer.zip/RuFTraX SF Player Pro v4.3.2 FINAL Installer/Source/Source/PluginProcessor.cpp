#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <BinaryData.h>

#define TSF_IMPLEMENTATION
#include "tsf.h"
#include <sfizz.h>

namespace { constexpr int midiChannel = 0; }

RuFTraXSF2PlayerAudioProcessor::RuFTraXSF2PlayerAudioProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
    saturator.functionToUse = [](float x) { return std::tanh(x); };
    clearTrackedNotes();
    loadBundledSoundFont();
}

RuFTraXSF2PlayerAudioProcessor::~RuFTraXSF2PlayerAudioProcessor()
{
    const juce::ScopedLock lock(synthLock);
    closeCurrentInstrument();
}

juce::AudioProcessorValueTreeState::ParameterLayout RuFTraXSF2PlayerAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"gain", 1}, "Volume",
        juce::NormalisableRange<float>(-60.0f, 6.0f, 0.1f), -6.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"pan", 1}, "Pan",
        juce::NormalisableRange<float>(-1.0f, 1.0f, 0.01f), 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"cutoff", 1}, "Cutoff",
        juce::NormalisableRange<float>(40.0f, 20000.0f, 1.0f, 0.28f), 20000.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"resonance", 1}, "Resonance",
        juce::NormalisableRange<float>(0.2f, 1.4f, 0.01f), 0.71f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"drive", 1}, "Drive",
        juce::NormalisableRange<float>(0.0f, 18.0f, 0.1f), 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"chorusMix", 1}, "Chorus",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"reverbMix", 1}, "Reverb",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.12f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"reverbSize", 1}, "Room Size",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.45f));
    layout.add(std::make_unique<juce::AudioParameterInt>(juce::ParameterID{"transpose", 1}, "Transpose",
        -24, 24, 0));
    return layout;
}

void RuFTraXSF2PlayerAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    maximumBlockSize = juce::jmax(1, samplesPerBlock);
    interleavedCapacity = juce::jmax(1, samplesPerBlock * 2);
    interleavedBuffer.allocate(static_cast<size_t>(interleavedCapacity), true);
    sfzCapacity = maximumBlockSize;
    sfzLeftBuffer.allocate(static_cast<size_t>(sfzCapacity), true);
    sfzRightBuffer.allocate(static_cast<size_t>(sfzCapacity), true);
    pitchFifoIndex = 0;
    pitchFifo.fill(0.0f);
    pitchFftData.fill(0.0f);
    outputFrequencyHz.store(0.0f, std::memory_order_relaxed);
    outputLevelDb.store(-100.0f, std::memory_order_relaxed);
    outputCents.store(0.0f, std::memory_order_relaxed);

    juce::dsp::ProcessSpec spec{sampleRate, static_cast<juce::uint32>(samplesPerBlock), 2};
    filter.reset();
    filter.prepare(spec);
    filter.setType(juce::dsp::StateVariableTPTFilterType::lowpass);
    chorus.reset();
    chorus.prepare(spec);
    chorus.setRate(0.45f);
    chorus.setDepth(0.22f);
    chorus.setCentreDelay(9.0f);
    chorus.setFeedback(0.08f);
    reverb.reset();

    const juce::ScopedLock lock(synthLock);
    configureSynth(soundFont);
    configureSfz(sfzSynth);
}

void RuFTraXSF2PlayerAudioProcessor::releaseResources() {}

bool RuFTraXSF2PlayerAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void RuFTraXSF2PlayerAudioProcessor::configureSynth(tsf* synth) const
{
    if (synth == nullptr) return;
    tsf_set_output(synth, TSF_STEREO_INTERLEAVED, static_cast<int>(currentSampleRate), 0.0f);
    tsf_channel_set_presetnumber(synth, midiChannel, currentPreset, 0);
}

void RuFTraXSF2PlayerAudioProcessor::configureSfz(sfizz_synth_t* synth) const
{
    if (synth == nullptr)
        return;

    sfizz_set_sample_rate(synth, static_cast<float>(currentSampleRate));
    sfizz_set_samples_per_block(synth, maximumBlockSize);
}

void RuFTraXSF2PlayerAudioProcessor::closeCurrentInstrument()
{
    if (soundFont != nullptr)
        tsf_close(soundFont);
    if (sfzSynth != nullptr)
        sfizz_free(sfzSynth);

    soundFont = nullptr;
    sfzSynth = nullptr;
    engine = InstrumentEngine::none;
}

bool RuFTraXSF2PlayerAudioProcessor::hasLoadedInstrument() const noexcept
{
    return (engine == InstrumentEngine::sf2 && soundFont != nullptr)
        || (engine == InstrumentEngine::sfz && sfzSynth != nullptr);
}

void RuFTraXSF2PlayerAudioProcessor::refreshPresetNames()
{
    presetNames.clear();
    if (engine == InstrumentEngine::sfz && sfzSynth != nullptr)
    {
        presetNames.add(loadedName.isNotEmpty() ? loadedName : "SFZ Instrument");
        currentPreset = 0;
        return;
    }

    if (engine != InstrumentEngine::sf2 || soundFont == nullptr)
        return;
    const int count = tsf_get_presetcount(soundFont);
    for (int i = 0; i < count; ++i)
    {
        const char* name = tsf_get_presetname(soundFont, i);
        presetNames.add(name != nullptr ? juce::String::fromUTF8(name) : "Preset " + juce::String(i + 1));
    }
    if (presetNames.isEmpty()) presetNames.add("Preset 1");
    currentPreset = juce::jlimit(0, presetNames.size() - 1, currentPreset);
}

bool RuFTraXSF2PlayerAudioProcessor::loadBundledSoundFont()
{
    auto* newSynth = tsf_load_memory(BinaryData::Wurly_EP1_sf2, BinaryData::Wurly_EP1_sf2Size);
    if (newSynth == nullptr) { statusText = "Could not load bundled Wurly SoundFont"; return false; }
    currentPreset = 0;
    configureSynth(newSynth);
    loadedName = "+Wurly +E.P. 1";
    {
        const juce::ScopedLock lock(synthLock);
        closeCurrentInstrument();
        soundFont = newSynth;
        engine = InstrumentEngine::sf2;
        refreshPresetNames();
    }
    clearTrackedNotes();
    externalInstrument = juce::File();
    statusText = "Bundled Wurly ready";
    return true;
}

bool RuFTraXSF2PlayerAudioProcessor::loadInstrument(const juce::File& file)
{
    if (!file.existsAsFile())
    {
        statusText = "File not found";
        return false;
    }

    const auto extension = file.getFileExtension().toLowerCase();
    if (extension != ".sf2" && extension != ".sfz")
    {
        statusText = "Choose an SF2 or SFZ instrument";
        return false;
    }

    const auto newName = file.getFileNameWithoutExtension();

    if (extension == ".sf2")
    {
        auto* newSynth = tsf_load_filename(
            file.getFullPathName().toRawUTF8());
        if (newSynth == nullptr)
        {
            statusText = "That file could not be opened as an SF2 bank";
            return false;
        }

        tsf_set_output(newSynth,
                       TSF_STEREO_INTERLEAVED,
                       static_cast<int>(currentSampleRate),
                       0.0f);
        tsf_channel_set_presetnumber(newSynth, midiChannel, 0, 0);
        const juce::ScopedLock lock(synthLock);
        closeCurrentInstrument();
        soundFont = newSynth;
        engine = InstrumentEngine::sf2;
        currentPreset = 0;
        loadedName = newName;
        refreshPresetNames();
    }
    else
    {
        auto* newSynth = sfizz_create_synth();
        if (newSynth == nullptr)
        {
            statusText = "The SFZ engine could not be started";
            return false;
        }

        configureSfz(newSynth);
        if (!sfizz_load_file(newSynth,
                             file.getFullPathName().toRawUTF8()))
        {
            sfizz_free(newSynth);
            statusText = "That SFZ could not be loaded; check its sample paths";
            return false;
        }

        const juce::ScopedLock lock(synthLock);
        closeCurrentInstrument();
        sfzSynth = newSynth;
        engine = InstrumentEngine::sfz;
        currentPreset = 0;
        loadedName = newName;
        refreshPresetNames();
    }

    clearTrackedNotes();
    externalInstrument = file;
    statusText = "Loaded: " + file.getFileName();
    return true;
}

void RuFTraXSF2PlayerAudioProcessor::selectPreset(int index)
{
    const juce::ScopedLock lock(synthLock);
    if (!hasLoadedInstrument() || presetNames.isEmpty())
        return;

    currentPreset = juce::jlimit(0, presetNames.size() - 1, index);
    if (engine == InstrumentEngine::sf2)
    {
        tsf_channel_note_off_all(soundFont, midiChannel);
        tsf_channel_set_presetnumber(soundFont, midiChannel, currentPreset, 0);
    }
    else
    {
        sfizz_send_cc(sfzSynth, 0, 120, 0);
    }
    clearTrackedNotes();
    statusText = "Preset: " + presetNames[currentPreset];
}

int RuFTraXSF2PlayerAudioProcessor::getNumPrograms() { return juce::jmax(1, presetNames.size()); }
int RuFTraXSF2PlayerAudioProcessor::getCurrentProgram() { return currentPreset; }
void RuFTraXSF2PlayerAudioProcessor::setCurrentProgram(int index) { selectPreset(index); }
const juce::String RuFTraXSF2PlayerAudioProcessor::getProgramName(int index)
{
    return juce::isPositiveAndBelow(index, presetNames.size()) ? presetNames[index] : "SoundFont";
}

void RuFTraXSF2PlayerAudioProcessor::clearTrackedNotes()
{
    heldKeys.fill(false);
    soundingNoteForInput.fill(-1);
    sustainPedalDown = false;
    appliedTransposeSemitones = getTransposeSemitones();

    for (auto& velocity : activeNoteVelocities)
        velocity.store(0, std::memory_order_relaxed);
}

int RuFTraXSF2PlayerAudioProcessor::getTransposeSemitones() const noexcept
{
    if (const auto* value = parameters.getRawParameterValue("transpose"))
        return juce::jlimit(-24, 24, juce::roundToInt(value->load()));

    return 0;
}

void RuFTraXSF2PlayerAudioProcessor::setTransposeSemitones(int semitones)
{
    if (auto* parameter = parameters.getParameter("transpose"))
    {
        const float normalised = parameter->convertTo0to1(
            static_cast<float>(juce::jlimit(-24, 24, semitones)));
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost(normalised);
        parameter->endChangeGesture();
    }
}

void RuFTraXSF2PlayerAudioProcessor::applyTransposeChangeIfNeeded()
{
    const int requestedTranspose = getTransposeSemitones();
    if (requestedTranspose == appliedTransposeSemitones)
        return;

    appliedTransposeSemitones = requestedTranspose;
    soundingNoteForInput.fill(-1);

    if (!hasLoadedInstrument())
        return;

    if (engine == InstrumentEngine::sf2)
        tsf_channel_note_off_all(soundFont, midiChannel);
    else
        sfizz_send_cc(sfzSynth, 0, 120, 0);

    for (int inputNote = 0; inputNote < 128; ++inputNote)
    {
        const int velocity = activeNoteVelocities[static_cast<size_t>(inputNote)]
            .load(std::memory_order_relaxed);
        if (velocity <= 0)
            continue;

        const int soundingNote = juce::jlimit(0, 127, inputNote + appliedTransposeSemitones);
        soundingNoteForInput[static_cast<size_t>(inputNote)] = soundingNote;
        if (engine == InstrumentEngine::sf2)
        {
            tsf_channel_note_on(soundFont,
                                midiChannel,
                                soundingNote,
                                static_cast<float>(velocity) / 127.0f);
        }
        else
        {
            sfizz_send_note_on(sfzSynth, 0, soundingNote, velocity);
        }
    }
}

void RuFTraXSF2PlayerAudioProcessor::updateMidiAnalysis(const juce::MidiMessage& message)
{
    if (message.isNoteOn())
    {
        const int note = juce::jlimit(0, 127, message.getNoteNumber());
        const int velocity = juce::jlimit(0, 127, static_cast<int>(message.getVelocity()));

        lastMidiNote.store(note, std::memory_order_relaxed);
        lastMidiVelocity.store(velocity, std::memory_order_relaxed);
        lastMidiChannel.store(message.getChannel(), std::memory_order_relaxed);
        lastAftertouch.store(0, std::memory_order_relaxed);
        heldKeys[static_cast<size_t>(note)] = true;
        activeNoteVelocities[static_cast<size_t>(note)].store(velocity, std::memory_order_relaxed);
    }
    else if (message.isNoteOff())
    {
        const int note = juce::jlimit(0, 127, message.getNoteNumber());
        heldKeys[static_cast<size_t>(note)] = false;

        if (!sustainPedalDown)
            activeNoteVelocities[static_cast<size_t>(note)].store(0, std::memory_order_relaxed);
    }
    else if (message.isController() && message.getControllerNumber() == 64)
    {
        const bool wasDown = sustainPedalDown;
        sustainPedalDown = message.getControllerValue() >= 64;

        if (wasDown && !sustainPedalDown)
            for (int note = 0; note < 128; ++note)
                if (!heldKeys[static_cast<size_t>(note)])
                    activeNoteVelocities[static_cast<size_t>(note)].store(0, std::memory_order_relaxed);
    }
    else if (message.isAftertouch())
    {
        lastAftertouch.store(message.getAfterTouchValue(), std::memory_order_relaxed);
        lastMidiChannel.store(message.getChannel(), std::memory_order_relaxed);
    }
    else if (message.isChannelPressure())
    {
        lastAftertouch.store(message.getChannelPressureValue(), std::memory_order_relaxed);
        lastMidiChannel.store(message.getChannel(), std::memory_order_relaxed);
    }
    else if (message.isAllNotesOff() || message.isAllSoundOff())
    {
        clearTrackedNotes();
    }
}

void RuFTraXSF2PlayerAudioProcessor::handleMidiMessage(const juce::MidiMessage& message)
{
    if (!message.isActiveSense() && !message.isMidiClock())
        midiActivityCounter.fetch_add(1, std::memory_order_relaxed);

    updateMidiAnalysis(message);

    if (!hasLoadedInstrument())
        return;

    if (message.isNoteOn())
    {
        const int inputNote = juce::jlimit(0, 127, message.getNoteNumber());
        const auto mapIndex = static_cast<size_t>(inputNote);
        const int previousSoundingNote = soundingNoteForInput[mapIndex];
        if (previousSoundingNote >= 0)
        {
            if (engine == InstrumentEngine::sf2)
                tsf_channel_note_off(soundFont, midiChannel, previousSoundingNote);
            else
                sfizz_send_note_off(sfzSynth, 0, previousSoundingNote, 0);
        }

        const int soundingNote = juce::jlimit(0, 127, inputNote + appliedTransposeSemitones);
        soundingNoteForInput[mapIndex] = soundingNote;
        if (engine == InstrumentEngine::sf2)
            tsf_channel_note_on(soundFont,
                                midiChannel,
                                soundingNote,
                                message.getFloatVelocity());
        else
            sfizz_send_note_on(sfzSynth,
                               0,
                               soundingNote,
                               juce::jlimit(1, 127,
                                   juce::roundToInt(message.getFloatVelocity() * 127.0f)));
    }
    else if (message.isNoteOff())
    {
        const int inputNote = juce::jlimit(0, 127, message.getNoteNumber());
        const auto mapIndex = static_cast<size_t>(inputNote);
        const int soundingNote = soundingNoteForInput[mapIndex] >= 0
            ? soundingNoteForInput[mapIndex]
            : juce::jlimit(0, 127, inputNote + appliedTransposeSemitones);
        if (engine == InstrumentEngine::sf2)
            tsf_channel_note_off(soundFont, midiChannel, soundingNote);
        else
            sfizz_send_note_off(sfzSynth,
                                0,
                                soundingNote,
                                juce::jlimit(0, 127,
                                    juce::roundToInt(message.getFloatVelocity() * 127.0f)));
        soundingNoteForInput[mapIndex] = -1;
    }
    else if (message.isAllNotesOff() || message.isAllSoundOff())
    {
        if (engine == InstrumentEngine::sf2)
            tsf_channel_note_off_all(soundFont, midiChannel);
        else
            sfizz_send_cc(sfzSynth, 0, 120, 0);
        soundingNoteForInput.fill(-1);
    }
    else if (message.isController())
    {
        if (engine == InstrumentEngine::sf2)
            tsf_channel_midi_control(soundFont,
                                     midiChannel,
                                     message.getControllerNumber(),
                                     message.getControllerValue());
        else
            sfizz_send_cc(sfzSynth,
                          0,
                          message.getControllerNumber(),
                          message.getControllerValue());
    }
    else if (message.isPitchWheel())
    {
        if (engine == InstrumentEngine::sf2)
            tsf_channel_set_pitchwheel(soundFont,
                                       midiChannel,
                                       message.getPitchWheelValue());
        else
            sfizz_send_hd_pitch_wheel(
                sfzSynth,
                0,
                juce::jlimit(-1.0f,
                             1.0f,
                             static_cast<float>(message.getPitchWheelValue() - 8192)
                                 / 8192.0f));
    }
    else if (message.isAftertouch())
    {
        if (engine == InstrumentEngine::sfz)
            sfizz_send_poly_aftertouch(sfzSynth,
                                       0,
                                       message.getNoteNumber(),
                                       message.getAfterTouchValue());
    }
    else if (message.isChannelPressure())
    {
        if (engine == InstrumentEngine::sfz)
            sfizz_send_channel_aftertouch(sfzSynth,
                                          0,
                                          message.getChannelPressureValue());
    }
    else if (message.isProgramChange())
    {
        if (engine == InstrumentEngine::sf2)
            selectPreset(message.getProgramChangeNumber());
        else
            sfizz_send_program_change(sfzSynth,
                                      0,
                                      message.getProgramChangeNumber());
    }
}

void RuFTraXSF2PlayerAudioProcessor::renderRange(juce::AudioBuffer<float>& buffer, int startSample, int numSamples)
{
    if (!hasLoadedInstrument() || numSamples <= 0)
        return;

    if (engine == InstrumentEngine::sf2)
    {
        const int required = numSamples * 2;
        if (required > interleavedCapacity)
        {
            interleavedCapacity = required;
            interleavedBuffer.allocate(static_cast<size_t>(interleavedCapacity), false);
        }
        tsf_render_float(soundFont, interleavedBuffer.get(), numSamples, 0);
        auto* left = buffer.getWritePointer(0, startSample);
        auto* right = buffer.getWritePointer(1, startSample);
        for (int i = 0; i < numSamples; ++i)
        {
            left[i] += interleavedBuffer[i * 2];
            right[i] += interleavedBuffer[i * 2 + 1];
        }
        return;
    }

    auto* left = buffer.getWritePointer(0, startSample);
    auto* right = buffer.getWritePointer(1, startSample);
    int rendered = 0;
    while (rendered < numSamples)
    {
        const auto frames = juce::jmin(maximumBlockSize,
                                       numSamples - rendered);
        float* channels[] { sfzLeftBuffer.get(), sfzRightBuffer.get() };
        sfizz_render_block(sfzSynth, channels, 2, frames);

        for (int i = 0; i < frames; ++i)
        {
            left[rendered + i] += sfzLeftBuffer[i];
            right[rendered + i] += sfzRightBuffer[i];
        }
        rendered += frames;
    }
}

void RuFTraXSF2PlayerAudioProcessor::updateEffects()
{
    filter.setCutoffFrequency(parameters.getRawParameterValue("cutoff")->load());
    filter.setResonance(parameters.getRawParameterValue("resonance")->load());
    chorus.setMix(parameters.getRawParameterValue("chorusMix")->load());
    juce::Reverb::Parameters p;
    p.roomSize = parameters.getRawParameterValue("reverbSize")->load();
    p.damping = 0.45f;
    p.wetLevel = parameters.getRawParameterValue("reverbMix")->load();
    p.dryLevel = 1.0f - 0.35f * p.wetLevel;
    p.width = 1.0f;
    p.freezeMode = 0.0f;
    reverb.setParameters(p);
}

void RuFTraXSF2PlayerAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();
    {
        const juce::ScopedLock lock(synthLock);
        applyTransposeChangeIfNeeded();
        int renderedUntil = 0;
        for (const auto metadata : midi)
        {
            const int eventSample = juce::jlimit(0, buffer.getNumSamples(), metadata.samplePosition);
            renderRange(buffer, renderedUntil, eventSample - renderedUntil);
            handleMidiMessage(metadata.getMessage());
            renderedUntil = eventSample;
        }
        renderRange(buffer, renderedUntil, buffer.getNumSamples() - renderedUntil);
    }

    updateEffects();
    const float driveGain = juce::Decibels::decibelsToGain(parameters.getRawParameterValue("drive")->load());
    buffer.applyGain(driveGain);
    juce::dsp::AudioBlock<float> block(buffer);
    juce::dsp::ProcessContextReplacing<float> context(block);
    saturator.process(context);
    filter.process(context);
    chorus.process(context);
    reverb.processStereo(buffer.getWritePointer(0), buffer.getWritePointer(1), buffer.getNumSamples());

    const float gain = juce::Decibels::decibelsToGain(parameters.getRawParameterValue("gain")->load());
    const float pan = parameters.getRawParameterValue("pan")->load();
    buffer.applyGain(0, 0, buffer.getNumSamples(), gain * (pan <= 0.0f ? 1.0f : 1.0f - pan));
    buffer.applyGain(1, 0, buffer.getNumSamples(), gain * (pan >= 0.0f ? 1.0f : 1.0f + pan));

    updateOutputAnalysis(buffer);
}

juce::Array<int> RuFTraXSF2PlayerAudioProcessor::getActiveNotes() const
{
    juce::Array<int> notes;

    for (int note = 0; note < 128; ++note)
        if (activeNoteVelocities[static_cast<size_t>(note)].load(std::memory_order_relaxed) > 0)
            notes.add(note);

    return notes;
}

void RuFTraXSF2PlayerAudioProcessor::analysePitchFrame()
{
    std::copy(pitchFifo.begin(), pitchFifo.end(), pitchFftData.begin());
    std::fill(pitchFftData.begin() + pitchFftSize, pitchFftData.end(), 0.0f);

    pitchWindow.multiplyWithWindowingTable(pitchFftData.data(), static_cast<size_t>(pitchFftSize));
    pitchFft.performFrequencyOnlyForwardTransform(pitchFftData.data(), true);

    const float sampleRate = static_cast<float>(currentSampleRate);
    const int minimumBin = juce::jmax(1, juce::roundToInt(40.0f * static_cast<float>(pitchFftSize) / sampleRate));
    const int maximumBin = juce::jmin(
        pitchFftSize / 2 - 2,
        juce::roundToInt(5000.0f * static_cast<float>(pitchFftSize) / sampleRate));

    int peakBin = 0;
    float peakMagnitude = 0.0f;

    for (int bin = minimumBin; bin <= maximumBin; ++bin)
    {
        const float magnitude = pitchFftData[static_cast<size_t>(bin)];

        if (magnitude > peakMagnitude
            && magnitude >= pitchFftData[static_cast<size_t>(bin - 1)]
            && magnitude >= pitchFftData[static_cast<size_t>(bin + 1)])
        {
            peakMagnitude = magnitude;
            peakBin = bin;
        }
    }

    if (peakBin <= 0 || peakMagnitude <= 1.0e-5f
        || outputLevelDb.load(std::memory_order_relaxed) < -72.0f)
    {
        outputFrequencyHz.store(0.0f, std::memory_order_relaxed);
        outputCents.store(0.0f, std::memory_order_relaxed);
        return;
    }

    const float left = pitchFftData[static_cast<size_t>(peakBin - 1)];
    const float centre = pitchFftData[static_cast<size_t>(peakBin)];
    const float right = pitchFftData[static_cast<size_t>(peakBin + 1)];
    const float denominator = left - 2.0f * centre + right;
    const float interpolation = std::abs(denominator) > 1.0e-12f
        ? 0.5f * (left - right) / denominator
        : 0.0f;
    const float refinedBin = static_cast<float>(peakBin) + juce::jlimit(-0.5f, 0.5f, interpolation);
    const float frequency = refinedBin * sampleRate / static_cast<float>(pitchFftSize);

    if (!std::isfinite(frequency) || frequency < 20.0f)
    {
        outputFrequencyHz.store(0.0f, std::memory_order_relaxed);
        outputCents.store(0.0f, std::memory_order_relaxed);
        return;
    }

    const float midiNote = 69.0f + 12.0f * std::log2(frequency / 440.0f);
    const float nearestNote = std::round(midiNote);

    outputFrequencyHz.store(frequency, std::memory_order_relaxed);
    outputCents.store((midiNote - nearestNote) * 100.0f, std::memory_order_relaxed);
}

void RuFTraXSF2PlayerAudioProcessor::updateOutputAnalysis(const juce::AudioBuffer<float>& buffer)
{
    if (buffer.getNumSamples() <= 0 || buffer.getNumChannels() <= 0)
        return;

    float rmsSquared = 0.0f;

    for (int channel = 0; channel < buffer.getNumChannels(); ++channel)
    {
        const float rms = buffer.getRMSLevel(channel, 0, buffer.getNumSamples());
        rmsSquared += rms * rms;
    }

    const float combinedRms = std::sqrt(rmsSquared / static_cast<float>(buffer.getNumChannels()));
    outputLevelDb.store(juce::Decibels::gainToDecibels(combinedRms, -100.0f),
                        std::memory_order_relaxed);

    const auto* left = buffer.getReadPointer(0);
    const auto* right = buffer.getNumChannels() > 1 ? buffer.getReadPointer(1) : left;

    for (int sample = 0; sample < buffer.getNumSamples(); ++sample)
    {
        pitchFifo[static_cast<size_t>(pitchFifoIndex++)] = 0.5f * (left[sample] + right[sample]);

        if (pitchFifoIndex == pitchFftSize)
        {
            analysePitchFrame();
            pitchFifoIndex = 0;
        }
    }
}

void RuFTraXSF2PlayerAudioProcessor::getStateInformation(juce::MemoryBlock& destination)
{
    auto state = parameters.copyState();
    state.setProperty("instrumentPath", externalInstrument.getFullPathName(), nullptr);
    state.setProperty("instrumentFormat",
                      engine == InstrumentEngine::sfz ? "sfz" : "sf2",
                      nullptr);
    state.setProperty("sf2Path",
                      engine == InstrumentEngine::sf2
                          ? externalInstrument.getFullPathName()
                          : juce::String(),
                      nullptr);
    state.setProperty("preset", currentPreset, nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destination);
}

void RuFTraXSF2PlayerAudioProcessor::setStateInformation(const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, size));
    if (xml == nullptr) return;
    auto state = juce::ValueTree::fromXml(*xml);
    if (!state.isValid()) return;
    parameters.replaceState(state);
    auto savedPath = state.getProperty("instrumentPath").toString();
    if (savedPath.isEmpty())
        savedPath = state.getProperty("sf2Path").toString();

    const juce::File savedFile(savedPath);
    if (savedFile.existsAsFile())
        loadInstrument(savedFile);
    else
        loadBundledSoundFont();
    selectPreset(static_cast<int>(state.getProperty("preset", 0)));
}

juce::String RuFTraXSF2PlayerAudioProcessor::getLoadedSoundFontName() const { return loadedName; }
juce::String RuFTraXSF2PlayerAudioProcessor::getStatus() const { return statusText; }
juce::StringArray RuFTraXSF2PlayerAudioProcessor::getPresetNames() const { const juce::ScopedLock lock(synthLock); return presetNames; }

juce::AudioProcessorEditor* RuFTraXSF2PlayerAudioProcessor::createEditor() { return new RuFTraXSF2PlayerAudioProcessorEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new RuFTraXSF2PlayerAudioProcessor(); }
