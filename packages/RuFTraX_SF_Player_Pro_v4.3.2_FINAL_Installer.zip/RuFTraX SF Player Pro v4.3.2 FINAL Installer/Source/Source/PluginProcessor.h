#pragma once
#include <JuceHeader.h>
#include <array>
#include <atomic>

struct tsf;
struct sfizz_synth_t;

class RuFTraXSF2PlayerAudioProcessor final : public juce::AudioProcessor
{
public:
    RuFTraXSF2PlayerAudioProcessor();
    ~RuFTraXSF2PlayerAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 5.0; }

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    bool loadInstrument(const juce::File& file);
    bool loadSoundFont(const juce::File& file) { return loadInstrument(file); }
    bool loadBundledSoundFont();
    juce::String getLoadedSoundFontName() const;
    juce::String getStatus() const;
    juce::StringArray getPresetNames() const;
    void selectPreset(int index);
    juce::uint32 getMidiActivityCounter() const noexcept { return midiActivityCounter.load(); }

    int getLastMidiNote() const noexcept { return lastMidiNote.load(std::memory_order_relaxed); }
    int getLastMidiVelocity() const noexcept { return lastMidiVelocity.load(std::memory_order_relaxed); }
    int getLastMidiChannel() const noexcept { return lastMidiChannel.load(std::memory_order_relaxed); }
    int getLastAftertouch() const noexcept { return lastAftertouch.load(std::memory_order_relaxed); }
    float getOutputFrequencyHz() const noexcept { return outputFrequencyHz.load(std::memory_order_relaxed); }
    float getOutputLevelDb() const noexcept { return outputLevelDb.load(std::memory_order_relaxed); }
    float getOutputCents() const noexcept { return outputCents.load(std::memory_order_relaxed); }
    int getTransposeSemitones() const noexcept;
    void setTransposeSemitones(int semitones);
    juce::Array<int> getActiveNotes() const;

    juce::AudioProcessorValueTreeState parameters;

private:
    enum class InstrumentEngine
    {
        none,
        sf2,
        sfz
    };

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void configureSynth(tsf* synth) const;
    void configureSfz(sfizz_synth_t* synth) const;
    void closeCurrentInstrument();
    bool hasLoadedInstrument() const noexcept;
    void refreshPresetNames();
    void renderRange(juce::AudioBuffer<float>& buffer, int startSample, int numSamples);
    void handleMidiMessage(const juce::MidiMessage& message);
    void updateMidiAnalysis(const juce::MidiMessage& message);
    void updateOutputAnalysis(const juce::AudioBuffer<float>& buffer);
    void analysePitchFrame();
    void clearTrackedNotes();
    void applyTransposeChangeIfNeeded();
    void updateEffects();

    mutable juce::CriticalSection synthLock;
    tsf* soundFont = nullptr;
    sfizz_synth_t* sfzSynth = nullptr;
    InstrumentEngine engine = InstrumentEngine::none;
    double currentSampleRate = 44100.0;
    int maximumBlockSize = 512;
    int currentPreset = 0;
    juce::StringArray presetNames;
    juce::String loadedName { "No SF2 or SFZ loaded" };
    juce::String statusText { "Starting..." };
    juce::File externalInstrument;
    juce::HeapBlock<float> interleavedBuffer;
    int interleavedCapacity = 0;
    juce::HeapBlock<float> sfzLeftBuffer;
    juce::HeapBlock<float> sfzRightBuffer;
    int sfzCapacity = 0;
    std::atomic<juce::uint32> midiActivityCounter { 0 };

    std::atomic<int> lastMidiNote { -1 };
    std::atomic<int> lastMidiVelocity { 0 };
    std::atomic<int> lastMidiChannel { 1 };
    std::atomic<int> lastAftertouch { 0 };
    std::array<std::atomic<int>, 128> activeNoteVelocities {};
    std::array<bool, 128> heldKeys {};
    std::array<int, 128> soundingNoteForInput {};
    bool sustainPedalDown = false;
    int appliedTransposeSemitones = 0;

    static constexpr int pitchFftOrder = 12;
    static constexpr int pitchFftSize = 1 << pitchFftOrder;
    juce::dsp::FFT pitchFft { pitchFftOrder };
    juce::dsp::WindowingFunction<float> pitchWindow
    {
        static_cast<size_t>(pitchFftSize),
        juce::dsp::WindowingFunction<float>::hann,
        true
    };
    std::array<float, pitchFftSize> pitchFifo {};
    std::array<float, pitchFftSize * 2> pitchFftData {};
    int pitchFifoIndex = 0;
    std::atomic<float> outputFrequencyHz { 0.0f };
    std::atomic<float> outputLevelDb { -100.0f };
    std::atomic<float> outputCents { 0.0f };

    juce::dsp::StateVariableTPTFilter<float> filter;
    juce::dsp::Chorus<float> chorus;
    juce::Reverb reverb;
    juce::dsp::WaveShaper<float> saturator;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RuFTraXSF2PlayerAudioProcessor)
};
