#!/bin/bash
set -euo pipefail

if [[ -z "${JUCE_DIR:-}" ]]; then
  echo 'Set JUCE_DIR first, for example:'
  echo '  export JUCE_DIR=~/Downloads/JUCE'
  exit 1
fi

rm -rf build
cmake -S . -B build -G Xcode -DJUCE_DIR="$JUCE_DIR"
cmake --build build --config Release --parallel --target RuFTraXSF2Player_AU RuFTraXSF2Player_Standalone 2>&1 | tee build.log

echo
echo 'Build complete.'
echo 'Standalone:'
echo '  build/RuFTraXSF2Player_artefacts/Release/Standalone/RuFTraX SF Player Pro.app'
echo 'Audio Unit:'
echo '  build/RuFTraXSF2Player_artefacts/Release/AU/RuFTraX SF Player Pro.component'
